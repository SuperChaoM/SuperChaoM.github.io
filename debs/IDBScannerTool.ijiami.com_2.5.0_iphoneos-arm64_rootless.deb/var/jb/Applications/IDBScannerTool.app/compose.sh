work_path=$(dirname $0)
cd ${work_path}  # 当前位置跳到脚本位置
rm -rf Package/Applications/*
