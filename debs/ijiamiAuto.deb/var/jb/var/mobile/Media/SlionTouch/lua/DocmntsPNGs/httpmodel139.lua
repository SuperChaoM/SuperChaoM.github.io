
function registrationequipment_json()-- 功能:注册设备
	stomLog("registrationequipment_json")
	header_send_table = {}
	--header_send_table["Content-Type"] = "application/x-www-form-urlencoded"
	post = {}
	post['serial'] = devicesinfo['serial']
	post['udid'] = devicesinfo['udid']
	post['osversion'] = devicesinfo['osversion']
	post['model'] =  devicesinfo['model']
	post['name'] =  devicesinfo['name']
	Device_Source = string.sub(post['name'], 1, 1)
	post['source'] = Device_Source
	local url = SLionLUA["ipaddress"].."stom/cpa/register?"..encodeQuery(post)
	local httpstatus, headers_resp, body_resp = stomhttpGet(url,10,header_send_table)
	--local httpstatus, headers_resp, body_resp = stomhttpsGet("https://httpbin.org/post",10,header_send_table, body_send_json)
	stomLog(url..'-----注册设备-----')
	if httpstatus == 200 then 
		stomLog(body_resp)
		local restb = json.decode(body_resp)
		local returnCode = restb["returnCode"]
		if returnCode ~= nil then
			if returnCode == 0 then
				accesstoken, userid = restb["token"], restb["uuid"]
				if userid == 1 then
					os.exit()
				else
				stomtoast("注册设备成功"..userid,1); 
				return 0
				end
			else
				stomLog('-----注册设备异常')
				stomtoast(returnCode..":注册设备异常",3); 
			end
		else
			stomLog("注册设备异常returnCode==nil")
			stomtoast("注册设备异常returnCode==nil",3);
		end
	else
		stomLog(httpstatus..'-----注册设备失败')
		stomtoast(httpstatus..":注册设备失败",3);
		--main()
	end

	return 1
end

function Acquisitiontask_json()--获取任务
	stomLog("Acquisitiontask_json");
	loopcount=0
	headers = {}
	post = {}
	post['userid'] = userid
	--post_send = json.encode(post)
	local url = SLionLUA["ipaddress"].."stom/cpa/task?"..encodeQuery(post)
	local httpstatus, headers_resp, body_resp = stomhttpGet(url,10,header_send_table)
	stomLog('获取任务----'..url);
	if httpstatus == 200 then
		stomLog(body_resp)
		local data = json.decode(body_resp); 
		local returnCode = data["returnCode"]
		if returnCode ~= nil then
			if returnCode == 0 then
				rinfo={}
				createpasswd=""
				Telnum=""
				tasktype = data["tasktype"]
				stomLog("tasktype:"..tasktype)
				if tasktype == 0 or tasktype == 1 then
					if tasktype == 1 then
						stomtoast(tasktype..":留存任务",1);
						g_now_idfa = data['idfa']
						runid = data["runid"]
						taskid = data["taskid"]
						filename = g_now_idfa..".zip"
						apple_appid = data["appleid"]
						apple_bid = data["bid"]
						appbid = apple_bid
						loopnum = 30
						taskname = "留存-注册"
						stomLogPUT("留存任务id="..taskid,0)
						return 0
					else
						stomtoast(tasktype..":CPSA任务",1);
						runid = data["runid"]
						isdau = tonumber(data["isdau"])
						stomLog("isdau--"..isdau)
						taskname = data["taskname"]
						taskid, apple_appid = data["taskid"],data["appleid"]
						apple_bid = data["bid"]
						appbid = apple_bid
						loopnum = 30
						durl = data["downloadurl"]
						callbackURLdata = "runid="..runid
						stomLogPUT("新增任务id="..taskid,0)
						return 0
					end
				else
					stomLog('-----获任务类型错误')
					stomtoast(tasktype..":任务类型错误",3);
				end
			elseif returnCode == 4 then
				stomLog("等待任务")
				stomtoast(returnCode..":等待任务"..userid,5);
				stomLogPUT(returnCode..":等待任务"..userid,1)
				return 2
			else
				stomLog('-----返回获取任务异常')
				stomtoast(":返回获取任务异常",3);
				--main()
			end
		else
			stomLog("获取任务异常returnCode==nil")
			stomtoast("获取任务异常returnCode==nil",3);
			--main()
		end
	else
		stomLog('-----httpstatus获取任务失败')
		stomtoast(":httpstatus获取任务失败",3); 
	end
	stomLogPUT("获取任务异常",1)
	return 2
end
function check_idfa()
	stomLog("check_idfa")
	return do_report(0)
end

function click_notice()
	stomLog("click_notice")
	-- return do_report(1)
	return true
end

function report_notice()
	stomLog("report_notice")
	if report_count == 0 then
		return do_report(2)
	end
end

function do_report(api)
	stomLog("do_report--"..api)
	headers = {}
	post = {}
	post['userid'] = userid
	post['runid'] = runid
	post['taskid'] = taskid
	post['idfa'] = g_now_idfa
	post['type'] = tasktype		--上报任务,type定义: 0 激活完成  1 留存完成，2 

	if tasktype == 0 then 
		rinfo['os'] = slionAppNew_info["OS"]
		rinfo['device'] = slionAppNew_info["model"]
	end
	rinfo['name'] = devicesinfo['name']
	rinfo['ip'] = g_now_ip
	rinfo['level'] = tonumber(slion_game_level) or 0 
	post['rinfo'] = rinfo
	local url = SLionLUA["ipaddress"].."stom/cpa/run?"..encodeQuery(post)
	stomLog(url)
	local httpstatus, headers_resp, body_resp = stomhttpGet(url,10,header_send_table)
	if httpstatus == 200 then
		local data = json.decode(body_resp); 
		local returnCode = data["returnCode"]
		if returnCode ~= nil then
			stomLog("Code:"..returnCode)
			if returnCode == 1 then
				return false
			elseif returnCode == 10 then
				stomtoast("等待任务",1)
				stomLog("等待任务")
				--lua_restart()
			elseif returnCode == 0 then
				stomLog("CheckOk")
				return true	
			end
		else
			stomLog("Code错误")
		end
	else
		stomLog("httpstatus:错误")
		stomLog(httpstatus)
	end
	return false
end

function errorreporting_json_old(errortype)--ID异常
	local header_send = {}
	local post = {}
	post['token'] = accesstoken
	post['userid'] = userid
	post['itunesid'] = itunesid
	post['taskid'] = taskid
	post['flag'] = errortype
	post_send = json.encode(post)
	post_escaped = http.build_request(post_send)
	local httpstatus,headers_resp, body_resp = http.post(ipaddress.."stom/cpa/itunesid?",30, header_send, post_escaped)
	stomLog(post_send..'账号异常上报'..body_resp);
	if httpstatus == 200 then
		local data = json.decode(body_resp); 
		local returnCode = data["returnCode"]
		if returnCode == 0 then
			itunesid, itunespw = data['TItunesAccount'], data["itunespwd"]
			CancelaccountOK()
			runApp('com.apple.AppStore');
		elseif returnCode == 1 then
			next_process = 1
			stomtoast("等待任务",3);
			mSleep(math.random(666,1000));
		else
			stomtoast(body_resp..":异常账号上报出错",3);
			mSleep(math.random(666,1000));
		end
	else
		stomtoast(httpstatus..":异常账号上报出错",3); 
		mSleep(math.random(666,1000));

	end

end
function errorreporting_json(errortype)--ID异常
	Devudid2 = "stop"..errortype
	CancelaccountOK()
	upAskdata(2)
end
function Askcomment()--获取评论
	local t1 = os.time()
	while (true) do
		local cjson = sz.json
		local http = sz.i82.http
		headers = {}
		post = {}
		post['token'] = "testtoken"
		post['userid'] = "8507"	--Askcommentuserid	--8070100-10.1.1
		post['appleid'] = apple_appid
		post_send = cjson.encode(post)
		post_escaped = http.build_request(post_send)
		local httpstatus,headers_resp,body_resp = http.post("http://121.42.27.96:1111/stom/1.0/comment/task?",10,headers,post_escaped)
		stomLog(post_send..'获取评论----');
		if httpstatus == 200 then
			stomLog(body_resp)
			local dataall = cjson.decode(body_resp); 
			if dataall['returnCode'] == 0 then
				commentTitle, commentContent = dataall['title']:atrim(), dataall["message"]:atrim()
				commentrandomname = dataall['randomname']
				commentid = dataall['commentid']
				tasktype = 0
--				stomLog(commentTitle)
--				stomLog(commentContent)
				return 0
			elseif dataall['returnCode'] == 4 then
				stomtoast(returnCode..":等待任务",10);
				mSleep(60*1000);
				return 4
			else
				stomLog(post_send.." ----- "..body_resp..'-----获取评论异常')
				stomtoast(body_resp..":获取评论异常",5);
				mSleep(60*1000);
			end
		else
			stomLog(post_send.." ----- "..httpstatus..'-----获取评论异常失败')
			mystomtoast(httpstatus..":获取评论异常失败",5); 
			mSleep(10*1000);
		end
		mSleep(10*1000);
		local t2 = os.time()
		if os.difftime(t2,t1) > 120 then
			stomLog("获取评论异常，重启")
			lua_restart()
		end
		
	end
end
function AskQQdata()
	stomLog("Askjob...")
	local sz = require("sz")
	local cjson = sz.json
	local http = sz.i82.http
	local getjoburl = "http://47.95.13.16/Api/account/getTask.php?IDFA="..idfa
	if AskQQdataType then
		getjoburl = "http://47.95.13.16/Api/account/getTask.php?IDFA="..idfa.."&AskQQdataType="..AskQQdataType
	end
	local body_resp = ""
	for i =1 , 20 do
		status_resp, headers_resp, body_resp = http.get(getjoburl, 5)
		mSleep(500)
		if status_resp == 200 then
			local account = http.header(body_resp,"account") 
			stomLog("account--"..body_resp)
			if account ~= nil then
				local body = cjson.decode(body_resp)
				accounttable = body["account"]
				return 0
			else
				stomLog("Askjob body nil")
				mSleep(3000)
				local msg = http.header(body_resp,"msg")
			end
		elseif status_resp == 500 then
			stomtoast("Ask false"..body_resp,5)
		end
		stomtoast("Ask false"..body_resp,5)
		stomLog("Ask false"..body_resp)
		mSleep(6000)
	end
end
function upAskQQdata(qqflag)
	stomLog("upAskQQdata...")
	local sz = require("sz")
	local cjson = sz.json
	local http = sz.i82.http
	local getjoburl = "http://47.95.13.16/Api/account/postTaskResult.php?recordID="..recordID.."&IMEI="..qqflag.."&deviceName="..DeviceName
	local body_resp = ""
	for i =1 , 20 do
		status_resp, headers_resp, body_resp = http.get(getjoburl, 5)
		mSleep(500)
		if status_resp == 200 or status_resp == 502 then
			return 0
		end
		stomtoast("upAskdata false"..body_resp,5)
		stomLog("upAskdata false"..body_resp)
		mSleep(6000)
	end
end
function Askdata()
	stomLog("Askjob...")
	local sz = require("sz")
	local cjson = sz.json
	local http = sz.i82.http
	local serial = sz.system.serialnumber()
	local getjoburl = "http://47.95.13.16/Api/account/getMyAppleID.php?IDFA="..serial.."&CY="..CY.."&deviceName="..DeviceName
	local body_resp = ""
	for i =1 , 20 do
		status_resp, headers_resp, body_resp = http.get(getjoburl, 5)
		mSleep(500)
		if status_resp == 200 then
			local account = http.header(body_resp,"account") 
			stomLog("account--"..body_resp)
			if account ~= nil then
				local body = cjson.decode(body_resp)
				accounttable = body["account"]
				local str = accounttable["content"]
				local tb = strSplit(str,"----")
				itunesid = tb[1]
				itunespw = tb[2]
				recordID = accounttable["recordID"]
				return 0
			else
				stomLog("Askjob body nil")
				mSleep(3000)
				local msg = http.header(body_resp,"msg")
			end
		elseif status_resp == 500 then
			stomtoast("Ask false"..body_resp,5)
		end
		stomtoast("Ask false"..body_resp,5)
		stomLog("Ask false"..body_resp)
		mSleep(3000)
	end
end
function upAskdata(status)
	stomLog("upAskdata...")
	local sz = require("sz")
	local cjson = sz.json
	local http = sz.i82.http
	local getjoburl = "http://47.95.13.16/Api/account/postMyTaskResult.php?recordID="..recordID.."&IMEI="..Devudid.."&deviceName="..DeviceName.."&CY="..CY.."&status="..status
	local body_resp = ""
	for i =1 , 20 do
		status_resp, headers_resp, body_resp = http.get(getjoburl, 5)
		mSleep(500)
		if status_resp == 200 or status_resp == 502 then
			Askdata()
			return 0
		end
		stomtoast("upAskdata false"..body_resp,5)
		stomLog("upAskdata false"..body_resp)
		mSleep(3000)
	end
end

function upContentData(apitype,content,field1,field2,field3)
	stomLog("upContentData...")
	local sz = require("sz")
	local json = sz.json
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	post={}
	local field1 = field1 or ""
	local field2 = field2 or ""
	local field3 = field3 or ""
	local getjoburl = "http://59.110.162.157/Api/common/add.php?type="..apitype.."&content="..content.."&field1="..field1.."&field2="..field2.."&field3="..field3
	local body_resp = ""
	--while (true) do
	local status_resp, headers_resp, body_resp = ts.httpGet(getjoburl, header_send, post)
	stomLog(body_resp)
	mSleep(200)
	if status_resp == 200 then
		return 0
	end
	stomtoast("upContentData false"..body_resp,5)
	--stomLog("upContentData false"..body_resp)
	--mSleep(6000)
	--end
end
function AskEmailCode(emailName, emailPasswd)
	stomLog("AskEmailCode...")
	local sz = require("sz")
	local cjson = sz.json
	local http = sz.i82.http
	local getjoburl = "http://47.254.135.246/api/rec.php?emailName="..emailName.."&emailPasswd="..emailPasswd
	local body_resp = ""
	emailCode = "nil"
	--for i =1 , 20 do
		status_resp, headers_resp, body_resp = http.get(getjoburl, 15)
		if status_resp == 200 then
			stomLog("account--"..body_resp)
			if string.find(body_resp,"code") then
				local tb = cjson.decode(body_resp) 
				local retunCode = tb.code
				local msg = tb.msg
				if retunCode == 200 then
					emailCode = msg
					return 0
				elseif retunCode == 201 then
					emailCode = "未收到"
					return 1
				else
					emailCode = msg
					return 2
				end
			else
				emailCode = body_resp
				return 2
			end
		end
--		stomtoast("Ask false"..body_resp,5)
--		stomLog("Ask false"..body_resp)
--		mSleep(6000)
		return 3
	--end
end
function filedownload(url,path) --功能:文件下载    参数1: 链接 ,参数2:路径
	stomLog("filedownload...")
	local header_send = {}
	header_send["Cache-Control"] = "no-cache"
	--header_send["Range"]= "bytes = 1-200"
	post={}
	local field1 = field1 or ""
	local field2 = field2 or ""
	local field3 = field3 or ""
	local body_resp = ""
	local status, headers, body = http.get(url, 30)
	if status == 200 then
		stomLog(headers)
		stomLog("filedownload...OK")
		file = io.open(path, "wb")
		if file then
			file:write(body)
			file:close()
			return status;
		else
			return -1;
		end
	else
		stomLog("filedownload...False")
		return status;
	end
end
function curlDownFile(url,filename,filepath)
	stomLog("downIpaInstall....")
	pathdownload = "/tmp"
	os.execute("rm -rf /tmp/*.deb")
	os.execute("rm -rf /tmp/*.ipa")
	os.execute("rm -rf /tmp/*.zip")
	--os.execute("rm -rf /tmp/*.tar")
	os.execute("rm -rf /tmp/*.bak")
	--local url = "https://www.ojbknet.com/ipa/"..filename
	local fullfilename = filepath..filename
	local cmd = "curl -o "..fullfilename.." -k -s -w %{http_code} "..url
	local current_text = os.date("%H:%M:%S", os.time())
	stomtoast("下载中",5)
	--fwShowWnd("wid", 0, 5, 240, 40,0)
	--fwShowTextView("wid","textid",current_text.." 下载中","left","000000","4cd964",15,0, 5, 0, 240, 40, 0.7)
	local http_code = "0"
	http_code = GetSystem(cmd)
	if http_code == "200" then
		local current_text = os.date("%H:%M:%S", os.time())
		stomtoast("下载成功",5)
		--fwShowTextView("wid","textid",current_text.." 下载成功","left","000000","4cd964",15,0, 5, 0, 240, 40, 0.7)
		return 0
--	else
--		--fwShowTextView("wid","textid",current_text.." 下载失败","left","000000","4cd964",15,0, 5, 0, 280, 40, 0.7)
--		stomtoast("下载失败",5)
--		stomLog(cmd)
--		mSleep(2000)
--		return 1
	end
	--fwCloseWnd("wid")
	--[[
	os.execute("rm -rf /tmp/*.deb")
	os.execute("rm -rf /tmp/*.ipa")
	os.execute("rm -rf /tmp/*.zip")
	os.execute("rm -rf /tmp/*.tar")
	os.execute("rm -rf /tmp/*.bak")
	
	local install_code = 0
	if http_code == "200" then
		local current_text = os.date("%H:%M:%S", os.time())
		fwShowTextView("wid","textid",current_text.." 安装中","left","000000","4cd964",15,0, 5, 0, 240, 40, 0.7)
		install_code = ipaInstall(filename)
	else
		fwShowTextView("wid","textid",current_text.." 下载失败","left","000000","4cd964",15,0, 5, 0, 280, 40, 0.7)
		mSleep(2000)
	end
	os.execute("rm -rf /tmp/*.deb")
	os.execute("rm -rf /tmp/*.ipa")
	os.execute("rm -rf /tmp/*.zip")
	os.execute("rm -rf /tmp/*.tar")
	os.execute("rm -rf /tmp/*.bak")
	fwCloseWnd("wid")
	if install_code == 1 then
		stomtoast("安装成功",2)
		stomLog("安装成功")
		return 0
	end
	stomtoast("安装失败"..http_code,2)
	stomLog("安装失败"..http_code)
	return 1
	]]
end
function curlDownFile2(path,filename)
	stomLog("curlDownFile2....")
	pathdownload = "/tmp"
	os.execute("rm -rf /tmp/*.deb")
	os.execute("rm -rf /tmp/*.ipa")
	os.execute("rm -rf /tmp/*.zip")
	--os.execute("rm -rf /tmp/*.tar")
	os.execute("rm -rf /tmp/*.bak")
	local url = "http://www.ojbknet.com"..path..filename
	local filename = userPath().."/tmp/"..filename
	local cmd = "curl -o "..filename.." -k -s -w %{http_code} "..url
	stomLog(cmd)
	local current_text = os.date("%H:%M:%S", os.time())
	fwShowWnd("wid", 0, 5, 240, 40,0)
	fwShowTextView("wid","textid",current_text.." 下载中","left","000000","4cd964",15,0, 5, 0, 240, 40, 0.7)
	local http_code = "0"
	http_code = GetSystem(cmd)
	if http_code == "200" then
		local current_text = os.date("%H:%M:%S", os.time())
		fwShowTextView("wid","textid",current_text.." 下载成功","left","000000","4cd964",15,0, 5, 0, 240, 40, 0.7)
	else
		fwShowTextView("wid","textid",current_text.." 下载失败","left","000000","4cd964",15,0, 5, 0, 280, 40, 0.7)
		mSleep(2000)
		return 1
	end
	fwCloseWnd("wid")
	saveVideoToAlbum(filename);
	os.execute("rm -rf /tmp/*.deb")
	os.execute("rm -rf /tmp/*.ipa")
	os.execute("rm -rf /tmp/*.zip")
	--os.execute("rm -rf /tmp/*.tar")
	os.execute("rm -rf /tmp/*.bak")
	return 0
end
function check_ip()-- 功能:ip排重
	local json = sz.json
	local http = sz.i82.http
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	post = {}
	post['appleid'] = apple_appid
	post['ip'] = g_now_ip
	post_send = json.encode(post)
	post_escaped = http.build_request(post_send)
	local httpstatus, headers_resp, body_resp = http.post(ipaddress.."stom/1.0/checkip?", 10, header_send, post_escaped)
	stomLog('-----检查ip-----'..body_resp)
	if httpstatus == 200 then 
		stomLog(body_resp)
		returnCode = http.header(body_resp,"returnCode")
		if returnCode == 0 then
			local data = json.decode(body_resp); 
			local flag = data['flag']
			if flag == 0 then
				return true
			end
		else
			return false
		end
	else
		return false
	end

	return false
end

function geturl222(url)
	local sz = require("sz")
	local json = sz.json
	local http = sz.i82.http
	local tb ={["ver"]="09112110",
		["DamaType"]="1",
		["id"]="uiqwfy@iCloud.com",
		["pw"]="Dd112211",
		["erase"] = "0",
		["VPN_variables"] = "0",
		["top1con"] = "0",
		["commentcon"] = "0",
		["source"] = "9999"
	}
	local status_resp, headers_resp, body_resp = http.get(url, 5)
	stomLog(body_resp)
	if status_resp == 200 then
		body = json.decode(body_resp)
		if body ~= nil then
			return body
		else
			return tb
		end
	else
		return tb
	end
end

function checkver1()
	stomLog("checkver...")
	local verr = geturl222("http://47.95.13.16/ver/cpa.json")
	vernew = tonumber(verr.ver)
	vernow = tonumber(buildver)
	DamaType = tonumber(verr.DamaType)
	if vernew > vernow then
		stomLog("更新脚本")
		mSleep(1000)
		lua_exit()
	end
end
function checkver()
	local sz = require("sz")
	local cjson = sz.json
	local http = sz.i82.http
	local getjoburl = "http://47.95.13.16/ver/cpa.json"
	local body_resp = ""
	while (true) do
		status_resp, headers_resp, body_resp = http.get(getjoburl, 30)
		if status_resp == 200 then
			local vertb = cjson.decode(body_resp)
			vernew = tonumber(vertb.ver)
			vernow = tonumber(buildver)
			DamaType = tonumber(vertb.DamaType)
			uninstalltb = vertb.unistall
			if vernew > vernow then
				stomLog("更新脚本")
				stomtoast("更新脚本",5)
				mSleep(5000)
				lua_exit()
			else
				UninstallVerApps()
				return 0
			end
		end
	end
end
function getPhoneRules()
	stomLog("getPhoneRules...")
	local result=httpGet("http://ekcomvpn.3322.org:8888/ver/getPhoneRules.txt")
	if result==false or result==nil or result=="" then
		error_60ma="连接getPhoneRules失败"
		return false
	end
	local jsonTable=json.decode(result)
	telnumsection = jsonTable.telnumsection
	telback = jsonTable.telback
	gettype = jsonTable.gettype
	stomLog("telnumsection"..telnumsection)
	stomLog("telback"..telback)
	stomLog("gettype"..gettype)
	return true
end
function UpCommon_add(Protype,content)
	stomLog("UpCommon_add...")
	local sz = require("sz")
	local json = sz.json
	local http = sz.i82.http
	local field1 = field1 or ""
	local getjoburl = "http://59.110.162.157/Api/common_add/add.php?type="..Protype.."&content="..content
	local body_resp = ""
	status_resp, headers_resp, body_resp = http.get(getjoburl,60)
	if status_resp == 200 then
		return 0
	else
		return 1
	end
end
function MangguoTV()
	stomLog("MangguoTV...")
	USER_AGENTS = {
		"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; AcooBrowser; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
		"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Acoo Browser; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506)",
		"Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.35; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
		"Mozilla/5.0 (Windows; U; MSIE 9.0; Windows NT 9.0; en-US)",
		"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 2.0.50727; Media Center PC 6.0)",
		"Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 1.0.3705; .NET CLR 1.1.4322)",
		"Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; InfoPath.2; .NET CLR 3.0.04506.30)",
		"Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.3 (Change: 287 c9dfb30)",
		"Mozilla/5.0 (X11; U; Linux; en-US) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.6",
		"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.2pre) Gecko/20070215 K-Ninja/2.1.1",
		"Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9) Gecko/20080705 Firefox/3.0 Kapiko/3.0",
		"Mozilla/5.0 (X11; Linux i686; U;) Gecko/20070322 Kazehakase/0.4.5",
		"Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.8) Gecko Fedora/1.9.0.8-1.fc10 Kazehakase/0.5.6",
		"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11",
		"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3) AppleWebKit/535.20 (KHTML, like Gecko) Chrome/19.0.1036.7 Safari/535.20",
		"Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; fr) Presto/2.9.168 Version/11.52",
		"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.11 TaoBrowser/2.0 Safari/536.11",
		"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.71 Safari/537.1 LBBROWSER",
		"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E; LBBROWSER)",
		"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E; LBBROWSER)",
		"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.84 Safari/535.11 LBBROWSER",
		"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)",
		"Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E; QQBrowser/7.0.3698.400)",
		"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E)",
		"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; SV1; QQDownload 732; .NET4.0C; .NET4.0E; 360SE)",
		"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E)",
		"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)",
		"Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.89 Safari/537.1",
		"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.89 Safari/537.1",
		"Mozilla/5.0 (iPad; U; CPU OS 4_2_1 like Mac OS X; zh-cn) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8C148 Safari/6533.18.5",
		"Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:2.0b13pre) Gecko/20110307 Firefox/4.0b13pre",
		"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:16.0) Gecko/20100101 Firefox/16.0",
		"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11",
		"Mozilla/5.0 (X11; U; Linux x86_64; zh-CN; rv:1.9.2.10) Gecko/20100922 Ubuntu/10.10 (maverick) Firefox/3.6.10"
	}
	RefererTB = {}
	local Referer = RefererTB[math.random(1,#RefererTB)]
	local UA = USER_AGENTS[math.random(1,#USER_AGENTS)]
	header_send = {
--		["Host"] = "adr-1414475071.cn-north-1.elb.amazonaws.com.cn",
		["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
		["User-Agent"] = UA,
		["Accept-Language"] = "zh-cn",
		["Accept-Encoding"] = "gzip, deflate",
		["Connection"] = "keep-alive",
		["Referer"] = Referer
	}
	ts.setHttpsTimeOut(10) --安卓不支持设置超时时间
	url = "http://adr-1414475071.cn-north-1.elb.amazonaws.com.cn/direct?cc=test29"
	--url = "https://httpbin.org/headers"
	body_send ={}
	local code,header_resp, body_resp = ts.httpsGet(url, header_send,body_send)
	stomLog(code)
--	stomLog(header_resp)
--	stomLog(body_resp)
	if code == 200 then
		stomLog("200...")
		stomLog(string.sub(body_resp,1,400))
		return 0
	end
	return 1

end
function GetPic()
	stomLog("GetPic...")
	local myimgpath = "/tmp/avatar.jpg"
	clearAllPhotos()
	delFile(myimgpath)
	for i =1 , 10 do
		local a = math.random(1,4)
		local typeidtb = {4001,4012,4013,4014}
		local pagetb = {40,40,260,60}
		local typeid = typeidtb[a]
		local page = math.random(1,pagetb[a])
		local url = "http://image.baidu.com/channel/listjson?width=300&height=300&tag1=美女&tag2=全部&ie=utf8&pn="..math.random(1,300).."&rn=10"
		local body_send ={}
		local header_send ={}
		header_send["Cache-Control"] = 'no-cache'
		local code,header_resp, body_resp = ts.httpGet(url, header_send,body_send)
		if code == 200 then
			--stomLog(body_resp)
			local data = json.decode(body_resp)
			if data["return_number"] == 10 then
				local picurl = data["data"][math.random(1,10)]["download_url"]
				stomLog(picurl)
				if picurl then
					httpdownFile(picurl, myimgpath)
					saveImageToAlbum(myimgpath);
					return true
				else
					stomLog("listdata = 0")
				end
--				local contentlistnum = #picdata
--				if contentlistnum > 0 then
--					local contentlistnum2 = math.random(1,contentlistnum)
--					stomLog("contentlistnum="..contentlistnum2)
--					local listdata = picdata[contentlistnum2]["list"]
--					if #listdata > 0 then
--						picurl = listdata[math.random(1,#listdata)]["middle"]
--						httpdownFile(picurl, myimgpath)
--						saveImageToAlbum(myimgpath);
--						return true
--					else
--						stomLog("listdata = 0")
--					end
--				else
--					stomLog("contentlistnum = 0")
--				end
			end
		end
		stomLog(code)
		stomtoast("GetPic失败",5)
		mSleep(3000)
	end
	--lua_restart()
end
function GetYYphoneStatus(phone)
	stomLog("GetYYphoneStatus...")
	if phone then else stomLog("phone nil")return false end
	header_send = {}
	header_send["Host"] = 'aq.yy.com'
	header_send["Accept"] = '*/*'
	header_send["X-Requested-With"] = 'XMLHttpRequest'
	header_send["Accept-Encoding"] = 'gzip, deflate'
	header_send["Accept-Language"] = 'zh-cn'
	header_send["Content-Type"] = 'application/x-www-form-urlencoded'
	header_send["Origin"] = 'https://aq.yy.com'
	header_send["Connection"] = 'keep-alive'
	header_send["User-Agent"] = 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_3_3 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Mobile/13G34 Platform/iOS9.3.3 APP/yymip7.6.0 Model/iPhone Browerser:Default Scale/2.00 YY/7.6.0, Build416, ClientEdition:yymip  AliBaichuan(2014_0_23472101@baichuan_h5_0.0.5/5.11)'
	body_send = {}
	body_send["account"] = phone
	body_send["busifrom"] = ''
	body_send["appid"] = 'yymip'
	body_send["yyapi"] = 'true'
	local url = "https://aq.yy.com/p/pwd/fgt/mnew/dpch.do"
	local code,header_resp, body_resp = ts.httpsPost(url, header_send,body_send)
	if code == 200 then
		local data = json.decode(body_resp)
		local rescode = data['code']
		if rescode == "-1" then
			stomLog("true")
			return true
		else
			stomLog("false")
			return false
		end
	end

end
function getWPcpatsak()
	local sz = require("sz")
	local cjson = sz.json
	local http = sz.i82.http
	local getjoburl = "http://47.95.13.16/ver/WPcpatsak.json"
	local body_resp = ""
	local status_resp, headers_resp, body_resp = http.get(getjoburl, 30)
	if status_resp == 200 and body_resp~=false or body_resp~=nil or body_resp~="" then
		local vertb = cjson.decode(body_resp)
		t_appid = vertb.appid:atrim()
		t_appbid = vertb.appbid:atrim()
		t_tasktype = vertb.tasktype:atrim()
		t_isdau = vertb.isdau:atrim()
		t_appname = vertb.appname:atrim()
		t_opentime = tonumber(vertb.opentime)
		return true
	end
	return false
end

function xiaooLoginToken(device_uuid,dev_version,appver)
	stomLog("xiaooLogin....")
	UserAgent = 'GCParentToCS/'..appver..'(com.greencheng.gcParentToC; build:'..appver..'; iOS '..dev_version..') Alamofire/4.7.3'
	header_str =  " -H 'Accept: */*'"..
	" -H 'Accept-Language: zh-Hans-CN;q=1.0'"..
	" -H 'Connection: keep-alive'"..
	" -H \""..UserAgent.."\""..
	" -H 'Content-Type: application/x-www-form-urlencoded; charset=utf-8'"
	--stomLog(header_str)
	body_send = {}
	body_send["client_id"] = 'GC-PT-IOS-APP-03'
	body_send["client_secret"] = '5OqXmE7HaTDcBdFn5QkuIkUTJOVgYE3P6CzFz3OA'
	body_send["device_os"] = '1'
	body_send["device_uuid"] = device_uuid
	body_send["grant_type"] = 'client_credentials'
	body_send["os_version"]	= appver
	local url = "https://orange-app-api.greencheng.com/v1/common/login"
	post_escaped = encodeQuery(body_send)
	--stomLog(post_escaped)
	local cmd = "curl -k -X POST \""..url.."\""..header_str.." -d \""..post_escaped.."\""
	stomLog(cmd)
	local res = GetSystem(cmd)
	stomLog(res)
	if res and res ~= "" then
		local restb = json.decode(res)
		if restb.ret_code == 200 then
			local toekn = restb.result.access_token
			stomtoast(toekn,2)
			return toekn
		end
	end
	return 1
end

function xiaooCode(token, phonenum,dev_version,appver)
	stomLog("xiaooCode....")
	UserAgent = 'GCParentToCS/'..appver..'(com.greencheng.gcParentToC; build:'..appver..'; iOS '..dev_version..') Alamofire/4.7.3'
	header_str = " -H 'Accept-Encoding:gzip;q=1.0,compress;q=0.5'"..
	" -H 'Accept-Language:zh-Hans-CN;q=1.0'"..
	" -H 'Authorization:Bearer "..token.."'"..
	" -H 'Connection:keep-alive'"..
	" -H 'Content-Length:32'"..
	" -H 'Content-Type:application/x-www-form-urlencoded'"..
	" -H 'Host:orange-app-api.greencheng.com'"..
	" -H \""..UserAgent.."\""..
	" -H 'client-child-id:0'"
	--stomLog(header_str)
	body_send = {}
	body_send["type"] = "login"
	body_send["cellphone"] = phonenum
	post_escaped = encodeQuery(body_send)

	url = "https://orange-app-api.greencheng.com/v1/common/code"
	local cmd = "curl -k -X POST \""..url.."\""..header_str.." -d \""..post_escaped.."\""
	--stomLog(cmd)
	local res = GetSystem(cmd)
	if res and res ~= "" then
		local restb  = json.decode(res)
		if restb.ret_code == 200 then
			stomtoast("短信发送成功",2)
			return 0
		else
			stomtoast(res,5)
		end
	end
	stomLog(res)
	return 1
end
function xiaooLoginCode(phonenum,smscode,device_uuid,dev_version,appver)
	stomLog("xiaooLoginCode....")
	UserAgent = 'GCParentToCS/'..appver..'(com.greencheng.gcParentToC; build:'..appver..'; iOS '..dev_version..') Alamofire/4.7.3'
	header_str =  " -H 'Accept: */*'"..
	" -H 'Accept-Language: zh-Hans-CN;q=1.0'"..
	" -H 'Connection: keep-alive'"..
	" -H \""..UserAgent.."\""..
	" -H 'Content-Type: application/x-www-form-urlencoded; charset=utf-8'"..
	" -H 'client-child-id:0'"
	--stomLog(header_str)
	body_send = {}
	body_send["client_id"] = 'GC-PT-IOS-APP-03'
	body_send["client_secret"] = '5OqXmE7HaTDcBdFn5QkuIkUTJOVgYE3P6CzFz3OA'
	body_send["device_os"] = '1'
	body_send["device_uuid"] = device_uuid
	body_send["grant_type"] = 'password'
	body_send["os_version"]	= appver
	body_send["cellphone"] = phonenum
	body_send["code"]	= smscode
	
	local url = "https://orange-app-api.greencheng.com/v1/common/login"
	post_escaped = encodeQuery(body_send)
	stomLog(post_escaped)
	local cmd = "curl -k -X POST \""..url.."\""..header_str.." -d \""..post_escaped.."\""
	stomLog(cmd)
	local res = GetSystem(cmd)
	stomLog(res)
	if res and res ~= "" then
		local restb = json.decode(res)
		if restb.ret_code == 200 then
			local action = restb.result.action
			if action == "register" then
				local access_token = restb.result.access_token
				stomtoast("注册成功",2)
				return 0, access_token
			else
				stomtoast(action,5)
				conmenttype = "xiaooCreate_Flase"
				return 1
			end
		end
	end
	return 1
end

function jingYuReq(url, UserAgent, body_send)
	stomLog("jingYuLoginCode....")
	header_str =  " -H 'Accept: */*'"..
	" -H \""..UserAgent.."\""..
	" -H 'Content-Type: application/x-www-form-urlencoded; charset=utf-8'"..
	" -H 'Accept-Encoding: gzip'"
	post_escaped = encodeQueryUnencode(body_send)
	signature = singeJY(post_escaped)
	if body_send["nick"] then
		body_send["nick"] = urlEncode(body_send["nick"])
		post_escaped = encodeQueryUnencode(body_send)
	elseif body_send["debugDescription"] then
		body_send["debugDescription"] = urlEncode(body_send["debugDescription"])
		body_send["description"] = urlEncode(body_send["description"])
		post_escaped = encodeQueryUnencode(body_send)
	end
	post_escaped = post_escaped.."&signature="..signature
	--stomLog(post_escaped)
	if isFileExist(cookiefile) then
		cmd = "curl -k -X POST \""..url.."\""..header_str.." -d \""..post_escaped.."\""-- -D "..cookiefile.." -b "..cookiefile..""
	else
		cmd = "curl -k -X POST \""..url.."\""..header_str.." -d \""..post_escaped.."\""-- -D "..cookiefile..""
	end
	stomLog(cmd)
	local res = GetSystem(cmd)
	stomLog(res)
	--dialog(res, 0)
	if res and res ~= "" then
		local restb = json.decode(res)
		if restb.errCode == "0" then
			if restb['object']['accessToken'] then
				accessToken_new = restb['object']['accessToken']
				stomLog(accessToken_new)
			end
			return 0
		end
	end
	return 1
end

function AskJYDJdata()
	stomLog("AskJYDJdata...")
	local sz = require("sz")
	local cjson = sz.json
	local http = sz.i82.http
	local serial = sz.system.serialnumber()
	local getjoburl = "http://39.106.73.162/Api/um/jingyudj/jy/getTask_ios.php"
	local body_resp = ""
	for i =1 , 20 do
		status_resp, headers_resp, body_resp = http.get(getjoburl, 10)
		mSleep(500)
		if status_resp == 200 then
			local code = http.header(body_resp,"code") 
			stomLog("data--"..body_resp)
			if code == 200 then
				local restb = json.decode(body_resp)
				datatable = restb["data"][1]
				return 0
			else
				stomLog("Askjob body nil")
				mSleep(3000)
				local msg = http.header(body_resp,"msg")
			end
		elseif status_resp == 500 then
			stomtoast("Ask false"..body_resp,5)
		end
		stomtoast("Ask false"..body_resp,5)
		stomLog("Ask false"..body_resp)
		mSleep(3000)
	end
end
function upAskJYDJdata()
	stomLog("upAskJYDJdata...")
	local sz = require("sz")
	local json = sz.json
	local http = sz.i82.http
	local getjoburl = "http://39.106.73.162/Api/um/jingyudj/jy/postTask_ios.php?"
	local body_resp = ""
	post={["deviceInfo"]={
		["type"] = tasktype,
        ["realDeviceName"]= DeviceName,
        ["device_id"]= device_id,
        ["task_id"]= task_id,
        ["accessToken"]= accessToken,
        ["phonenum"]= phonenumber,
        ["passwd"]= "qqqwwweee"}
	}
	post_send = json.encode(post)
	headers = {}
	headers['Content-Type'] = 'application/json'
	headers_send = json.encode(headers)
	stomLog("upAskdata false"..post_send)
	for i =1 , 20 do
		status_resp, headers_resp, body_resp = http.post(getjoburl, 10, headers_send, post_send)
		mSleep(500)
		if status_resp == 200 or status_resp == 502 then
			stomtoast(body_resp,5)
			stomLog("upAskdata OK"..body_resp)
			return 0
		end
		stomtoast("upAskdata false"..body_resp,5)
		stomLog("upAskdata false"..body_resp)
		mSleep(3000)
	end
end

function updateDDNS(ip)
	url = "http://members.3322.net/dyndns/update"
	--username:password
end

function getTaskConfig(appid)
	stomLog("getTaskConfig...")
	local getjoburl = "http://59.110.162.157/Api/cpa4.0/getconfig.php?appid="..appid
	local header_send_table={}
	local body_resp = ""
	for i =1 , 20 do
		status_resp, headers_resp, body_resp = stomhttpGet(getjoburl,10,header_send_table)
		if status_resp == 200 then
			local restb = json.decode(body_resp)
			local code = restb["code"]
			stomLog(body_resp)
			if code == 200 then
				taskConfigTable = restb["info"]
				return 0
			end
		elseif status_resp == 500 then
			stomtoast("Ask false"..body_resp,5)
		end
		stomtoast("getTaskConfig false"..body_resp,5)
		stomLog("getTaskConfig false"..body_resp)
		mSleep(3000)
	end
	return 1
end

function AskSFZdata()
	stomLog("Askjob...")
	local sz = require("sz")
	local cjson = sz.json
	local http = sz.i82.http
	local getjoburl = "http://47.95.13.16/Api/account/getSFZ.php?IDFA="..idfa
	local body_resp = ""
	for i =1 , 20 do
		status_resp, headers_resp, body_resp = http.get(getjoburl, 5)
		mSleep(500)
		if status_resp == 200 then
			local account = http.header(body_resp,"account") 
			stomLog("account--"..body_resp)
			if account ~= nil then
				local body = cjson.decode(body_resp)
				accounttable = body["account"]
				szfdata = accounttable["content"]
				recordID = accounttable["recordID"]
				qqdatatb = strSplit(qqdata,"----")
				if #qqdatatb > 0 then
					sfzname = qqdatatb[1]:atrim()
					qqpaswd = qqdatatb[2]:atrim()
				else
					dialog("没有账号", 60)
					mSleep(30*1000)
					lua_restart()
				end
				return 0
			else
				stomLog("Askjob body nil")
				mSleep(3000)
				local msg = http.header(body_resp,"msg")
			end
		elseif status_resp == 500 then
			stomtoast("Ask false"..body_resp,5)
		end
		stomtoast("Ask false"..body_resp,5)
		stomLog("Ask false"..body_resp)
		mSleep(6000)
	end
end


function getipus()
	local ipurl = "http://lumtest.com/myip.json?"
	--local ipurl = "http://httpbin.org/get"
	local code, headers_resp, res  = stomhttpGet(ipurl,{}, "")
	if code == 200 then
		local i,j = string.find(res, "%d+%.%d+%.%d+%.%d+")
		if i ~= nil and j ~= nil then
			local ipaddr =string.sub(res,i,j)
			local ipaddr2 = stomtrim(ipaddr)
			local t =json.decode(res)
			local latitude = t["geo"]["latitude"]
			local longitude = t["geo"]["longitude"]
			return code, ipaddr2, latitude, longitude
		end
	end
	return code, nil
end

function getVPN(vpnstatus,region)
	stomLog("getVPN..."..vpnstatus)
	local localIP = stomtrim(System.getLocalIPAddress())
	local region = region or "QG"
	local status_resp = ""
	local body_resp = ""
	if localIP ~= nil then
		local getjoburl = SLionLUA["VPN_SER"].."localip="..localIP.."&enable="..vpnstatus.."&region="..region
		local status_resp, headers_resp, body_resp = stomhttpGet(getjoburl,header_send, body_send)
		--stomLog(body_resp)
		if status_resp == 200 then
			local t = json.decode(body_resp)
			if t["code"] == "200" then
				return true
			else
				stomtoast(body_resp,2)
			end
		end
		--stomtoast(status_resp.."getVPN FALSE",5)
	end
	return false
end

function sendYingYuPhonenumber(url,body_send)
	stomLog("sendYingYuPhonenumber...")
	for i =1 , 3 do
		header_str =  " -H 'Accept: */*'"..
		" -H 'Accept-Language: zh;q=1.0'"..
		" -H 'Connection: keep-alive'"..
		" -H 'Accept-Encoding: gzip, deflate'"..
		" -H 'Host: apineo.llsapp.com'"..
		" -H \""..UserAgent.."\""..
		" -H 'Content-Type: application/json'"
		--stomLog(header_str)
	--	body_send = {}
	--	body_send["client_id"] = 'GC-PT-IOS-APP-03'
	--	body_send["client_secret"] = '5OqXmE7HaTDcBdFn5QkuIkUTJOVgYE3P6CzFz3OA'
	--	body_send["device_os"] = '1'
	--	body_send["device_uuid"] = device_uuid
	--	body_send["grant_type"] = 'client_credentials'
	--	body_send["os_version"]	= appver
		--local url = "https://orange-app-api.greencheng.com/v1/common/login"
		--post_escaped = encodeQuery(body_send)
		post_escaped = sz.json.encode(body_send)
		--stomLog(post_escaped)
		local cmd = "curl -k -X POST --connect-timeout 10 -m 15 \""..url.."\""..header_str.." -d \'"..post_escaped.."\'"
		stomLog(cmd)
		local res = GetSystem(cmd)
		stomLog(res)
		--dialog(cmd, time)
		--dialog(res, time)
		if res and res ~= "" then
			yyrestb = json.decode(res)
			return 0
		end
		mSleep(1000)
	end
	return 1

	--[[
	local headers = {
		["Host"] = "apineo.llsapp.com",
		["Content-Type"] = "application/json",
		["Accept-Encoding"] = "gzip, deflate",
		["Connection"] = "keep-alive",
		["Accept"] = "*/*",
		["User-Agent"] = "Lingome/6.0.1 (iPhone; iOS "..math.random(9,11)..".0.2; Scale/2.00)",
		["Accept-Language"] = "zh;q=1"}

--	local sDeviceId = myRand(6,40,2)
--	local body = {
--		["sDeviceId"] = sDeviceId,
--		["deviceId"] = sDeviceId,
--		["appVer"] = "6",
--		["appId"] = "lls",
--		["mobile"] = phone}

--	local url = "https://apineo.llsapp.com/api/v1/password/request_reset"
	ts.setHttpsTimeOut(60)
	local code ,header_resp, body_resp = ts.httpsPost(url, headers, body)
	--	dialog(code)
	--	stomtoast(body_resp,2)
	stomLog(code)
	stomLog(body_resp)
	if code == 200 or code == 201 then
		yydata = sz.json.decode(body_resp)
		return 0
--		if data.error_code == 10010 then
--			return 1
--		end
	end
	dialog(code, time)
	dialog(body_resp, time)
	return 1]]
end

--function postfile(appid, filepath)
--	stomLog("postfile..")
--	local url = "https://api.ojbknet.com/api/postfile.php?appid="..appid
--	local cmd = "curl -k -X POST \""..url.."\"".." -F 'file=@"..filepath.."'"
--	local res = GetSystem(cmd)
--	stomLog(res)
--	if res and res ~= "" then
--		local yyrestb = json.decode(res)
--		return yyrestb
--	end
--	return {}
--end
function getAIDTask(apitype)
	local url = "http://106.75.21.9:8083/affiche/api/task"
	stomLog("getSSPtask...")
	postTable["adSlotId"]="ba15fef094fb457d964108a990047467"
	postTable["adSysId"]="KP0001"
	postTable["adToken"]= ""
	postTable["affid"]= "e397d8dc409142d9a37e7e4b61a12010"
	postTable["type"]= apitype
	
	
	
	
end
function getSSPtask()
	stomLog("getSSPtask...")
	postTable["app_key"]="ba15fef094fb457d964108a990047467"
	postTable["slot_id"]="52a3ccedef9446d8afde29335bd7aa0a"
	postTable["av"]= "V2.0.1"
	postTable["ctype"]= "json"
	postTable["rip"]= "1.85.217.20"
	postTable["w"]= 160
	postTable["h"]= 200
	postTable["ct"]= 3
	postTable["dct"]= 13
	postTable["udid"]= "af12eeade4521ac3"
	postTable["imei"]= "862533030034307"
	postTable["ll"]= "108.9286,34.2583"
	postTable["lla"]= "10"
	postTable["llt"]= "2"
	postTable["llp"]= "n"
	postTable["dn"]= "samsung,SM-A7100,SM-A7100"
	postTable["z"]= "+0800"
	postTable["os"]= "1"
	postTable["osv"]= "6.0.1"
	postTable["o"]= "p"
	postTable["sc_a"]= "2.0"
	postTable["sc_w"]= 1600
	postTable["sc_h"]= 2438
	postTable["sc_ppi"]= 320
	postTable["dtype"]= 1
	postTable["mac"]= "aa:f7:f4:a4:bc:22"
	postTable["mcc"]= "460"
	postTable["mnc"]= "02"
	postTable["iso"]= "cn"
	postTable["cn"]= "中国电信"
	postTable["lac"]= ""
	postTable["cid"]= ""
	postTable["wifi"]= "aa:f7:f3:a4:bc:5a,NetEase,af:f7:f3:a4:bc:5a,liaofan,bf:f7:f3:a4:bc:5a"
	postTable["ran"]= 5
	postTable["cids"]= ""
	status_resp, headers_resp, body_resp = http.get(getjoburl, 5)
	
	
	
end

function stomcheckser()
	local url = "http://www.ojbknet.com/api/ros/0/setips.php"
	local httpstatus, headers_resp, body_resp = stomhttpGet(url,10,header_send_table)
	--stomLog("stomcheck"..httpstatus)
	if httpstatus == 200 then
		SLionLUA["ipaddress"] = "http://139.129.99.171:1111/"
		SLionLUA["downZipURL"] = "http://api.ojbknet.com/stom"
		SLionLUA["upZipURL"] = "http://api.ojbknet.com/api/postfile.php"
		SLionLUA["callbackURL"] = "http://139.129.99.171:1111/stom/cpa/pb"
		SLionLUA["VPN_SER"] = "http://www.ojbknet.com/api/ros/0/setips.php?"
		SLionLUA["deb_SER"] = "http://www.ojbknet.com/cydia/debs"
		applePWDs = "Zxc112211"
	elseif httpstatus == 404 then
		SLionLUA["ipaddress"] = "http://39.107.47.192:1111/"
		SLionLUA["downZipURL"] = "http://api.izuan.live/stom"
		SLionLUA["upZipURL"] = "http://api.izuan.live/api/postfile.php"
		SLionLUA["callbackURL"] = "http://39.107.47.192:1111/stom/cpa/callback_notice"
		SLionLUA["VPN_SER"] = "http://api.izuan.live/api/ros/0/setips.php?"
		SLionLUA["deb_SER"] = "http://www.api.izuan.live/cydia/debs"
		applePWDs = "Aa112211"
	else
		stomLogPUT("请检查网络是否正常",1)
		os.exit()
	end
	
end


function nnnnnnnn()
end