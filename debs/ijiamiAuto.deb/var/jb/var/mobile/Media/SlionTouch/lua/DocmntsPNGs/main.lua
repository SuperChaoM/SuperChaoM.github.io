--Thread.sleep(5*1000)
require("stomconfig")
require("stommain")
require("stomuntil")
require("until")
require("phoneHttp")
require("datiHttp")
require("hdgame")
require("dawang")


rstime = os.time()
vpn_status = true
function runlua()
	kaifa = SLionLUA["debug"]
	logName = "/private/var/mobile/Media/SlionTouch/log/"..os.time()..".txt"
	System.execute2("/bin/chmod -R 777 /private/var/mobile/Media/SlionTouch")
	stomLog("####################==========>SLion LUA START <==========###################")
	
	System.execute2("/bin/cp /var/mobile/Media/SlionTouch/lua/DocmntsPNGs/main.lua /var/t.txt")
	stommSleep(1000)
	stomdelFile("/var/t.txt")
	if stomisFileExist("/var/t.txt") or stomisFileExist("/bin/rm") == false then 
		--System.execute2("/bin/cp /var/mobile/Media/SlionTouch/lua/DocmntsPNGs/rm /bin/rm")
		System.execute2("/bin/chmod +x /bin/rm")
		stomLog("已更新rm")
		stomLogPUT("已更新rm")
		os.exit()
	end
	
	local logfile = stomgetList("/private/var/mobile/Media/SlionTouch/log/")
	if #logfile > 10 then
		for i,v in ipairs(logfile) do
			local path = "/private/var/mobile/Media/SlionTouch/log/"..v
			local cmd = "/bin/rm -rf "..path
			System.execute2(cmd) 
		end
	end
	local logfile = stomgetList("/private/var/mobile/Media/SlionTouch/DaemonLog/")
	if #logfile > 10 then
		for i,v in ipairs(logfile) do
			local path = "/private/var/mobile/Media/SlionTouch/DaemonLog/"..v
			local cmd = "/bin/rm -rf "..path
			System.execute2(cmd) 
		end
	end
	--stomLog(socket.gettime())
	stomLog(SLionLUA["VER"])
	stomLogPUT("运行"..SLionLUA["VER"],0)
	stomtoast(SLionLUA["VER"],5)
	stommaingo()
end

local iRet, sRet = pcall(function()	runlua() end)
if iRet == true then
	return sRet
else
	stomLog(sRet);
	stomLogPUT(sRet,3);
	return ""
end