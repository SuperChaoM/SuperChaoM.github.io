--require("wgjyyidai")
--local sz = require("sz")

zhangkq={
	["姓氏"]="周李王彭吕张闫岳杜戴赵马郝姚文江胡刘陈邓江毛习曹司钟任徐宁冯苗祁梅秋方邱狄童职朱祝",
	["名字"]="香莹旭敏疏影歌涛章杰伦恩来泽东进平思丝丽颖美艳学友宝川马"..
	"照师欣新乔恩启紫修小琴青庆晴清倾箐沁进金锦华琪鱼花布珠露"..
	"明光千永兆环丰良祺珍曲书沛琪仙之竹向识益女北未自作宜冰伦"..
	"封风峰冯丰锋烽嘉游有佑悠幽攸莲涟爱琴勤钦建剑壮锦尽劲津巾"..
	"瑾矜静华桦符福赋刚余鱼于雨玉宇语羽欲预俞域御育郁渝裕於峪"
}

gongsi={
	["公司"]="西你我清君若想星尘光平华灵杯贝暗彩财草厂超臭串",
	["职位"]="经金销客设人运维工出和顾"
}
function stommove(x1,x2,y1,y2,time)
	if time then
		sleeptime=time
	else
		sleeptime=500
	end
	touchDown(x1, x2)
	stommSleep(sleeptime)
	touchMove(y1,  y2)
	stommSleep(sleeptime)
	touchUp(y1,  y2)
end

function ZKQ_Word(strs,i,Szzd)
	function GetDeviceSeed()	--根据设备ID 产生不同的值
		stommSleep(100)
		local SJ = 0; for l=1,string.len(getDeviceID()) do SJ=string.byte(getDeviceID():sub(l,l))+SJ end
		return SJ
	end
	local RetStr,Length,Seed="",1,0
	if string.byte(strs:sub(1,1))>=0x80 then
		Length = 3
	end
	math.randomseed(tostring(os.time()):reverse():sub(1, 6) + GetDeviceSeed() + (Seed or 0))	--叠加时间参数确保任何数值不同
	math.random(string.len(strs)/Length)
	for i=1, i do
		Seed=math.random(string.len(strs)/Length)
		RetStr = RetStr..string.sub(strs,(Seed*Length)-(Length-1),(Seed*Length))
	end
	return(RetStr)
end

--  nicheng = ZKQ_Word(zhangkq["姓氏"],1,1)..ZKQ_Word(zhangkq["名字"],3,3)


function keyboard()
	local yanzhenma = yanzhenma or ""
	local y = string.sub(yanzhenma, 1, 1)
	local y1 = string.sub(yanzhenma, 2, 2)
	local y2 = string.sub(yanzhenma, 3, 3)
	local y3 = string.sub(yanzhenma, 4, 4)
	local y4 = string.sub(yanzhenma, 5, 5)
	local y5 = string.sub(yanzhenma, 6, 6)
	a = {y, y1,y2,y3,y4,y5}
	for i,v in ipairs(a) do  
		stommSleep(300)
		stomLog(v)
		if v == "1" then
			tap(113,  743)
		elseif v  == "2" then
			tap(316,  747)
		elseif v  == "3" then
			tap(541,  740)
		elseif v == "4" then
			tap( 106,  857)
		elseif v == "5" then
			tap(324,  850)
		elseif v == "6" then
			tap(541,  855)
		elseif v == "7" then
			tap(107,  952)
		elseif v == "8" then
			tap(318,  959)
		elseif v == "9" then
			tap(540,  959)
		elseif v == "0" then
			tap(314, 1086)
		end
	end
end

function get1osver()
	local myosverion = 0
	if whoAmI() == 100 then
		myosverion = devicesinfo['osversion']
	else	
		myosverion = getOSVer()
	end
	return tonumber(string.match(myosverion,"%d+"))
end

function appleshop_12ios()
	if stomMultiColor("只输密码-12",{
		{   44,  191, 0x000000},
		{  133,  529, 0x8f9098},
		{  129,  541, 0x8f9198},
		{  133,  551, 0x8f9098},
	}) then
		stommSleep(800)
		stomInpuText(applePWD)
		stommSleep(800)
		stomtap(348,  629)
	end
	if 	stomMultiColor("账号和密码横向CN-12",{
		{  535,  346, 0xc7c7cd},
		{  535,  358, 0xc9c9cf},
		{  458,  405, 0x007aff},
		{  456,  446, 0x007aff},
	}) or stomMultiColor("账号和密码横向EN-12",{
		{  476,  348, 0xc7c7cd},
		{  487,  348, 0xc7c7cd},
		{  468,  351, 0xc7c7cd},
		{  479,  369, 0xc7c7cd},
	})then
		stommSleep(500)
		stomtap(27, 1055)
		stomInpuText(applePWD)
		stommSleep(500)
		stomtap(531,  677)
	end			
		stomMultiColorTap("现有id纵-12",{
			{  240,  537, 0x007aff},
			{  255,  539, 0x007aff},
			{  278,  535, 0x007aff},
			{  447,  538, 0x007aff},
		}) 
		stomMultiColorTap("横屏使用现有id-12",{
			{  346,  503, 0x097fff},
			{  352,  526, 0x007aff},
			{  344,  605, 0x007aff},
			{  346,  660, 0x007aff},
		}) 
		stomMultiColorTap("15分需要横-12",{
			{  185,  604, 0x007aff},
			{  195,  616, 0x007aff},
			{  185,  653, 0x007aff},
			{  189,  727, 0x007aff},
		}) 
		stomMultiColorTap("购买确认-12",{
			{  303, 1040, 0xffffff},
			{   44,  524, 0x000000},
			{  267, 1024, 0x007aff},
			{  369, 1032, 0x007aff},
		}) 
		stomMultiColorTap("购买确认2-12",{
			{  318, 1034, 0x007aff},
			{   38,  556, 0x000000},
			{   58,  559, 0x898e94},
			{  264, 1033, 0x007aff},
		})
end

function shopapplestore()
		applePWD="Zxc112211"
				if stomMultiColor("sw设置界面",{
					{  295,  424, 0x215da5},
					{  283,  441, 0x295d9c},
					{  307,  444, 0x215da5},
					{  299,  494, 0xb5d7f7},
				})	then
					stomtap(414,34)
				end
				stomMultiColorTap("绿色对勾绑定成功",{
				{  537,  830, 0x848684},
				{  541,  530, 0x000000},
				{  540,  536, 0x100c10},
				{  541,  560, 0x393c42},
			})
				stomMultiColorTap("进入商城1",{
				{  417,   26, 0xc65921},
				{  404,   20, 0xe7c763},
				{  403,   41, 0xf7d363},
				{  398,   34, 0xe7b64a},
			})
				stomMultiColorTap("进入商城2",{
				{  478,   26, 0xc65521},
				{  472,   19, 0xe7c763},
				{  471,   40, 0xefd363},
				{  465,   23, 0xe7b242},
			})
			--if myosver < 11 then
				if stomMultiColor("横向只输密码",{
					{  437,  348, 0xc7c7cd},
					{  437,  357, 0xc7c7cd},
					{  428,  382, 0xcdcdd3},
					{  420,  371, 0xcbcbd1},
				}) then
					stommSleep(300)
					stomInpuText(applePWD)
					stommSleep(300)
					stomtap(368,  692)
				end
				stomMultiColorTap("横向长账号设置",{
					{  203,  691, 0x007aff},
					{  204,  718, 0x007aff},
					{  189,  712, 0x007aff},
					{  425,  485, 0x000000},
				})
				if stomMultiColor("长账号纵支付密码",{
					{   99,  402, 0xc7c7cd},
					{  106,  402, 0xc7c7cd},
					{  104,  421, 0xc7c7cd},
					{  126,  415, 0xd0d0d5},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(300)
					stomMultiColorTap("确认密码",{
						{  455,  505, 0x007aff},
						{  458,  505, 0x007aff},
						{  462,  505, 0x007aff},
					})
				end
				if stomMultiColor("长账号横支付密码",{
					{  544,  768, 0x676f73},
					{  506,  550, 0x17191a},
					{  427,  348, 0xc7c7cd},
					{  420,  373, 0xc7c7cd},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(300)
					stomMultiColorTap("确认密码",{
						{  367,  706, 0x007aff},
						{  367,  709, 0x007aff},
						{  367,  713, 0x007aff},
					})
				end
				if stomMultiColor("账号和密码横向CN",{
					{  191,  196, 0x000000},
					{  230,  196, 0x000000},
					{  400,  270, 0x9d9dad},
					{   99,  343, 0xd4d4d9},
				}) or stomMultiColor("账号和密码横向EN",{
				{  188,  232, 0x000000},
				{  229,  232, 0x000000},
				{  410,  331, 0xffffff},
				{  100,  380, 0xc7c7cd},
				})then
					stommSleep(500)
					stomtap(598, 1109)
					stomInpuText(applePWD)
					stommSleep(500)
					stomtap(353,  332)
				end	
				if 	stomMultiColor("账号和密码横向CN",{
					{  567,  436, 0x000000},
					{  582,  481, 0x000000},
					{  500,  620, 0xffffff},
					{  431,  690, 0x007aff},
				}) or stomMultiColor("账号和密码横向EN",{
					{  444,  348, 0xc7c7cd},
					{  435,  344, 0xc7c7cd},
					{  436,  352, 0xc7c7cd},
					{  445,  378, 0xc7c7cd},
				})then
					stommSleep(500)
					stomtap(27, 1055)
					stomInpuText(applePWD)
					stommSleep(500)
					stomtap(545,  344)
				end		
				
			--end
					stomMultiColorTap("纵向设置",{
					{  442,  668, 0x007aff},
					{  428,  671, 0x007aff},
					{  471,  664, 0x007aff},
					{  472,  682, 0x007aff},
				})		
					stomMultiColorTap("注册完成关闭多益账号显示",{
						{  437,  831, 0x8c8684},
						{  221,  389, 0x528af7},
						{  280,  484, 0x1086f7},
						{  443,  311, 0xde0010},
					})				
					stomMultiColorTap("单行密码已输入确认",{
						{  461,  489, 0x007aff},
						{   98,  397, 0x000000},
						{  114,  397, 0x000000},
						{  474,  305, 0x606668},
						{  192,  217, 0x000000},
					})
					stomMultiColorTap("无法连接IT横粗",{
						{  252,  559, 0x007aff},
						{  367,  393, 0x000000},
						{  373,  471, 0x8c999c},
						{  364,  578, 0xb7c2c7},
					})
					stomMultiColorTap("使用现有B",{
						{  343,  503, 0x007aff},
						{  249,  454, 0x007aff},
						{  173,  548, 0x007aff},
						{  466,  545, 0x242526},
					})
					stomMultiColorTap("使用现有纵",{
						{  241,  538, 0x007aff},
						{  240,  547, 0x0c80ff},
						{  278,  536, 0x007aff},
						{  446,  539, 0x007aff},
					})
					stomMultiColorTap("设置纵粗",{
						{  444,  668, 0x007aff},
						{  428,  667, 0x007aff},
						{  224,  476, 0x000000},
						{  157,  667, 0x007aff},
						{  462,  562, 0x000000},
					})
				stomMultiColorTap("网络异常重登",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("无法连接IT纵粗",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("验证失败再次粗",{
					{  652,  403, 0x007aff},
					{  510,  252, 0x000000},
					{  585,  251, 0x000000},
					{  763,  303, 0xd8dcda},
				})
				stomMultiColorTap("确认购买纵粗？？",{
					{  425,  666, 0x007aff},
					{  166,  483, 0x000000},
					{  422,  483, 0x616161},
					{  554,  678, 0xf9f9f9},
				})			
				stomMultiColorTap("使用现有",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("使用现有纵",{
					{  277,  537, 0x007aff},
					{  305,  430, 0x000000},
					{  334,  429, 0x595d5d},
					{  473,  635, 0xced2d2},
				})				
				if stomMultiColor("登录换行",{
					{   38,  968, 0x363737},
					{  581,  444, 0x4b4d4f},
					{  581,  481, 0x000000},
					{  437,  413, 0x007aff},
				})	then
					stommSleep(500)	
					stomMultiColorTap("登录换行",{
					{   38,  968, 0x363737},
					{  581,  444, 0x4b4d4f},
					{  581,  481, 0x000000},
					{  437,  413, 0x007aff},
				})	
					stommSleep(500)	
					if stomMultiColor("输入txt",{
						{  491,  348, 0xc7c7cd},
						{  485,  396, 0xffffff},
						{  270,  377, 0x605f60},
						{  365,  412, 0x007aff},
					})	then
						stomInpuText(applePWD)
						stommSleep(300)
						stomMultiColorTap("点击上行",{
							{  550,  688, 0xffffff},
							{  488,  688, 0xffffff},
							{  338,  518, 0xccced1},
						})		
						--复制 @163.com
					end
				end
				--[[if stomMultiColor("登录换行纵向",{
					{  191,  196, 0x000000},
					{  232,  203, 0x585c5b},
					{  362,  292, 0xffffff},
					{  100,  345, 0xc7c7cd},
				}) or stomMultiColor("登录换行纵向B",{
					{   93,  321, 0xd0dafc},
					{  195,  232, 0x000000},
					{  175,  384, 0xffffff},
					{  106,  332, 0xffffff},
					{  262,  244, 0x000000},
				})  	then
					stommSleep(500)
					stomMultiColorTap("换行",{
					{  597, 1079, 0x353535},
					{  232,  203, 0x585c5b},
					{  362,  292, 0xffffff},
					{  100,  345, 0xc7c7cd},
				})
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(300)
					stomMultiColorTap("点击上行",{
						{  369,  298, 0xffffff},
						{  232,  203, 0x585c5b},
						{  362,  292, 0xffffff},
						{  100,  345, 0xc7c7cd},
					})		
						--复制 @163.com
				end]]
				stomMultiColorTap("设置",{
					{  217,  676, 0x007aff},
					{  401,  550, 0x636566},
					{  400,  579, 0x000000},
					{  405,  644, 0x000000},
				})	
				stomMultiColorTap("设置纵向",{
					{  472,  663, 0x007aff},
					{  375,  664, 0xccd0d1},
					{  221,  484, 0x000000},
					{  273,  488, 0x666869},
				})	
				stomMultiColorTap("15分钟后需要",{
					{  357,  705, 0x007aff},
					{  409,  704, 0x56a5fd},
					{  466,  704, 0x007aff},
					{  362,  448, 0x000000},
				})	
				if stomMultiColor("请输入M横向-long",{
					{  570,  509, 0x000000},
					{  550,  766, 0x5d6568},
					{  502,  546, 0x000000},
					{  418,  347, 0xc7c7cd},
					{  418,  355, 0xc7c7cd},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(500)
					stomMultiColorTap("登录",{
					{  363,  656, 0xd8e6f0},
					{  361,  694, 0x007aff},
					{  366,  709, 0x007aff},
					{  369,  764, 0xe6eaeb},
				})
				end				
				stomMultiColorTap("无法连接IT",{
					{  437,  628, 0x007aff},
					{  472,  626, 0xabd1fb},
					{  146,  521, 0x000000},
					{  222,  531, 0x8f8f8f},
				})
				--[[if stomMultiColorTap("购买完成",{
					{  548,  493, 0x000000},
					{  427,  406, 0xffffff},
					{  425,  352, 0xcdcdd3},
					{  500,  715, 0x000000},
				}) or stomMultiColorTap("购买完成B",{
					{  309,  644, 0x007aff},
					{  259,  491, 0x000000},
					{  411,  553, 0x000000},
					{  517,  556, 0xf9f9f9},
				})then
					stommSleep(500)					
					OpenApp("com.duoyi.shenwu3")
				--else stomLog("notfound")
			end		--]]	
end
			

function shouchong_fun()
	stomMultiColorTap("开始充值",{
	{   93,  713, 0xefcb31},
	{   95,  796, 0xe7cb31},
	{   97,  739, 0x9c6510},
	{   95,  768, 0x946910},
})
	if stomMultiColor("开始充值",{
		{  575,  529, 0x3965a5},
		{  575,  538, 0x3169ad},
		{  567,  535, 0x3965a5},
		{  322,  324, 0xffffff},
	}) then
		stommSleep(500)
		stomtap(421,  363)
		stommSleep(300)
	end
end

function SW1282917929_fn_pro()
	if stomMultiColor("战斗中",{
	{  581,   77, 0xffffff},
	{  579,   77, 0x1871a5},
	{  589,   77, 0x2975b5},
	{  583,   95, 0x8caece},
}) and pro_num<3 and tasktype==1 and swNowtime > swtime_cha/2 then
	protimestart=os.time()
	while (true) do
		SW1282917929_fn_duihua()
		SW1282917929_fn_tankuang()
		if stomMultiColorTap("自动战斗",{--自动战斗
		{   45, 1110, 0xd6f3ff},
		{   60, 1080, 0xe7f7ff},
		{   45, 1081, 0xd6efff},
		{   60, 1095, 0xdef7ff},
		}) then
		elseif stomMultiColorTap("自动战斗2",{--自动战斗
			{   52, 1087, 0xd6f3ff},
			{   71, 1084, 0x52a2de},
			{   67, 1110, 0x429ade},
			{   27, 1103, 0x7bdbf7},
		})	then
		end
		if stomMultiColor("关闭死亡",{
			{  552,  540, 0x3165ad},
			{  545,  541, 0x3965a5},
			{  550,  556, 0x3165a5},
			{  545,  581, 0x7ba6de},
		})  then
			hdtap(551,  864)
		end			
	stomLog("pro阶段."..pro_num)
	stomMultiColorTap("等级奖励",{
		{  416,  868, 0x4aa2ef},
		{  417,  812, 0x4aa6e7},
		{  416,  914, 0x4aa2ef},
	})
	stomMultiColorTap("首冲奖励",{
		{  185,  698, 0xe4c22d},
		{  190,  653, 0xbb4411},
		{  206,  687, 0xeacb74},
		{  196,  674, 0xbb4411},
	})
	stomMultiColorTap("没有充值则关闭",{
		{  549, 1000, 0xc64129},
		{  188,  640, 0xbd4110},
		{  185,  680, 0xbd4510},
		{  207,  728, 0xe7cf7b},
	})
	stomMultiColorTap("绑定账号奖励",{
	{  212,  642, 0xe5c630},
	{  217,  589, 0xe6c33c},
	{  217,  613, 0x996611},
	{  592,  492, 0xf7d25e},
})
	stomMultiColorTap("实名奖励",{
	{  188,  649, 0xe7c763},
	{  181,  596, 0xe7c342},
	{  179,  696, 0xe7c329},
})
	stomMultiColorTap("关闭熊猫",{
		{  268,  529, 0x3165ad},
		{  278,  549, 0x3165ad},
		{  331,  443, 0x3965a5},
		{  343,  459, 0x3965a5},
	})
	stomLog("jiangli_num="..jiangli_count)
		if pro_num==0 then	
			if stomMultiColor("未进入奖励",{
				{  572,  811, 0x3996de},
				{  572,  824, 0x3992d6},
				{  594,  869, 0x08385a},
				{  607,  869, 0x103852},
			})then
				hdtap(604,  768)
				stommSleep(300)
			end
			if stomMultiColor("在及奖励界面",{
				{   61,  158, 0x73a2ce},
				{  167,  158, 0x7baad6},
				{  349,  156, 0x7ba6d6},
				{  549,  156, 0x73a6ce},
			}) then
			hdtap(499,  231)
			stommSleep(999)
			if jiangli_num==0 then
				hdtap(435,  231)
				jiangli_num=1
			elseif jiangli_num==1 then
				hdtap(368,  232)
				jiangli_num=2
			elseif jiangli_num==2 then
				hdtap(295,  232)
				jiangli_num=3
			elseif jiangli_num==3 then
				hdtap(348,   98)
				jiangli_count=jiangli_count+1
				stomLog(jiangli_count)
				jiangli_num=0
			end
			stommSleep(888)
			if jiangli_count>=1 then
				pro_num=1
				break
			end
		end
	elseif pro_num==1 then
				stomMultiColorTap("关闭上个模式弹窗",{
				{  579,  988, 0x9c2800},
				{  584,  992, 0x841c00},
				{  582,  985, 0x842000},
			})
			stomMultiColorTap("打开左侧三角",{
				{  542,   32, 0x318ace},
				{  542,   26, 0x52aeef},
				{  547,   27, 0x427dc6},
			})
			stomMultiColorTap("进入商城1",{
				{  417,   26, 0xc65921},
				{  404,   20, 0xe7c763},
				{  403,   41, 0xf7d363},
				{  398,   34, 0xe7b64a},
			})
			stomMultiColorTap("进入商城2",{
				{  478,   26, 0xc65521},
				{  472,   19, 0xe7c763},
				{  471,   40, 0xefd363},
				{  465,   23, 0xe7b242},
			})
			stomMultiColorTap("进入商城3",{
				{  408,   42, 0xf7d763},
				{  410,   28, 0xe7c75a},
				{  409,   47, 0xf7d363},
				{  410,   48, 0x734110},
			})
			if stomMultiColorTap("选择经验书",{
				{  498,  509, 0x3165ad},
				{  495,  524, 0x3169ad},
				{  477,  516, 0xb5d7f7},
				{  474,  584, 0xb5d3f7},
			})then
			elseif  stomMultiColorTap("选择经验书2",{
				{  406,  509, 0x3165ad},
				{  402,  552, 0x3165a5},
				{  405,  573, 0x3965a5},
				{  396,  590, 0x3165a5},
			})then
			end
			if stomMultiColorTap("当前商品是经验书且能够购买",{
				{  545,  709, 0x3965a5},
				{  533,  761, 0x3965a5},
				{  542,  776, 0x3165a5},
				{  200,  863, 0x00ff00},
			})then
				for var= 1, 10 do
					hdtap(92,  898)--购买
					stommSleep(60)
				end
				buybooknum=	buybooknum+1
			else
				nobook=nobook+1
			end
			if nobook>10 or buybooknum>5 then
				hdtap(415,  100)
				pro_num=2
				break
			end
			if stomMultiColor("元宝不足",{
				{  575,  529, 0x3965a5},
				{  575,  536, 0x3169ad},
				{  568,  547, 0x3165ad},
				{  556,  600, 0xadd7f7},
			}) or stomMultiColor("元宝不足红色",{
				{  202,  867, 0xff0000},
				{  193,  867, 0xff0000},
				{  199,  863, 0xff0000},
			})then
				stommSleep(500)
				hdtap(130, 1093)				
				stommSleep(300)
				--hdtap(130, 1093)
				pro_num=2
				stomLog("pro函数阶段即将进入"..pro_num)
				break
			end
		elseif pro_num==2 then
			stomMultiColorTap("关闭上个模式弹窗",{
				{  579,  988, 0x9c2800},
				{  584,  992, 0x841c00},
				{  582,  985, 0x842000},
			})			
			if stomMultiColor("关闭商城",{
				{   97,  738, 0x946910},
				{  103,  889, 0xad6d18},
				{  109,  790, 0xe7cb63},
				{  561,  197, 0xffffff},
			})then
				hdtap(389,   92)
			end
			if stomMultiColor("元宝不足",{
				{  575,  529, 0x3965a5},
				{  575,  536, 0x3169ad},
				{  568,  547, 0x3165ad},
				{  556,  600, 0xadd7f7},
			}) or stomMultiColor("元宝不足红色",{
				{  202,  867, 0xff0000},
				{  193,  867, 0xff0000},
				{  199,  863, 0xff0000},
			})then
				stommSleep(500)
				hdtap(130, 1093)				
				stommSleep(300)
				hdtap(130, 1093)
			end
			stomMultiColorTap("打开背包",{
				{  110, 1089, 0x7b7952},
				{  112, 1104, 0x847952},
				{  105, 1079, 0x847942},
			})
			stomMultiColorTap("打开背包2",{
				{  110, 1088, 0xf7d763},
				{  103, 1079, 0xffcb52},
				{  107, 1110, 0xf7d363},
			})
			stomMultiColorTap("打开背包3",{
				{  115, 1088, 0x67350c},
				{  106, 1079, 0xf8ca53},
				{  110, 1091, 0xf5d05e},
			})
			if buttonnotfind > 3 or booknotfind > 3 then
				pro_num=3
				stommSleep(500)
				hdtap(460,   93)	
				break
			end
			if stomMultiColor("在背包",{
				{  191,  188, 0xde6d84},
				{  152,  188, 0x5ab2ff},
				{  111,  188, 0xefcb6b},
				{   69,  188, 0xefa263},
			}) then
				--[[stomMultiColorTap("整理背包",{
					{   90,  891, 0xa57118},
					{   92,  864, 0xe7c331},
					{   97,  935, 0xe7c342},
				})	]]
				stommSleep(500)
				if getbook==0 then
					x,y = findMultiColorInRegionFuzzy( 0x5aa6c6, "-20|-18|0xbdc3bd,-9|19|0x52a2bd",90, 150, 596, 534, 982)
					if x ~= -1 then	--找经验书	
						stomtap(x,y)
						stommSleep(300)
						getbook=1
						--[[touchDown(x,y)
						stommSleep(2000)
						for i = 0, 475-x , 5 do
						touchMove(x+i,  y)
						stommSleep(100)
						end
						for j= 0, y-640, 5 do
							touchMove(475,  y-j)
							stommSleep(70)
						end
						touchUp(475,640)]]
					else 
						stommSleep(300)
						booknotfind=booknotfind+1
						stomLog("booknotfind"..booknotfind)
					end
				elseif getbook==1 then
					x,y = findMultiColorInRegionFuzzy( 0xe7cf39, "7|-14|0x9c6510,0|24|0x9c6910,11|24|0x9c6510",90, 11, 224, 431, 988)
					--x,y = findMultiColorInRegionFuzzy( 0x946510, "0|7|0x9c6510,0|14|0x946518,-7|66|0xe7c329", 90, 16, 216, 464, 931)
					if x ~= -1 then	--找使用按钮
						for var= 1, 10 do
						stomtap(x,y)
						stommSleep(500)
						end
						stommSleep(500)
						hdtap(460,   93)	
						stomLog("使用了经验书")
						pro_num=3
					else 
						stommSleep(300)
						buttonnotfind=buttonnotfind+1
						stomLog("buttonnotfind"..buttonnotfind)
					end
				end
			end
		elseif pro_num == 3 then
			break
		end
	stommSleep(500)
	protimeend=os.time()
	if protimeend -protimestart > 3*60 then
		break
	end
	end--while
	end--if战斗中
end

function SW1282917929_fn_CZ()
	if 	stomMultiColorTap("商城",{
			{  561,  201, 0xffffff},
			{   90,  793, 0xe7d339},
			{  559,  369, 0x5a96c6},
			{  197,  778, 0xce924a},
		}) or stomMultiColorTap("账号",{
			{  286,  436, 0x2959a5},
			{  300,  497, 0xb5d7f7},
			{  442,  524, 0xdeb64a},
			{  527,  529, 0x4275b5},
		}) 
		then	
		stomtoast("进入充值模式")
		local choice = 0--dialogRet("请选择账号注册模式：", "自动", "手动", "", 5);
		stommSleep(300)
		local loop=0
		local flag=0
		local getloop = 0
		local num = 0
		local m = math.random(6,12) 
		local mima = myRand(3,m,2)
		local yanzhenma
		local fa = 0
		local messgwait =4000
		getPhoneType = "lx"
		docks = "1112"--1156
		while (true) do
			if loop==0 then
				--DuoYiCZ([],[],[])
				stomMultiColorTap("多益点账号注册",{
						{  215,  430, 0x318aff},
						{  217,  444, 0x318aff},
						{  291,  511, 0x1086f7},
						{  444,  320, 0xd60010},
					})				
				if choice==0 or choice==3 then
					--DuoYiCZ(getloop,num,mima,yanzhenma,fa,getPhoneType,docks)
						stomLog("获取号码。。。"..getloop)
						if getloop == 0 then						
							check_Rules = 1
							Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
							if Telnum then
								stomLog(Telnum)
								getloop = 1
								num = 0
							else
								stomLog("重新获取号码中")
								stommSleep(2000)
								num = num + 1
							end
							--[[if num > 3 then
								stomLog("获取号码失败")
								stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
								stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
							end]]
						elseif getloop == 1 then
							phonenumber = Telnum
							if stomMultiColor("在注册界面",{
								{  535,  369, 0xefebe7},
								{  466,  710, 0x1086f7},
								{  537,  534, 0x000000},
								{  466,  647, 0xffffff},
							}) then 
								stomMultiColorTap("多益注册主界面点手机号",{
									{  473,  423, 0xb5aead},
									{  468,  435, 0xffffff},
									{  151,  488, 0x108af7},
									{  158,  643, 0x108aff},
								})
								if stomMultiColor("多益输入手机号",{
									{  467,  427, 0xffffff},
									{  468,  449, 0xffffff},
									{  463,  502, 0xffffff},
									{  470,  657, 0xffffff},
								}) then
									stommSleep(500) 
									stomInpuText(phonenumber)
									getloop=2
									stommSleep(500) 
								end
							end
						elseif getloop == 2 then
							if stomMultiColorTap("多益输手机号已填写关闭键盘",{
								{  541,  401, 0xefebe7},
								{  470,  653, 0x949694},
								{  470,  670, 0x949294},
								{  461,  661, 0x9c9694},
							}) then
								stommSleep(500)
								stomMultiColorTap("多益获取验证码",{
									{  461,  716, 0x108af7},
									{  485,  759, 0x1086f7},
									{  534,  659, 0xe7efef},
									{  458,  801, 0x108aff},
								})
							end
							stomMultiColorTap("多益输点击密码框",{
								{  312,  435, 0xffffff},
								{  311,  441, 0xadaead},
								{  313,  485, 0x84827b},
								{  309,  519, 0x9c9694},
							})					
							if stomMultiColor("多益输密码未输入",{
								{  420,  418, 0xffffff},
								{  420,  434, 0xffffff},
								{  420,  448, 0xffffff},
								{  414,  359, 0x605e5d},
								{  418,  385, 0x797b7c},
							})	then
								stommSleep(500)
								stomInpuText(mima)
							end
							if stomMultiColorTap("多益密码已输入关闭键盘",{
								{  350,  332, 0xf7f7f7},
								{  419,  419, 0x000000},
								{  420,  433, 0x000000},
								{  420,  447, 0x000000},
								{  500,  457, 0x9f9ea2},
							}) then
								getloop=3
							end
						elseif getloop == 3 then
							stomLog("获取短信..."..fa)
							messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
							stomMultiColorTap("多益密码已输入关闭键盘",{
								{  350,  332, 0xf7f7f7},
								{  419,  419, 0x000000},
								{  420,  433, 0x000000},
								{  420,  447, 0x000000},
								{  500,  457, 0x9f9ea2},
							})
							if messg then
								messgwait=300
								stomMultiColorTap("多益验证码开始输入",{
								{  391,  419, 0xffffff},
								{  388,  442, 0x848284},
								{  389,  457, 0xa59e9c},
								{  393,  495, 0xc6c3bd},
							})				
								--messg = string.gsub(messg,"30分","")
								--messg = string.sub(messg,9)
								yanzhenma = string.match(messg,"%d+")
								stomLog("yanzhenmaOK-"..yanzhenma)
								toast(yanzhenma)
								if stomMultiColor("多益验证码输入界面",{
									{  487,  331, 0x010101},
									{  498,  364, 0xbfc0bf},
									{  489,  427, 0xffffff},
									{  408,  420, 0x000000},
								}) or stomMultiColor("多益验证码输入界面B",{
									{  424,  420, 0xffffff},
									{  423,  329, 0x191a1a},
									{  428,  340, 0x9a949a},
									{  423,  364, 0x4a4d4a},
								}) then
									stommSleep(300)
									stomInpuText(yanzhenma)
									stommSleep(100)			
									stomtap(413,  320) 
									getloop =5
								else nLog("未找到输入界面")
								end
								stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
								stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
							else
								stomLog("get sms")
								fa = fa +1
							end	
							if fa > 10 then
								stomLog("获取短信失败")
								stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
								stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
								getloop = 4
							end
							stommSleep(messgwait)
						elseif getloop == 4 then
							stomMultiColorTap("多益取消验证码输入",{
								{  475,  303, 0xffffff},
								{  487,  330, 0x080808},
								{  492,  339, 0x8c9294},
								{  498,  365, 0xbfc0bf},
							})
							stomMultiColorTap("返回",{
								{  536,  300, 0x848684},
								{  528,  306, 0x848684},
								{  544,  305, 0x84868c},
							})
							if stomMultiColorTap("多益注册账号",{
								{  438,  316, 0xd60010},
								{  328,  319, 0xf7f7f7},
								{  297,  484, 0x108af7},
								{  211,  793, 0xf7f7f7},
							}) then
								getloop=0
								fa = 0								
							end
							if stomMultiColor("多益注册界面返回getloop0",{
								{  529,  534, 0x000000},
								{  254,  532, 0xf7f7f7},
								{  486,  707, 0x108aff},
								{  157,  647, 0x1086f7},
							}) then
								getloop=0
								fa = 0
							end							
						elseif getloop == 5 then
							if stomMultiColorTap("立即注册",{
								{  172,  463, 0x108aff},
								{  172,  662, 0x1086f7},
								{  243,  714, 0xf7f7f7},
								{  525,  458, 0xefefef},
							}) then
								stommSleep(3000)
								if stomMultiColor("绑定成功",{
									{  363,  402, 0x63ba63},
									{  368,  597, 0x000000},
									{  370,  648, 0x4a494a},
									{  542,  556, 0x9c9a9c},
								})	or stomMultiColor("绑定成功C",{
									{  363,  402, 0x63ba63},
									{  368,  597, 0x000000},
									{  370,  648, 0x4a494a},
									{  542,  556, 0x9c9a9c},
								})	or stomMultiColor("绑定成功B",{
									{  314,  413, 0x63ba63},
									{  535,  530, 0x000000},
									{  538,  831, 0x84868c},
									{   90,  531, 0xf7f7f7},
								})	then
									stomLog("绑定成功");stommSleep(3000)
									getloop = 99
								else getloop =4 
									stomLog("绑定失败")
								end
							end
						end
				end
				if choice==1 then
					
				end
				if stomMultiColor("绑定成功",{
					{  363,  402, 0x63ba63},
					{  368,  597, 0x000000},
					{  370,  648, 0x4a494a},
					{  542,  556, 0x9c9a9c},
				})	or stomMultiColor("绑定成功C",{
					{  363,  402, 0x63ba63},
					{  368,  597, 0x000000},
					{  370,  648, 0x4a494a},
					{  542,  556, 0x9c9a9c},
				})	or stomMultiColor("绑定成功B",{
					{  314,  413, 0x63ba63},
					{  535,  530, 0x000000},
					{  538,  831, 0x84868c},
					{   90,  531, 0xf7f7f7},
				})	
					then
					stomopenURL("prefs:root=STORE");
					loop=1
				end
				--stomLog(flag)
				--[[if flag==0 then
					if stomMultiColor("已登录",{
						{   39,  332, 0x000000},
						{   76,   92, 0x007aff},
						{  105,  330, 0x060606},
						{  202,  331, 0xffffff},
					}) then
						stommSleep(300)
						local user = dialogRet("是否注销", "是", "否", "", 5);
						flag=1
						stommSleep(4000)
						if user==0 or user==3 then
						stomtap(250,250)
						elseif user==1 then
						OpenApp("com.duoyi.shenwu3")					
						loop=1					
						end
					end
				end]]
				stomMultiColorTap("注销",{
					{  307,  610, 0x007aff},
					{  327,  604, 0x007aff},
					{  132,  375, 0xf7f7f7},
					{  279,  367, 0x000000},
				})	
				if stomMultiColor("未登录",{
					{   38,  237, 0x027bff},
					{   72,  244, 0x0f81ff},
					{  138,   84, 0x000000},
					{  271,  433, 0xffffff},
				})then
					OpenApp("com.duoyi.shenwu3")					
					loop=1
				end
				-- 切换至游戏内充值界面
			elseif loop==1 then
				
				if stomMultiColor("长账号纵支付密码",{
					{   99,  402, 0xc7c7cd},
					{  106,  402, 0xc7c7cd},
					{  104,  421, 0xc7c7cd},
					{  126,  415, 0xd0d0d5},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(300)
					stomMultiColorTap("确认密码",{
						{  455,  505, 0x007aff},
						{  458,  505, 0x007aff},
						{  462,  505, 0x007aff},
					})
				end
				if stomMultiColor("长账号横支付密码",{
					{  544,  768, 0x676f73},
					{  506,  550, 0x17191a},
					{  427,  348, 0xc7c7cd},
					{  420,  373, 0xc7c7cd},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(300)
					stomMultiColorTap("确认密码",{
						{  367,  706, 0x007aff},
						{  367,  709, 0x007aff},
						{  367,  713, 0x007aff},
					})
				end
				if stomMultiColor("账号和密码横向CN",{
					{  191,  196, 0x000000},
					{  230,  196, 0x000000},
					{  400,  270, 0x9d9dad},
					{   99,  343, 0xd4d4d9},
				}) or stomMultiColor("账号和密码横向EN",{
				{  188,  232, 0x000000},
				{  229,  232, 0x000000},
				{  410,  331, 0xffffff},
				{  100,  380, 0xc7c7cd},
				})then
					stommSleep(500)
					stomtap(598, 1109)
					stomInpuText(applePWD)
					stommSleep(300)
					stomtap(353,  332)
				end	
				if 	stomMultiColor("账号和密码横向CN",{
					{  567,  436, 0x000000},
					{  582,  481, 0x000000},
					{  500,  620, 0xffffff},
					{  431,  690, 0x007aff},
				}) or stomMultiColor("账号和密码横向EN",{
					{  596,  443, 0x000000},
					{  598,  480, 0x000000},
					{  496,  735, 0xffffff},
					{  460,  348, 0xc7c7cd},
					{  367,  709, 0x007aff},
				})then
					stommSleep(500)
					stomtap(27, 1055)
					stomInpuText(applePWD)
					stommSleep(300)
					stomtap(545,  344)
				end							
				
				stomMultiColorTap("神武--账号关闭",{
					{  599,  997, 0xadf3ef},
					{  596,  990, 0x2969ce},
					{  102,  927, 0x8cbae7},
					{  323,  683, 0xc6dbf7},
				})				
					--[[stomMultiColorTap("注册完成关闭账号注册成功",{
						{  537,  830, 0x878786},
						{  537,  821, 0xececeb},
						{  537,  298, 0x848483},
						{  535,  308, 0xefefee},
					})		]]				
					stomMultiColorTap("注册完成关闭多益账号显示",{
						{  437,  831, 0x8c8684},
						{  221,  389, 0x528af7},
						{  280,  484, 0x1086f7},
						{  443,  311, 0xde0010},
					})				
					stomMultiColorTap("单行密码已输入确认",{
						{  461,  489, 0x007aff},
						{   98,  397, 0x000000},
						{  114,  397, 0x000000},
						{  474,  305, 0x606668},
						{  192,  217, 0x000000},
					})
					stomMultiColorTap("无法连接IT横粗",{
						{  252,  559, 0x007aff},
						{  367,  393, 0x000000},
						{  373,  471, 0x8c999c},
						{  364,  578, 0xb7c2c7},
					})
					stomMultiColorTap("使用现有B",{
						{  343,  503, 0x007aff},
						{  249,  454, 0x007aff},
						{  173,  548, 0x007aff},
						{  466,  545, 0x242526},
					})
					stomMultiColorTap("设置纵粗",{
						{  444,  668, 0x007aff},
						{  428,  667, 0x007aff},
						{  224,  476, 0x000000},
						{  157,  667, 0x007aff},
						{  462,  562, 0x000000},
					})
				stomMultiColorTap("网络异常重登",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("无法连接IT纵粗",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				if stomMultiColor("纵向请输入M粗sort",{
					{  100,  396, 0xc7c7cd},
					{  200,  225, 0x000000},
					{  264,  232, 0x515151},
					{  462,  489, 0x007aff},
				})then
					stommSleep(500)
					stomInpuText("Aa112211")
					stommSleep(500)
					stomMultiColorTap("登录",{
					{  462,  489, 0x007aff},
					{  100,  396, 0xc7c7cd},
					{  200,  225, 0x000000},
					{  264,  232, 0x515151},
				})
				end		
			
				if stomMultiColor("纵向请输入M粗long",{
					{  100,  396, 0xc7c7cd},
					{  200,  225, 0x000000},
					{  264,  232, 0x515151},
					{  462,  489, 0x007aff},
				})then
					stommSleep(500)
					stomInpuText("Aa112211")
					stommSleep(500)
					stomMultiColorTap("登录",{
					{  462,  489, 0x007aff},
					{  100,  396, 0xc7c7cd},
					{  200,  225, 0x000000},
					{  264,  232, 0x515151},
				})
				end	
				stomMultiColorTap("验证失败再次粗",{
					{  652,  403, 0x007aff},
					{  510,  252, 0x000000},
					{  585,  251, 0x000000},
					{  763,  303, 0xd8dcda},
				})
				stomMultiColorTap("确认购买纵粗？？",{
					{  425,  666, 0x007aff},
					{  166,  483, 0x000000},
					{  422,  483, 0x616161},
					{  554,  678, 0xf9f9f9},
				})			
				stomMultiColorTap("使用现有",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("使用现有纵",{
					{  277,  537, 0x007aff},
					{  305,  430, 0x000000},
					{  334,  429, 0x595d5d},
					{  473,  635, 0xced2d2},
				})				
				if stomMultiColor("登录换行",{
					{   38,  968, 0x363737},
					{  581,  444, 0x4b4d4f},
					{  581,  481, 0x000000},
					{  437,  413, 0x007aff},
				})	then
					stommSleep(500)	
					stomMultiColorTap("登录换行",{
					{   38,  968, 0x363737},
					{  581,  444, 0x4b4d4f},
					{  581,  481, 0x000000},
					{  437,  413, 0x007aff},
				})	
					stommSleep(500)	
					if stomMultiColor("输入txt",{
						{  491,  348, 0xc7c7cd},
						{  485,  396, 0xffffff},
						{  270,  377, 0x605f60},
						{  365,  412, 0x007aff},
					})	then
						stomInpuText(applePWD)
						stommSleep(300)
						stomMultiColorTap("点击上行",{
							{  550,  688, 0xffffff},
							{  488,  688, 0xffffff},
							{  338,  518, 0xccced1},
						})		
						--复制 @163.com
					end
				end
				if stomMultiColor("登录换行纵向",{
					{  191,  196, 0x000000},
					{  232,  203, 0x585c5b},
					{  362,  292, 0xffffff},
					{  100,  345, 0xc7c7cd},
				}) or stomMultiColor("登录换行纵向B",{
					{   93,  321, 0xd0dafc},
					{  195,  232, 0x000000},
					{  175,  384, 0xffffff},
					{  106,  332, 0xffffff},
					{  262,  244, 0x000000},
				})  	then
					stommSleep(500)
					stomMultiColorTap("换行",{
					{  597, 1079, 0x353535},
					{  232,  203, 0x585c5b},
					{  362,  292, 0xffffff},
					{  100,  345, 0xc7c7cd},
				})
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(300)
					stomMultiColorTap("点击上行",{
						{  369,  298, 0xffffff},
						{  232,  203, 0x585c5b},
						{  362,  292, 0xffffff},
						{  100,  345, 0xc7c7cd},
					})		
						--复制 @163.com
				end
				stomMultiColorTap("设置",{
					{  217,  676, 0x007aff},
					{  401,  550, 0x636566},
					{  400,  579, 0x000000},
					{  405,  644, 0x000000},
				})	
				stomMultiColorTap("设置纵向",{
					{  472,  663, 0x007aff},
					{  375,  664, 0xccd0d1},
					{  221,  484, 0x000000},
					{  273,  488, 0x666869},
				})	
				stomMultiColorTap("15分钟后需要",{
					{  357,  705, 0x007aff},
					{  409,  704, 0x56a5fd},
					{  466,  704, 0x007aff},
					{  362,  448, 0x000000},
				})	
				if stomMultiColor("请输入M-sort",{
					{  548,  493, 0x000000},
					{  427,  406, 0xffffff},
					{  425,  352, 0xcdcdd3},
					{  500,  715, 0x000000},
				})then
					stommSleep(500)
					stomInpuText("Aa112211")
					stommSleep(500)
					stomMultiColorTap("登录",{
						{  367,  710, 0x007aff},
						{  367,  613, 0xcdd6dd},
						{  294,  600, 0x606669},
						{  519,  715, 0x000000},
					})
				end
				if stomMultiColor("请输入M横向-long",{
					{  570,  509, 0x000000},
					{  550,  766, 0x5d6568},
					{  502,  546, 0x000000},
					{  418,  347, 0xc7c7cd},
					{  418,  355, 0xc7c7cd},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(500)
					stomMultiColorTap("登录",{
					{  363,  656, 0xd8e6f0},
					{  361,  694, 0x007aff},
					{  366,  709, 0x007aff},
					{  369,  764, 0xe6eaeb},
				})
				end				
				if stomMultiColor("纵向请输入M",{
						{  196,  225, 0x000000},
						{  465,  315, 0x1d1e1e},
						{  100,  396, 0xc7c7cd},
						{  101,  431, 0xcacccc},
					})then
					stomInpuText("Aa112211")
					stommSleep(500)
					stomMultiColorTap("登录",{
						{  450,  486, 0x007aff},
						{  144,  435, 0xf8f8f8},
						{  198,  225, 0x000000},
						{  495,  314, 0x222222},
					})
				end
				stomMultiColorTap("无法连接IT",{
					{  437,  628, 0x007aff},
					{  472,  626, 0xabd1fb},
					{  146,  521, 0x000000},
					{  222,  531, 0x8f8f8f},
				})
				if stomMultiColorTap("购买完成",{
					{  548,  493, 0x000000},
					{  427,  406, 0xffffff},
					{  425,  352, 0xcdcdd3},
					{  500,  715, 0x000000},
				}) or stomMultiColorTap("购买完成B",{
					{  309,  644, 0x007aff},
					{  259,  491, 0x000000},
					{  411,  553, 0x000000},
					{  517,  556, 0xf9f9f9},
				})then
					stommSleep(500)					
					OpenApp("com.duoyi.shenwu3")
				--else stomLog("notfound")
				end			
			end
				stomMultiColorTap("圆形实名",{
						{  138,  628, 0xefbe18},
						{  583,  415, 0x4aaade},
						{  554,  453, 0xb5dbff},
						{  558,  543, 0xefbe4a},
					})
				if stomMultiColor("实名认证窗体",{--实名认证窗体
						{  547,  528, 0x000000},
						{  534,  563, 0x000000},
						{  538,  585, 0x000000},
						{  527,  609, 0xe7e7e7},
						})==true then
					stomMultiColorTap("第一个文本框",{
							{  303,  554, 0xa5a6a5},
							{  307,  434, 0xced3d6},
							{  307,  459, 0xd6cfce},
							{  312,  490, 0xffffff},
						})	
					stommSleep(500)
					stomInpuText("彭会")
					stommSleep(2000)
					if 
					stomMultiColorTap("第二个文本框",{
						{  405,  449, 0xffffff},
						{  406,  475, 0xffffff},
					}) then 
					stommSleep(500)
					stomInpuText("440282195610226964")
					stommSleep(500)
					stomMultiColorTap("提交",{--提交
							{  411,  613, 0x1088fb},
							{  408,  524, 0x1088f8},
							{  396,  583, 0xc7e4ff},
							{  354,  550, 0xfdfefe},
						})
					stommSleep(500)
					stomMultiColorTap("确定",{--确定
							{  247,  725, 0x1086f7},
							{  414,  340, 0xefebef},
							{  345,  607, 0xf7f7f7},
							{  418,  554, 0x100808},
						})
					end
				end			
				if stomMultiColor("在外观商城程序结束",{
					{  451,  565, 0x94c3ef},
					{  539,  221, 0xdeefe7},
					{  161,  475, 0x3965a5},
					{  549,  903, 0x4a92c6},
				}) or stomMultiColor("在外观商城程序结束B",{
					{  378,  478, 0xbdd3f7},
					{   57,  664, 0x21496b},
					{  288,  311, 0x73beef},
					{  580,  639, 0xadcbff},
				}) or stomMultiColor("短信",{
					{  278,   80, 0x000000},
					{  324,   77, 0x535353},
					{  383,  162, 0xf9f9f9},
					{  581,   88, 0x007aff},
				})then
					stomcloseApp("com.duoyi.shenwu3")
					stommSleep(5000)
					stomrunApp("com.duoyi.shenwu3")
					stomMultiColor("在外观商城关闭",{
						{  581,  977, 0x429ade},
						{  485,  208, 0xefc75a},
						{  133,  204, 0x73baef},
						{  130,  599, 0xbddbff},
					})
					stommSleep(1000)
					stomMultiColor("个人属性关闭",{
						{  599,  997, 0xadf3ef},
						{  545,  566, 0x4aa6ef},
						{  392,  544, 0xde6984},
						{   82,  654, 0xe7c331},
					})
					stomtoast("充值流程结束")
						--购买升级所需物品
					break
				end
			stomLog(loop)
			stommSleep(100)
		end
	end
end

function SW1282917929_fn_CZ2()
	if --[[stomMultiColorTap("商城",{
			{  561,  201, 0xffffff},
			{   90,  793, 0xe7d339},
			{  559,  369, 0x5a96c6},
			{  197,  778, 0xce924a},
		}) or ]]stomMultiColor("账号",{
			{  302,  583, 0x3165ad},
			{  289,  432, 0x295da5},
			{  294,  439, 0xb5d3f7},
			{  299,  446, 0x295da5},
			{  444,  524, 0xe7cb63},
		}) then	
		stomtoast("进入充值模式")
		local choice = 0--注册开关--dialogRet("请选择账号注册模式：", "自动", "手动", "", 5);
		local loop=0--0注册模式 1充值模式
		local flag=0
		local getloop = 2--2正常进入，0表单界面
		local num = 0
		local m = math.random(6,8) 
		local mima = myRand(3,m,2)
		local yanzhenma
		local BlackPhone=0
		local getphonenum=0
		local messgwait=4000
		local inputphone=0
		local yanzhengtoast=0
		local getphonenumcount=0
		local chongzhiTimeStart=os.time()
		shouchong=0
		fa = 0
		getPhoneType = "lx"
		docks = "1112"--1156
		stomopenURL("prefs:root=STORE");
		stommSleep(2000)
		while (true) do
			isfront = stomisFrontApp("com.duoyi.shenwu3")
			if isfront==1 then
				yanzhengtoast =1
			end				
			if yanzhengtoast == 0 then
				stomopenURL("prefs:root=STORE");
				stomtoast("请检查是否需要注销并返回游戏")
				stommSleep(8000)
			end
			SW1282917929_fn_duihua()		
			if loop==0 then
				if choice==0 then
					stomLog("当前阶段.."..getloop)
					if stomMultiColor("密码未输入",{
						{  308,  422, 0x8c8a8c},
						{  310,  453, 0xadb2b5},
						{  311,  519, 0x9c9694},
						{  311,  594, 0x949694},
						{  311,  646, 0x848684},
					}) then
						stommSleep(500)
						stomMultiColorTap("多益输点击密码框",{
							{  312,  435, 0xffffff},
							{  311,  441, 0xadaead},
							{  313,  485, 0x84827b},
							{  309,  519, 0x9c9694},
						})
						stommSleep(500)
						stomInpuText(mima)
						stommSleep(999)
					end
					if stomMultiColorTap("多益密码已输入关闭键盘",{
						{  350,  332, 0xf7f7f7},
						{  419,  419, 0x000000},
						{  420,  433, 0x000000},
						{  420,  447, 0x000000},
						{  500,  457, 0x9f9ea2},
					}) then
						stommSleep(500)
					end
					if getloop == 0 then
						if getphonenum==0 then
							if getphonenumcount <= 4 then
								check_Rules = 1
								Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
							else stomtoast("获取号码已到达5次",60)
							end
							if Telnum then
								stomLog(Telnum)
								phonenumber = Telnum
								num = 0
								getphonenum=1
								getphonenumcount = getphonenumcount + 1
							else
								stomLog("重新获取号码中")
								stommSleep(2000)
								num = num + 1
							end
						end
						if getphonenum==1 then
							if stomMultiColor("手机号未输入",{
								{  467,  417, 0x8c8684},
								{  466,  422, 0x8c8a8c},
								{  465,  432, 0x848a8c},
								{  465,  451, 0x8c8684},
								{  476,  451, 0xa5a6ad},
							}) then
								stomMultiColorTap("多益注册主界面点手机号",{
									{  473,  423, 0xb5aead},
									{  468,  435, 0xffffff},
									{  151,  488, 0x108af7},
									{  158,  643, 0x108aff},
								})
								stommSleep(1000)
								--if inputphone==0 then
									stomLog("执行了stomInpuText"..Telnum)
									stomInpuText(Telnum)
									--inputphone=1
								--else
									--stomInpuStr(Telnum)
									--inputphone=0
								--end
								stommSleep(300)
								phoneok=1
							end
						end
						if phoneok==1 and stomMultiColorTap("手机号已输且验证码能获取",{
							{  455,  709, 0x1086f7},
							{  455,  736, 0x108af7},
							{  455,  764, 0x108af7},
							{  455,  785, 0x1086f7},
						}) then
							phoneok=2
						end					
						if stomMultiColorTap("多益获取验证码",{
							{  453,  712, 0x73797b},
							{  453,  734, 0x73797b},
							{  453,  762, 0x73797b},
							{  453,  784, 0x73797b},
						}) and phoneok==2 then
							stommSleep(8888)
							messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)							
							getloop=1
						end
						stomMultiColorTap("多益输手机号已填写关闭键盘",{
							{  541,  401, 0xefebe7},
							{  470,  653, 0x949694},
							{  470,  670, 0x949294},
							{  461,  661, 0x9c9694},
						}) 
					elseif getloop == 1 then
						stomLog("获取短信..."..fa)
						if messg then
							stomtoast(yanzhenma)
							if BlackPhone==0 then
								BlackPhone=1
								messgwait=300
								stomtoast("已收验证码 正在处理",3)
								yanzhenma = string.match(messg,"%d+")
								stomLog("yanzhenmaOK-"..yanzhenma)
							else 
								stomtoast(yanzhenma)
							end
							if stomMultiColorTap("多益验证码未输入开始输入",{
								{  394,  525, 0x8c9294},
								{  396,  548, 0x948e94},
								{  390,  561, 0x84868c},
								{  383,  572, 0x7b8284},
							})then	
								stommSleep(500)
								stomInpuText(yanzhenma)
								stommSleep(2000)
								stomtap(568,  375)
								--stommSleep(300)
								--stomtap(389,  928)
							end
							if stomMultiColor("多益验证码未输入不操作",{
								{  394,  525, 0x8c9294},
								{  396,  548, 0x948e94},
								{  390,  561, 0x84868c},
								{  383,  572, 0x7b8284},
							})then
							else
								stommSleep(60)
								if stomMultiColor("立即注册",{
								{  172,  463, 0x108aff},
								{  172,  662, 0x1086f7},
								{  243,  714, 0xf7f7f7},
								{  525,  458, 0xefefef},
							}) then
									stommSleep(1000)
									--[[stomMultiColorTap("立即注册",{
									{  172,  463, 0x108aff},
									{  172,  662, 0x1086f7},
									{  243,  714, 0xf7f7f7},
									{  525,  458, 0xefefef},
								}) ]]
									stomtap(159,  562)
									stommSleep(9999)
									if stomMultiColor("绑定成功",{
										{  363,  402, 0x63ba63},
										{  368,  597, 0x000000},
										{  370,  648, 0x4a494a},
										{  542,  556, 0x9c9a9c},
									})	or stomMultiColor("绑定成功C",{
										{  363,  402, 0x63ba63},
										{  368,  597, 0x000000},
										{  370,  648, 0x4a494a},
										{  542,  556, 0x9c9a9c},
									})	or stomMultiColor("绑定成功B",{
										{  314,  413, 0x63ba63},
										{  535,  530, 0x000000},
										{  538,  831, 0x84868c},
										{   90,  531, 0xf7f7f7},
									})  or	stomMultiColor("红色已绑定",{
										{  437,  315, 0xd60008},
										{  221,  390, 0x4a8ef7},
										{  223,  458, 0x73aaff},
										{  299,  494, 0x108af7},
									})	then
										stomLog("绑定成功")
										--stommSleep(3000)
										getloop = 99
										--stomopenURL("prefs:root=STORE");
										stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
										stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)	
										loop=1
									else 
										--stomtoast("注册失败3秒后跳转")
										--stommSleep(3000)
										stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
										stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)	
										stomLog("绑定失败")	
										czendtime=os.time()
										--[[if czendtime-czstartime<90 then
											stomtoast("冻结操作，second="..(90-czendtime+czstartime),(90-czendtime+czstartime))
											stommSleep((90-czendtime+czstartime)*1000)
										end]]
										getloop =99--getloop=2为正常开始
									end	
								end	
							end
						else
							messgwait=4000
							messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
							stomLog("get sms")
							stomtoast("GetMegNO."..fa,4)
							fa = fa +1
						end
						if fa > 10 then
							stomLog("获取短信失败")
							stomtoast("get短信")
							stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
							stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
							getloop = 2
						end
						stommSleep(messgwait)
					elseif getloop == 2 then
						czstartime= os.time()
						stomtoast("等待开始",1)
						stommSleep(999)
						fa = 0	
						BlackPhone=0
						getphonenum=0
						inputphone=0
						stomMultiColor("账号",{
							{  302,  583, 0x3165ad},
							{  289,  432, 0x295da5},
							{  294,  439, 0xb5d3f7},
							{  299,  446, 0x295da5},
							{  444,  524, 0xe7cb63},
						}) 
						stomMultiColorTap("账号",{
							{  302,  583, 0x3165ad},
							{  289,  432, 0x295da5},
							{  294,  439, 0xb5d3f7},
							{  299,  446, 0x295da5},
							{  444,  524, 0xe7cb63},
						})
						stomMultiColorTap("取消表单",{
							{  537,  299, 0x8c8684},
							{  529,  305, 0x8c8684},
							{  544,  305, 0x84868c},
							{  537,  533, 0x080400},
							{  537,  559, 0x000000},
						})
						stomMultiColorTap("取消表单B",{
							{  537,  300, 0x848684},
							{  528,  306, 0x848684},
							{  530,  488, 0xefebef},
							{  252,  834, 0xf7f7f7},
						})
						if stomMultiColorTap("多益点账号注册",{
							{  215,  430, 0x318aff},
							{  217,  444, 0x318aff},
							{  291,  511, 0x1086f7},
							{  444,  320, 0xd60010},
						}) then
							getloop=0
						end	
					end
				end
					if stomMultiColor("绑定成功",{
						{  363,  402, 0x63ba63},
						{  368,  597, 0x000000},
						{  370,  648, 0x4a494a},
						{  542,  556, 0x9c9a9c},
					})	or stomMultiColor("绑定成功C",{
						{  363,  402, 0x63ba63},
						{  368,  597, 0x000000},
						{  370,  648, 0x4a494a},
						{  542,  556, 0x9c9a9c},
					})	or stomMultiColor("绑定成功B",{
						{  314,  413, 0x63ba63},
						{  535,  530, 0x000000},
						{  538,  831, 0x84868c},
						{   90,  531, 0xf7f7f7},
					})  or	stomMultiColor("红色已绑定",{
						{  437,  315, 0xd60008},
						{  221,  390, 0x4a8ef7},
						{  223,  458, 0x73aaff},
						{  299,  494, 0x108af7},
					})	then
						stomLog("绑定成功")
						stommSleep(3000)
						getloop = 99
						loop=1
					end
			elseif loop==1 then
				appleshop_12ios()
				SW1282917929_fn_tankuang()
				if shouchong==0 then
					shouchong_fun()
				end
				if stomMultiColorTap("首次充值弹窗18岁提示",{
					{  201,  432, 0x017bff},
					{  420,  513, 0x000000},
					{  416,  547, 0x6e6b6a},
					{  368,  469, 0x000000},
				}) or stomMultiColorTap("首次充值弹窗18岁提示-12",{
					{  205,  433, 0x007aff},
					{  211,  432, 0x1786fe},
					{  373,  480, 0x5d6466},
					{  314,  566, 0x000000},
				}) then
					shouchong=1
				end
				--[[isfront = stomisFrontApp("com.duoyi.shenwu3")
				if isfront==1 then
					yanzhengtoast =1
				end				
				if yanzhengtoast == 0 then
					stomopenURL("prefs:root=STORE");
					stomtoast("请检查是否需要注销并返回游戏")
					stommSleep(3000)
				end]]
				if stomMultiColor("sw设置界面",{
					{  295,  424, 0x215da5},
					{  283,  441, 0x295d9c},
					{  307,  444, 0x215da5},
					{  299,  494, 0xb5d7f7},
				})	then
					stomtap(414,34)
				end
				stomMultiColorTap("绿色对勾绑定成功",{
				{  537,  830, 0x848684},
				{  541,  530, 0x000000},
				{  540,  536, 0x100c10},
				{  541,  560, 0x393c42},
			})
				stomMultiColorTap("进入商城1",{
				{  417,   26, 0xc65921},
				{  404,   20, 0xe7c763},
				{  403,   41, 0xf7d363},
				{  398,   34, 0xe7b64a},
			})
				stomMultiColorTap("进入商城2",{
				{  478,   26, 0xc65521},
				{  472,   19, 0xe7c763},
				{  471,   40, 0xefd363},
				{  465,   23, 0xe7b242},
			})
			if myosver < 11 then
				if stomMultiColor("横向只输密码",{
					{  437,  348, 0xc7c7cd},
					{  437,  357, 0xc7c7cd},
					{  428,  382, 0xcdcdd3},
					{  420,  371, 0xcbcbd1},
				}) then
					stommSleep(300)
					stomInpuText(applePWD)
					stommSleep(300)
					stomtap(368,  692)
				end
				stomMultiColorTap("横向长账号设置",{
					{  203,  691, 0x007aff},
					{  204,  718, 0x007aff},
					{  189,  712, 0x007aff},
					{  425,  485, 0x000000},
				})
				if stomMultiColor("长账号纵支付密码",{
					{   99,  402, 0xc7c7cd},
					{  106,  402, 0xc7c7cd},
					{  104,  421, 0xc7c7cd},
					{  126,  415, 0xd0d0d5},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(300)
					stomMultiColorTap("确认密码",{
						{  455,  505, 0x007aff},
						{  458,  505, 0x007aff},
						{  462,  505, 0x007aff},
					})
				end
				if stomMultiColor("长账号横支付密码",{
					{  544,  768, 0x676f73},
					{  506,  550, 0x17191a},
					{  427,  348, 0xc7c7cd},
					{  420,  373, 0xc7c7cd},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(300)
					stomMultiColorTap("确认密码",{
						{  367,  706, 0x007aff},
						{  367,  709, 0x007aff},
						{  367,  713, 0x007aff},
					})
				end
				if stomMultiColor("账号和密码横向CN",{
					{  191,  196, 0x000000},
					{  230,  196, 0x000000},
					{  400,  270, 0x9d9dad},
					{   99,  343, 0xd4d4d9},
				}) or stomMultiColor("账号和密码横向EN",{
				{  188,  232, 0x000000},
				{  229,  232, 0x000000},
				{  410,  331, 0xffffff},
				{  100,  380, 0xc7c7cd},
				})then
					stommSleep(500)
					stomtap(598, 1109)
					stomInpuText(applePWD)
					stommSleep(500)
					stomtap(353,  332)
				end	
				if 	stomMultiColor("账号和密码横向CN",{
					{  567,  436, 0x000000},
					{  582,  481, 0x000000},
					{  500,  620, 0xffffff},
					{  431,  690, 0x007aff},
				}) or stomMultiColor("账号和密码横向EN",{
					{  444,  348, 0xc7c7cd},
					{  435,  344, 0xc7c7cd},
					{  436,  352, 0xc7c7cd},
					{  445,  378, 0xc7c7cd},
				})then
					stommSleep(500)
					stomtap(27, 1055)
					stomInpuText(applePWD)
					stommSleep(500)
					stomtap(545,  344)
				end		
			end
				--[[if 	stomMultiColorTap("支付密码纵向B",{
					{  523,  289, 0x686868},
					{  310,  330, 0x222222},
					{  332,  414, 0xffffff},
					{   99,  413, 0xc7c7cd},
				}) then
					stomInpuText(applePWD)
					stommSleep(300)
					stomtap(478,  468)
				end			]]
				--[[
				if stomMultiColor("登录换行",{
					{   38,  968, 0x363737},
					{  581,  444, 0x4b4d4f},
					{  581,  481, 0x000000},
					{  437,  413, 0x007aff},
				})	then
					stommSleep(500)	
					stomMultiColorTap("登录换行",{
					{   38,  968, 0x363737},
					{  581,  444, 0x4b4d4f},
					{  581,  481, 0x000000},
					{  437,  413, 0x007aff},
				})	
					stommSleep(500)	
					if stomMultiColor("输入txt",{
						{  491,  348, 0xc7c7cd},
						{  485,  396, 0xffffff},
						{  270,  377, 0x605f60},
						{  365,  412, 0x007aff},
					})	then
						stomInpuText(applePWD)
						stommSleep(300)
						stomMultiColorTap("点击上行",{
							{  550,  688, 0xffffff},
							{  488,  688, 0xffffff},
							{  338,  518, 0xccced1},
						})		
						--复制 @163.com
					end
				end	]]
					stomMultiColorTap("纵向设置",{
					{  442,  668, 0x007aff},
					{  428,  671, 0x007aff},
					{  471,  664, 0x007aff},
					{  472,  682, 0x007aff},
				})		
					stomMultiColorTap("注册完成关闭多益账号显示",{
						{  437,  831, 0x8c8684},
						{  221,  389, 0x528af7},
						{  280,  484, 0x1086f7},
						{  443,  311, 0xde0010},
					})				
					stomMultiColorTap("单行密码已输入确认",{
						{  461,  489, 0x007aff},
						{   98,  397, 0x000000},
						{  114,  397, 0x000000},
						{  474,  305, 0x606668},
						{  192,  217, 0x000000},
					})
					stomMultiColorTap("无法连接IT横粗",{
						{  252,  559, 0x007aff},
						{  367,  393, 0x000000},
						{  373,  471, 0x8c999c},
						{  364,  578, 0xb7c2c7},
					})
					stomMultiColorTap("使用现有B",{
						{  343,  503, 0x007aff},
						{  249,  454, 0x007aff},
						{  173,  548, 0x007aff},
						{  466,  545, 0x242526},
					})
					stomMultiColorTap("使用现有纵",{
						{  241,  538, 0x007aff},
						{  240,  547, 0x0c80ff},
						{  278,  536, 0x007aff},
						{  446,  539, 0x007aff},
					})
					stomMultiColorTap("设置纵粗",{
						{  444,  668, 0x007aff},
						{  428,  667, 0x007aff},
						{  224,  476, 0x000000},
						{  157,  667, 0x007aff},
						{  462,  562, 0x000000},
					})
				stomMultiColorTap("网络异常重登",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
					stomMultiColorTap("重试横屏",{
					{  254,  685, 0x007aff},
					{  270,  684, 0x007aff},
					{  258,  720, 0x007aff},
					{  245,  674, 0x007aff},
				})
				stomMultiColorTap("无法连接IT纵粗",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("验证失败再次粗",{
					{  652,  403, 0x007aff},
					{  510,  252, 0x000000},
					{  585,  251, 0x000000},
					{  763,  303, 0xd8dcda},
				})
				stomMultiColorTap("确认购买纵粗？？",{
					{  425,  666, 0x007aff},
					{  166,  483, 0x000000},
					{  422,  483, 0x616161},
					{  554,  678, 0xf9f9f9},
				})			
				stomMultiColorTap("使用现有",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("使用现有纵",{
					{  277,  537, 0x007aff},
					{  305,  430, 0x000000},
					{  334,  429, 0x595d5d},
					{  473,  635, 0xced2d2},
				})				
				if stomMultiColor("登录换行",{
					{   38,  968, 0x363737},
					{  581,  444, 0x4b4d4f},
					{  581,  481, 0x000000},
					{  437,  413, 0x007aff},
				})	then
					stommSleep(500)	
					stomMultiColorTap("登录换行",{
					{   38,  968, 0x363737},
					{  581,  444, 0x4b4d4f},
					{  581,  481, 0x000000},
					{  437,  413, 0x007aff},
				})	
					stommSleep(500)	
					if stomMultiColor("输入txt",{
						{  491,  348, 0xc7c7cd},
						{  485,  396, 0xffffff},
						{  270,  377, 0x605f60},
						{  365,  412, 0x007aff},
					})	then
						stomInpuText(applePWD)
						stommSleep(300)
						stomMultiColorTap("点击上行",{
							{  550,  688, 0xffffff},
							{  488,  688, 0xffffff},
							{  338,  518, 0xccced1},
						})		
						--复制 @163.com
					end
				end
				--[[if stomMultiColor("登录换行纵向",{
					{  191,  196, 0x000000},
					{  232,  203, 0x585c5b},
					{  362,  292, 0xffffff},
					{  100,  345, 0xc7c7cd},
				}) or stomMultiColor("登录换行纵向B",{
					{   93,  321, 0xd0dafc},
					{  195,  232, 0x000000},
					{  175,  384, 0xffffff},
					{  106,  332, 0xffffff},
					{  262,  244, 0x000000},
				})  	then
					stommSleep(500)
					stomMultiColorTap("换行",{
					{  597, 1079, 0x353535},
					{  232,  203, 0x585c5b},
					{  362,  292, 0xffffff},
					{  100,  345, 0xc7c7cd},
				})
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(300)
					stomMultiColorTap("点击上行",{
						{  369,  298, 0xffffff},
						{  232,  203, 0x585c5b},
						{  362,  292, 0xffffff},
						{  100,  345, 0xc7c7cd},
					})		
						--复制 @163.com
				end]]
				stomMultiColorTap("设置",{
					{  217,  676, 0x007aff},
					{  401,  550, 0x636566},
					{  400,  579, 0x000000},
					{  405,  644, 0x000000},
				})	
				stomMultiColorTap("设置纵向",{
					{  472,  663, 0x007aff},
					{  375,  664, 0xccd0d1},
					{  221,  484, 0x000000},
					{  273,  488, 0x666869},
				})	
				stomMultiColorTap("15分钟后需要",{
					{  357,  705, 0x007aff},
					{  409,  704, 0x56a5fd},
					{  466,  704, 0x007aff},
					{  362,  448, 0x000000},
				})	
				if stomMultiColor("请输入M横向-long",{
					{  570,  509, 0x000000},
					{  550,  766, 0x5d6568},
					{  502,  546, 0x000000},
					{  418,  347, 0xc7c7cd},
					{  418,  355, 0xc7c7cd},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(500)
					stomMultiColorTap("登录",{
					{  363,  656, 0xd8e6f0},
					{  361,  694, 0x007aff},
					{  366,  709, 0x007aff},
					{  369,  764, 0xe6eaeb},
				})
				end		
		
				stomMultiColorTap("无法连接IT",{
					{  437,  628, 0x007aff},
					{  472,  626, 0xabd1fb},
					{  146,  521, 0x000000},
					{  222,  531, 0x8f8f8f},
				})
					stomMultiColorTap("购买横屏",{
					{  217,  688, 0x007aff},
					{  227,  676, 0x007aff},
					{  232,  696, 0x007aff},
					{  235,  726, 0x007aff},
				})
				if stomMultiColorTap("购买完成",{
					{  548,  493, 0x000000},
					{  427,  406, 0xffffff},
					{  425,  352, 0xcdcdd3},
					{  500,  715, 0x000000},
				}) or stomMultiColorTap("购买完成B",{
					{  309,  644, 0x007aff},
					{  259,  491, 0x000000},
					{  411,  553, 0x000000},
					{  517,  556, 0xf9f9f9},
				})then
					stommSleep(500)					
					OpenApp("com.duoyi.shenwu3")
				--else stomLog("notfound")
				end			
			end
			stomMultiColorTap("圆形实名",{
					{  138,  628, 0xefbe18},
					{  583,  415, 0x4aaade},
					{  554,  453, 0xb5dbff},
					{  558,  543, 0xefbe4a},
				})
			if	stomMultiColorTap("请输入姓名",{
				{  307,  440, 0x7b8284},
				{  307,  443, 0x84827b},
				{  302,  470, 0xa59e9c},
				{  299,  470, 0x9ca2a5},
				{  307,  334, 0x101418},
			}) then
				nicheng = ZKQ_Word(zhangkq["姓氏"],1,1)..ZKQ_Word(zhangkq["名字"],2,3)
				stommSleep(999)
				stomInpuText(nicheng)
				stommSleep(999)
				stomtap(552,  173)
			elseif	stomMultiColorTap("请输入身份证",{
				{  220,  437, 0x8c8e94},
				{  225,  457, 0x8c8a84},
				{  224,  472, 0xadaaad},
				{  226,  559, 0x9ca2a5},
				{  226,  380, 0x000000},
			}) then
				stommSleep(999)
				stomInpuText("440282195610226964")
				stommSleep(999)
				stomtap(552,  173)
			else stomMultiColorTap("确认",{
				{  126,  515, 0x108aff},
				{  128,  567, 0x108aff},
				{  128,  610, 0x1086f7},
				{  138,  578, 0xffffff},
			}) 
			end	
			stomMultiColorTap("确认提交",{
				{  245,  648, 0x108af7},
				{  322,  482, 0x7b757b},
				{  324,  508, 0x080408},
				{  410,  499, 0xe7efef},
			})
				isfront = stomisFrontApp("com.apple.MobileSMS")
				if isfront==1 then
					break
				end
				if stomMultiColor("在外观商城程序结束",{
					{  451,  565, 0x94c3ef},
					{  539,  221, 0xdeefe7},
					{  161,  475, 0x3965a5},
					{  549,  903, 0x4a92c6},
				}) or stomMultiColor("在外观商城程序结束B",{
					{  378,  478, 0xbdd3f7},
					{   57,  664, 0x21496b},
					{  288,  311, 0x73beef},
					{  580,  639, 0xadcbff},
				}) or stomMultiColor("短信",{
					{  278,   80, 0x000000},
					{  324,   77, 0x535353},
					{  383,  162, 0xf9f9f9},
					{  581,   88, 0x007aff},
				})then
					stomMultiColor("在外观商城关闭",{
						{  581,  977, 0x429ade},
						{  485,  208, 0xefc75a},
						{  133,  204, 0x73baef},
						{  130,  599, 0xbddbff},
					})
					stommSleep(1000)
					stomMultiColor("个人属性关闭",{
						{  599,  997, 0xadf3ef},
						{  545,  566, 0x4aa6ef},
						{  392,  544, 0xde6984},
						{   82,  654, 0xe7c331},
					})
					stomtoast("充值流程结束")
						--购买升级所需物品
					break
				end
			chongzhiTimeEnd=os.time()
			if chongzhiTimeEnd-chongzhiTimeStart>60*60 then
				break
			end
			stommSleep(100)
		end
	end
end

function duoyi_fn_zhuce()
	stomtoast("进入注册模式")
	fn_zhucestart=os.time()
	--while (true) do
	local getloop =2
	local num = 0
	local m = math.random(6,8) 
	local mima = myRand(3,m,2)
	local yanzhenma
	local BlackPhone=0
	local getphonenum=0
	local messgwait=4000
	local inputphone=0
	local testzhuce=0
	fa = 0
	getPhoneType = "lx"
	docks = "1112"--1156--2292
	while (true) do
		SW1282917929_fn_duihua()
		--if loop == 0 then
		stomLog("当前阶段.."..getloop)
		if stomMultiColor("密码未输入",{
				{  308,  422, 0x8c8a8c},
				{  310,  453, 0xadb2b5},
				{  311,  519, 0x9c9694},
				{  311,  594, 0x949694},
				{  311,  646, 0x848684},
				}) then
			stommSleep(500)
			stomMultiColorTap("多益输点击密码框",{
					{  312,  435, 0xffffff},
					{  311,  441, 0xadaead},
					{  313,  485, 0x84827b},
					{  309,  519, 0x9c9694},
				})
			stommSleep(500)
			stomInpuText(mima)
			stommSleep(999)
		end
		if stomMultiColorTap("多益密码已输入关闭键盘",{
				{  350,  332, 0xf7f7f7},
				{  419,  419, 0x000000},
				{  420,  433, 0x000000},
				{  420,  447, 0x000000},
				{  500,  457, 0x9f9ea2},
				}) then
			stommSleep(500)
		end
		if getloop == 0 then
			--stomtoast(error_60ma)
			if getphonenum==0 then
				if num <= 4 then
					check_Rules = 1
					Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
					num = num + 1
				else
					--return 1
				end
				if Telnum then
					stomLog(Telnum)
					phonenumber = Telnum
					num = 0
					getphonenum=1
				else
					stomLog("重新获取号码中")
					stommSleep(2000)
					num = num + 1
				end
			end
			if getphonenum==1 then
				if stomMultiColor("手机号未输入",{
						{  467,  417, 0x8c8684},
						{  466,  422, 0x8c8a8c},
						{  465,  432, 0x848a8c},
						{  465,  451, 0x8c8684},
						{  476,  451, 0xa5a6ad},
						}) then
					stomMultiColorTap("多益注册主界面点手机号",{
							{  473,  423, 0xb5aead},
							{  468,  435, 0xffffff},
							{  151,  488, 0x108af7},
							{  158,  643, 0x108aff},
						})
					stommSleep(1000)
					if inputphone==0 then
						stomInpuText(Telnum)
						inputphone=1
					else
						stomInpuStr(Telnum)
						inputphone=0
					end
					stommSleep(300)
					phoneok=1
				end
			end
			if phoneok==1 and stomMultiColorTap("手机号已输且验证码能获取",{
					{  455,  709, 0x1086f7},
					{  455,  736, 0x108af7},
					{  455,  764, 0x108af7},
					{  455,  785, 0x1086f7},
					}) then
				phoneok=2
			end					
			if stomMultiColorTap("多益获取验证码",{
					{  453,  712, 0x73797b},
					{  453,  734, 0x73797b},
					{  453,  762, 0x73797b},
					{  453,  784, 0x73797b},
					}) and phoneok==2 then
				stommSleep(8888)
				messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)							
				getloop=1
			end
			stomMultiColorTap("多益输手机号已填写关闭键盘",{
					{  541,  401, 0xefebe7},
					{  470,  653, 0x949694},
					{  470,  670, 0x949294},
					{  461,  661, 0x9c9694},
				}) 
		elseif getloop == 1 then
			stomLog("获取短信..."..fa)
			if messg then
				stomtoast(yanzhenma)
				if BlackPhone==0 then
					testzhuce=testzhuce+1
					BlackPhone=1
					messgwait=300
					stomtoast("已收验证码 正在处理",3)
					yanzhenma = string.match(messg,"%d+")
					stomLog("yanzhenmaOK-"..yanzhenma)
				else 
					stomtoast(yanzhenma)
				end
				if stomMultiColorTap("多益验证码未输入开始输入",{
						{  394,  525, 0x8c9294},
						{  396,  548, 0x948e94},
						{  390,  561, 0x84868c},
						{  383,  572, 0x7b8284},
						})then	
					stommSleep(500)
					stomInpuText(yanzhenma)
					stommSleep(2000)
					stomtap(568,  375)
					--stommSleep(300)
					--stomtap(389,  928)
				end
				if stomMultiColor("多益验证码未输入不操作",{
						{  394,  525, 0x8c9294},
						{  396,  548, 0x948e94},
						{  390,  561, 0x84868c},
						{  383,  572, 0x7b8284},
						})then
				else
					stommSleep(60)
					if stomMultiColor("立即注册",{
							{  172,  463, 0x108aff},
							{  172,  662, 0x1086f7},
							{  243,  714, 0xf7f7f7},
							{  525,  458, 0xefefef},
							}) then
						stommSleep(2000)
						stomMultiColorTap("立即注册",{
								{  172,  463, 0x108aff},
								{  172,  662, 0x1086f7},
								{  243,  714, 0xf7f7f7},
								{  525,  458, 0xefefef},
							}) 
						stommSleep(15000)
						if stomMultiColor("绑定成功",{
								{  363,  402, 0x63ba63},
								{  368,  597, 0x000000},
								{  370,  648, 0x4a494a},
								{  542,  556, 0x9c9a9c},
								})	or stomMultiColor("绑定成功C",{
								{  363,  402, 0x63ba63},
								{  368,  597, 0x000000},
								{  370,  648, 0x4a494a},
								{  542,  556, 0x9c9a9c},
								})	or stomMultiColor("绑定成功B",{
								{  314,  413, 0x63ba63},
								{  535,  530, 0x000000},
								{  538,  831, 0x84868c},
								{   90,  531, 0xf7f7f7},
								})  or	stomMultiColor("红色已绑定",{
									{  437,  315, 0xd60008},
									{  221,  390, 0x4a8ef7},
									{  223,  458, 0x73aaff},
									{  299,  494, 0x108af7},
								})	then
								stomLog("绑定成功")
								stommSleep(3000)
								getloop = 99
								break
							--stomopenURL("prefs:root=STORE");
							stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
							stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)	
							--loop=1
						else 
							stomtoast("注册失败3秒后跳转")
							stommSleep(3000)
							stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
							stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)	
							stomLog("绑定失败")	
							czendtime=os.time()
							--[[if testzhuce>=3 then
								return 1
							end]]
							--[[if czendtime-czstartime<90 then
								stomtoast("冻结操作，second="..(90-czendtime+czstartime),(90-czendtime+czstartime))
								stommSleep((90-czendtime+czstartime)*1000)
							end]]
							getloop=99
							MODEsw=2
							return 1
							--stomLog("return了1")
							--do return 1 end
						end	
					end	
				end
			else
				messgwait=4000
				messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
				stomLog("get sms")
				stomtoast("GetMegNO."..fa,4)
				fa = fa +1
			end
			if fa > 10 then
				stomLog("获取短信失败")
				stomtoast("get短信")
				stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
				stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
				getloop = 2
			end
			stommSleep(messgwait)
		elseif getloop == 2 then
			czstartime= os.time()
			stomtoast("等待开始",1)
			stommSleep(999)
			fa = 0	
			BlackPhone=0
			getphonenum=0
			inputphone=0
			stomMultiColorTap("账号",{
					{  302,  583, 0x3165ad},
					{  289,  432, 0x295da5},
					{  294,  439, 0xb5d3f7},
					{  299,  446, 0x295da5},
					{  444,  524, 0xe7cb63},
				})
			stomMultiColorTap("取消表单",{
					{  537,  299, 0x8c8684},
					{  529,  305, 0x8c8684},
					{  544,  305, 0x84868c},
					{  537,  533, 0x080400},
					{  537,  559, 0x000000},
				})
			stomMultiColorTap("取消表单B",{
					{  537,  300, 0x848684},
					{  528,  306, 0x848684},
					{  530,  488, 0xefebef},
					{  252,  834, 0xf7f7f7},
				})
			if stomMultiColorTap("多益点账号注册",{
					{  215,  430, 0x318aff},
					{  217,  444, 0x318aff},
					{  291,  511, 0x1086f7},
					{  444,  320, 0xd60010},
					}) then
				getloop=0
			end	
		end
		if stomMultiColor("绑定成功",{
				{  363,  402, 0x63ba63},
				{  368,  597, 0x000000},
				{  370,  648, 0x4a494a},
				{  542,  556, 0x9c9a9c},
				})	or stomMultiColor("绑定成功C",{
				{  363,  402, 0x63ba63},
				{  368,  597, 0x000000},
				{  370,  648, 0x4a494a},
				{  542,  556, 0x9c9a9c},
				})	or stomMultiColor("绑定成功B",{
				{  314,  413, 0x63ba63},
				{  535,  530, 0x000000},
				{  538,  831, 0x84868c},
				{   90,  531, 0xf7f7f7},
				})  or	stomMultiColor("红色已绑定",{
					{  437,  315, 0xd60008},
					{  221,  390, 0x4a8ef7},
					{  223,  458, 0x73aaff},
					{  299,  494, 0x108af7},
				})	then
			stomLog("绑定成功")
			stommSleep(3000)
			getloop = 99
			return 0
			--stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
			--stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)	
		end
		--[[elseif loop == 1 then
			
		end--]]
	stomMultiColorTap("圆形实名",{
			{  138,  628, 0xefbe18},
			{  583,  415, 0x4aaade},
			{  554,  453, 0xb5dbff},
			{  558,  543, 0xefbe4a},
		})
	if	stomMultiColorTap("请输入姓名",{
			{  307,  440, 0x7b8284},
			{  307,  443, 0x84827b},
			{  302,  470, 0xa59e9c},
			{  299,  470, 0x9ca2a5},
			{  307,  334, 0x101418},
			}) then
		nicheng = ZKQ_Word(zhangkq["姓氏"],1,1)..ZKQ_Word(zhangkq["名字"],2,3)
		stommSleep(999)
		stomInpuText(nicheng)
		stommSleep(999)
		stomtap(552,  173)
	elseif stomMultiColorTap("请输入身份证",{
			{  220,  437, 0x8c8e94},
			{  225,  457, 0x8c8a84},
			{  224,  472, 0xadaaad},
			{  226,  559, 0x9ca2a5},
			{  226,  380, 0x000000},
			}) then
		stommSleep(999)
		stomInpuText("440282195610226964")
		stommSleep(999)
		stomtap(552,  173)
	else stomMultiColorTap("确认",{
				{  126,  515, 0x108aff},
				{  128,  567, 0x108aff},
				{  128,  610, 0x1086f7},
				{  138,  578, 0xffffff},
			}) 
	end	
	stomMultiColorTap("确认提交",{
			{  245,  648, 0x108af7},
			{  322,  482, 0x7b757b},
			{  324,  508, 0x080408},
			{  410,  499, 0xe7efef},
		})
	if stomMultiColor("身份证有误",{
			{  480,  375, 0x313439},
			{  471,  383, 0xe7dfde},
			{  474,  451, 0x8c8e8c},
			{  472,  612, 0x737173},
			{  476,  635, 0x848a8c},
			}) then
		--重启游戏
		stomcloseApp("com.duoyi.shenwu3")
		stommSleep(5000)
		stomrunApp("com.duoyi.shenwu3")
	end	
	stommSleep(300)
	fn_zhucesend=os.time()
	if fn_zhucesend-fn_zhucestart>=60*7 then
		return 1
	end
end--while
end

function SW1282917929_fn_tankuang()
		stomMultiColorTap("高等级场景限制",{
	{  205,  346, 0x946910},
	{  204,  325, 0xe7c731},
	{  199,  389, 0xefcf31},
	{  312,  468, 0xffffff},
})
	stomMultiColorTap("关闭礼包a",{
	{  527,  917, 0xa52c18},
	{  532,  910, 0x942418},
	{  458,  444, 0xf7ebc6},
	{  149,  355, 0xf7e7c6},
})
	stomMultiColorTap("更新失败",{
	{  223,  549, 0x007aff},
	{  228,  549, 0x007aff},
	{  408,  514, 0x000000},
	{  212,  584, 0x007aff},
})
	stomMultiColorTap("没有充值则关闭首充",{
		{  549, 1000, 0xc64129},
		{  188,  640, 0xbd4110},
		{  185,  680, 0xbd4510},
		{  207,  728, 0xe7cf7b},
	})
	stomMultiColorTap("首充奖励领取",{
	{  182,  697, 0xdec731},
	{  190,  654, 0xbd4110},
	{  498,  483, 0xc68210},
	{  506,  528, 0xce9610},
})
	stomMultiColorTap("绑定账号奖励",{
	{  212,  642, 0xe5c630},
	{  217,  589, 0xe6c33c},
	{  217,  613, 0x996611},
	{  592,  492, 0xf7d25e},
})
	stomMultiColorTap("开具动画",{
	{  368,  640, 0x7767ae},
	{  144,  451, 0xa75636},
	{  104, 1090, 0x403172},
	{  467,   90, 0x131418},
})
	stomMultiColorTap("网络异常正中重试",{
	{  239,  515, 0x007aff},
	{  396,  510, 0x000000},
	{  396,  517, 0x000000},
	{  381,  555, 0x585e61},
})
	stomMultiColorTap("网络异常-右侧重新登录",{
		{  235,  651, 0x007aff},
		{  233,  678, 0x007aff},
		{  238,  693, 0x007aff},
		{  235,  720, 0x007aff},
	})
	stomMultiColorTap("短信关闭",{
		{  235,  651, 0x007aff},
		{  233,  678, 0x007aff},
		{  238,  693, 0x007aff},
		{  235,  720, 0x007aff},
	})
	stomMultiColorTap("短信关闭B",{
		{  210,  404, 0x007aff},
		{  210,  413, 0x007aff},
		{  191,  424, 0x007aff},
		{  432,  520, 0x4c4f53},
	})
	stomMultiColorTap("更新失败重试",{
		{  239,  550, 0x007aff},
		{  400,  517, 0x000000},
		{  401,  583, 0x62605f},
		{  232,  585, 0x007aff},
	})
	stomMultiColorTap("改名新",{
		{  409,  611, 0x4aa2ef},
		{  566,  519, 0xffffff},
		{  561,  542, 0xffffff},
		{  415,  529, 0xe7c342},
	})
	stomMultiColorTap("取消gamecenter",{
		{  607,   73, 0xeeefef},
		{  497,  599, 0xffa002},
		{  465,  631, 0x12abfc},
		{  487,  527, 0xfc3294},
	})	
	stomMultiColor("服务器维护重试",{
		{  235,  686, 0x007aff},
		{  376,  507, 0x000000},
		{  384,  515, 0x7d7a72},
		{  379,  541, 0x000000},
		{  389,  557, 0x000000},
	})
	stomMultiColorTap("版本过低更新",{
		{  237,  546, 0x007aff},
		{  237,  551, 0x007aff},
		{  237,  561, 0x007aff},
		{  247,  577, 0x007aff},
	})
	stomMultiColorTap("关闭gamecenter",{
		{  605,   54, 0x5856d6},
		{  604,   87, 0x5856d6},
		{  546,  534, 0xfd338d},
		{  607,  661, 0xf7f1f0},
		{  388,  754, 0x67635e},
	})
	stomMultiColorTap("关闭gamecenterB",{
		{  615,   54, 0x5856d6},
		{  620,   70, 0x5856d6},
		{  615,   92, 0x5856d6},
		{  402,  403, 0x000000},
		{  397,  538, 0x474441},
	})
	stomMultiColorTap("下载失败重试",{
		{  198,  549, 0x007aff},
		{  216,  549, 0x007aff},
		{  215,  591, 0x007aff},
		{  193,  596, 0x007aff},
		{  201,  547, 0x78b5f4},
	})
	stomMultiColorTap("绿色对勾绑定成功",{
	{  537,  830, 0x848684},
	{  541,  530, 0x000000},
	{  540,  536, 0x100c10},
	{  541,  560, 0x393c42},
})
	stomMultiColorTap("注册完成关闭账号注册成功",{
		{  537,  830, 0x848684},
		{  541,  530, 0x000000},
		{  541,  535, 0x5a5552},
		{  536,  563, 0x5a5d63},
		{  536,  578, 0xefebef},
	})
	stomMultiColorTap("注册完成关闭多益账号显示",{
		{  437,  831, 0x8c8684},
		{  221,  389, 0x528af7},
		{  280,  484, 0x1086f7},
		{  443,  311, 0xde0010},
	})	
	stomMultiColorTap("重新登录",{--
		{  235,  517, 0x007aff},
		{  387,  511, 0x000000},
		{  386,  506, 0xa2a199},
		{  382,  580, 0x000000},
	})
	stomMultiColorTap("游客登录",{--
		{  166,  273, 0x84d363},
		{  159,  309, 0xffffff},
		{  163,  376, 0xf7fff7},
		{  154,  436, 0x84cb5a},
	})
	stomMultiColorTap("同意协议",{
		{   73,  647, 0xde3c29},
		{   72,  688, 0xffffff},
		{   69,  751, 0xde3c29},
		{  574,  460, 0xd61c10},
	})
	stomMultiColorTap("确认更新",{--
		{  203,  324, 0x946910},
		{  194,  398, 0xefd742},
		{  404,  537, 0xffffff},
		{  401,  564, 0x4279ce},
	})
	stomMultiColorTap("连接超时",{--
		{  201,  748, 0xe7cf39},
		{  410,  537, 0xffffff},
		{  403,  565, 0x4a75c6},
		{  403,  587, 0xffffff},
	})
	stomMultiColorTap("下载失败",{--
		{  206,  491, 0xdadedd},
		{  432,  509, 0x000000},
		{  418,  584, 0x000000},
		{  423,  614, 0xaaafaa},
	})
	stomMultiColorTap("暂不更新",{--
		{  210,  381, 0x007aff},
		{  416,  507, 0x000000},
		{  393,  513, 0x000000},
		{  418,  542, 0x000000},
	})
	stomMultiColorTap("暂不更新",{--
		{  210,  372, 0x007aff},
		{  221,  449, 0x007aff},
		{  413,  517, 0x000000},
		{  401,  543, 0x000000},
	})	
	stomMultiColorTap("等级不足无法进行主线",{--
		{  202,  754, 0xe7c731},
		{  319,  424, 0xffffff},
		{  310,  513, 0xffffff},
		{  413,  537, 0x4a75c6},
	})
	stomMultiColorTap("确认取消改名",{--
		{  203,  379, 0xe7c731},
		{  413,  531, 0x4a75c6},
		{  402,  554, 0x4275ce},
		{  406,  580, 0xffffff},
	})
	if stomMultiColor("关闭活力",{--
	{  438,  537, 0x3165ad},
	{  448,  537, 0x3165ad},
	{  445,  555, 0x3965a5},
	{  435,  557, 0xadd7f7},
})	then
		stomtap(422,  110)
	end
	if stomMultiColor("使用修炼药水1",{--
	{  231,  496, 0x3169ad},
	{  228,  515, 0x3165ad},
	{  111,  696, 0xe7cb73},
	{  230,  569, 0x3965ad},
})	then
		stomtap(93,  901)
	end
	if stomMultiColor("使用修炼药水2",{--
	{  235,  303, 0x3965a5},
	{  241,  328, 0x3169ad},
	{  235,  347, 0x3965a5},
	{   89,  865, 0xe7cb31},
})	then
		stomtap(105,  716)
	end
	if stomMultiColor("使用修炼药水3",{--
	{  319,  118, 0x3169ad},
	{  308,  118, 0x3165a5},
	{  313,  149, 0x3965a5},
	{  114,  573, 0xe7cf84},
})	then
		stomtap(367,   82)
	end
	if stomMultiColor("选择角色",{--选择角色
			{  613,   22, 0xf7cf18},
			{   54,  114, 0x944529},
			{   44,  214, 0xefbe31},
			{   43,  184, 0x8c4929},
			})==true then 
		stomtap(119,  231)
		stommSleep(20) 
		stomtap(40,  144)
	end
	stomMultiColorTap("14级卡点",{--
		{  452,  963, 0xffff4a},
		{  421,  971, 0x4aff21},
		{  420,  984, 0x429231},
		{  424, 1011, 0x317929},
	})	
	stomMultiColorTap("14级卡点B",{--
		{  449,  984, 0xffff42},
		{  442,  988, 0x736539},
		{  451, 1028, 0x636939},
		{  446, 1046, 0xffff42},
	})	
	stomMultiColorTap("关闭世界对话",{--
		{  607,  482, 0x4a8ace},
		{  607,  423, 0xceebff},
		{  609,   54, 0xceefff},
		{  606,  299, 0xc6e7ff},
	})	

	if 	stomMultiColor("打造装备",{ 
		{   98,  881, 0x946510},
		{   98,  925, 0xe7c731},
		{  262,  489, 0xa5d7ff},
		{  551,  546, 0xffffff},
	}) then
		stomtap(600,  997)
	end
	if stomMultiColorTap("自动战斗",{--自动战斗
		{   45, 1110, 0xd6f3ff},
		{   60, 1080, 0xe7f7ff},
		{   45, 1081, 0xd6efff},
		{   60, 1095, 0xdef7ff},
	}) then
	elseif stomMultiColorTap("自动战斗2",{--自动战斗
		{   52, 1087, 0xd6f3ff},
		{   71, 1084, 0x52a2de},
		{   67, 1110, 0x429ade},
		{   27, 1103, 0x7bdbf7},
	})	then
	end
	stomMultiColorTap("关闭熊猫",{
		{  268,  529, 0x3165ad},
		{  278,  549, 0x3165ad},
		{  331,  443, 0x3965a5},
		{  343,  459, 0x3965a5},
	})	
	stomMultiColorTap("有小弹窗",{--自动战斗
		{  127,  944, 0x63aad6},
		{  128,  977, 0x63aade},
		{  127, 1011, 0x6baad6},
		{  133,  976, 0x5aa6de},
	})
	stomMultiColorTap("回到原服",{--自动战斗
		{  204,  353, 0xe7c731},
		{  397,  536, 0x4279ce},
		{  400,  554, 0xffffff},
		{  413,  582, 0x4279ce},
	})
	if 	stomMultiColor("关闭历程",{ 
		{  393, 1024, 0x3169ad},
		{  393, 1017, 0x3965a5},
		{  363, 1025, 0x3965a5},
		{  337, 1016, 0x52d7ff},
	}) or 	stomMultiColor("关闭阵法",{ 
		{  559,  459, 0x3965a5},
		{  558,  501, 0x3165ad},
		{  554,  537, 0xbdebff},
		{  554,  721, 0x42d7d6},
	})then
		stomtap(600,  997)
	end
	stomMultiColorTap("升级伙伴",{--自动战斗
		{  207,  314, 0xe4c02c},
		{  197,  387, 0xead43b},
		{  403,  532, 0xffffff},
		{  408,  583, 0xffffff},
	})
	if 	stomMultiColor("创建队伍关闭",{ 
		{  539,  198, 0xe7d34a},
		{  553,  217, 0x9c6510},
		{  480,  315, 0xb5d7f7},
		{  477,  902, 0x84b2e7},
	}) then
		stomtap(600,  997)
	end
	stomMultiColorTap("组队界面关闭",{
		{  598, 1000, 0xadf3ef},
		{  556,  193, 0xe7c34a},
		{   66,  957, 0xefe35a},
		{  316,  316, 0xb5cbef},
	})
	stomMultiColorTap("活力关闭",{
		{  516,  820, 0x429ae7},
		{  485,  537, 0x3965a5},
		{  495,  537, 0x3965a5},
		{  492,  555, 0x3165ad},
		{  484,  499, 0xa5dbf7},
	})
	stomMultiColorTap("上交政务",{--使用装备
		{  317,  958, 0xffffff},
		{  315,  941, 0x1855ad},
		{  324,  941, 0x2171bd},
		{  314, 1007, 0xffffff},
		{  319, 1033, 0xffffff},
	})
	stomMultiColorTap("如果在队伍状态去任务主界面",{
		{  499,  972, 0x948239},
		{  505, 1017, 0x52a6f7},
		{  503, 1061, 0x6b3408},
		{  522, 1051, 0x6bcbe7},
	})
	stomMultiColorTap("新手调查",{--新手调查
		{  286,  716, 0xffffff},
		{  528,  479, 0xfff77b},
		{  520,  543, 0xfff77b},
		{  520,  649, 0xfff77b},
	})
	if stomMultiColor("选择宠物2",{--选择宠物2
	   {  111,  571, 0xcea621},
	   {  560,  521, 0xffffbd},
	   {  561,  550, 0xffffc6},
	   {  532,  635, 0x842808},
	  }) then
	  tby = {438,710}
	  aa = math.random(1,#tby)
	  y1 = tby[aa]
	  stomtap(290,y1)
	  stommSleep(1000)
	  stomMultiColorTap("选择宠物2",{--选择宠物2
	   {  111,  571, 0xcea621},
	   {  560,  521, 0xffffbd},
	   {  561,  550, 0xffffc6},
	   {  532,  635, 0x842808},
	  })
	end	
	if stomMultiColor("领取桃子",{--新手调查
	{  340,  427, 0x3165ad},
	{  307,  440, 0x94c3ef},
	{  338,  438, 0x3165ad},
	{  343,  435, 0x5a82b5},
	}) or stomMultiColor("领取桃子2",{--新手调查
		{  268,  530, 0x3165a5},
		{  268,  550, 0x3165a5},
		{  267,  573, 0x3965a5},
		{  250,  613, 0x94c3ef},
	})then
		hdtap(123,  553)
	end
	stomMultiColorTap("桃子高亮2",{--新手调查
		{  606,  696, 0xfffbff},
		{  590,  688, 0xffff6b},
		{  590,  707, 0xffef6b},
	})
	stomMultiColorTap("选择宠物1",{--选择宠物1
			{  321,  444, 0x633410},
			{  560,  521, 0xffffbd},
			{  561,  550, 0xffffc6},
			{  532,  635, 0x842808},
		})
	stomMultiColorTap("选择宠物2",{--选择宠物2
			{  111,  571, 0xcea621},
			{  560,  521, 0xffffbd},
			{  561,  550, 0xffffc6},
			{  532,  635, 0x842808},
		})

	stomMultiColorTap("使用装备",{--使用装备
			{  134,  963, 0xfffbf7},
			{  273,  919, 0xffffa5},
			{  118,  940, 0x6bb2d6},
			{  264, 1035, 0xdee7d6},
		})
	if stomMultiColorTap("门派功法界面，一键学习B",{--门派功法界面，一键学习1
			{   74,  628, 0xe7cf39},
			{   84,  674, 0x9c6510},
			{   73,  717, 0xefd339},
			{  534, 1013, 0x0079ad},
		})	or
		stomMultiColorTap("门派功法界面，一键学习",{--门派功法界面，一键学习1
			{   84,  630, 0x9c6510},
			{  623,  242, 0x4a5d6b},
			{  625,  267, 0xb5b6b5},
			{  606,  351, 0x4a799c},
		}) or stomMultiColorTap("门派功法界面，一键学习多一行",{--门派功法界面，一键学习1
			{  203,  387, 0xe7c731},
			{  221,  333, 0xefcf84},
			{  410,  508, 0xffffff},
			{  406,  527, 0x4279ce},
		})then
		stommSleep(500)
	end
	if stomMultiColorTap("门派功法界面，确认",{--门派功法界面，一键学习2确认
			{  211,  348, 0x945510},
			{  473,  300, 0xc6df84},
			{  403,  555, 0x4a75c6},
			{  410,  608, 0xcedbef},
		}) then
		stommSleep(300)
		stomtap(606,994) 
	end 
	if stomMultiColor("门派功法界面，一键学习B",{--门派功法界面，一键学习1
			{   74,  628, 0xe7cf39},
			{   84,  674, 0x9c6510},
			{   73,  717, 0xefd339},
			{  534, 1013, 0x0079ad},
		})	or
	stomMultiColor("门派功法界面，一键学习",{--门派功法界面，一键学习1
			{   84,  630, 0x9c6510},
			{  623,  242, 0x4a5d6b},
			{  625,  267, 0xb5b6b5},
			{  606,  351, 0x4a799c},
		}) then
		stommSleep(300)
		stomtap(600,1000)
	end	
	stomMultiColorTap("跳过剧情",{--跳过剧情 
			{  586, 1063, 0x7bfbff},
			{  587, 1041, 0x7befef},
			{  607, 1105, 0x085594},
			{  572, 1106, 0x529ae7},
		})
	stomMultiColorTap("跳过剧情2",{--跳过剧情 
		{  608, 1020, 0x73e3e7},
		{  566,   96, 0x000000},
		{   56,  488, 0x000000},
		{  600, 1085, 0x00387b},
	})
	stomMultiColorTap("关闭公告",{ 
		{  598,  954, 0xceefff},
		{  600,  508, 0xe74d4a},
		{  609,  285, 0x8cb6d6},
		{  601,  584, 0xfffbce},
	})
	if stomMultiColor("活力兑换关闭",{ 
		{  490,  537, 0x3165ad},
		{  485,  548, 0xaddbf7},
		{  492,  555, 0x3165ad},
		{  486,  578, 0x3165ad},
	})then
		stomtap(516,  819)
	end
	if stomMultiColor("如果没钱！！",{ 
		{  424,  524, 0x3165ad},
		{  418,  572, 0x3165a5},
		{  425,  609, 0xe7ba73},
		{  410,  611, 0xefba7b},
	}) then
		stommSleep(500)
		stomtap(391,   95)
		stommSleep(500)
		stomtap(391,   95)
	end
	stomMultiColorTap("烤猪-1",{ 
		{  486,  631, 0xf7cf73},
		{  481,  609, 0x081008},
		{  462,  631, 0xcecfde},
		{  454,  618, 0x4a71a5},
	})
	stomMultiColorTap("烤猪-2",{ 
		{  163,  633, 0xe7c329},
		{  164,  756, 0xe7be29},
		{  485,  632, 0xf7c352},
		{  164,  689, 0x946518},
	})
	if stomMultiColor("请选择物品",{ 
		{  458,  334, 0x737d94},
		{  463,  357, 0xffffff},
		{  452,  375, 0x4a758c},
		{  461,  407, 0x949ead},
		{  228,  534, 0x102c4a},
	}) then
		stomtap(467,  634)
	end
	if stomMultiColor("装备打造",{ 
		{  190,  564, 0xc6e7ff},
		{  191,  591, 0x3965a5},
		{  193,  608, 0x4a86bd},
		{  106,  840, 0xe7c342},
		{  103,  905, 0x9c6510},
	}) or stomMultiColor("我的伙伴关闭",{ 
	{  191,  467, 0xe76d84},
	{  139,  461, 0xf7cb6b},
	{   99,  467, 0x18dba5},
	{  181,  849, 0x9c6510},
}) then
		stomtap(602,  996)
	end
	if 	stomMultiColor("竞技场任务关闭",{ 
		{   90,  560, 0x9c6510},
		{   71,  645, 0xefdf52},
		{   96,  810, 0xe7c35a},
		{  548,  378, 0xbdd3f7},
	}) then
		stomtap(600,  997)
	end

	if 	stomMultiColor("南山大王关闭",{ 
		{  154,  267, 0x94c3ef},
		{  283,  676, 0x3169ad},
		{  282,  725, 0x3165ad},
		{  178,  936, 0xe7c731},
	}) then
		stomtap(600,  997)
	end	
	stomMultiColorTap("给予物品",{ 
		{  168,  644, 0xe7c34a},
		{  160,  690, 0x9c6510},
		{  162,  720, 0x9c6510},
		{  473,  662, 0xfff77b},
		{  495,  662, 0xfff79c},
	})
	stomMultiColorTap("对话卡点",{ 
		{    4,  833, 0x1871b5},
		{   39,  249, 0x2971b5},
		{   39,  296, 0x317dbd},
		{  216,  509, 0x94d7e7},
	})
	stomMultiColorTap("点错人物属性关闭",{--点错人物属性关闭
			{  599,  997, 0xd66921},
			{  623,  238, 0x31495a},
			{  617,  274, 0xa5b2bd},
			{  626,  353, 0xb5bebd},
		})
	if	stomMultiColorTap("商店任务",{--商店任务
		{   79,  860, 0xe7cb31},
		{   86,  949, 0x946510},
		{  537,  225, 0xefdf42},
		{  208,  311, 0x9cc3ef},
	}) --[[or stomMultiColorTap("商店任务B",{--商店任务
			{   89,  899, 0x8c5510},
			{  624,  248, 0x214563},
			{  619,  255, 0x294963},
			{  627,  297, 0x213c5a},
		}) ]]
		or 	stomMultiColorTap("商店任务药店",{--商店任务药店
			{   75,  823, 0xefdf42},
			{  566,  176, 0xffeb63},
			{  567,  182, 0x735921},
			{  567,  201, 0x7b5521},
		})
		or	stomMultiColorTap("商店任务备用",{--商店任务备用
			{   99,  866, 0xe7c331},
			{  104,  905, 0x946518},
			{   96,  943, 0xe7c731},
			{  627,  252, 0xced7ef},
		})
		or stomMultiColorTap("商店任务备用2",{--商店任务备用
			{   92,  848, 0x9c5510},
			{  631,  269, 0xcec7c6},
			{  602,  155, 0xfff7c6},
			{  621,  316, 0x215984},
		})then
			stomtap(601, 1002)
		end
	--[[stomMultiColorTap("商店任务",{--商店任务
			{   89,  899, 0x8c5510},
			{  624,  248, 0x214563},
			{  619,  255, 0x294963},
			{  627,  297, 0x213c5a},
		})]]

	--[[stomMultiColorTap("服饰店购买关闭",{--服饰店购买关闭
			{  599,  997, 0xd66921},
			{  445,  442, 0xffffff},
			{  457,  465, 0xffffff},
			{  441,  493, 0xadaebd},
		})]]
	if stomMultiColorTap("武器店购买",{--武器店购买
			{   86,  842, 0xe7cb31},
			{  626,  272, 0xc6c7ce},
			{  550,  182, 0x8c6521},
			{  555,  223, 0xbd9a42},
		})		or stomMultiColorTap("服饰店购买",{--服饰店购买
			{   96,  827, 0x845510},
			{  620,  264, 0xbdc7ce},
			{  552,  181, 0x735529},
			{  552,  208, 0x849284},
		})
		 then
		stommSleep(300)
		stomtap(600,1000)
	end

	stomMultiColorTap("购买药品后关闭",{--购买药品后关闭 --此操作点击了左侧靠中位置
			{  351,  110, 0x100808},
			{  449,  448, 0xffffff},
			{  449,  454, 0xeff3f7},
			{  458,  474, 0x212442},
		})
	if stomMultiColor("购买界面",{--师门任务购买商品
		{  503,  201, 0x9cc3e7},
		{  174,  195, 0x94c3ef},
		{   73,  658, 0xe7c331},
		{   87,  236, 0x3169ad},
	})==true then 
	x,y = findMultiColorInRegionFuzzy( 0xad5531, "-12|12|0xf7cf6b,-3|22|0xa53821,-16|27|0xffeb6b", 70, 301, 352, 490, 424)
		if x ~= -1 then--找购买类型需求	
				--toast("t")
			stomtap(x,y)
			j,k = findMultiColorInRegionFuzzy( 0xe7597b, "28|26|0xd67194,27|49|0xef6584,-29|0|0xe74163", 90, 95, 441, 546, 931)
			if j ~= -1 then	--找商品需求	
				stomtap(j,k)
				stommSleep(60)
				stomtap(70,690)--购买
			else stomMultiColorTap("下一页",{
					{   68,  841, 0x4a9ed6},
					{   73,  852, 0xffffff},
					{   76,  896, 0xc6dbef},
					{   75,  910, 0x5296ce},
				})
			end
		else
			--toast("f")
		end
	end

	stomMultiColorTap("自动装备",{--自动装备
			{  133,  995, 0x4aa2ef},
			{  253,  953, 0xf7fbff},
			{  133,  957, 0xffffff},
			{  263, 1034, 0xcee7f7},
		})
	stomMultiColorTap("自动领取右下角",{--自动领取右下角
			{  133,  971, 0xffffff},
			{  267,  918, 0x6b92ad},
			{  117,  945, 0x52b2f7},
			{  263, 1035, 0xd6e7f7},
		})
	if 	stomMultiColor("找到对话框",{--对话框左侧双行任务
			{  417,  997, 0x6b8abd},
			{  240, 1046, 0xa5d7ff},
			{  193, 1048, 0xaddbff},
			{  112, 1039, 0x94c3ef},
		}) then
		if 	stomMultiColorTap("先做主线",{--对话框左侧双行任务
			{  188,  738, 0x5286ce},
			{  181,  742, 0x528ace},
			{  194,  765, 0x528ace},
			{  181,  797, 0x5a86c6},
			{  192,  844, 0x5a86ce},
		}) then
			stommSleep(100)
		elseif  stomMultiColorTap("先做主线第三行",{--对话框左侧双行任务
			{  137,  741, 0x5a86c6},
			{  140,  765, 0x528ace},
			{  139,  781, 0x5a86c6},
			{  131,  969, 0xa5dbf7},
		}) or  stomMultiColorTap("先做主线第三行",{--对话框左侧双行任务
			{  194,  741, 0x528ace},
			{  188,  741, 0x528ace},
			{  181,  741, 0x5a86c6},
			{  194,  765, 0x528ace},
		})   then
			stommSleep(100)		
		elseif  stomMultiColorTap("先做师门第三行",{--对话框左侧双行任务
			{  134,  756, 0x5286ce},
			{  148,  764, 0x5286ce},
			{  147,  771, 0x5a86c6},
			{  136,  771, 0x4279bd},
		})then
			stommSleep(100)
		elseif  stomMultiColorTap("单行任务",{--对话框左侧双行任务
			{  239,  781, 0x5a86c6},
			{  254,  744, 0xc6e7ff},
			{  223,  746, 0x9cd7ff},
		})then
			stommSleep(100)	
		elseif  stomMultiColorTap("宋吕过任务",{--对话框左侧双行任务
			{  235,  736, 0x528ace},
			{  236,  836, 0xa5d7ff},
			{  235,  890, 0xa5dbff},
			{  232,  767, 0x528ace},
		})then
			stommSleep(100)	
		else
			local i=math.random(0,1)
			if i==1 then
				stomtap(269,  757)--第一行
			else
				stomtap(244,  996)--第二行
			end
			--[[stomMultiColorTap("执行对话框左侧双行任务",{--对话框左侧双行任务
					{  242,  725, 0xa5dbff},
					{  585,  698, 0x6ba2d6},
					{   23, 1107, 0x8cb6e7},
					{  582, 1105, 0x42a2e7},
				})
			stomMultiColorTap("对话框左侧双行任务B",{--对话框左侧双行任务
					{  328,  900, 0x2171bd},
					{  277,  908, 0x2175bd},
					{  261, 1080, 0x186dbd},
					{   38,  264, 0x2975b5},
				})	]]
		end
	end
	--[[stomMultiColorTap("右侧任务",{--右侧任务
			{  241, 1076, 0xa5dbff},
			{  524,  732, 0x94beef},
			{  172,  390, 0xffeb94},
			{   38, 1087, 0x94beef},
		})]]
	stomMultiColorTap("右侧任务单行备用",{--右侧任务
			{  240, 1073, 0xceebff},
			{  586,  699, 0x6b9ed6},
			{   22, 1108, 0x94beef},
			{  577, 1110, 0x4aaeef},
		})
	stomMultiColorTap("宝图任务",{--宝图任务
			{  211,  926, 0x8c3829},
			{  173,  389, 0xffefa5},
			{  529,  717, 0x94beef},
			{  224,  771, 0xc6e7ff},
		})	
	if stomMultiColor("宝图任务新手提示",{--宝图任务新手提示
			{  508,  464, 0xf792a5},
			{  470,  620, 0x3165a5},
			{  471,  639, 0x3965a5},
			{  472,  648, 0xadd3ff},
			})==true then stomtap(599,  361)
	end
	stomMultiColorTap("模式关闭",{--模式关闭
			{  210,  817, 0xe7c34a},
			{  305,  353, 0xff0000},
			{  359,  347, 0xffffff},
			{  341,  372, 0xffffff},
		})
	stomMultiColorTap("对话框左侧战斗",{--对话框左侧战斗
			{  322,  980, 0xffffff},
			{   39,  232, 0x2171b5},
			{   43,  308, 0x8cb6d6},
			{  259,  895, 0x2182ce},
		})
	stomMultiColorTap("对话框右侧战斗",{--对话框右侧战斗 
			{  323,  915, 0x2171bd},
			{   11,  770, 0x296194},
			{   38,  906, 0x215da5},
			{  266,  904, 0x1055ad},
		})
	stomMultiColorTap("右下角前往",{--右下角前往
			{  205,  884, 0xe7c34a},
			{  308,  804, 0x5a86c6},
			{  204,  805, 0xa5d3ff},
			{  200, 1071, 0x3982ce},
		})
	if stomMultiColor("弹窗学习技能满级,关闭",{--弹窗学习技能满级,关闭
			{  605,  244, 0x8cb6c6},
			{  451,  628, 0x424d63},
			{  447,  553, 0x9c9ead},
			{  606,  994, 0xf7be7b},
			})==true then stomtap(606,994) 
	end
	if stomMultiColor("弹窗学习技能满级,关闭B",{--弹窗学习技能满级,关闭
			{  449,  400, 0xffffff},
			{  442,  422, 0xffffff},
			{  471,  430, 0xffefad},
			{  446,  530, 0x94929c},
		})==true then stomtap(606,994) 
	end
	stomMultiColorTap("关闭改名",{--关闭改名
			{  328, 1089, 0x429ee7},
			{  316,  913, 0xffff7b},
			{  317,  975, 0xefba52},
			{  299,  984, 0xce9a31},
		})
	if stomMultiColor("tk1",{
			{  470,  566, 0x3165ad},
			{  464,  594, 0x3165a5},
			{  419,  445, 0xded3de},
			{  441,  597, 0x3965a5},
			})==true then 
		stomtap(615,  361)
		stommSleep(300)
		stomMultiColorTap("tktap",{
				{  608,  999, 0xffd78c},
				{  597,  985, 0xffbe5a},
				{  588,  996, 0xffd373},
				{  595, 1001, 0xde7129},
			})
	end

	stomMultiColorTap("经验不足关闭",{
			{  593,  996, 0xe7c763},
			{  393,  545, 0xe76d84},
			{  525,  499, 0x9cc3e7},
			{   98,  595, 0xe7cf7b},
		})
	stomMultiColorTap("升级礼包自动关闭1",{--升级礼包自动关闭1
			{  484, 1067, 0x080c08},
			{  314,  952, 0xffff73},
			{  307,  981, 0xa5aea5},
			{  308,  994, 0xbd6521},
		}) 
	stomMultiColorTap("升级礼包自动关闭1B",{--升级礼包自动关闭1
			{  197,  977, 0xe7cb31},
			{  220,  677, 0xce418c},
			{  195,  916, 0xe7cf39},
			{  280,  717, 0xefebf7},
		})
	--[[stomMultiColorTap("升级礼包自动关闭2",{--升级礼包自动关闭2
			{  484, 1067, 0x080c08},
			{  549,   98, 0xf7e7a5},
			{  601,  358, 0x52b6d6},
			{  579,  985, 0xd69e63},
		})]]
	stomMultiColorTap("升级礼包领取",{--升级礼包自动关闭1
		{  416,  814, 0x4aa2e7},
		{  420,  857, 0xc6efff},
		{  419,  884, 0xceefff},
		{  419,  899, 0xceefff},
	})
	if stomMultiColor("继续组队弹窗",{--继续组队弹窗
			{  437,  362, 0x639ad6},
			{  122,  392, 0xffdba5},
			{  318,  760, 0xffffff},
			{  208,  391, 0xdec331},
			})==true then stomtap(208,391)
	end
	if stomMultiColor("经验已满",{--
		{    0, 1135, 0x08cf5a},
		{    3, 1135, 0x08aa52},
		{    5, 1135, 0x42b273},
		{    8, 1135, 0x9ccfad},
	}) or stomMultiColor("经验已满弹窗",{--
		{    0, 1135, 0x006531},
		{    4, 1135, 0x085531},
		{    8, 1135, 0x4a695a},
		{    6, 1135, 0x31614a},
	}) then 
		stomtap(601,  985)
		stommSleep(500)
	end
	if stomMultiColor("人物界面经验已满",{--
		{  491,  861, 0x73d7ad},
		{  493,  861, 0x63d7a5},
		{  496,  861, 0x52cf9c},
		{  498,  861, 0x4ac79c},
	})	then
		stomtap(497,  659)
		stommSleep(500)
	end
	
	if 	stomMultiColorTap("手动升级",{--帮派申请
		{  170,  548, 0xffffff},
		{  167,  531, 0x4aa2ef},
		{  169,  605, 0x4aa2ef},
		{  411,  706, 0x52d39c},
		{  406,  706, 0x63d7a5},
	}) then
		pro_num=2
		getbook=0--重新找经验书
		zhuceflag=1
	end
	if stomMultiColor("注册",{--
		{  437,  315, 0xd60008},
		{  292,  498, 0x1086f7},
		{  215,  430, 0x318aff},
		{  198,  421, 0xf7f7f7},
	}) and zhuceflag==1then
		duoyi_fn_zhuce()
	end

	if stomMultiColorTap("取消表单",{--return0
			{  537,  299, 0x8c8684},
			{  529,  305, 0x8c8684},
			{  544,  305, 0x84868c},
			{  537,  533, 0x080400},
			{  537,  559, 0x000000},
		}) or 
	stomMultiColorTap("取消表单B",{
			{  537,  300, 0x848684},
			{  528,  306, 0x848684},
			{  530,  488, 0xefebef},
			{  252,  834, 0xf7f7f7},
		}) then
		stommSleep(500)
	stomMultiColorTap("多益注册账号关闭",{
			{  438,  831, 0x84868c},
			{  366,  316, 0x080808},
			{  373,  335, 0x9c9694},
			{  367,  361, 0x000000},
			{  440,  317, 0xd60010},
		})
	end
	if stomMultiColorTap("经验不足关闭小",{
		{  492,  763, 0xadd7f7},
		{  172,  529, 0x4aa2ef},
		{  161,  609, 0x4aa2ef},
		{  493,  537, 0xffef73},
	})	then
		zhuceflag=0
	end
	stomMultiColorTap("关闭蓝色经验条",{--帮派申请
		{  492,  763, 0xadd7f7},
		{  498,  757, 0xc6ebff},
		{  485,  770, 0x9cc7e7},
		{  181,  563, 0x4aa2ef},
		{  415,  434, 0x5a82a5},
	})
	--[[stomMultiColorTap("经验已满",{--帮派申请
		{  496,  686, 0xffffff},
		{  492,  861, 0x63dbad},
		{  495,  861, 0x5acf9c},
		{  499,  861, 0x4ac38c},
	})]]
	if zhuceflag == 0 then
		stomMultiColorTap("多益注册账号关闭",{
			{  438,  831, 0x84868c},
			{  366,  316, 0x080808},
			{  373,  335, 0x9c9694},
			{  367,  361, 0x000000},
			{  440,  317, 0xd60010},
		})
	end	
	if stomMultiColor("人物界面经验不满则关闭",{--帮派申请
		{  491,  862, 0x6b96ce},
		{  494,  862, 0x6b8ec6},
		{  497,  862, 0x6392c6},
		{  498,  860, 0x6b92ce},
		{  392,  544, 0xde6984},
	}) then
		zhuceflag=0
		stomtap(602,  999)
	end
	--[[stomMultiColor("备用直接关闭人物属性",{
		{   85,  569, 0x9c6510},
		{   80,  542, 0xe7c731},
		{  393,  544, 0xde6d84},
		{  344,  544, 0x5ab2ff},
	})]]
	stomMultiColorTap("帮派申请",{--帮派申请
			{  202,  938, 0x9c6510},
			{  307,  954, 0xa5b2ad},
			{  315,  972, 0xbd6921},
			{  289,  638, 0xf7aeff},
		})
	stomMultiColorTap("关闭双倍",{--关闭双倍
			{  418,  986, 0xb5d3ef},
			{  449,  405, 0xa50408},
			{  403,  556, 0xffffff},
			{  398,  591, 0xffffff},
		})	
	stomMultiColorTap("招募狼狗",{--招募狼狗
			{  107,  842, 0x8c5d18},
			{  197,  378, 0x3169ad},
			{  200,  404, 0x3165ad},
			{  256,  715, 0xefa2b5},
		})
	stomMultiColorTap("关闭招募",{--关闭招募
			{  597,  996, 0xd66d29},
			{  391,  210, 0x52595a},
			{  393,  230, 0x4a71a5},
			{  378,  281, 0xe7ebef},
		})
	if stomMultiColor("新手招募弹窗",{--新手招募弹窗
			{  184,  482, 0x3165a5},
			{  187,  503, 0x3965a5},
			{  107,  768, 0xf78ead},
			{  179,  569, 0xadd3f7},
			})==true then stomtap(47,  964)
		stommSleep(300)
		stomMultiColorTap("招募狼狗",{--招募狼狗
				{  107,  842, 0x8c5d18},
				{  197,  378, 0x3169ad},
				{  200,  404, 0x3165ad},
				{  256,  715, 0xefa2b5},
			})
		stommSleep(300)
		stomMultiColorTap("关闭",{--关闭
				{  597,  996, 0xd66d29},
				{  391,  210, 0x52595a},
				{  393,  230, 0x4a71a5},
				{  378,  281, 0xe7ebef},
			})
	end
	stomMultiColorTap("圆形实名",{
			{  138,  628, 0xefbe18},
			{  583,  415, 0x4aaade},
			{  554,  453, 0xb5dbff},
			{  558,  543, 0xefbe4a},
		})
	if	stomMultiColorTap("请输入姓名",{
		{  307,  440, 0x7b8284},
		{  307,  443, 0x84827b},
		{  302,  470, 0xa59e9c},
		{  299,  470, 0x9ca2a5},
		{  307,  334, 0x101418},
	}) then
		nicheng = ZKQ_Word(zhangkq["姓氏"],1,1)..ZKQ_Word(zhangkq["名字"],2,3)
		stommSleep(999)
		stomInpuText(nicheng)
		stommSleep(999)
		stomtap(552,  173)
	elseif	stomMultiColorTap("请输入身份证",{
		{  220,  437, 0x8c8e94},
		{  225,  457, 0x8c8a84},
		{  224,  472, 0xadaaad},
		{  226,  559, 0x9ca2a5},
		{  226,  380, 0x000000},
	}) then
		stommSleep(999)
		stomInpuText("440282195610226964")
		stommSleep(999)
		stomtap(552,  173)
	else stomMultiColorTap("确认",{
		{  126,  515, 0x108aff},
		{  128,  567, 0x108aff},
		{  128,  610, 0x1086f7},
		{  138,  578, 0xffffff},
	}) 
	end	
	stomMultiColorTap("确认提交",{
		{  245,  648, 0x108af7},
		{  322,  482, 0x7b757b},
		{  324,  508, 0x080408},
		{  410,  499, 0xe7efef},
	})
	if stomMultiColor("身份证有误",{
		{  480,  375, 0x313439},
		{  471,  383, 0xe7dfde},
		{  474,  451, 0x8c8e8c},
		{  472,  612, 0x737173},
		{  476,  635, 0x848a8c},
	}) then
		--重启游戏
		stomcloseApp("com.duoyi.shenwu3")
		stommSleep(5000)
		stomrunApp("com.duoyi.shenwu3")
	end
	stomMultiColorTap("切换任务界面",{
		{  508,  934, 0x949284},
		{  496,  962, 0x947531},
		{  499,  970, 0x948239},
		{  506,  988, 0x7b6939},
		{  497,  991, 0x8c6d29},
	})
	--[[if stomMultiColor("实名认证窗体",{--实名认证窗体
			{  547,  528, 0x000000},
			{  534,  563, 0x000000},
			{  538,  585, 0x000000},
			{  527,  609, 0xe7e7e7},
			})==true then
		stomMultiColorTap("第一个文本框",{
				{  303,  554, 0xa5a6a5},
				{  307,  434, 0xced3d6},
				{  307,  459, 0xd6cfce},
				{  312,  490, 0xffffff},
			})	
		stommSleep(500)
		stomInpuText("彭会")
		stommSleep(2000)
		if 
		stomMultiColorTap("第二个文本框",{
			{  405,  449, 0xffffff},
			{  406,  475, 0xffffff},
		}) then 
		stommSleep(500)
		stomInpuText("440282195610226964")
		stommSleep(500)
		stomMultiColorTap("提交",{--提交
				{  411,  613, 0x1088fb},
				{  408,  524, 0x1088f8},
				{  396,  583, 0xc7e4ff},
				{  354,  550, 0xfdfefe},
			})
		stommSleep(500)
		stomMultiColorTap("确定",{--确定
				{  247,  725, 0x1086f7},
				{  414,  340, 0xefebef},
				{  345,  607, 0xf7f7f7},
				{  418,  554, 0x100808},
			})
		end
	end]]
	stomMultiColorTap("实名已设置关闭",{
		{  125,  528, 0x108af7},
		{  392,  437, 0x6b7173},
		{  383,  466, 0x6b6d6b},
		{  526,  555, 0x181818},
		{  533,  527, 0x000000},
	})
	if stomMultiColor("绑定账号点击",{--绑定账号关闭
			{  315,  910, 0xffff7b},
			{  308,  935, 0xb56921},
			{  267,  973, 0x5a86d6},
			{  198,  945, 0xe7c731},
			})==true then stomtap(198,945)
		stommSleep(500)
		stomMultiColorTap("绑定账号关闭",{
				{  579,  988, 0x9c2800},
				{  587,  169, 0x31719c},
				{   23,  157, 0x6396c6},
				{   11,  982, 0x6396c6},
			})	
	end

	if stomMultiColor("判断是否有高亮礼包",{--判断是否有高亮礼包
			{  586,  687, 0xe7b24a},
			{  609,  694, 0xffffff},
			{  625,  700, 0xadcf73},
			{  628,  706, 0x529218},
			})==true then 
		stomtap(628,  706)
		stommSleep(200)
		stomMultiColorTap("领取桃子",{--判断领取桃子
				{  126,  552, 0xc6ebff},
				{  342,  437, 0x3165ad},
				{  340,  463, 0x3165ad},
				{  126,  539, 0xc6efff},
			})
	end
	stomMultiColorTap("关闭伙伴",{
		{  598,  996, 0xadf3ef},
		{  605,  988, 0xbdffef},
		{  102,  929, 0xbdbec6},
		{  559,  239, 0x9ccbf7},
	})
	stomMultiColorTap("关闭竞技场",{--关闭
		{  599,  995, 0xadf3ef},
		{  591,  988, 0x94ebff},
		{  589, 1000, 0x3161ce},
	})
	if stomMultiColor("彩石任务",{--关闭
		{  486,  700, 0xe7c710},
		{  364,  428, 0x8cc773},
		{  269,  833, 0x6baaef},
		{   87,  632, 0xff92a5},
	})then
		touchDown(491,  692)
		stommSleep(100)
		touchMove(356,  428)
		stommSleep(100)
		touchMove(245,  828)
		stommSleep(100)
		touchMove(84,  625)
		stommSleep(100)
		touchMove(177,  361)
		stommSleep(100)
		touchUp(177,  361)
	end
	stomMultiColorTap("老头任务1A",{--
		{  318,  950, 0xffffff},
		{  310,  963, 0xffffff},
		{  307,  927, 0x1871c6},
		{  318, 1002, 0xffffff},
		{  330, 1056, 0x2171bd},
	})
	stomMultiColorTap("老头任务2B",{--
		{  271,  939, 0xffffff},
		{  275,  916, 0x2175bd},
		{  276,  989, 0xffffff},
		{  271, 1017, 0xffffff},
		{  276, 1057, 0x2171bd},
	})	
	stomMultiColorTap("老头任务3B",{--
		{  262,  940, 0x1865bd},
		{  279,  947, 0x2171bd},
		{  267,  966, 0xffffff},
		{  272,  975, 0xffffff},
		{  277,  974, 0xffffff},
	})
	if 	stomMultiColorTap("右侧三行任务点上方",{--
	{  368,  958, 0xffffff},
	{  370,  920, 0x2171bd},
	{  316,  924, 0x1051ad},
	{  263,  924, 0x1065b5},
}) then
		stommSleep(300)
	elseif stomMultiColorTap("右侧双行任务点上方",{--
		{  323,  933, 0x2171bd},
		{  324, 1063, 0x1871bd},
		{  275,  920, 0x2175bd},
		{  277, 1073, 0x2171bd},
	})or 
	stomMultiColorTap("右侧双行任务点上方",{--
		{  323,  933, 0x2171bd},
		{  324, 1063, 0x1871bd},
		{  275,  920, 0x2175bd},
		{  277, 1073, 0x2171bd},
	})then
		stommSleep(300)
	end
	--[[stomMultiColorTap("绑定账号关闭!!",{
				{  579,  988, 0x9c2800},
				{  587,  169, 0x31719c},
				{   23,  157, 0x6396c6},
				{   11,  982, 0x6396c6},
			})	]]
	if stomMultiColor("七日",{{  318,  145, 0x9c3810},{  267,  157, 0x9c3410},{  226,  148, 0x9c4110},{  181,  147, 0x9c3810},})==true then
		if stomMultiColor("1d",{--七日
			{  127,  241, 0x8c5510},
			{  127,  243, 0xffdb52},
		})==true then 
			stomtap(127,  243)
		end
			if stomMultiColor("2d",{
			{  127,  362, 0x8c5510},
			{  127,  364, 0xffdb52},
		})==true then 
			stomtap(127,  364)
			end
			if stomMultiColor("3d",{
			{  125,  483, 0x8c5510},
			{  125,  485, 0xffdb52},
		})==true then 
			stomtap(125,  485)
			end
			if stomMultiColor("4d",{
			{  127,  604, 0x8c5510},
			{  127,  606, 0xffdb52},
		})==true then 
			stomtap(127,  606)
		end
			if stomMultiColor("5d",{			
			{  127,  749, 0xf7e37b},
			{  127,  729, 0xf7e37b},
		})==true then 
			stomtap(127,  729)
		end
			if stomMultiColor("6d",{
			{  125,  843, 0x8c5510},
			{  125,  845, 0xffdb52},
		})==true then 
			stomtap(125,  845)
			end
			if stomMultiColor("7d",{
			{  125,  962, 0x8c5510},
			{  125,  964, 0xffdb52},
		})==true then 
			stomtap(125,  964)
		end
		stomtap(450, 1025)
	end
	if stomMultiColor("购买需求商品",{--购买需求商品
		{  626,  252, 0xcecbce},
		{  613,  257, 0x5a6984},
		{  615,  302, 0x426184},
		{  600,  996, 0xd66929},
		})==true then	
		x,y = findMultiColorInRegionFuzzy( 0xde597b, "27|35|0xf76184,-9|14|0xffe7ce,16|38|0xef5d7b", 90, 100, 445, 545, 933)
		if x ~= -1 then
			stomtap(x,y)
			stommSleep(100)
			stomtap(70,  684)
		end
	end
	--[[
	if whoAmI() > 3 then
		if stomMultiColor("需要滑动验证",{
			{  463,  283, 0x4a9ac6},
			{  441,  761, 0x4a8ece},
			{  159,  295, 0xe7c76b},
			{  159,  753, 0x3179c6},
		}) then
			local picPath = stomgetSandboxPath(apple_bid).."/tmp/yz.jpg"
			os.execute("rm -rf "..picPath)
			local tmtype = "6001"
			stomsnapshot(picPath,132,  271, 441,  815, 0.5)	--滑动
			stommSleep(999)
			if stomisFileExist(picPath) then
				stommSleep(1000)
				local dmTB = sendPIC_HaoAi(picPath,tmtype,tmtimeout)
				if #dmTB > 0 then
					stommoveTo(156,  323, 150, dmTB[2]-50)
					stommSleep(5000)
				else
					stomLog("dmTB错误")
					stomtoast("dmTB错误",5)
					stommSleep(5000)
				end
			else
				stomLog("JPG不存在")
				stomtoast("JPG不存在",5)
				stommSleep(5000)
			end
		end
	end
	
	--获取等级
	if whoAmI() > 3 then
		if stomMultiColor("等级界面",{}) then
			local picPath = stomgetSandboxPath(apple_bid).."/tmp/yz.jpg"
			os.execute("rm -rf "..picPath)
			local tmtype = "1002"
			stomsnapshot(picPath,540,  384, 567,  422)	--等级
			stomLog(picPath)
			if stomisFileExist(picPath) then
				stommSleep(1000)
				local dmTB = sendPIC_HaoAi(picPath,tmtype,tmtimeout)
				if #dmTB > 0 then
					sw_dengji = dmTB[1]
					stomLog(sw_dengji)
					stommSleep(5000)
				else
					stomLog("dmTB错误")
					stomtoast("dmTB错误",5)
					stommSleep(5000)
				end
			else
				stomLog("JPG不存在")
				stomtoast("JPG不存在",5)
				stommSleep(5000)
			end
		end
	end	
	]]
	
end

function SW1282917929_fn_siwang()
		if stomMultiColor("死亡界面",{--死亡界面
			{  421,  285, 0x311818},
			{  550,  531, 0x3165ad},
			{  500,  514, 0x3165a5},
			{  541,  870, 0x84cbff},
			})==true then 
		if stomMultiColor("招募高亮则点击",{--招募高亮则点击
				{  420,  483, 0xfff3a5},
				{  502,  514, 0x4a6db5},
				{  329,  501, 0x734121},
				{  387,  521, 0xffeb5a},
				})==true then stomtap(387,521)
			stommSleep(50)
			stomMultiColorTap("招募最后一个小伙伴",{--招募最后一个小伙伴
					{  400,  400, 0x212021},
					{  415,  341, 0x4a5163},
					{  354,  341, 0xe7e7e7},
					{  359,  401, 0xc6bebd},
					})	stommSleep(30)
			stomtap(97,844)--招募
			stommSleep(50)
			stomtap(597,993)--关闭招募
			stommSleep(50)
			stomMultiColorTap("关闭死亡界面",{--关闭死亡界面
					{  546,  859, 0x4aa2e7},
					{  441,  285, 0xef9e7b},
					{  371,  309, 0xf7db6b},
					{  496,  533, 0x427dbd},
				})
			stomMultiColorTap("点开日程任务",{--点开日程任务
					{  603,  369, 0xa52429},
					{  601,  370, 0xc69e63},
					{  615,  377, 0xf7e7ad},
					{  617,  365, 0xf7e7ad},
				})		
			stomMultiColorTap("点开日程任务B",{--点开日程任务
			{  590,  368, 0xf7df9c},
			{  602,  384, 0xffb600},
			{  603,  374, 0xceb67b},
			{  608,  361, 0x63e3a5},
		})
		elseif stomMultiColor("死亡是打造装备高亮",{--死亡是打造装备高亮
			{  491,  516, 0x3169ad},
			{  492,  542, 0x3165a5},
			{  385,  487, 0x94beef},
			{  393,  767, 0x94beef},
			{  396,  620, 0x0886b5},
		})==true then 
				stomtap(549,  860)
				stommSleep(300)
				stomtap(599,  369)--打开日常
		elseif stomMultiColor("死亡是打造装备高亮",{--死亡是打造装备高亮
				{  500,  495, 0x3165ad},
				{  388,  508, 0x94beef},
				{  383,  654, 0x42699c},
				{  380,  751, 0x94c3ef},
				})==true then 
			stomtap(547,  861)
			stommSleep(200)
			stomMultiColorTap("点开日程任务",{--点开日程任务
					{  603,  369, 0xa52429},
					{  601,  370, 0xc69e63},
					{  615,  377, 0xf7e7ad},
					{  617,  365, 0xf7e7ad},
				})
		elseif stomMultiColor("sw1",{
				{  491,  521, 0x3965a5},
				{  498,  535, 0x8cbeef},
				{  386,  488, 0x7b3818},
				{  378,  763, 0xd6dfe7},
				})==true then 
			stomMultiColorTap("关闭死亡界面",{--关闭死亡界面
					{  546,  859, 0x4aa2e7},
					{  441,  285, 0xef9e7b},
					{  371,  309, 0xf7db6b},
					{  496,  533, 0x427dbd},
				})	
			stommSleep(200)
			stomtap(59,  958)--打开伙伴
			stommSleep(200)
			stomtap(467,  195)--第一个人头
			stommSleep(200)
			stomMultiColorTap("升级装备",{--升级装备
					{  104,  941, 0xdebe31},
					{  102,  845, 0x946510},
					{  113,  852, 0xe7c75a},
					{  102,  903, 0xdec331},
				})
			stommSleep(200)
			stomMultiColorTap("确认打造",{--确认打造
					{  206,  385, 0xdec331},
					{  403,  493, 0xffffff},
					{  409,  548, 0x4279ce},
					{  310,  349, 0xffffff},
				})
			stommSleep(200)
			stomtap(481,  284)--第2个人头
			stommSleep(200)
			stomMultiColorTap("升级装备",{--升级装备
					{  104,  941, 0xdebe31},
					{  102,  845, 0x946510},
					{  113,  852, 0xe7c75a},
					{  102,  903, 0xdec331},
				})
			stommSleep(200)
			stomMultiColorTap("确认打造",{--确认打造
					{  206,  385, 0xdec331},
					{  403,  493, 0xffffff},
					{  409,  548, 0x4279ce},
					{  310,  349, 0xffffff},
				})
			stommSleep(200)
			stomtap(479,  368)--第3个人头
			stommSleep(200)
			stomMultiColorTap("升级装备",{--升级装备
					{  104,  941, 0xdebe31},
					{  102,  845, 0x946510},
					{  113,  852, 0xe7c75a},
					{  102,  903, 0xdec331},
				})
			stommSleep(200)
			stomMultiColorTap("确认打造",{--确认打造
					{  206,  385, 0xdec331},
					{  403,  493, 0xffffff},
					{  409,  548, 0x4279ce},
					{  310,  349, 0xffffff},
				})
			stommSleep(200)
			stomtap(378,  198)--第4个人头
			stommSleep(200)
			stomMultiColorTap("升级装备",{--升级装备
					{  104,  941, 0xdebe31},
					{  102,  845, 0x946510},
					{  113,  852, 0xe7c75a},
					{  102,  903, 0xdec331},
				})
			stommSleep(200)
			stomMultiColorTap("确认打造",{--确认打造
					{  206,  385, 0xdec331},
					{  403,  493, 0xffffff},
					{  409,  548, 0x4279ce},
					{  310,  349, 0xffffff},
				})
			stommSleep(200)
			stomtap(349,  106)
			stommSleep(200)
			stomtap(598,  366) --打开日常
			if stomMultiColor("sw2",{
					{  394,  424, 0xff96b5},
					{  537,  496, 0xefdbde},
					{  503,  773, 0x8cbae7},
					{  399,  770, 0x84beef},
					})==true then stomtap(598,  366) 
			end
			----stomLog("刚不过 打日常")
			--return 1
		else --tap(548,861)--关闭死亡界面
		end
	end
end

function SW1282917929_fn_duihua()
	for i=1,20,1 do
		if stomMultiColorTap("对话框右侧",{--对话框右侧
		{   34,  958, 0x184573},
		{   32,  582, 0x2179a5},
		{   38,  799, 0x1865ad},
		{   42,  872, 0x638eb5},
		}) then 
			stommSleep(40)
		end
		if stomMultiColor("对话框左侧",{--对话框左侧
		{   34,  234, 0x2165a5},
		{   43,  262, 0x73a6ce},
		{   39,  345, 0x2975b5},
		{   34,  831, 0x2179a5},
		})==true then
			if stomMultiColor("判断守卫",{--判断守卫
				{  174,  156, 0xde9a73},
				{  234,  268, 0x4ae3de},
				{   23,  223, 0xffef73},
				{  119,  749, 0xf7efef},
				})==true 
				then
					stomMultiColorTap("关闭守卫对话",{
					{  112,  689, 0xffffff},
					{  233,  269, 0x39d3c6},
					{  108,  521, 0xffffff},
					{  115,  626, 0xffffff},
				})
				----stomLog("开始执行守卫任务")
				stomtap(349,  574)--关闭对话框
				stommSleep(100)
				stomtap(230,  160)--走位第一个点
				stommSleep(1900)
				stomtap(430,  217)
				stommSleep(900)
					if stomMultiColor("如果位置达到第二个点",{--如果位置达到第二个点
					{  586,  251, 0x94b24a},
					{  149,   80, 0xe7a231},
					{   69,  630, 0x421808},
					{  189, 1029, 0xffba29},
					})==true 
					then 
						stomtap(452,  964)
						stommSleep(100)
					end
			else 
				stomMultiColorTap("对话框左侧",{--对话框左侧
				{   34,  831, 0x2179a5},
				{   34,  234, 0x2165a5},
				{   43,  262, 0x73a6ce},
				{   39,  345, 0x2975b5},
			})
				stommSleep(40)
			end
		end
		--[[if stomMultiColor("如果在主界面",{
		{  123,  390, 0xffdf9c},
		{   30,  388, 0xffffbd},
		{  494, 1110, 0x4aaae7},
		{   80, 1088, 0xd6d7a5},
		})==true 
		then break
		end]]
	end
end

function SW1282917929_fn_renwujiance()
	checkcount=1
	for var= 1, 3 do
		stomLog("开始检测"..checkcount)
		stomtoast("检测-请勿操作")
		stomMultiColorTap("打开任务",{
			{  499,  972, 0xf7d363},
		})
		stommSleep(500)
		if 	stomMultiColor("任务列表中",{
				{  546,  267, 0x3165ad},
				{  547,  277, 0x3965a5},
				{  544,  294, 0x3165a5},
				{  544,  364, 0xbdd3f7},
		}) then
			if stomMultiColorTap("选中当前任务",{
				{  534, 1001, 0x396594},
				{  522, 1014, 0xadcbff},
				{  476, 1002, 0x395d8c},
			}) then
				stommSleep(500)
			end
			--当前任务
			if stomMultiColor("主线",{
				{  547,  483, 0x4261a5},
				{  541,  486, 0x3169ad},
				{  534,  479, 0x3165ad},
				{  534,  492, 0x3165a5},
			}) then
				stomMultiColorTap("勾选",{{  497,  188, 0x5282bd},})
			end
			
			stommSleep(500)
			stomtap(455,  244)--第二个任务
			stommSleep(1000)
			if stomMultiColor("右边引导-师门",{
				{  471,  486, 0x3169ad},
				{  470,  511, 0x3165ad},
				{  472,  648, 0x3165ad},
				{  472,  674, 0x3165a5},
			}) then
				stomMultiColorTap("关闭对勾",{{  453,  188, 0x73ebc6},})
				break
			end
			if stomMultiColor("主线",{
				{  547,  483, 0x4261a5},
				{  541,  486, 0x3169ad},
				{  534,  479, 0x3165ad},
				{  534,  492, 0x3165a5},
			}) then
				stomMultiColorTap("勾选",{{	453,  187, 0x5a82b5 },})
			end
			
			stommSleep(500)
			stomtap(414,  296)--第三个任务
			stommSleep(1000)
			if stomMultiColor("右边引导-师门",{
				{  471,  486, 0x3169ad},
				{  470,  511, 0x3165ad},
				{  472,  648, 0x3165ad},
				{  472,  674, 0x3165a5},
			}) then
				stomMultiColorTap("关闭对勾",{{  408,  189, 0x6bebc6},})
				break
			end
			if stomMultiColor("主线",{
				{  547,  483, 0x4261a5},
				{  541,  486, 0x3169ad},
				{  534,  479, 0x3165ad},
				{  534,  492, 0x3165a5},
			}) then
				stomMultiColorTap("勾选",{{	411,  187, 0x5a82b5 },})
			end
			
			stommSleep(500)
			stomtap(368,  296)--第四个任务
			stommSleep(1000)
			if stomMultiColor("右边引导-师门",{
				{  471,  486, 0x3169ad},
				{  470,  511, 0x3165ad},
				{  472,  648, 0x3165ad},
				{  472,  674, 0x3165a5},
			}) then
				stomMultiColorTap("关闭对勾",{{  363,  189, 0x73ebbd},})
				break
			end
			if stomMultiColor("主线",{
				{  547,  483, 0x4261a5},
				{  541,  486, 0x3169ad},
				{  534,  479, 0x3165ad},
				{  534,  492, 0x3165a5},
			}) then
				stomMultiColorTap("勾选",{{	 367,  187, 0x5a82b5 },})
			end
			--[[x,y = findMultiColorInRegionFuzzy( 0x6be7bd, "3|72|0x3169ad,-1|78|0x3169ad,8|129|0x3165ad,12|147|0x3165ad", 90, 338, 242, 475, 404)
			stommSleep(500)
			if x ~= -1 then 
				stomtap(x,y)--检查是否有引导任务
				stommSleep(300)
				stomLog("执行了关闭")
				stomtap(333,  110)--关闭任务
				break
			end]]
			checkcount=checkcount+1
		end	
		if 	stomMultiColor("关闭任务列表",{
				{  546,  267, 0x3165ad},
				{  547,  277, 0x3965a5},
				{  544,  294, 0x3165a5},
				{  544,  364, 0xbdd3f7},
		}) then
			stomtap(333,  110)--关闭任务
		end	
		if checkcount > 2 then
			break
		end
		SW1282917929_fn_tankuang()
		SW1282917929_fn_duihua()
		SW1282917929_fn_richangrenwu()
	end
end

function SW1282917929_fn_login()
	--人物选择
	if stomMultiColor("进入主界面",{--进入主界面
				{  123,  390, 0xffdf9c},
				{  452,  964, 0xffff42},
				})==true or stomMultiColor("进入主界面2",{--进入主界面
				{  502,  937, 0xffe784},
				{  179,  383, 0xffaa21},
				})==true then
			stommSleep(300)
		--	stomtap( 604,  371)
		--SW1282917929_fn_renwujiance()
		--[[if stomMultiColorTap("领取双倍",{--领取双倍
				{  546,  966, 0x0079b5},
				{  558,  953, 0x52b2d6},
				{  557,  970, 0xceeff7},
				{  535,  970, 0xe7ebf7},
			}) then 
		stommSleep(100)
		stomMultiColorTap("点加号",{--点加号
				{  350,  663, 0xc6e3ff},
				{  356,  421, 0x3165ad},
				{  356,  427, 0x29498c},
				{  356,  436, 0x3165ad},
			})
		stommSleep(100)
		stomMultiColorTap("点加号",{--点加号
				{  350,  663, 0xc6e3ff},
				{  356,  421, 0x3165ad},
				{  356,  427, 0x29498c},
				{  356,  436, 0x3165ad},
			})
		stommSleep(100)
		stomMultiColorTap("点加号",{--点加号
				{  350,  663, 0xc6e3ff},
				{  356,  421, 0x3165ad},
				{  356,  427, 0x29498c},
				{  356,  436, 0x3165ad},
			})
		stommSleep(100)
		stomtap(492,  769)
		end]]
		return true
	end
end

function SW1282917929_fn_jineng()
	stomMultiColorTap("学习技能",{--学习技能
	{  200,  936, 0x9c5510},
	{  265,  656, 0xce558c},
	{  311,  929, 0xefcb52},
	{  272,  978, 0x5286de},
})
	stomMultiColorTap("弹窗学习技能",{--弹窗学习技能
	{   54,  870, 0x6b5dde},
	{  171,  429, 0x527db5},
	{  144,  455, 0x3975bd},
	{  125,  765, 0xc64dde},
})
	if stomMultiColor("判断是否有竞技场",{--判断是否有竞技场
		{  356,  982, 0xffff42},
		{  347,  983, 0xffef31},
		{  349, 1007, 0xffff42},
		{  355, 1033, 0xffff42},
		})==true then 
	stomtap(484,  953)
	stommSleep(100)
	x,y = findMultiColorInRegionFuzzy( 0xa5ffd6, "3|86|0x3165a5,8|108|0x3169ad,11|144|0x5286bd", 90, 238, 169, 519, 349)
		if x ~= -1 then 
			stomLog("关闭竞技场")
			stomtap(x,y)--取消竞技场任务
			stommSleep(100)
		end
		j,k = findMultiColorInRegionFuzzy( 0x7befc6, "6|71|0x6bebde,7|88|0x3165ad,7|149|0x3165ad", 90, 327, 165, 521, 421)
		if j ~= -1 then
			stomLog("关闭竞技场")
			stomtap(j,k)--取消竞技场任务
			stommSleep(100)
		end
		stommSleep(300)
	end	
	if stomMultiColor("判断丝绸任务",{
	{  409, 1009, 0xa59e9c},
	{  409, 1020, 0xa5a2a5},
	{  418, 1036, 0xffffff},
	{  415, 1045, 0x8c8684},
}) then
		stomtap( 452,  963)
		stommSleep(100)		
		if stomMultiColor("判断任务列表丝绸任务",{
			{  456,  573, 0x3165ad},
			{  465,  595, 0x3965a5},
			{  504,  266, 0x3165a5},
			{  505,  356, 0x3169ad},
		}) then
		stommSleep(500)
		stomtap(495,  184)
		end
	end
end

function SW1282917929_fn_zhuxian()

	if stomMultiColor("守卫任务",{
		{  415,  966, 0x42ff21},
		{  414,  973, 0x42ff21},
		{  414,  984, 0x318629},
		{  420, 1014, 0x42ff21},
	})	then
		hdtap( 55,  961)
		stommSleep(300)
		stomMultiColorTap("伙伴6",{--弹窗学习技能
		{  382,  377, 0xb5b6bd},
		{  385,  383, 0x181410},
		{  390,  393, 0xadaead},
	})
		stommSleep(300)
		stomMultiColorTap("招募",{--弹窗学习技能
		{   89,  848, 0xe7db42},
		{   87,  863, 0x9c6510},
		{   88,  917, 0xe7db42},
	})
		stommSleep(300)		
		stomMultiColorTap("伙伴5",{--弹窗学习技能
		{  380,  281, 0xe7e7e7},
		{  402,  275, 0x181c21},
		{  395,  268, 0xdee3de},
	})
		stommSleep(300)
		stomMultiColorTap("招募",{--弹窗学习技能
		{   89,  848, 0xe7db42},
		{   87,  863, 0x9c6510},
		{   88,  917, 0xe7db42},
	})
		stommSleep(300)	
		hdtap(349,  106)
		stommSleep(300)	
		--[[stomMultiColorTap("守卫任务",{
			{  415,  966, 0x42ff21},
			{  414,  973, 0x42ff21},
			{  414,  984, 0x318629},
			{  420, 1014, 0x42ff21},
		})		]]
	end
	if stomMultiColor("判断主界面",{--判断主界面
			{  123,  390, 0xffdf9c},
			{  452,  964, 0xffff42},
			})==true or stomMultiColor("判断主界面",{
			{  502,  937, 0xffe784},
			{  179,  383, 0xffaa21},
		})
		then 
		--stomLog("找到了主界面")
		x,y = findMultiColorInRegionFuzzy( 0xffff42, "0|17|0xffff42,-14|21|0xffef31,-11|40|0xf7ff4a", 80, 235, 897, 478, 963)
		if stomMultiColor("执行了下方任务--等级限制18",{--18级限制
			{  417,  923, 0x4aff21},
			{  417,  937, 0x4aff21},
			{  416, 1020, 0xffffff},
			{  373,  963, 0xffff42},
		})==true
		then hdtap(371,  969)--支线
		stommSleep(2000)
		stomMultiColorTap("点开日程任务B",{--点开日程任务
			{  590,  368, 0xf7df9c},
			{  602,  384, 0xffb600},
			{  603,  374, 0xceb67b},
			{  608,  361, 0x63e3a5},
		})
		elseif stomMultiColor("沙僧任务",{
			{  416,  951, 0x39b221},
			{  422,  953, 0x39d718},
			{  415,  977, 0x397918},
			{  408,  974, 0x398a10},
			{  394,  948, 0x398618},
		})==true then
			hdtap(601,  364)
			stommSleep(300)
			if stomMultiColorTap("日程师门",{--日程1
			{  613,  239, 0xadbec6},
			{  513,  249, 0xefc308},
			{  468,  272, 0xefb26b},
			{  492,  262, 0xf77d5a},
			})==true or
			stomMultiColorTap("日程师门B",{--日程1
				{  504,  242, 0xefc318},
				{  491,  262, 0xef7d5a},
				{  517,  272, 0xefcb18},
				{  477,  255, 0xefd77b},
			}) or
			stomMultiColorTap("日程师门c",{--日程1
				{  480,  250, 0xefdf84},
				{  480,  233, 0xefdf84},
				{  479,  251, 0xa57d42},
				{  482,  268, 0x633408},
			})then
			else hdtap(439, 1056)--关闭
				stommSleep(300)
				hdtap(439, 1056)--做主线
			end			
		elseif stomMultiColor("执行了上方任务--等级限制18",{
		{  172,  390, 0xffeb94},
		{  345,  922, 0x42ff21},
		{  329,  923, 0x4af321},
		{  332,  941, 0x4af329},
		})==true or 
		stomMultiColor("执行了上方任务--等级限制18B",{
			{  321, 1022, 0x5c666e},
			{  312, 1028, 0xffffff},
			{  314, 1042, 0xffffff},
			{  314, 1109, 0xe5e2e4},
			{  312,  923, 0x44ff22},
		}) then hdtap(452,  964)
			--stomLog("执行了上方任务--等级限制18")
			stommSleep(2000)
		elseif stomMultiColor("执行了下方任务--等级限制18new",{
			{  453,  978, 0xffff42},
			{  444,  981, 0xffff4a},
			{  461, 1002, 0xffff42},
			{  449, 1000, 0xffff42},
			{  444, 1001, 0xffff4a},
			{  417,  936, 0x42ff21},
		}) then 
			if stomMultiColorTap("下方可做",{{  373,  964, 0xffff42},}) then
			else 
				local i = math.random(0,2) 	
				if i==0 then				
					hdtap(605,  228)--打开日常  第一位日常
				else 
					hdtap(452,  964)--执行了首行任务
				end
			end
			stommSleep(2000)	
		elseif stomMultiColor("执行了上方任务--等级限制18B",{--18级备选
		{  338,  934, 0x42ff21},
		{  344,  934, 0x42ff21},
		{  331,  940, 0x42ff21},
		{  328,  964, 0xffffff},
		})==true then hdtap(452,  964)
			--stomLog("执行了上方任务--等级限制18B")
			stommSleep(2000)
		elseif stomMultiColor("25等级限制首行",{--25等级限制！！
			{  420,  919, 0x42ff21},
			{  409,  927, 0x4aff21},
			{  411,  932, 0x42ff21},
			{  422,  934, 0x426531},
		}) or stomMultiColor("25等级限制B",{
			{  409,  922, 0x42ff21},
			{  425, 1023, 0xffffff},
			{  455,  982, 0xffff42},
			{  450, 1027, 0xffff4a},
			{  423, 1042, 0xffffff},
		}) or stomMultiColor("25等级限制C",{
			{  409,  924, 0x42ff21},
			{  455,  982, 0xffff42},
			{  452, 1006, 0xffff42},
			{  444, 1023, 0xffff4a},
		}) then 
			if stomMultiColorTap("下方可做",{{  373,  964, 0xffff42},}) then
			else 
				local i = math.random(0,4) 	
				if i==0 then
					hdtap(452,  964)--执行了首行任务
				else 
					hdtap(600,  369)--打开日常
				end
			end
			stommSleep(3000)
		--stomLog("18级等级限制，执行了日常方法")
		elseif stomMultiColor("25等级限制--第二行且下方有任务",{--25等级限制！！
			{  409,  920, 0x44ff22},
			{  415, 1041, 0xffffff},
			{  455,  982, 0xffff44},
			{  455, 1026, 0xffff44},
			{  373,  964, 0xffff44},
		}) then
			hdtap(373,  964)
		elseif stomMultiColor("25等级限制--第五行",{--25等级限制！！
			{  313,  978, 0x6e676d},
			{  318,  996, 0xfcffff},
			{  321, 1024, 0x65636a},
			{  314, 1042, 0xfcf9fc},
			{  302, 1042, 0xfffcff},
		}) then
			if stomMultiColor("下方还有任务",{{  268,  963, 0xffff4a},}) then 
			local i = math.random(0,1) 	
				if i==1 then
					hdtap(452,  964)--上方任务		
				else 
					stomMultiColorTap("25等级限制--第六行",{{  268,  963, 0xffff4a},}) 
				end				
			else
				local i = math.random(0,1) 	
				if i==1 then
					hdtap(452,  964)--上方任务		
				else 
					hdtap(600,  369)--打开日常
				end	
				hdtap(452,  964)--上方任务		
			end
		elseif stomMultiColor("25等级限制--第六行",{--25等级限制！！
			{  225,  921, 0x4aff21},
			{  225,  925, 0x4aff21},
			{  239,  938, 0x42ff21},
			{  230,  941, 0x42ff21},
			{  271, 1026, 0xffff42},
			{  267, 1052, 0xffff42},
		}) or stomMultiColor("25等级限制--第七行",{--25等级限制！！
			{  236,  933, 0x44ff22},
			{  241, 1025, 0xffffff},
			{  240,  935, 0x44ff22},
			{  271,  982, 0xffff44},
			{  268, 1006, 0xffff44},
		}) or stomMultiColor("25等级限制--第八行",{--25等级限制！！
			{  209,  975, 0xf9ffff},
			{  209,  983, 0xf8fdff},
			{  215, 1023, 0xfffdff},
			{  208, 1045, 0x858287},
			{  205, 1041, 0xfffbff},
		})then
			local i = math.random(0,3) 	
			if i==1 then
				hdtap( 373,  965)--执行了中间任务
			else 
				hdtap(452,  964)--执行了首行任务	
			end
			stommSleep(2000)
		elseif stomMultiColor("32等级限制B",{--35等级限制！！
			{  409,  923, 0x4aff21},
			{  425,  924, 0x426921},
			{  410,  939, 0x428e39},
			{  408,  934, 0x42a231},
			{  456,  981, 0x8c8642},
		}) then
			hdtap(602,  365)
			stommSleep(300)
			if stomMultiColorTap("日程师门",{--日程1
			{  613,  239, 0xadbec6},
			{  513,  249, 0xefc308},
			{  468,  272, 0xefb26b},
			{  492,  262, 0xf77d5a},
			})==true or
			stomMultiColorTap("日程师门B",{--日程1
				{  504,  242, 0xefc318},
				{  491,  262, 0xef7d5a},
				{  517,  272, 0xefcb18},
				{  477,  255, 0xefd77b},
			}) or
			stomMultiColorTap("日程师门c",{--日程1
				{  480,  250, 0xefdf84},
				{  480,  233, 0xefdf84},
				{  479,  251, 0xa57d42},
				{  482,  268, 0x633408},
			})then
			else stomtap(439, 1056)--关闭
				stommSleep(300)
				hdtap(439, 1056)--做主线
			end		
		elseif stomMultiColor("35等级限制B",{--35等级限制！！
			{  422,  919, 0x42ff29},
			{  422,  927, 0x42ff29},
			{  411,  927, 0x4aff21},
			{  409,  920, 0x42ff21},
		})==true  then 

			if stomMultiColor("下方有任务",{
			{  373,  968, 0xffff42},
			{  373,  965, 0xffff42},
			{  373,  962, 0xffff42},
		})==true then
			stomMultiColorTap("点开日程任务",{--点开日程任务
			{  373,  968, 0xffff42},
			{  373,  965, 0xffff42},
			{  373,  962, 0xffff42},
		})
			stomMultiColorTap("点开日程任务B",{--点开日程任务
			{  590,  368, 0xf7df9c},
			{  602,  384, 0xffb600},
			{  603,  374, 0xceb67b},
			{  608,  361, 0x63e3a5},
		})
			stommSleep(2000)
			else hdtap(452,  964)--执行主线
			end
		elseif stomMultiColor("判定组队在第3行",{--判定组队在第3行
			{  399,  929, 0x4aff21},
			{  398,  945, 0x42ff21},
			{  396,  975, 0x42ff21},
			{  382, 1003, 0x42ff29},
		})==true then 
			if stomMultiColor("强敌限制进行支线1",{
				{  373,  963, 0xffff42},
				{  373,  969, 0xffff42},
			})==true then	
			hdtap(324,  977)
			stommSleep(2000)
			--stomLog("强敌限制进行支线1")
			elseif stomMultiColor("强敌限制进行支线1B",{
			{  347,  968, 0xffff42},
			{  347,  960, 0xffff42},
		})==true then hdtap(347,  960)
			--stomLog("强敌限制进行支线1")
			stommSleep(2000)
			else 
				local i = math.random(0,3) 	
				if i~=0 then
					hdtap(600,  370)--点开日常
				else 
					hdtap( 446,  974)
					stommSleep(2000)
					stomLog("无多余任务开始刚")
				end				
			end
		elseif stomMultiColor("强敌限制（第三行）进行支线2",{
		{  320,  929, 0x42ff29},
		{  316,  959, 0x42ff21},
		{  318,  979, 0x42ff29},
		{  303,  997, 0x4aff21},
		{  314, 1011, 0x42ff29},
		})==true then 
			local qiangdi2 = math.random(0,9) 
			if qiangdi2==0 then
				hdtap(373,  962)--执行了第三行行任务			
				stommSleep(6000)
			else
				hdtap(451,  974)--首行
				stommSleep(2000)
			end
			--stomLog("强敌限制进行支线2")	
		elseif stomMultiColor("强敌限制进行支线3",{
			{  302,  930, 0x42ff21},
			{  321,  930, 0x42ff21},
			{  321,  952, 0x42ff21},
			{  310, 1019, 0x318e29},
			})==true then hdtap(451,  962)
				stommSleep(2000)
				--stomLog("强敌限制进行支线3")
		elseif stomMultiColor("强敌任务 执行了上方任务",{--强敌任务 执行了上方任务
				{  295,  930, 0x42ff21},
				{  275,  930, 0x42c321},
				{  293,  945, 0x4aff21},
				{  295,  973, 0x39df21},
			})==true then hdtap(450,  984)
			stommSleep(2000)
		elseif stomMultiColor("45级等级限制",{--45级等级限制
			{  424,  925, 0x42ff29},
			{  408,  926, 0x42ff21},
			{  423,  940, 0x42ff21},
			{  410,  939, 0x42ff29},
		})==true then 
				if	stomMultiColor("等级到达45",{
				{  569,  956, 0xdefbf7},
				{  576,  960, 0xc6dfe7},
				{  566,  959, 0xadc3bd},
				{  566,  967, 0xbdcbd6},
				{  572,  965, 0x9caebd},
				{  578,  967, 0xadcfd6},
			})==true then 
					stomMultiColorTap("做上方45任务",{
					{  451,  923, 0xffff42},
					{  452,  948, 0xffff42},
					{  416,  925, 0x31aa21},
					{  424,  937, 0x42ff29},
				})
					stommSleep(300)
				end
				if	stomMultiColor("45级等级限制1",{
				{  499,  935, 0xefcb94},
				{   29,  388, 0xffefad},
				{  373,  960, 0xffff42},
				{  373,  969, 0xffff42},
				})==true then hdtap(373,  969)--执行下方任务
				stommSleep(300)
				
				else hdtap(610,  373)--接任务
					stommSleep(200)
					stomMultiColorTap("做日常45",{--45级等级限制
						{  480,  251, 0xefdf84},
						{  482,  235, 0x633410},
						{  480,  270, 0xefdf84},
						{  481,  286, 0x734918},
					})
				end
		--stomLog("45级等级限制1")
		elseif stomMultiColor("45级等级限制",{--45级等级限制
			{  345,  925, 0x4aff21},
			{  329,  926, 0x42ff21},
			{  333,  932, 0x42ff21},
			{  344,  940, 0x42ff21},
		})==true then hdtap(449,  962)
		stommSleep(2000)
		--stomLog("45级等级限制2")
		elseif stomMultiColor("45级等级限制B",{--45级等级限制
			{  319,  925, 0x4aff21},
			{  303,  926, 0x42ff21},
			{  307,  932, 0x42ff21},
			{  318,  940, 0x42ff21},
			})==true then hdtap(456,  982)--执行了上方任务
		elseif stomMultiColor("32级等级限制",{--32
			{  421,  919, 0x4aff21},
			{  410,  919, 0x42ff29},
			{  417,  927, 0x423c21},
			{  409,  940, 0x42ff21},
		})==true then hdtap(608,  360)--打开日常
		stommSleep(3000)
		elseif stomMultiColor("32级等级限制",{--32
			{  342,  919, 0x42ff29},
			{  332,  919, 0x42ff21},
			{  342,  932, 0x42ff21},
			{  341,  932, 0x42ff21},
		})==true then hdtap(443,  996)--执行上方任务
		stommSleep(500)
		elseif x ~= -1 then--找主线
			stomtap(x,y)
			stommSleep(2000)
			--stomLog("执行了主线"..x..y)
			--end
		else hdtap(452,  964)
			stomLog("默认任务")
			stommSleep(2000)
			--stomLog("任务不满足当前条件-开始刚")
		end
	else  --stomLog("未找到任务主界面")
		
	end
	----stomLog("执行了主线方法")
	--return 1
end

function SW1282917929_fn_shengjiineng()
	stomMultiColorTap("打开技能",{--打开技能
	{   54,  790, 0x394552},
	{   75,  799, 0x6b869c},
	{   71,  779, 0x638e9c},
	{   17,  802, 0x847542},
})
	stomMultiColorTap("打开技能2",{--打开技能
	{   56,  868, 0x635de7},
	{   71,  869, 0x637de7},
	{   72,  885, 0xbddfff},
	{   46,  883, 0x5a51d6},
})
end
function SW1282917929_fn_do()
	if 	stomMultiColor("换区界面",{--打开技能whoAmI() > 3 
	{  540,  207, 0x3165ad},
	{  542,  233, 0x3165ad},
	{  539,  195, 0x7bb6ef},
	{  535,  255, 0x3965a5},
}) and whoAmI() > 3 then
		stomtoast(taskid,3)
	end
	
end
function SW1282917929_fn_richangrenwu()
	if stomMultiColorTap("日程师门",{--日程1
		{  613,  239, 0xadbec6},
		{  513,  249, 0xefc308},
		{  468,  272, 0xefb26b},
		{  492,  262, 0xf77d5a},
	}) or
	stomMultiColorTap("日程师门B",{--日程1
		{  504,  242, 0xefc318},
		{  491,  262, 0xef7d5a},
		{  517,  272, 0xefcb18},
		{  477,  255, 0xefd77b},
	}) or
	stomMultiColorTap("日程师门c",{--日程1
		{  480,  250, 0xefdf84},
		{  480,  233, 0xefdf84},
		{  479,  251, 0xa57d42},
		{  482,  268, 0x633408},
	})
    then 
		stommSleep(100)
		stomMultiColorTap("做师门c",{--日程1
		{  495,  261, 0xf7865a},
	})
		stommSleep(6000)
		stomtap(598,  366)
		stommSleep(200)
		stomMultiColorTap("做师门c",{--日程1
		{  495,  261, 0xf7865a},
	})
		stommSleep(6000)
	elseif stomMultiColorTap("历练任务1-5",{--日程1
		{  479,  596, 0xefe384},
		{  472,  619, 0xefcb7b},
		{  479,  635, 0xf7df7b},
		{  492,  625, 0xfffb84},
	}) or stomMultiColorTap("历练任务2-1",{
		{  344,  230, 0xefdf84},
		{  340,  250, 0xefd37b},
		{  332,  270, 0xefb66b},
		{  344,  285, 0xefe384},
	}) or stomMultiColorTap("历练任务2-4",{
		{  344,  598, 0xefdf84},
		{  343,  616, 0xefdf84},
		{  344,  635, 0xefe384},
	}) or stomMultiColorTap("历练任务2-5",{
		{  348,  747, 0xffe74a},
		{  344,  721, 0xefe384},
		{  343,  741, 0xf7df7b},
		{  344,  757, 0xefe384},
	})
	and lilian==0 then
	elseif stomMultiColor("日程师门不可做",{--日程1
		{  517,  269, 0xcec7c6},
		{  480,  252, 0xdedbde},
		{  482,  235, 0x393c42},
		{  467,  269, 0x4a4942},
	}) then
		hdtap(452,  961)
		stommSleep(500)
		stomtap(452,  961)
		stommSleep(10000)		
	end
	
	if stomMultiColor("历练-第一章",{
		{  536,  420, 0x5a96ef},
		{  536,  450, 0x5296ef},
		{  534,  495, 0x529aef},
		{  524,  421, 0x529aef},
	}) or  stomMultiColor("历练-第n章",{
		{  549,  413, 0x5a9aef},
		{  550,  418, 0x5a96ef},
		{  550,  426, 0x5a96ef},
		{  544,  501, 0x529aef},
	}) then
		local i = math.random(0,3) 	
		if i==0 then
			hdtap(216,  399)--
		elseif i==1 then
			hdtap(240,  262)--
		elseif i==2 then
			hdtap(241,  651)--
		else--elseif i==3 then
			hdtap(249,  872)--
		end
	end
	if stomMultiColor("历练-江州",{
	{  387,  237, 0x3965a5},
	{  384,  261, 0x3165ad},
	{  383,  273, 0x3965a5},
	{  380,  301, 0x3165ad},
})then
		hdtap(210,  268)
		lilian =1
	elseif stomMultiColor("历练-求援",{
	{  377,  239, 0x3965a5},
	{  387,  260, 0x3169ad},
	{  380,  282, 0x3165a5},
	{  385,  297, 0x3965a5},
})then
		hdtap(210,  268)
	elseif stomMultiColor("历练-付州",{
	{  378,  240, 0x3165a5},
	{  380,  261, 0x3165ad},
	{  381,  288, 0x3169ad},
	{  377,  303, 0x3965a5},
})then
		hdtap(210,  268)
	elseif stomMultiColor("历练-勇将",{
		{  379,  241, 0x3965a5},
		{  376,  259, 0x3165ad},
		{  382,  281, 0x3165ad},
		{  379,  298, 0x3169ad},
	})then
		hdtap(210,  268)
	elseif stomMultiColor("历练-龙",{
		{  380,  262, 0x3165a5},
		{  372,  262, 0x3165a5},
		{  386,  278, 0x3165ad},
		{  372,  284, 0x3165ad},
	}) then
		hdtap(210,  268)
	end

	--[[elseif stomMultiColorTap("执行捉鬼",{--执行捉鬼
	{  489,  620, 0xc69629},
	{  472,  612, 0xdeb263},
	{  510,  617, 0xdeba42},
	{  510,  640, 0xffd74a},
}) then 
	stommSleep(2000)
	stomMultiColorTap("选择跨服",{--选择跨服
	{  138,  790, 0x5a86ce},
	{  493,  877, 0x186594},
	{  143,  786, 0x528ace},
	{  338,  988, 0x3165a5},
})
	stommSleep(200)
	stomMultiColorTap("确认跨服",{--确认跨服
	{  205,  395, 0xe7c329},
	{  315,  295, 0xffffff},
	{  318,  329, 0x7bb2e7},
	{  302,  335, 0xffffff},
})
	stommSleep(9999)
	stomMultiColorTap("点开日程任务",{--点开日程任务
		{  603,  369, 0xa52429},
		{  601,  370, 0xc69e63},
		{  615,  377, 0xf7e7ad},
		{  617,  365, 0xf7e7ad},
	})
	stommSleep(999)
	stomMultiColorTap("执行捉鬼",{--执行捉鬼
		{  489,  620, 0xc69629},
		{  472,  612, 0xdeb263},
		{  510,  617, 0xdeba42},
		{  510,  640, 0xffd74a},
	})
	stommSleep(999)
	stomMultiColorTap("开始组队",{--执行捉鬼
		{  189,  894, 0xa5dbff},
		{  193,  785, 0x5a86c6},
		{  193,  766, 0x528ace},
		{  557,  721, 0x8cbae7},
	})
	stommSleep(99999)
	end--]]
end


function create_1282917929_main()							--神武3
	buybooknum=0
	nobook=0
	pro_num=0
	jiangli_count=0
	jiangli_num=0
	buttonnotfind=0
	booknotfind=0
	getbook=0
	applePWD = applePWDs or "Zxc112211"
	myosver = get1osver()
	swtime_cha =  math.random(10,15)*60
	local t1 = os.time()
	--[[if tasktype==1 then
		swtime_cha =  math.random(10,15)*60
	else
		swtime_cha =  math.random(15,20)*60
	end]]
	local loop = 0	--主线开关
	local sw_flag = false--判断是否进入游戏
	zhuceflag = 0	--注册开关
	MODEsw=0--注册开关 =2时程序结束
	lilian =0 --历练开关(默认开)
	--getPhoneType = "lx"
	--docks = "1112"
	timestarts = os.time()
	local isfrontnum = 0
	while (true) do
		isfront = stomisFrontApp("com.duoyi.shenwu3")
		if isfront then
			if isfront == 0 then
				stommSleep(5000)
				stomrunApp("com.duoyi.shenwu3")
				isfrontnum=isfrontnum+1
			end
		else 
			stommSleep(5000)
			stomrunApp("com.duoyi.shenwu3")
			isfrontnum=isfrontnum+1
		end
		if isfrontnum > 7 then
			return 0
		end
		timeend =os.time()
		if loop==0 then
			SW1282917929_fn_tankuang()
			sw_flag = SW1282917929_fn_login()
			SW1282917929_fn_richangrenwu()	
			SW1282917929_fn_duihua()
			SW1282917929_fn_CZ2()
			if sw_flag then
				loop = 1
				stomLog("任务开始")
				t1=os.time()
			end			
		elseif loop==1 then	
			SW1282917929_fn_do()
			SW1282917929_fn_duihua()
			SW1282917929_fn_tankuang()
			SW1282917929_fn_jineng()
			SW1282917929_fn_siwang()
			SW1282917929_fn_richangrenwu()
			SW1282917929_fn_zhuxian()
			SW1282917929_fn_CZ2()
		end
		if timeend-timestarts < 10 then
			color1 = getColor(364,  380)
			color2 = getColor(331,  638)
			color3 = getColor(548,  568)
		end
		if timeend-timestarts >=30 and timeend-timestarts <= 31 or  timeend-timestarts >=60 and timeend-timestarts <= 61 then--卡顿比色
			color11 = getColor(364,  380)
			color22 = getColor(331,  638)
			color33 = getColor(548,  568)	
			if color1==color11 and  color2==color22 and color3==color3 then
				stomtap(488,  152)
				--SW1282917929_fn_renwujiance()
			end
			color1 = getColor(364,  380)
			color2 = getColor(331,  638)
			color3 = getColor(548,  568)
			stommSleep(2000)
		end		
		if timeend-timestarts > 61 then--定时升级技能
			timestarts = os.time()
			color11 = getColor(364,  380)
			color22 = getColor(331,  638)
			color33 = getColor(548,  568)	
			if color1==color11 and color2==color22 and color3==color3 then
				stomtap(600,1000)
				stommSleep(200)
			end
			stomMultiColorTap("长时间不动备用点击",{
			{  452,  964, 0xffff42},
		})
			SW1282917929_fn_shengjiineng()
		end
		
		local t2 = os.time()
		swNowtime=t2-t1
		--stomLog(swNowtime)
		SW1282917929_fn_pro()
		if os.difftime(t2,t1) > swtime_cha then
			for var= 1, 5 do
				SW1282917929_fn_tankuang()
				SW1282917929_fn_duihua()
				hdtap(356,   80)
				stommSleep(300)
			end
			for var= 1, 5 do
				if stomMultiColor("关闭日常",{
					{  572,  533, 0x219aff},
					{  566,  533, 0xffffff},
					{  574,  559, 0x218aff},
					{  564,  559, 0xffffff},
				})  then
					hdtap( 598,  997)
				end
				if stomMultiColor("关闭死亡",{
					{  552,  540, 0x3165ad},
					{  545,  541, 0x3965a5},
					{  550,  556, 0x3165a5},
					{  545,  581, 0x7ba6de},
				})  then
					hdtap(551,  864)
				end				
				SW1282917929_fn_tankuang()
				hdtap(601,  988)
				stommSleep(300)
				if stomMultiColor("等级界面",{
					{  553,  437, 0xffffff},
					{  393,  543, 0xde6d84},
					{  344,  544, 0x5ab2ff},
					{  291,  537, 0xf7cb6b},
				}) and whoAmI() > 3  and tasktype==1 then
					--if whoAmI() > 3 then
					--if stomMultiColor("等级界面",{}) then
					local picPath = stomgetSandboxPath(apple_bid).."/tmp/yz.jpg"
					System.execute2("rm -rf "..picPath)
					local tmtype = "1002"
					stomsnapshot(picPath,540,  384, 567,  422)	--等级
					stommSleep(999)
					stomLog(picPath)
					if stomisFileExist(picPath) then
						stommSleep(1000)
						local dmTB = sendPIC_HaoAi(picPath,tmtype,tmtimeout)
						if #dmTB > 0 then
							slion_game_level = dmTB[1]
							stomLog(slion_game_level)
							stomtoast(slion_game_level,3)
							--stommSleep(5000)
						else
							stomLog("dmTB错误")
							stomtoast("dmTB错误",5)
							stommSleep(5000)
						end
					else
						stomLog("JPG不存在")
						stomtoast("JPG不存在",5)
						stommSleep(5000)
					end
					--end
					--end	
					break
				else
					stomLog("结束未找到等级界面")
				end
			end
			--stomtoast("下机结账",30)
			return 0
		end
		if stomMultiColor("服务器异常",{
			{  518,  525, 0xffef7b},
			{  513,  555, 0xffef73},
			{  454,  629, 0xe7cf39},
			{  377,  507, 0xefcf31},
			{  451,  486, 0x9c6910},
		}) or stomMultiColor("服务器维护重试2",{
			{  461,  420, 0x9c6910},
			{  461,  424, 0x9c6910},
			{  465,  438, 0x845510},
			{  454,  486, 0xe7cb31},
		})--[[or stomMultiColor("师门任务已满",{
			{  475,  229, 0xbdbab5},
			{  474,  240, 0x393c39},
			{  479,  252, 0x7b8284},
			{  471,  269, 0xadaead},
			{  471,  286, 0x737573},
		})]]
			then
			return 0 	
		end
		if stomMultiColor("账号双重认证",{
			{  501,  547, 0x635d5a},
			{  502,  559, 0x000000},
			{  497,  611, 0x000000},
			{  199,  509, 0x1086f7},
		}) then
			slion_account_status=1
			return 0 
		end
		if stomMultiColor("使用第三方封号",{
			{  509,  225, 0x000000},
			{  543,  234, 0x000000},
			{  503,  282, 0x000000},
			{  529,  287, 0x716761},
			{  763,  286, 0x000000},
		}) or stomMultiColor("使用第三方封号",{
			{  415,  509, 0x000000},
			{  415,  523, 0x000000},
			{  402,  544, 0x696664},
			{  352,  529, 0x716761},
		})then
			slion_account_status=2
			return 0 
		end
		if stomMultiColor("需要滑动验证",{
		   {  463,  283, 0x4a9ac6},
		   {  441,  761, 0x4a8ece},
		   {  159,  295, 0xe7c76b},
		   {  159,  753, 0x3179c6},
		  })  then
			--slion_game_level=3
			return 0 
		end
		if MODEsw==2 then
			return 0
		end
--------------
			stomMultiColorTap("关闭上个模式弹窗",{
				{  579,  988, 0x9c2800},
				{  584,  992, 0x841c00},
				{  582,  985, 0x842000},
			})
			if  stomMultiColorTap("关闭背包",{
					{  192,  187, 0xde6d84},
					{  153,  188, 0x52b6ff},
					{  110,  188, 0xf7cb6b},
					{   69,  187, 0xef9e63},
				}) or stomMultiColor("关闭商城",{
					{   97,  738, 0x946910},
					{  103,  889, 0xad6d18},
					{  109,  790, 0xe7cb63},
					{  561,  197, 0xffffff},
				})then
				hdtap(389,   92)
			end
				if stomMultiColor("元宝不足",{
			{  575,  529, 0x3965a5},
			{  575,  536, 0x3169ad},
			{  568,  547, 0x3165ad},
			{  556,  600, 0xadd7f7},
			}) or stomMultiColor("元宝不足红色",{
				{  202,  867, 0xff0000},
				{  193,  867, 0xff0000},
				{  199,  863, 0xff0000},
			})then
				stommSleep(500)
				hdtap(130, 1093)				
				stommSleep(300)
				hdtap(130, 1093)
			end	
--------------
		stomLog("当前阶段"..loop)
		--if t4-t3>1200 then break end
		----stomLog(os.date("%Y-%m-%d %H:%M:%S",t4))
		stommSleep(100)
	end
end


function JZJ1463368792_fn_pro()
	for var= 1, 400 do
		if stomMultiColor("短信",{
			{  278,   80, 0x000000},
			{  324,   77, 0x535353},
			{  383,  162, 0xf9f9f9},
			{  581,   88, 0x007aff},
		})or stomMultiColor("没钱",{
			{  443,  779, 0x849ab5},
			{  207,  619, 0x736d6b},
			{  211,  719, 0x6b6563},
			{  452,  529, 0xc6efff},
			{  440,  553, 0xc6efff},
		})then
				break
		end
		stomMultiColorTap("回城",{
			{   63, 1078, 0xa58639},
			{   49, 1078, 0x8c7531},
			{   16, 1078, 0xcee7f7},
			{   14, 1096, 0xc6dfef},
		})
			stomMultiColorTap("完成任务",{
			{  423, 1115, 0xcef3de},
			{  441,  898, 0x08cf6b},
			{  402,  892, 0x08cb63},
			})
		if stomMultiColor("在城内KX",{--在城内
			{   59, 1081, 0xdedfe7},
			{   42, 1086, 0x5279ad},
			})==true then 
		stommSleep(500)		
		if stomMultiColorTap("自动建造1",{
				{   47,  864, 0x214d84},
				{   46,  889, 0xb5efff},
				{   51,  903, 0x214573},
				}) then 
			stommSleep(500)
			JZJ1463368792_fn_dachui()
		elseif stomMultiColorTap("自动建造2",{
				{  391,  110, 0x73a6d6},
				{  382,  111, 0x6396c6},
				{  379,  115, 0x73a2c6},
				}) then 
			stommSleep(500)
			JZJ1463368792_fn_dachui()
		--[[elseif stomMultiColorTap("自动建造科技",{
					{  291,  110, 0x73a6d6},
					{  284,  111, 0x73aade},
					{  279,  113, 0x6ba2c6},
				}) then 
		stomLog("findkx")
		--stomMultiColorRegTap("找金色小锤升级",0xffffe7, "11|6|0xffffff,6|11|0xffffb5", 90, 97, 18, 493, 721)
		--stomMultiColorRegTap("高亮科技点击",0xffffff, "-23|-19|0xe7db9c,13|26|0xffebad,31|-1|0xfffbbd", 75,68, 26, 481, 677)-- 106, 38, 441, 910)
		stommSleep(500)
		stomMultiColorRegTap("高亮科技点击2",0xffffff, "28|-2|0xffffce,-27|-3|0xffffbd",75,68, 26, 481, 677)
		stommSleep(4000)]]	
		end
		stomMultiColorTap("找金色大锤升级1",{
				{   47,  864, 0x214d84},
				{   46,  889, 0xb5efff},
				{   51,  903, 0x214573},
			})
		end
		stomMultiColorTap("快速建造1",{
			{  449,  193, 0xc6dfe7},
			{  443,  193, 0xc6dfe7},
			{  464,  194, 0x738a9c},
		})
		stomMultiColorTap("快速建造2",{
			{  380,  193, 0xc6dfef},
			{  388,  193, 0xc6dfef},
			{  400,  194, 0x849aa5},
		})	
		stomMultiColorTap("快速建造3",{
			{  282,  193, 0xbddbef},
			{  289,  194, 0xc6dfef},
			{  300,  194, 0x738e9c},
		})
		stomMultiColorTap("确认",{
			{  216,  622, 0x845921},
			{  215,  658, 0xffefbd},
			{  436,  533, 0xc6efff},
			{  215,  441, 0x7b3042},
		})
		stomMultiColorTap("关闭个人信息窗体",{
			{  584, 1002, 0x849ebd},
			{  593,  993, 0xadbede},
			{  591, 1010, 0xa5bade},
			{  575, 1010, 0x637d9c},
		})
		JZJ1463368792_fn_tanchuang()
		JZJ1463368792_fn_duihua()
		stommSleep(100)
		stomLog(loop)
	end
end
function JZJ1463368792_fn_CZ()
	if 	stomMultiColorTap("多益注册账号",{
		{  215,  430, 0x318aff},
		{  217,  444, 0x318aff},
		{  291,  511, 0x1086f7},
		{  444,  320, 0xd60010},
	})--[[ or 
stomMultiColorTap("多益注册账号",{
	{  363,  308, 0x102031},
	{  174,  511, 0x313c39},
	{  272,  706, 0x101818},
	{  490,  528, 0x94965a},
})]]
		then	
		stomtoast("进入充值模式")
		local choice = 0--注册开关--dialogRet("请选择账号注册模式：", "自动", "手动", "", 5);
		local loop=0
		local flag=0
		local getloop = 2
		local num = 0
		local m = math.random(6,8) 
		local mima = myRand(3,m,2)
		local yanzhenma
		local BlackPhone=0
		local getphonenum=0
		local messgwait =4000
		local inputphone=0
		local yanzhengtoast=0
		local getphonenumcount=0
		fa = 0
		getPhoneType = "lx"
		docks = "1112"--1156
		while (true) do
			if loop==0 then
				if choice==0 then
					stomLog("当前阶段.."..getloop)
					if stomMultiColor("密码未输入",{
						{  308,  422, 0x8c8a8c},
						{  310,  453, 0xadb2b5},
						{  311,  519, 0x9c9694},
						{  311,  594, 0x949694},
						{  311,  646, 0x848684},
					}) then
						stommSleep(500)
						stomMultiColorTap("多益输点击密码框",{
							{  312,  435, 0xffffff},
							{  311,  441, 0xadaead},
							{  313,  485, 0x84827b},
							{  309,  519, 0x9c9694},
						})
						stommSleep(500)
						stomInpuText(mima)
						stommSleep(999)
					end
					if stomMultiColorTap("多益密码已输入关闭键盘",{
						{  350,  332, 0xf7f7f7},
						{  419,  419, 0x000000},
						{  420,  433, 0x000000},
						{  420,  447, 0x000000},
						{  500,  457, 0x9f9ea2},
					}) then
						stommSleep(999)
					end
					if getloop == 0 then
						if getphonenum==0 then
							if getphonenumcount <= 4 then
								check_Rules = 1
								Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
								num = num + 1
							else stomtoast("获取号码已到达5次",60)
							end
							if Telnum then
								stomLog(Telnum)
								phonenumber = Telnum
								num = 0
								getphonenum=1
								getphonenumcount = getphonenumcount+1
							else
								stomLog("重新获取号码中")
								stommSleep(2000)
								num = num + 1
							end
						end
						if getphonenum==1 then
							if stomMultiColor("手机号未输入",{
								{  467,  417, 0x8c8684},
								{  466,  422, 0x8c8a8c},
								{  465,  432, 0x848a8c},
								{  465,  451, 0x8c8684},
								{  476,  451, 0xa5a6ad},
							}) then
								stomMultiColorTap("多益注册主界面点手机号",{
									{  473,  423, 0xb5aead},
									{  468,  435, 0xffffff},
									{  151,  488, 0x108af7},
									{  158,  643, 0x108aff},
								})
								stommSleep(1000)
								if inputphone==0 then
									stomInpuText(Telnum)
									inputphone=1
								else
									stomInpuStr(Telnum)
									inputphone=0
								end
								stommSleep(300)
								phoneok=1
							end
						end
						if phoneok==1 and stomMultiColorTap("手机号已输且验证码能获取",{
							{  455,  709, 0x1086f7},
							{  455,  736, 0x108af7},
							{  455,  764, 0x108af7},
							{  455,  785, 0x1086f7},
						}) then
							phoneok=2
						end					
						if stomMultiColorTap("多益获取验证码",{
							{  453,  712, 0x73797b},
							{  453,  734, 0x73797b},
							{  453,  762, 0x73797b},
							{  453,  784, 0x73797b},
						}) and phoneok==2 then
							stommSleep(3000)
							messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)							
							getloop=1
						end
						--[[stomMultiColorTap("多益输手机号已填写关闭键盘",{
							{  541,  401, 0xefebe7},
							{  470,  653, 0x949694},
							{  470,  670, 0x949294},
							{  461,  661, 0x9c9694},
						}) ]]
					elseif getloop == 1 then
						stomLog("获取短信..."..fa)
						if messg then
							stomtoast(yanzhenma)
							if BlackPhone==0 then
								BlackPhone=1
								messgwait=300
								stomtoast("已收验证码 正在处理",3)
								yanzhenma = string.match(messg,"%d+")
								stomLog("yanzhenmaOK-"..yanzhenma)
							else 
								stomtoast(yanzhenma)
							end
							if stomMultiColorTap("多益验证码未输入开始输入",{
								{  394,  525, 0x8c9294},
								{  396,  548, 0x948e94},
								{  390,  561, 0x84868c},
								{  383,  572, 0x7b8284},
							})then	
								stommSleep(500)
								stomInpuText(yanzhenma)
								stommSleep(500)
								stomtap(378,  204)
								stommSleep(300)
								stomtap(389,  928)
							end
							if stomMultiColor("多益验证码未输入不操作",{
								{  394,  525, 0x8c9294},
								{  396,  548, 0x948e94},
								{  390,  561, 0x84868c},
								{  383,  572, 0x7b8284},
							})then
							else
								stommSleep(60)
								if stomMultiColor("立即注册",{
								{  172,  463, 0x108aff},
								{  172,  662, 0x1086f7},
								{  243,  714, 0xf7f7f7},
								{  525,  458, 0xefefef},
							}) then
									stommSleep(1000)
									--[[stomMultiColorTap("立即注册",{
									{  172,  463, 0x108aff},
									{  172,  662, 0x1086f7},
									{  243,  714, 0xf7f7f7},
									{  525,  458, 0xefefef},
								}) ]]
									stomtap(159,  562)
									stommSleep(3000)
									if stomMultiColor("绑定成功",{
										{  363,  402, 0x63ba63},
										{  368,  597, 0x000000},
										{  370,  648, 0x4a494a},
										{  542,  556, 0x9c9a9c},
									})	or stomMultiColor("绑定成功C",{
										{  363,  402, 0x63ba63},
										{  368,  597, 0x000000},
										{  370,  648, 0x4a494a},
										{  542,  556, 0x9c9a9c},
									})	or stomMultiColor("绑定成功B",{
										{  314,  413, 0x63ba63},
										{  535,  530, 0x000000},
										{  538,  831, 0x84868c},
										{   90,  531, 0xf7f7f7},
									})  or	stomMultiColor("红色已绑定",{
										{  437,  315, 0xd60008},
										{  221,  390, 0x4a8ef7},
										{  223,  458, 0x73aaff},
										{  299,  494, 0x108af7},
									})	then
										stomLog("绑定成功");stommSleep(3000)
										getloop = 99
										stomopenURL("prefs:root=STORE");
										stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
										stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)	
										loop=1
									else 
										stomtoast("注册失败3秒后跳转")
										stommSleep(3000)
										stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
										stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)	
										stomLog("绑定失败")	
										czendtime=os.time()
										--[[if czendtime-czstartime<90 then
											stomtoast("操作等待.."..(90-czendtime+czstartime),(90-czendtime+czstartime))
											stommSleep((90-czendtime+czstartime)*1000)
										end		]]																		
										getloop =99--getloop=2为正常开始
									end	
									
								end	
							end
						else
							messgwait=4000
							messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
							stomLog("get sms")
							stomtoast("GetMegNO."..fa,4)
							fa = fa +1
						end
						if fa > 10 then
							stomLog("获取短信失败")
							stomtoast("get短信失败")
							stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
							stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
							getloop = 2
						end
						stommSleep(messgwait)
					elseif getloop == 2 then
						czstartime=os.time()
						stomtoast("等待重新开始",1)
						fa = 0	
						BlackPhone=0
						getphonenum=0
						stomMultiColorTap("账号",{
							{  302,  583, 0x3165ad},
							{  289,  432, 0x295da5},
							{  294,  439, 0xb5d3f7},
							{  299,  446, 0x295da5},
							{  444,  524, 0xe7cb63},
						})
						stomMultiColorTap("取消表单",{
							{  537,  299, 0x8c8684},
							{  529,  305, 0x8c8684},
							{  544,  305, 0x84868c},
							{  537,  533, 0x080400},
							{  537,  559, 0x000000},
						})
						stomMultiColorTap("取消表单B",{
							{  537,  300, 0x848684},
							{  528,  306, 0x848684},
							{  530,  488, 0xefebef},
							{  252,  834, 0xf7f7f7},
						})
						if stomMultiColorTap("多益点账号注册",{
							{  215,  430, 0x318aff},
							{  217,  444, 0x318aff},
							{  291,  511, 0x1086f7},
							{  444,  320, 0xd60010},
						}) then
							getloop=0
						end	
					end
				end
					if stomMultiColor("绑定成功",{
						{  363,  402, 0x63ba63},
						{  368,  597, 0x000000},
						{  370,  648, 0x4a494a},
						{  542,  556, 0x9c9a9c},
					})	or stomMultiColor("绑定成功C",{
						{  363,  402, 0x63ba63},
						{  368,  597, 0x000000},
						{  370,  648, 0x4a494a},
						{  542,  556, 0x9c9a9c},
					})	or stomMultiColor("绑定成功B",{
						{  314,  413, 0x63ba63},
						{  535,  530, 0x000000},
						{  538,  831, 0x84868c},
						{   90,  531, 0xf7f7f7},
					})  or	stomMultiColor("红色已绑定",{
						{  437,  315, 0xd60008},
						{  221,  390, 0x4a8ef7},
						{  223,  458, 0x73aaff},
						{  299,  494, 0x108af7},
					})	then
						stomLog("绑定成功");stommSleep(3000)
						getloop = 99
						stomopenURL("prefs:root=STORE");
						loop=1
					end
			elseif loop==1 then
				if yanzhengtoast == 0 then
					stomtoast("请检查是否需要注销并返回游戏")
				end
				isfront = stomisFrontApp("com.liwei.m2q7")
				if isfront==1 then
					yanzhengtoast =1
				end				
				stomMultiColorTap("绿色对勾绑定成功",{
					{  537,  830, 0x848684},
					{  541,  530, 0x000000},
					{  540,  536, 0x100c10},
					{  541,  560, 0x393c42},
				})			
				stomMultiColorTap("注册完成关闭多益账号显示",{
					{  437,  831, 0x8c8684},
					{  221,  389, 0x528af7},
					{  280,  484, 0x1086f7},
					{  443,  311, 0xde0010},
				})			
				if stomMultiColor("横向只输密码",{
					{  437,  348, 0xc7c7cd},
					{  437,  357, 0xc7c7cd},
					{  428,  382, 0xcdcdd3},
					{  420,  371, 0xcbcbd1},
				}) then
					stommSleep(300)
					stomInpuText(applePWD)
					stommSleep(300)
					stomtap(368,  692)
				end
				stomMultiColorTap("横向长账号设置",{
					{  203,  691, 0x007aff},
					{  204,  718, 0x007aff},
					{  189,  712, 0x007aff},
					{  425,  485, 0x000000},
				})			
				if stomMultiColor("长账号纵支付密码",{
					{   99,  402, 0xc7c7cd},
					{  106,  402, 0xc7c7cd},
					{  104,  421, 0xc7c7cd},
					{  126,  415, 0xd0d0d5},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(300)
					stomMultiColorTap("确认密码",{
						{  455,  505, 0x007aff},
						{  458,  505, 0x007aff},
						{  462,  505, 0x007aff},
					})
				end
				if stomMultiColor("长账号横支付密码",{
					{  544,  768, 0x676f73},
					{  506,  550, 0x17191a},
					{  427,  348, 0xc7c7cd},
					{  420,  373, 0xc7c7cd},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(300)
					stomMultiColorTap("确认密码",{
						{  367,  706, 0x007aff},
						{  367,  709, 0x007aff},
						{  367,  713, 0x007aff},
					})
				end
				if stomMultiColor("账号和密码横向CN",{
					{  191,  196, 0x000000},
					{  230,  196, 0x000000},
					{  400,  270, 0x9d9dad},
					{   99,  343, 0xd4d4d9},
				}) or stomMultiColor("账号和密码横向EN",{
				{  188,  232, 0x000000},
				{  229,  232, 0x000000},
				{  410,  331, 0xffffff},
				{  100,  380, 0xc7c7cd},
				})then
					stommSleep(500)
					stomtap(598, 1109)
					stomInpuText(applePWD)
					stommSleep(300)
					stomtap(353,  332)
				end	
				if 	stomMultiColor("账号和密码横向CN",{
					{  567,  436, 0x000000},
					{  582,  481, 0x000000},
					{  500,  620, 0xffffff},
					{  431,  690, 0x007aff},
				}) or stomMultiColor("账号和密码横向EN",{
					{  596,  443, 0x000000},
					{  598,  480, 0x000000},
					{  496,  735, 0xffffff},
					{  460,  348, 0xc7c7cd},
					{  367,  709, 0x007aff},
				})then
					stommSleep(500)
					stomtap(27, 1055)
					stomInpuText(applePWD)
					stommSleep(300)
					stomtap(545,  344)
				end			
					stomMultiColorTap("单行密码已输入确认",{
						{  461,  489, 0x007aff},
						{   98,  397, 0x000000},
						{  114,  397, 0x000000},
						{  474,  305, 0x606668},
						{  192,  217, 0x000000},
					})
					stomMultiColorTap("无法连接IT横粗",{
						{  252,  559, 0x007aff},
						{  367,  393, 0x000000},
						{  373,  471, 0x8c999c},
						{  364,  578, 0xb7c2c7},
					})
					stomMultiColorTap("使用现有B",{
						{  343,  503, 0x007aff},
						{  249,  454, 0x007aff},
						{  173,  548, 0x007aff},
						{  466,  545, 0x242526},
					})
					stomMultiColorTap("设置纵粗",{
						{  444,  668, 0x007aff},
						{  428,  667, 0x007aff},
						{  224,  476, 0x000000},
						{  157,  667, 0x007aff},
						{  462,  562, 0x000000},
					})
				stomMultiColorTap("网络异常重登",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("无法连接IT纵粗",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("验证失败再次粗",{
					{  652,  403, 0x007aff},
					{  510,  252, 0x000000},
					{  585,  251, 0x000000},
					{  763,  303, 0xd8dcda},
				})
				stomMultiColorTap("确认购买纵粗？？",{
					{  425,  666, 0x007aff},
					{  166,  483, 0x000000},
					{  422,  483, 0x616161},
					{  554,  678, 0xf9f9f9},
				})					
				stomMultiColorTap("使用现有",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("使用现有纵",{
					{  277,  537, 0x007aff},
					{  305,  430, 0x000000},
					{  334,  429, 0x595d5d},
					{  473,  635, 0xced2d2},
				})				
				stomMultiColorTap("设置",{
					{  217,  676, 0x007aff},
					{  401,  550, 0x636566},
					{  400,  579, 0x000000},
					{  405,  644, 0x000000},
				})	
				stomMultiColorTap("设置纵向",{
					{  472,  663, 0x007aff},
					{  375,  664, 0xccd0d1},
					{  221,  484, 0x000000},
					{  273,  488, 0x666869},
				})	
				stomMultiColorTap("15分钟后需要",{
					{  357,  705, 0x007aff},
					{  409,  704, 0x56a5fd},
					{  466,  704, 0x007aff},
					{  362,  448, 0x000000},
				})	

				stomMultiColorTap("无法连接IT",{
					{  437,  628, 0x007aff},
					{  472,  626, 0xabd1fb},
					{  146,  521, 0x000000},
					{  222,  531, 0x8f8f8f},
				})				
				if stomMultiColorTap("购买完成",{
					{  548,  493, 0x000000},
					{  427,  406, 0xffffff},
					{  425,  352, 0xcdcdd3},
					{  500,  715, 0x000000},
				}) or stomMultiColorTap("购买完成B",{
					{  309,  644, 0x007aff},
					{  259,  491, 0x000000},
					{  411,  553, 0x000000},
					{  517,  556, 0xf9f9f9},
				})then
					stommSleep(500)					
					OpenApp("com.liwei.m2q7")
				--else stomLog("notfound")
				end			
				if stomMultiColor("在资源信息程序结束B",{
					{  458,  149, 0x31617b},
					{  500,  409, 0x63a2d6},
					{  235,  260, 0x31556b},
					{  236,  694, 0x31556b},
				})then
					stomMultiColor("在外观商城关闭",{
					{  583, 1002, 0x849ebd},
					{  579,  524, 0x4a6d7b},
					{  588,  554, 0xc6e3f7},
					{  589,  607, 0xcee7ef},
				})
					stommSleep(1000)
					stomMultiColor("个人属性关闭",{
						{  599,  997, 0xadf3ef},
						{  545,  566, 0x4aa6ef},
						{  392,  544, 0xde6984},
						{   82,  654, 0xe7c331},
					})
					stomtoast("充值流程结束")
						JZJ1463368792_fn_pro()
						--购买升级所需物品
					break
				end
				if stomMultiColorTap("实名窗体",{
					{  154,  520, 0x318242},
					{  157,  556, 0xb5ffce},
					{  513,  519, 0x526573},
					{  498,  526, 0xb5dff7},
				}) then
					--stommSleep(500)		
				end
				if stomMultiColor("实名认证窗体",{--实名认证窗体
					{  547,  528, 0x000000},
					{  534,  563, 0x000000},
					{  538,  585, 0x000000},
					{  527,  609, 0xe7e7e7},
					})==true then
				stomMultiColorTap("第一个文本框",{
					{  304,  476, 0xffffff},
					{  533,  529, 0x000000},
					{  300,  437, 0x8c8e94},
					{  312,  515, 0x7b8284},
				})	
				stommSleep(500)
				stomInpuText("彭会")
				stommSleep(2000)
				if 
				stomMultiColorTap("第二个文本框",{
					{  406,  450, 0xffffff},
					{  406,  356, 0x030303},
					{  407,  368, 0x1b1c1d},
					{  410,  759, 0xffffff},
				}) then 
				stommSleep(500)
				stomInpuText("440282195610226964")
				stommSleep(500)
				stomMultiColorTap("提交",{--提交
						{  411,  613, 0x1088fb},
						{  408,  524, 0x1088f8},
						{  396,  583, 0xc7e4ff},
						{  354,  550, 0xfdfefe},
					})
				stommSleep(500)
				stomMultiColorTap("确定",{--确定
					{  214,  628, 0x295184},
					{  443,  558, 0xceefff},
					{  205,  433, 0x8c384a},
				})
				end
			end
				stomMultiColorTap("确认提交",{
					{  245,  648, 0x108af7},
					{  322,  482, 0x7b757b},
					{  324,  508, 0x080408},
					{  410,  499, 0xe7efef},
				})
				stomLog(loop)
				stommSleep(100)
			end
			if stomMultiColor("在军衔信息程序结束",{
					{  112,  336, 0x737173},
					{  523,  280, 0x94efff},
					{  348,  335, 0xffe78c},
					{  155,  852, 0x182429},
				}) or stomMultiColor("短信",{
					{  278,   80, 0x000000},
					{  324,   77, 0x535353},
					{  383,  162, 0xf9f9f9},
					{  581,   88, 0x007aff},
				})then
					stomMultiColor("个人属性关闭",{
						{  599,  997, 0xadf3ef},
						{  545,  566, 0x4aa6ef},
						{  392,  544, 0xde6984},
						{   82,  654, 0xe7c331},
					})			
					stomMultiColor("在外观商城关闭",{
					{  583, 1002, 0x849ebd},
					{  579,  524, 0x4a6d7b},
					{  588,  554, 0xc6e3f7},
					{  589,  607, 0xcee7ef},
				})
					stommSleep(1000)
					stomMultiColor("个人属性关闭",{
						{  599,  997, 0xadf3ef},
						{  545,  566, 0x4aa6ef},
						{  392,  544, 0xde6984},
						{   82,  654, 0xe7c331},
					})
					stomtoast("充值流程结束")
					--JZJ1463368792_fn_pro()
						--购买升级所需物品
				break
			end
		end
	end
end

function JZJ1463368792_fn_zhengbing2()
	stomMultiColorTap("使用预备兵",{
			{  112,  744, 0x212429},
			{  109,  750, 0x182831},
			{  615,  170, 0x42596b},
			{   48,  614, 0x8c8684},
		}) 
	stommSleep(300)
	stomMultiColorTap("补满兵力",{
			{   64,  789, 0x845d29},
			{   48,  819, 0xc69639},
			{   73,  897, 0x734921},
		})
	stommSleep(300)
	stomMultiColorTap("开始征兵",{
			{   48,  672, 0x5adb63},
			{   68,  616, 0x317542},
			{   78,  727, 0x31794a},
		})
	stommSleep(300)
	stomMultiColorTap("关闭",{
			{  587, 1005, 0x8c9ebd},
			{  597,  995, 0xadc3de},
			{  597, 1015, 0xadc3de},
			{  577,  996, 0x637d94},
		})
end

function JZJ1463368792_fn_zhengbing()
	stomMultiColorTap("点击部队",{
			{   39,  996, 0x84aace},
			{   49,  985, 0xe7eff7},
			{   51, 1005, 0xdee7f7},
			{   43, 1015, 0x39456b},
		})	
	stommSleep(300)
	stomMultiColorTap("点击部队B",{
			{   54,  839, 0x7ba2ce},
			{   39,  848, 0xdeebef},
			{   56,  849, 0xefeb7b},
			{   13,  832, 0xd6efff},
		})	
	stommSleep(300)	
	
	for var= 1,3 do

		if stomMultiColorTap("待命1兵力不满",{
			{  426,  125, 0x52ba39},
			{  382,  481, 0x182831},
			{  380,  481, 0x182831},
		}) then
			stommSleep(500)
			JZJ1463368792_fn_zhengbing2()
		end
		if stomMultiColorTap("待命2兵力不满",{
			{  426,  687, 0x52ba39},
			{  381, 1043, 0x182021},
			{  383, 1043, 0x182021},
		}) then
			stommSleep(500)
			JZJ1463368792_fn_zhengbing2()
		end	
		if stomMultiColorTap("待命3兵力不满",{
			{  156,  477, 0x182431},
			{  159,  477, 0x212429},
			{  203,  125, 0x5aba31},
		}) then
			stommSleep(500)
			JZJ1463368792_fn_zhengbing2()
		end	
		if stomMultiColorTap("DC待命1兵力不满",{
			{  164,  476, 0x182431},
			{  166,  476, 0x182429},
			{  211,  126, 0x52b631},
		}) then
			stommSleep(500)
			JZJ1463368792_fn_zhengbing2()
		end	
		if stomMultiColorTap("DC待命2兵力不满",{
			{  165, 1040, 0x182431},
			{  167, 1040, 0x182431},
			{  211,  687, 0x5aba31},
		}) then
			stommSleep(500)
			JZJ1463368792_fn_zhengbing2()
		end	
	stommSleep(300)
	end	
	--[[if i==1 then
	stomMultiColorTap("点击部队1",{
			{  425,   35, 0x7ba6ce},
			{  430,   35, 0x73aade},
			{  425,   59, 0x7baad6},
		})
	elseif  i==2 then
	stomMultiColorTap("点击部队2",{
			{  425,  598, 0x73aade},
			{  425,  621, 0x7baade},
			{  418,  630, 0x7baade},
			{  429,  687, 0x5aba31},
		})
	stommSleep(500)
	else 
	end]]

	stommSleep(300)
	for var= 1, 3 do
		stomMultiColorTap("关闭",{
		{  614, 1097, 0xcedf8c},
		{  603, 1096, 0xb5c363},
		{  603, 1108, 0xb5b25a},
		{  616, 1108, 0xd6cb73},
	})	
		stommSleep(60)
	end
		stomMultiColorTap("关闭",{
		{  608, 1101, 0x7b9abd},
		{  609, 1090, 0x182429},
		{  609, 1113, 0x212429},
		{  610, 1122, 0x5a7594},
	})
	stommSleep(300)
end

function JZJ1463368792_fn_wudaodahui()

	if	stomMultiColorTap("比武",{
		{  495,  455, 0x29384a},
		{  534,  226, 0xceebff},
		{  499,  490, 0xbddfff},
	}) then
		stommSleep(1000)
	end
	if	stomMultiColorTap("挑战1",{
		{  183, 1067, 0x398642},
		{  615,   58, 0xc6e7f7},
		{  618,   80, 0x425163},
		{  617,  104, 0x4a5963},
	}) then
		stommSleep(500)
	elseif stomMultiColorTap("挑战3",{
		{  184,  656, 0x39824a},
		{  615,   58, 0xc6e7f7},
		{  618,   80, 0x425163},
		{  617,  104, 0x4a5963},
	}) then
		stommSleep(500)
	end
	if stomMultiColorTap("进入对战",{
		{   50,  639, 0x31864a},
		{   58,  681, 0xb5ffce},
		{  586,  544, 0xe7d79c},
		{  581,  591, 0xe7db94},
	}) then
		stommSleep(500)
	end
	if stomMultiColorTap("退出",{
		{   46,  666, 0x7b3042},
		{   48,  690, 0xffbace},
		{   49,  710, 0xffbece},
		{   44,  405, 0x29598c},
	}) then
		stommSleep(500)
	end
	if stomMultiColorTap("关闭武道",{
		{  609, 1102, 0x849ebd},
		{  612, 1089, 0x182431},
		{  613,   46, 0x395563},
		{  613,   83, 0x212c39},
	}) then
		stommSleep(500)
	end
end

function JZJ1463368792_fn_zhuxian()
	if stomMultiColorTap("完成任务",{
			{  423, 1115, 0xcef3de},
			{  441,  898, 0x08cf6b},
			{  402,  892, 0x08cb63},
			}) then
		stommSleep(500)
		stomtap(423, 1115)
	end	

	if stomMultiColor("主线1-10",{
			{  423,  967, 0xd6a65a},
			{  428,  990, 0xefba63},
			{  416, 1000, 0xe7b663},
			{  424, 1017, 0x9c864a},
			}) or stomMultiColor("主线1-10第四行",{
			{  307, 1001, 0xefba63},
			{  318, 1023, 0x9c864a},
			{  319, 1038, 0x423418},
			{  310, 1059, 0xefba6b},
			}) or stomMultiColor("主线1-10第四行B",{
			{  338,  990, 0xefba63},
			{  329, 1001, 0xefba63},
			{  335, 1027, 0xe7b65a},
			{  333, 1039, 0xefba63},
			}) then
		if 	stomMultiColorTap("日常2",{
				{  563,  317, 0xadc7de},
				{  548,  313, 0x9cbad6},
				{  528,  303, 0xcee7f7},
				{  532,  327, 0x424d52},
				}) then
			stommSleep(500)
		end
		JZJ1463368792_fn_wudaodahui()
		stomMultiColorTap("点城内",{
				{   63, 1077, 0xa58239},
				{   46, 1074, 0xffffff},
				{   23, 1099, 0x212431},
				{   16, 1078, 0xcee7f7},
			})
		stommSleep(500)	
		return 1
	--else --stomLog("no1-10")
	end

	if stomMultiColorTap("主线1-1",{
			{  425,  966, 0xc69a52},
			{  417,  967, 0xd6a65a},
			{  426,  990, 0xf7be63},
			{  417,  990, 0xefbe63},
			}) then
		stommSleep(500)	
		stomMultiColorTap("出征",{
				{  316,  726, 0x293439},
				{  331,  702, 0xd6dfef},
				{  331,  721, 0xd6e3e7},
				{  318,  778, 0xdeebef},
			})	
	end

	if stomMultiColorTap("确认出征",{
			{  102,  758, 0x8c5d29},
			{  100,  820, 0x8c6129},
			{  583,  520, 0xbde7f7},
			{  591,  532, 0xc6dfe7},
			})	then
		stommSleep(2000)	
	end

	if stomMultiColor("主线1-2",{
			{  425,  966, 0xc69a52},
			{  417,  967, 0xd6a65a},
			{  427,  987, 0xefba63},
			{  416,  989, 0xb5924a},
			}) then
		stommSleep(500)	
		zhengbing(1)
		stomMultiColorTap("主线1-2",{
				{  425,  966, 0xc69a52},
				{  417,  967, 0xd6a65a},
				{  427,  987, 0xefba63},
				{  416,  989, 0xb5924a},
			})
	end	

	if stomMultiColor("主线1-3",{
			{  423,  989, 0xefba5a},
			{  417,  988, 0xe7be63},
			{  429,  989, 0xdeb25a},
			{  423,  967, 0xd6a65a},
			{  428, 1012, 0xefba63},
			}) then
		stommSleep(500)	
		zhengbing(1)
		stomMultiColorTap("主线1-3",{
				{  423,  989, 0xefba5a},
				{  417,  988, 0xe7be63},
				{  429,  989, 0xdeb25a},
				{  423,  967, 0xd6a65a},
			})		
	end

	if stomMultiColor("建造任务首行",{
			{  428,  912, 0x4abaef},
			{  419,  918, 0x42beef},
			{  425,  937, 0x4abaef},
			}) then
		if stomMultiColor("2级先锋营无法建造",{
				{  427,  964, 0x42b6e7},
				{  430,  999, 0x42baef},
				{  427, 1012, 0x215d7b},
				{  427, 1035, 0x215573},
				{  416, 1041, 0x39aade},
				}) then 
			stommSleep(500)	
			if stomMultiColorTap("去城外",{--在城内
					{   59, 1081, 0xdedfe7},
					{   42, 1086, 0x5279ad},
					})==true then 
				stommSleep(500)
			end
			if stomMultiColorTap("主线1-7第四行",{
					{  297,  991, 0xe7ae5a},
					{  291, 1007, 0xe7b65a},
					{  297, 1028, 0x423821},
					{  292, 1059, 0xdeb263},
					}) then
				stommSleep(2000)
				stomMultiColorTap("点击调动",{
						{  381,  706, 0xadc7e7},
						{  374,  755, 0xdeefef},
						{  371,  773, 0xdeefe7},
						{  378,  789, 0x213039},
					})	
			end
		else stomMultiColorTap("建造任务首行",{
					{  428,  912, 0x4abaef},
					{  419,  918, 0x42beef},
					{  425,  937, 0x4abaef},
				}) 
			stommSleep(2000)		
		end
		if stomMultiColor("在城内",{--在城内
				{   59, 1081, 0xdedfe7},
				{   42, 1086, 0x5279ad},
				})==true then 
			stommSleep(500)		
			if stomMultiColor("主城",{--在城内
					{  580, 1133, 0x849294},
					{   28,  442, 0xefe7ce},
					{  350,  237, 0xe7df73},
					{    8,  593, 0xc6baa5},
					})==true then
				stomMultiColorRegTap("找金色大锤升级1",0xffffff, "8|3|0xffffff,-25|7|0xffffff,32|-2|0xfffbe7", 90, 65, 558, 144, 655)
				stommSleep(500)
			else
				--		for var= 1, 2 do
				stomLog("findZX")
				stomMultiColorRegTap("找金色大锤升级1",0xffffe7, "-2|10|0xffffef,-26|11|0xf7f3d6", 90, 102, 273, 380, 749)
				stommSleep(500)
				stomMultiColorRegTap("找金色小锤升级",0xffffe7, "11|6|0xffffff,6|11|0xffffb5", 90, 133, 369, 451, 843)
				stommSleep(500)
				stomMultiColorRegTap("找金色大锤升级2",0xffffe7, "4|9|0xffffad,-25|7|0xffffe7", 88, 102, 273, 380, 749)
				--stomMultiColorRegTap("找金色大锤升级1",0xffffef, "13|6|0xfffff7,3|-13|0x292c29,-4|32|0x292c29", 90, 88, 335, 482, 880)
				stommSleep(800)
				--		end
			end
			stomMultiColorTap("确认建造",{
					{   47,  864, 0x214d84},
					{   46,  889, 0xb5efff},
					{   51,  903, 0x214573},
				})
			stommSleep(5000)
		else --stomLog("不在城内")
		end
		stommSleep(2000)
	end

	if stomMultiColorTap("科技任务首行",{
			{  428,  911, 0x42baef},
			{  421,  911, 0x4abae7},
			{  419,  922, 0x42b2e7},
			{  427,  937, 0x4abae7},
			}) then
		stommSleep(2000)
	end
	--[[if stomMultiColorTap("建造任务4行",{
		{  342,  909, 0x42baef},
		{  334,  918, 0x42baef},
		{  333,  928, 0x399ec6},
		{  339,  937, 0x4abae7},
	}) then
		stommSleep(2000)
	end]]
	if stomMultiColor("主线1-5",{
			{  428,  965, 0xe7ba63},
			{  428,  987, 0xe7ba6b},
			{  428,  993, 0xd6aa5a},
			{  423,  992, 0xe7b663},
			{  416,  990, 0xefba63},
			{  427, 1068, 0x6b5d31},
			}) then
		stommSleep(500)
		stomMultiColorTap("点击部队",{
				{   49,  830, 0xd6e3f7},
				{   58,  836, 0x425dad},
				{   43,  859, 0x39456b},
				{   13,  855, 0xd6eff7},
			})	
		stommSleep(500)	
		stomMultiColorTap("点击部队2",{
				{  320,  805, 0x29415a},
				{  292,  783, 0x428abd},
				{  290,  799, 0x428abd},
				{  611,   57, 0xc6e3ef},
			})	
		touchDown(140,  210)
		for i = 0, 300, 50 do
			touchMove(140+i,  210)
			stommSleep(70)
		end
		for j= 0, 250, 50 do
			touchMove(440,  210+j)
			stommSleep(70)
		end
		touchUp(440,460)
		stommSleep(300)
		touchDown(140,  210)
		for i = 0, 300, 50 do
			touchMove(140+i,  210)
			stommSleep(70)
		end
		for j= 0, 450, 50 do
			touchMove(440,  210+j)
			stommSleep(70)
		end
		touchUp(440,660)
		stommSleep(300)
		stomMultiColorTap("关闭部队",{
				{  587, 1005, 0x8c9ebd},
				{  596,  996, 0xadbede},
				{  596, 1006, 0x293442},
				{  596, 1014, 0xadbede},
			})	
		stommSleep(500)
		stomMultiColorTap("关闭",{
				{  608, 1101, 0x7b9abd},
				{  616, 1097, 0xa5bede},
				{  619, 1102, 0x212831},
				{  615, 1109, 0xa5b6d6},
			})
		--return 2
	end
	--return 1

	if stomMultiColor("主线1-6",{
			{  426,  966, 0xc69652},
			{  428,  992, 0xe7b263},
			{  424,  987, 0xc6a25a},
			{  416,  990, 0xefba63},
			{  415, 1069, 0xdeaa5a},
			{  424, 1066, 0x182021},
			}) then
		stomMultiColorTap("1-6出征",{
				{  327,  705, 0xdee3ef},
				{  328,  719, 0xd6e7ef},
				{  294,  742, 0x31455a},
				{  318,  758, 0xdeebef},
			})	
		stommSleep(200)
		stomMultiColorTap("1-6出征B",{
				{  327,  705, 0xdee3ef},
				{  328,  719, 0xd6e7ef},
				{  294,  742, 0x31455a},
				{  318,  758, 0xdeebef},
			})			
		stommSleep(200)
		JZJ1463368792_fn_zhengbing()
		stommSleep(200)		
		stomMultiColorTap("主线1-6",{
				{  426,  966, 0xc69652},
				{  428,  992, 0xe7b263},
				{  424,  987, 0xc6a25a},
				{  416,  990, 0xefba63},
				{  415, 1069, 0xdeaa5a},
				{  424, 1066, 0x182021},
			})
		stommSleep(300)
	end

	if stomMultiColorTap("资源补给",{
			{  425,  914, 0xdeb663},
			{  422,  970, 0xe7b263},
			{  426,  991, 0xefba6b},
			{  423, 1009, 0xdeae5a},
			}) then
		stommSleep(500)
		stomMultiColorTap("点击调动",{
				{  327,  716, 0xd6e7f7},
				{  327,  705, 0xd6e3ef},
				{  317,  753, 0xd6dfde},
			})	
	end

	if stomMultiColorTap("主线1-7",{
			{  422,  967, 0xcea65a},
			{  428,  988, 0xe7ae5a},
			{  428,  992, 0xe7ba5a},
			{  422,  991, 0xe7be63},
			{  425, 1006, 0x8c7942},
			}) then
		stommSleep(2000)
		stomMultiColorTap("点击调动",{
				{  381,  706, 0xadc7e7},
				{  374,  755, 0xdeefef},
				{  371,  773, 0xdeefe7},
				{  378,  789, 0x213039},
			})	
	end

	if stomMultiColor("主线1-8",{
			{  426,  990, 0x212829},
			{  427, 1009, 0xefba63},
			{  425, 1024, 0xefbe6b},
			{  420, 1048, 0x212018},
			{  416,  990, 0xefba63},
			}) then
		stomMultiColorTap("出征",{
				{  327,  705, 0xdee3ef},
				{  328,  719, 0xd6e7ef},
				{  294,  742, 0x31455a},
				{  318,  758, 0xdeebef},
			})
		stommSleep(500)
		stomMultiColorTap("主线1-8",{
				{  426,  990, 0x212829},
				{  427, 1009, 0xefba63},
				{  425, 1024, 0xefbe6b},
				{  420, 1048, 0x212018},
				{  416,  990, 0xefba63},
			})
	end

	if stomMultiColorTap("主线1-8领取",{
			{  458,  897, 0x21558c},
			{  525,  269, 0x945d21},
			{  531,  307, 0xdeefff},
			{  460,  952, 0xbdefff},
			}) then
		stommSleep(500)
	end

	if stomMultiColor("主线1-8下方点击",{
			{  292,  990, 0xefba63},
			{  299, 1009, 0xbd9a52},
			{  284, 1031, 0xbd9652},
			{  293, 1048, 0x524529},
			{  297, 1063, 0xefba63},
			}) then
		stomMultiColorTap("出征B",{
				{  328,  705, 0xd6e7f7},
				{  330,  720, 0xd6e3ef},
				{  320,  757, 0xdeefef},
				{  318,  777, 0x636d73},
			})
		stommSleep(500)
		stomMultiColorTap("主线1-8下方点击",{
				{  292,  990, 0xefba63},
				{  299, 1009, 0xbd9a52},
				{  284, 1031, 0xbd9652},
				{  293, 1048, 0x524529},
				{  297, 1063, 0xefba63},
			})
		stommSleep(3000)
	end

	if stomMultiColor("升级技能",{
			{  427, 1009, 0x4abae7},
			{  421, 1023, 0x42b6e7},
			{  398, 1011, 0xadc3c6},
			{  404, 1036, 0x63657b},
			}) then
		stomMultiColorTap("点击武将",{
				{   59,  928, 0x314163},
				{   68,  929, 0xe7f3ff},
				{   32,  926, 0x395984},
			})
		stommSleep(300)
		stomMultiColorTap("选择第一个武将",{
				{  392,  160, 0xbdebff},
				{  416,  193, 0x6bc752},
				{  216,   43, 0x317d39},
			})
		stommSleep(300)
		stomMultiColorTap("选择技能",{
				{  423,  658, 0x31a24a},
				{  401,  647, 0x080c08},
				{  354,  645, 0x319a4a},
			})
		stommSleep(300)		
		stomMultiColorTap("升级技能1",{
				{   56,  520, 0x946529},
				{  583,  387, 0x42ae42},
				{   54,  599, 0x9c7131},
			})
		stommSleep(300)	
		stomMultiColorTap("升级技能2",{
				{   56,  520, 0x946529},
				{  583,  387, 0x42ae42},
				{   54,  599, 0x9c7131},
			})
		stommSleep(300)	
		stomtap(610, 1103)
		stommSleep(300)	
		stomtap(610, 1103)
		stommSleep(300)	
		stomtap(610, 1103)
	end
--[[if stomMultiColorTap("支线迷雾",{
		{  428,  916, 0xefba63},
		{  428,  972, 0x423421},
		{  428,  984, 0x846531},
		{  429, 1057, 0x735929},
	}) then
		stommSleep(500)
		stomMultiColorTap("探索",{
		{  329,  551, 0xbddbff},
		{  327,  580, 0xbddfff},
		{  331,  599, 0x21304a},
		{  526,  406, 0xd6e7f7},
	}) 
		stommSleep(500)
		stomMultiColorTap("隐藏",{
		{  179,   26, 0x182431},
		{  174,   28, 0x9cb6ce},
		{  155,   22, 0x848ea5},
		{  159,   33, 0xceefff},
	})
		stommSleep(500)
		JZJ1463368792_fn_duihua()
		stommSleep(500)
		JZJ1463368792_fn_duihua()
		stommSleep(500)
		JZJ1463368792_fn_duihua()
		stommSleep(5000)
		stomtap(420,  560);stommSleep(300)
		stomtap(420,  730);stommSleep(300)
	
		stomtap(543,  312);stommSleep(300)
		stomtap(538,  480);stommSleep(300)--1
		
		stomtap(368,  470);stommSleep(300)
		stomtap(369,  634);stommSleep(300)
		
		stomtap(414,  200);stommSleep(300)
		stomtap(413,  367);stommSleep(300)--2
		
		stomtap(319,  373);stommSleep(300)
		stomtap(318,  539);stommSleep(300)
		
		stomtap(459,  297);stommSleep(300)
		stomtap(458,  465);stommSleep(300)--3	 	
		
		stomtap(460,  474);stommSleep(300)
		stomtap(459,  645);stommSleep(300)
	
		stomtap(456,  121);stommSleep(300)
		stomtap(460,  286);stommSleep(300)--4
		
		stomtap(409,  381);stommSleep(300)
		stomtap(408,  545);stommSleep(300)
		
		stomtap(499,  393);stommSleep(300)
		stomtap(496,  564);stommSleep(300)--5
		
		stomtap(368,  276);stommSleep(300)
		stomtap(371,  447);stommSleep(300)
		
		stomtap(498,  221);stommSleep(300)
		stomtap(499,  386);stommSleep(300)--6
		
		stomtap(534,  145);stommSleep(300)
		stomtap(535,  256);stommSleep(300)--end
		stomMultiColorTap("展开",{
			{  177,   28, 0xc6e7ff},
			{  177,   20, 0xc6e7ff},
			{  184,   41, 0x102431},
			{  157,   23, 0xceefff},
		})
	end--]]
	if stomMultiColorTap("1-9第一行",{
			{  420,  966, 0xc69652},
			{  423,  993, 0xefba63},
			{  427, 1005, 0xefb663},
			{  420, 1042, 0x5a4d21},
			}) 	 then
		stommSleep(800)
		stomMultiColorTap("点部队1",{
				{  501,   82, 0xceefff},
				{  499,   95, 0xceefff},
			})
		stommSleep(300)	
		stomMultiColorTap("撤退",{
				{  373,  206, 0x733042},
				{  367,  221, 0xf7bac6},
				{  368,  262, 0x7b344a},
			})
		stommSleep(300)	
		stomMultiColorTap("确认撤退",{
				{  199,  621, 0x295984},
				{  448,  560, 0xceebff},
				{  197,  508, 0x84344a},
				{  321,  616, 0x73aade},
			})
		stommSleep(300)	
		stomMultiColorTap("点部队2",{
				{  430,   78, 0xceebff},
				{  432,   84, 0x7b868c},
				{  434,   99, 0xadc7d6},
			})
		stommSleep(300)	
		stomMultiColorTap("撤退",{
				{  376,  203, 0x6b2c39},
				{  365,  224, 0xdea6bd},
				{  366,  257, 0x7b3c52},
			})
		stommSleep(300)
		stomMultiColorTap("确认撤退",{
				{  199,  621, 0x295984},
				{  448,  560, 0xceebff},
				{  197,  508, 0x84344a},
				{  321,  616, 0x73aade},
			})
		stommSleep(300)	
	end

	if stomMultiColor("1-9第四行",{
			{  428,  916, 0xefba63},
			{  428,  972, 0x423421},
			{  428,  984, 0x846531},
			{  429, 1057, 0x735929},
			}) or stomMultiColor("1-9第六行",{
			{  292,  994, 0xefba5a},
			{  296, 1005, 0xe7ba63},
			{  292, 1035, 0x948242},
			{  297, 1064, 0x7b6131},
			})  then
		stomMultiColorTap("点部队1",{
				{  501,   82, 0xceefff},
				{  499,   95, 0xceefff},
			})
		stommSleep(300)	
		stomMultiColorTap("撤退",{
				{  373,  206, 0x733042},
				{  367,  221, 0xf7bac6},
				{  368,  262, 0x7b344a},
			})
		stommSleep(300)	
		stomMultiColorTap("确认撤退",{
				{  199,  621, 0x295984},
				{  448,  560, 0xceebff},
				{  197,  508, 0x84344a},
				{  321,  616, 0x73aade},
			})
		stommSleep(300)	
		stomMultiColorTap("点部队2",{
				{  430,   78, 0xceebff},
				{  432,   84, 0x7b868c},
				{  434,   99, 0xadc7d6},
			})
		stommSleep(300)	
		stomMultiColorTap("撤退",{
				{  376,  203, 0x6b2c39},
				{  365,  224, 0xdea6bd},
				{  366,  257, 0x7b3c52},
			})
		stommSleep(300)
		stomMultiColorTap("确认撤退",{
				{  199,  621, 0x295984},
				{  448,  560, 0xceebff},
				{  197,  508, 0x84344a},
				{  321,  616, 0x73aade},
			})
		stommSleep(300)	
	end
	
	if stomMultiColorTap("捡资源",{
			{  335,  971, 0xe7b263},
			{  339,  991, 0xefba63},
			{  337, 1008, 0xbd9a52},
			{  311,  913, 0xcedbd6},
			}) 	 then
		stommSleep(500)
		stomMultiColorTap("对话",{
				{  327,  705, 0xd6e3ef},
				{  328,  719, 0xd6e7ef},
				{  315,  777, 0x313439},
				{  321,  777, 0xdeefef},
			})
	end
	return 0
end 

function JZJ1463368792_fn_zhaomu()
	if stomMultiColorTap("招募高亮",{
			{   33, 1005, 0x424d6b},
			{   71, 1023, 0xce3829},
			{   61, 1031, 0xce3829},
			{   49,  976, 0x5aaade},
			})	or 
		stomMultiColorTap("招募高亮金",{
			{   43,  998, 0xffff84},
			{   73,  998, 0xfffff7},
			{    9,  997, 0xffffff},
		})	 then 
		stommSleep(500)	
	end	
		
	if stomMultiColorTap("招募A免费",{
			{  211,  125, 0x7bbaff},
			{  211,  135, 0x7bbaf7},
			{  210,  144, 0x7bbaff},
			{  204,  113, 0x102852},
			})	then 
		stommSleep(500)
		stomMultiColorTap("点击招募A",{
				{  118,   78, 0x845929},
				{  115,  143, 0x8c6129},
				{  159,  100, 0xffdfad},
			})
		stommSleep(500)
	--[[elseif stomMultiColorTap("点击招募传说免费A",{
			{  101,  184, 0xcea242},
			{  128,  181, 0x6b4121},
			{  103,  250, 0x946d31},
			{  154,  192, 0xffdba5},
			}) then
		stommSleep(500)
		stomtap(320,  517)--关闭弹窗武将
		stommSleep(500)]]
		--[[stomMultiColorTap("--点击关闭",{
			{  101,  184, 0xcea242},
			{  128,  181, 0x6b4121},
			{  103,  250, 0x946d31},
			{  154,  192, 0xffdba5},
		})]]
	elseif stomMultiColorTap("点击招募传说免费A2",{
		{  211,  503, 0x7bbaff},
		{  211,  508, 0x73beff},
		{  207,  508, 0x73baff},
		{  207,  520, 0x73beff},
		}) then
	stommSleep(500)
	stomMultiColorTap("点击招募A2",{
			{  113,  425, 0x946129},
			{  103,  494, 0xc69639},
			{  156,  478, 0xffdba5},
		})
	stommSleep(500)
	stomtap(320,  517)--关闭弹窗武将
	stommSleep(500)
	elseif stomMultiColorTap("招募紫色A2",{
		{  120,  456, 0x845521},
		{  112,  472, 0xffebbd},
		{  156,  478, 0xffdba5},
		{  160,  498, 0xffdba5},
		}) then
	stommSleep(500)	
	elseif stomMultiColorTap("蓝色B免费",{
		{  298,  567, 0xefffff},
		{  298,  578, 0xefffff},
		{  301,  591, 0x7baade},
		{  297,  593, 0xefffff},
	}) then
	stommSleep(500)
		stomMultiColorTap("点击2",{
		{  111,  429, 0x946529},
		{  108,  522, 0x946929},
		{  167,  475, 0xffdba5},
		{  167,  498, 0xffdfad},
	})		
	stommSleep(500)
		stomMultiColorTap("点击1",{
		{  109,  514, 0x8c6929},
		{  147,  575, 0xffdba5},
		{  147,  563, 0xffdba5},
		{  150,  593, 0xffdfad},
	})		
	stommSleep(500)			
	elseif stomMultiColorTap("招募紫色A1",{
		{  103,  142, 0x9c7531},
		{  160,  184, 0xffdbad},
		{  156,  196, 0x6b61b5},
		{  164,  212, 0xffdbad},
	}) then
	stommSleep(500)
	elseif stomMultiColorTap("招募紫色B1",{
		{  115,  141, 0x845d21},
		{  158,  162, 0xe78252},
		{  147,  198, 0xffdfad},
		{  150,  215, 0xffdfad},
		{  243,  101, 0x391c42},
	}) then
	stommSleep(500)
	elseif stomMultiColorTap("招募紫色B2",{
		{  118,  426, 0x845929},
		{  149,  484, 0xffdfad},
		{  151,  503, 0xffdba5},
		{  214,  509, 0xbd8eef},
	}) then
	stommSleep(500)
	elseif stomMultiColorTap("招募蓝色A1",{
		{  118,  133, 0x7b5529},
		{  115,  235, 0x8c5d21},
		{  164,  188, 0xffdbad},
		{  161,  212, 0xffdfad},
		{  155,  227, 0x29344a},
	}) then
	stommSleep(500)
	else
		stomLog("什么也没有执行")
		return 1
	end
	stomMultiColorTap("关闭4星",{
			{  549,  741, 0x5ab2ce},
			{   62,  741, 0x427da5},
			{   62,  661, 0x4286ad},
		})	

	stomMultiColorTap("关闭招募A",{
			{  609, 1102, 0x849ebd},
			{  607,   51, 0xbddfef},
			{   97,  445, 0x845929},
			{   94,  676, 0xad8a52},
		})
		return 0

end

function JZJ1463368792_fn_dachui()
	stomLog("findZD")
	if stomMultiColor("在城内",{--在城内
		{  580, 1133, 0x849294},
		{   28,  442, 0xefe7ce},
		{  350,  237, 0xe7df73},
		{    8,  593, 0xc6baa5},
		})==true then
		stomMultiColorRegTap("找金色大锤升级1",0xffffff, "8|3|0xffffff,-25|7|0xffffff,32|-2|0xfffbe7", 90, 65, 558, 144, 655)
		stommSleep(500)
	else
	stomMultiColorRegTap("找金色大锤升级1",0xffffe7, "-2|10|0xffffef,-26|11|0xf7f3d6", 90, 146, 253, 499, 796)
	stommSleep(500)
	stomMultiColorRegTap("找金色大锤升级2",0xffffe7, "4|9|0xffffad,-25|7|0xffffe7", 90, 102, 273, 380, 749)
	--stomMultiColorRegTap("找金色大锤升级1",0xffffef, "13|6|0xfffff7,3|-13|0x292c29,-4|32|0x292c29", 90, 88, 335, 482, 880)
	stommSleep(500)
	end
end

function JZJ1463368792_fn_kongxian()
	if stomMultiColor("在城内KX",{--在城内
			{   59, 1081, 0xdedfe7},
			{   42, 1086, 0x5279ad},
			})==true then 
		stommSleep(500)		
		if stomMultiColorTap("自动建造1",{
				{   47,  864, 0x214d84},
				{   46,  889, 0xb5efff},
				{   51,  903, 0x214573},
				}) then 
			stommSleep(500)
			JZJ1463368792_fn_dachui()
		elseif stomMultiColorTap("自动建造2",{
				{  391,  110, 0x73a6d6},
				{  382,  111, 0x6396c6},
				{  379,  115, 0x73a2c6},
				}) then 
			stommSleep(500)
			JZJ1463368792_fn_dachui()
		elseif stomMultiColorTap("自动建造科技",{
					{  291,  110, 0x73a6d6},
					{  284,  111, 0x73aade},
					{  279,  113, 0x6ba2c6},
				}) then 
		stomLog("findkx")
		--stomMultiColorRegTap("找金色小锤升级",0xffffe7, "11|6|0xffffff,6|11|0xffffb5", 90, 97, 18, 493, 721)
		--stomMultiColorRegTap("高亮科技点击",0xffffff, "-23|-19|0xe7db9c,13|26|0xffebad,31|-1|0xfffbbd", 75,68, 26, 481, 677)-- 106, 38, 441, 910)
		stommSleep(500)
		stomMultiColorRegTap("高亮科技点击2",0xffffff, "28|-2|0xffffce,-27|-3|0xffffbd",75,68, 26, 481, 677)
		stommSleep(4000)	
		else JZJ1463368792_fn_renwu2()
			stommSleep(2000)
		end
		stomMultiColorTap("找金色大锤升级1",{
				{   47,  864, 0x214d84},
				{   46,  889, 0xb5efff},
				{   51,  903, 0x214573},
			})
	end
end

function JZJ1463368792_fn_tanchuang()
	if stomMultiColorTap("完成任务",{
			{  423, 1115, 0xcef3de},
			{  441,  898, 0x08cf6b},
			{  402,  892, 0x08cb63},
		}) then
		stommSleep(500)
		stomtap(423, 1115)
	end	
	if stomMultiColor("在科技",{
		{  615,   40, 0xc6e7f7},
		{  614,   57, 0x738e9c},
		{  619,   80, 0xceebf7},
		{  608,  325, 0x8c8684},
	})	then
		for var= 1, 3 do
			stomLog("findKJ")
		stomMultiColorRegTap("高亮科技点击",0xffffff, "-23|-19|0xe7db9c,13|26|0xffebad,31|-1|0xfffbbd", 60, 95, 53, 489, 782)
		stommSleep(500)
		stomMultiColorRegTap("高亮科技点击2",0xffffff, "34|-7|0x949ea5,-35|-1|0x395584,-6|-3|0xffff94", 60, 94, 54, 448, 924)
		stommSleep(1000)
		end
	end


	--[[if stomMultiColorTap("福利是红点",{
			{  557,  317, 0xadc7de},
			{  524,  312, 0xcee7f7},
			{  560,  334, 0xce3829},
			{  573,  334, 0xc63c29},
		{  570,  391, 0xc63829},
		{  548,  372, 0x101c29},
	}) or stomMultiColorTap("福利是红点2",{
		{  558,  374, 0xadc7de},
		{  562,  391, 0xc63829},
				})  then
		stommSleep(500)				
		stomMultiColorTap("领取奖励",{
			{  413,  861, 0x295184},
			{  421,  831, 0x295584},
			{  400,  922, 0x3979ad},
			{  429,  932, 0x316d9c},
		})
		stommSleep(500)		
		stomMultiColorTap("领取进度奖励",{
			{  409,  850, 0x296194},
			{  408,  933, 0x296194},
			{  553,  558, 0xb5d7e7},
		})	
		stomLog("findFL")
		stommSleep(500)		
		x,y = findMultiColorInRegionFuzzy( 0x212831, "39|118|0xc63829,33|125|0xce3829,-7|125|0x101421", 80, 87, 160, 445, 319)
		stommSleep(500)
			if x ~= -1 then--找购买类型需求	
				stomtap(x,y)
			else 
				touchDown( 109,  239)
				for i = 0, 300, 50 do
					touchMove(109+i,  239)
					stommSleep(70)
				end
				touchUp(409,  239)
				stommSleep(2000)
				stomMultiColorRegTap("寻找福利",0x212831, "39|118|0xc63829,33|125|0xce3829,-7|125|0x101421", 70, 87, 160, 445, 319)
			end
		stomMultiColorRegTap("签到", 0xffe3a5, "71|0|0xffe3a5,71|71|0xffe3a5,0|71|0xffe3a5", 80, 94, 335, 494, 866)
		stomMultiColorTap("领取奖励",{
			{  413,  861, 0x295184},
			{  421,  831, 0x295584},
			{  400,  922, 0x3979ad},
			{  429,  932, 0x316d9c},
		})
		stommSleep(500)		
		stomMultiColorTap("领取进度奖励",{
			{  409,  850, 0x296194},
			{  408,  933, 0x296194},
			{  553,  558, 0xb5d7e7},
		})
		stomMultiColorTap("领取实名奖励",{
			{  143,  595, 0x398242},
			{  140,  699, 0x31864a},
		})
		stomMultiColorTap("关闭福利",{
			{  552,  953, 0x84a2c6},
			{  558,  545, 0xc6e7f7},
			{  555,  576, 0xc6e7f7},
			{   62,  979, 0x42596b},
		})
	end]]
	stomMultiColorTap("出征",{
		{  327,  705, 0xdee3ef},
		{  328,  719, 0xd6e7ef},
		{  294,  742, 0x31455a},
		{  318,  758, 0xdeebef},
	})
	stomMultiColorTap("确认建造",{
		{   47,  864, 0x214d84},
		{   46,  889, 0xb5efff},
		{   51,  903, 0x214573},
	})
	stomMultiColorTap("点援助1",{
			{  446,  193, 0xbddfef},
			{  452,  200, 0xc6dbe7},
			{  497,   56, 0xc6efff},
			{  453,  200, 0xa5c3d6},
		})
	stomMultiColorTap("点援助2",{
			{  378,  188, 0xc6dbe7},
			{  385,  188, 0xc6dfef},
			{  391,  188, 0xc6dfef},
			{  386,  198, 0x395973},
		})
	stomMultiColorTap("点援助3",{
			{  289,  188, 0xc6dfef},
			{  279,  196, 0xbdd7e7},
			{  292,  199, 0xbddbe7},
			{  497,   56, 0xc6efff},
		})
	stomMultiColorTap("研究科技2",{
		{  219,  105, 0xffffff},
		{  198,   85, 0xffefb5},
		{  224,  104, 0xffffff},
	})
	stomMultiColorTap("研究科技确认",{
			{  112,  575, 0xd6aa42},
			{  129,  558, 0xffefbd},
			{  535,  278, 0x213039},
		})
	--[[stomMultiColorTap("关闭加速完成!!",{
			{  444,  779, 0x84a2c6}, 
			{  436,  522, 0xceebff},
			{  201,  518, 0xad5d73},
		})--]]
	stomMultiColorTap("领金币",{
			{  490,  367, 0x291c18},
			{  480,  367, 0x7b86a5},
			{  499,  367, 0xa5a2b5},
		})
	stomMultiColorTap("建造无队列取消",{
		{  609, 1099, 0x849ebd},
		{   48,  860, 0x182c4a},
		{   39,  938, 0x183c5a},
		{  559,  662, 0x081010},
	})
	stomMultiColorTap("主界面4星弹窗",{	
		{  528,  474, 0xffe384},
		{  529,  507, 0xffe784},
		{  527,  537, 0xffe784},
		{  528,  565, 0xffe78c},
	})
	stomMultiColorTap("确认取消改名",{	
		{  213,  633, 0x295184},
		{  439,  526, 0xceefff},
		{  445,  576, 0xc6ebff},
		{  208,  508, 0x84304a},
	})
	stomMultiColorTap("关闭武将详细",{	
		{  609, 1101, 0x8c9ebd},
		{  613,   62, 0xc6e7f7},
		{  607,   94, 0xbde3f7},
		{  614,  112, 0x394d63},
	})
	stomMultiColorTap("关闭武将界面",{	
		{  609, 1102, 0x849ebd},
		{  614,   56, 0xc6e3f7},
		{  605,  165, 0x7baade},
		{  609,  194, 0x73aade},
	})
	if stomMultiColorTap("征兵提示",{	
		{  199,  517, 0x295984},
		{  455,  536, 0xceefff},
		{  204,  563, 0xb5efff},
		{  459,  796, 0x293442},
		}) then 
		stommSleep(500)
		stomtap(31,  847)
		stommSleep(500)
		JZJ1463368792_fn_zhengbing()
	end
	if stomMultiColorTap("实名窗体",{
		{  154,  520, 0x318242},
		{  157,  556, 0xb5ffce},
		{  513,  519, 0x526573},
		{  498,  526, 0xb5dff7},
	}) then
		stommSleep(500)		
	end
	
	if stomMultiColor("实名认证窗体",{--实名认证窗体
			{  547,  528, 0x000000},
			{  534,  563, 0x000000},
			{  538,  585, 0x000000},
			{  527,  609, 0xe7e7e7},
			})==true then
		stomMultiColorTap("第一个文本框",{
			{  304,  476, 0xffffff},
			{  533,  529, 0x000000},
			{  300,  437, 0x8c8e94},
			{  312,  515, 0x7b8284},
		})	
		stommSleep(500)
		stomInpuText("彭会")
		stommSleep(2000)
		if 
		stomMultiColorTap("第二个文本框",{
			{  406,  450, 0xffffff},
			{  406,  356, 0x030303},
			{  407,  368, 0x1b1c1d},
			{  410,  759, 0xffffff},
		}) then 
		stommSleep(500)
		stomInpuText("440282195610226964")
		stommSleep(500)
		stomMultiColorTap("提交",{--提交
				{  411,  613, 0x1088fb},
				{  408,  524, 0x1088f8},
				{  396,  583, 0xc7e4ff},
				{  354,  550, 0xfdfefe},
			})
		stommSleep(500)
		stomMultiColorTap("确定",{--确定
			{  214,  628, 0x295184},
			{  443,  558, 0xceefff},
			{  205,  433, 0x8c384a},
		})
		end
	end
	stomMultiColorTap("关闭福利",{
		{  552,  953, 0x84a2c6},
		{  558,  545, 0xc6e7f7},
		{  555,  576, 0xc6e7f7},
		{   62,  979, 0x42596b},
	})
	stomMultiColorTap("确认撤退",{
		{  199,  621, 0x295984},
		{  448,  560, 0xceebff},
		{  197,  508, 0x84344a},
		{  321,  616, 0x73aade},
	})	
	stomMultiColorTap("关闭部队",{
		{  609, 1102, 0x849ebd},
		{  610,   46, 0x9cbece},
		{  610,   84, 0xc6e3f7},
		{   26,   32, 0x181c21},
	})	
	stomMultiColorTap("关闭任务界面",{
			{  602, 1027, 0x84a2c6},
			{  596,  545, 0xb5dff7},
			{  605,  556, 0x52697b},
			{  602, 1035, 0x29384a},
		})
	stomMultiColorTap("确认调动",{	
		{   98,  729, 0x8c6531},
		{  104,  751, 0xffefbd},
		{  109,  793, 0xffefb5},
		{   99,  833, 0x8c6529},
	})
	stomMultiColorTap("无法调动",{	
		{  582, 1004, 0x849ebd},
		{  470,  474, 0x101018},
		{  393,  474, 0x081010},
		{  115,  849, 0x7b7573},
	})
	stomMultiColorTap("无法升级科技",{	
		{  530,  870, 0x8c9ebd},
		{  535,  518, 0xcee7f7},
		{  534,  546, 0xcee3f7},
		{  266,  692, 0xb5344a},
	})
	stomMultiColorTap("同盟帮助",{
		{  143, 1086, 0xd6dfe7},
		{  134, 1093, 0xb5c3d6},
		{  118, 1099, 0x5a717b},
		{  120, 1114, 0xceebff},
	})
	stomMultiColorTap("确认屯田",{
	{  104,  732, 0x845929},
	{  362,  600, 0x4286bd},
	{  104,  813, 0xffefbd},
	{  328,  643, 0x7b5d21},
	{  360,  582, 0x4286bd},
})
	stomMultiColorTap("科技加速关闭",{
		{  529,  870, 0x849ebd},
		{  530,  534, 0xc6e3f7},
		{  129,  662, 0x29a618},
		{  136,  709, 0xf7ebbd},
	})
	stomMultiColorTap("关闭武将详情",{
		{  592, 1007, 0x84a2c6},
		{  608,  104, 0x313442},
		{  595,  522, 0xbddbef},
		{  600,  592, 0xcee7f7},
	})
	stomMultiColorTap("关闭抽奖结束",{
		{  609, 1103, 0x849ebd},
		{  618,   53, 0xcee7f7},
		{  114,  518, 0x845929},
		{  113,  620, 0x846129},
	})
	stomMultiColorTap("关闭抽奖结束B",{
		{  610, 1101, 0x84a2c6},
		{  606,   50, 0xbddff7},
		{  602,   59, 0x213842},
		{  602,   86, 0xb5dbf7},
	})	
	stomMultiColorTap("跳过剧情",{
		{  553, 1079, 0xdee3e7},
		{  549, 1099, 0xdee3e7},
		{  553, 1125, 0xd6dfe7},
		{  558, 1055, 0x31618c},
	})
	stomMultiColorTap("跳过",{
		{  553, 1056, 0xd6e7ef},
		{  554, 1063, 0xd6e3ef},
		{  554, 1090, 0xdee3e7},
		{  554, 1124, 0xcedbe7},
	})
	stomMultiColorTap("姓名",{
		{  192,  533, 0x9c7531},
		{  200,  608, 0x8c5d29},
		{  484,  560, 0x639ab5},
		{  471,  550, 0xceefff},
	})
	stomMultiColorTap("改名",{
		{  197,  487, 0x29598c},
		{  465,  521, 0xceefff},
		{  462,  552, 0xceebff},
		{  208,  728, 0xffebbd},
	})
	stomMultiColorTap("获得弹窗",{
		{  477,  502, 0xf7db84},
		{  484,  549, 0xf7df9c},
		{  482,  599, 0x522418},
		{  480,  635, 0xf7e38c},
	})
	stomMultiColorTap("出征",{
		{  316,  726, 0x293439},
		{  331,  702, 0xd6dfef},
		{  331,  721, 0xd6e3e7},
		{  318,  778, 0xdeebef},
	})
	stomMultiColorTap("关闭高亮部队",{
		{  610, 1102, 0xd6df9c},
		{  609, 1094, 0xadb239},
		{  602, 1102, 0xada631},
		{  609, 1113, 0xa59221},
	})	
		stommSleep(500)	
	if stomMultiColorTap("确认出征",{
		{  102,  758, 0x8c5d29},
		{  100,  820, 0x8c6129},
		{  583,  520, 0xbde7f7},
		{  591,  532, 0xc6dfe7},
	}) then
		stommSleep(500)	
		--[[stomMultiColorTap("点击任务",{
		{  465,  948, 0xa57d39},
		{  477,  908, 0x946939},
		{  468,  958, 0xf7e3bd},
		{  456,  998, 0xe7be52},
	})	]]
	end
	if stomMultiColorTap("征兵高亮",{
		{   39,  843, 0xe7eb94},
		{   74,  835, 0xffffef},
		{   43,  878, 0xffffff},
		{   18,  820, 0xffff8c},
	}) then 
	JZJ1463368792_fn_zhengbing()
	end
	stomMultiColorTap("关闭科技界面",{
		{  609, 1102, 0x849ebd},
		{  607,   40, 0xb5e3f7},
		{  613,   80, 0xc6e7f7},
		{  609,   53, 0x213442},
	})
	stomMultiColorTap("招募结束卡顿",{
		{  609, 1101, 0x8c9ebd},
		{  115,  451, 0xffefb5},
		{  112,  669, 0x8c6529},
		{  105,  702, 0x946d29},
	})
	stomMultiColorTap("无技能升级",{
		{  609, 1099, 0x849ebd},
		{  618, 1099, 0x212831},
		{  616, 1095, 0x5a697b},
		{  599,  125, 0xaddbef},
	})
	stomMultiColorTap("关闭福利",{
		{  552,  953, 0x84a2c6},
		{  558,  545, 0xc6e7f7},
		{  555,  576, 0xc6e7f7},
		{   62,  979, 0x42596b},
	})
end

function JZJ1463368792_fn_duihua()
	stomMultiColorTap("右侧对话框",{
			{  169,  622, 0x63bede},
			{   71,  372, 0x213c52},
			{   15,  570, 0x94c3e7},
		})
	stomMultiColorTap("左侧对话框",{
			{  169,  500, 0x6bc3e7},
			{  169,  585, 0x215573},
			{   15,  570, 0x94c3e7},
		})
	stomMultiColorTap("右侧红色对话框",{
			{  171,  613, 0xd6457b},
			{  171,  630, 0xd64984},
			{  169,  625, 0xe77594},
			{   17,  567, 0xde868c},
		})
	stomMultiColorTap("左侧红色对话框",{
			{  174,  500, 0xc63c6b},
			{  170,  514, 0xe74d8c},
			{   14,  569, 0xde92a5},
		})
end

function JZJ1463368792_fn_renwu1()
	stomMultiColorTap("点击任务",{
		{  465,  948, 0xa57d39},
		{  477,  908, 0x946939},
		{  468,  958, 0xf7e3bd},
		{  456,  998, 0xe7be52},
		})	
	stommSleep(500)
	stomMultiColorTap("成长任务",{
		{  164,  886, 0x29598c},
		{  238,  172, 0xdeebff},
		{  233,  183, 0xdeefff},
		{  238,  195, 0xdeefff},
		{  244,  254, 0xdeebff},
	})	
	stommSleep(500)
end

function JZJ1463368792_fn_renwu2()
	JZJ1463368792_fn_zhengbing()
	if stomMultiColorTap("点击任务",{
			{  465,  948, 0xa57d39},
			{  477,  908, 0x946939},
			{  468,  958, 0xf7e3bd},
			{  456,  998, 0xe7be52},
		})	then
	stommSleep(500)
	touchDown(30,500)
	for i = 0, 510, 50 do
		touchMove(30+i,500)
		stommSleep(70)
	end
	touchUp(540,500)
	stommSleep(2000)
		for var= 1, 3 do
			if JZJ1463368792_fn_renwu3()
			then
			stommSleep(60);
			else
			touchDown(306,  331);    
			stommSleep(60);
			touchMove(160,  331);    
			stommSleep(60);
			touchDown(160,  331);    
			stommSleep(60);
			touchUp(160,  331);
			stommSleep(200);
		end
			JZJ1463368792_fn_renwu3()
			end
	else stomMultiColorTap("关闭任务界面",{
			{  602, 1027, 0x84a2c6},
			{  596,  545, 0xb5dff7},
			{  605,  556, 0x52697b},
			{  602, 1035, 0x29384a},
		})

	end
	--[[if stomMultiColorTap("左慈任务没做完",{	
		{  161,  915, 0x316594},
		{  238,  288, 0xdeebff},
		{  233,  288, 0x8c5921},
		{  229,  312, 0xcedbde},
	}) then
		stommSleep(300)
		stomMultiColorTap("隐藏",{
		{  179,   26, 0x182431},
		{  174,   28, 0x9cb6ce},
		{  155,   22, 0x848ea5},
		{  159,   33, 0xceefff},
	})
		stommSleep(500)
		stomtap(420,  560);stommSleep(300)
		stomtap(420,  730);stommSleep(300)
	
		stomtap(543,  312);stommSleep(300)
		stomtap(538,  480);stommSleep(300)--1
		
		stomtap(368,  470);stommSleep(300)
		stomtap(369,  634);stommSleep(300)
		
		stomtap(414,  200);stommSleep(300)
		stomtap(413,  367);stommSleep(300)--2
		
		stomtap(319,  373);stommSleep(300)
		stomtap(318,  539);stommSleep(300)
		
		stomtap(459,  297);stommSleep(300)
		stomtap(458,  465);stommSleep(300)--3	 	
		
		stomtap(460,  474);stommSleep(300)
		stomtap(459,  645);stommSleep(300)
	
		stomtap(456,  121);stommSleep(300)
		stomtap(460,  286);stommSleep(300)--4
		
		stomtap(409,  381);stommSleep(300)
		stomtap(408,  545);stommSleep(300)
		
		stomtap(499,  393);stommSleep(300)
		stomtap(496,  564);stommSleep(300)--5
		
		stomtap(368,  276);stommSleep(300)
		stomtap(371,  447);stommSleep(300)
		
		stomtap(498,  221);stommSleep(300)
		stomtap(499,  386);stommSleep(300)--6
		stomtap(534,  145);stommSleep(300)--end
		stomtap(535,  256)
		stomMultiColorTap("展开",{
			{  177,   28, 0xc6e7ff},
			{  177,   20, 0xc6e7ff},
			{  184,   41, 0x102431},
			{  157,   23, 0xceefff},
		})		

	end

	if stomMultiColorTap("攻城引导第三个任务",{	
		{  163,  903, 0xbdefff},
		{  233,  239, 0xdeefff},
		{  234,  248, 0xdeebff},
		{  247,  272, 0xdeefff},
	}) then
		stommSleep(300)
			stomMultiColorTap("进入副本",{	
			{   29,  519, 0x398242},
			{  616,   72, 0xbddbef},
			{  616,   90, 0xbddbef},
			{  614,  112, 0x425963},
		})
		stommSleep(1000)
		stomMultiColorTap("右侧对话框",{
			{  169,  622, 0x63bede},
			{   71,  372, 0x213c52},
			{   15,  570, 0x94c3e7},
		})
		stommSleep(800)
		stomMultiColorTap("右侧对话框",{
			{  169,  622, 0x63bede},
			{   71,  372, 0x213c52},
			{   15,  570, 0x94c3e7},
		})
		stommSleep(300)
		stomMultiColorTap("右侧对话框",{
			{  169,  622, 0x63bede},
			{   71,  372, 0x213c52},
			{   15,  570, 0x94c3e7},
		})
		stommSleep(500)
		stomtap(316,  563)
		stommSleep(500)
		stomMultiColorTap("出征",{
		{  320,  712, 0xa5b6ce},
		{  329,  702, 0xd6e7ef},
		{  325,  719, 0x737d84},
		{  317,  774, 0xd6e7e7},
	})
		stommSleep(500)
		for var= 1, 99 do
			if stomMultiColorTap("确认出征",{
			{  320,  712, 0xa5b6ce},
			{  329,  702, 0xd6e7ef},
			{  325,  719, 0x737d84},
			{  317,  774, 0xd6e7e7},
			}) then
				break
			end
		stommSleep(500)
		end
		stommSleep(5000)
		stomMultiColorTap("右侧对话框",{
			{  169,  622, 0x63bede},
			{   71,  372, 0x213c52},
			{   15,  570, 0x94c3e7},
		})
		stommSleep(500)
		stomMultiColorTap("当前任务",{
			{  422,  969, 0xe7ba6b},
			{  424,  985, 0xefba6b},
			{  425, 1005, 0x6b5931},
			{  424, 1022, 0x736139},
		})
		stommSleep(500)
		stomMultiColorTap("建造2",{
			{  295,  713, 0xefe7ce},
			{  286,  717, 0xd6cfa5},
			{  294,  759, 0xc6aa7b},
			{  288,  773, 0xbda273},
		})
		stommSleep(500)
		stomMultiColorTap("建造3",{
			{  213,  519, 0x214573},
			{  203,  613, 0x29598c},
			{  436,  548, 0xceebff},
		})
		stommSleep(500)
		stomMultiColorTap("建造4",{
			{  202,  647, 0x21518c},
			{  197,  489, 0x84344a},
			{  461,  556, 0xceefff},
		})
		stommSleep(9999)
		stomMultiColorTap("右侧对话框",{
			{  169,  622, 0x63bede},
			{   71,  372, 0x213c52},
			{   15,  570, 0x94c3e7},
		})
		stommSleep(1000)
		stomMultiColorTap("右侧对话框",{
			{  169,  622, 0x63bede},
			{   71,  372, 0x213c52},
			{   15,  570, 0x94c3e7},
		})
		stommSleep(1000)
		stomMultiColorTap("当前任务",{
			{  422,  969, 0xe7ba6b},
			{  424,  985, 0xefba6b},
			{  425, 1005, 0x6b5931},
			{  424, 1022, 0x736139},
		})
		stommSleep(500)
		stomMultiColorTap("调动",{
			{  353,  711, 0x8ca6bd},
			{  353,  718, 0xb5cbe7},
			{  354,  760, 0x5a6573},
			{  353,  770, 0xd6ebe7},
		})
		stommSleep(500)	
		stomMultiColorTap("确认调动",{
			{   97,  725, 0x946529},
			{  579,  543, 0xbddfef},
			{  118,  825, 0x7b4d21},
		})
		stommSleep(500)	
		stomMultiColorTap("当前任务",{
			{  422,  969, 0xe7ba6b},
			{  424,  985, 0xefba6b},
			{  425, 1005, 0x6b5931},
			{  424, 1022, 0x736139},
		})
		stommSleep(500)
		stomMultiColorTap("调动2",{
			{  353,  711, 0x8ca6bd},
			{  353,  718, 0xb5cbe7},
			{  354,  760, 0x5a6573},
			{  353,  770, 0xd6ebe7},
		})
		stommSleep(500)	
		stomMultiColorTap("确认调动",{
			{   97,  725, 0x946529},
			{  579,  543, 0xbddfef},
			{  118,  825, 0x7b4d21},
		})
		stommSleep(9999)
		stomMultiColorTap("右侧对话框",{
			{  169,  622, 0x63bede},
			{   71,  372, 0x213c52},
			{   15,  570, 0x94c3e7},
		})
		stommSleep(1000)
		stomMultiColorTap("右侧对话框",{
			{  169,  622, 0x63bede},
			{   71,  372, 0x213c52},
			{   15,  570, 0x94c3e7},
		})
		stommSleep(1000)
		stomMultiColorTap("当前任务",{
			{  422,  969, 0xe7ba6b},
			{  424,  985, 0xefba6b},
			{  425, 1005, 0x6b5931},
			{  424, 1022, 0x736139},
		})
		stommSleep(500)
		stomMultiColorTap("出征",{
			{  328,  704, 0xdee3ef},
			{  328,  719, 0xd6e7ef},
			{  319,  757, 0xdeefe7},
			{  318,  777, 0x6b717b},
		})
		stommSleep(500)
		stomMultiColorTap("确认出征",{
			{  103,  726, 0x845d29},
			{   99,  828, 0x8c6529},
			{  580,  530, 0xbddff7},
		})
		stommSleep(500)
		stomMultiColorTap("当前任务",{
			{  422,  969, 0xe7ba6b},
			{  424,  985, 0xefba6b},
			{  425, 1005, 0x6b5931},
			{  424, 1022, 0x736139},
		})
		stommSleep(500)
		stomMultiColorTap("出征",{
			{  328,  704, 0xdee3ef},
			{  328,  719, 0xd6e7ef},
			{  319,  757, 0xdeefe7},
			{  318,  777, 0x6b717b},
		})
		stommSleep(500)
		stomMultiColorTap("确认出征",{
			{  103,  726, 0x845d29},
			{   99,  828, 0x8c6529},
			{  580,  530, 0xbddff7},
		})
		stommSleep(500)
		stomMultiColorTap("右侧对话框",{
			{  169,  622, 0x63bede},
			{   71,  372, 0x213c52},
			{   15,  570, 0x94c3e7},
		})
		stommSleep(50000)
		stomMultiColorTap("当前任务",{
			{  422,  969, 0xe7ba6b},
			{  424,  985, 0xefba6b},
			{  425, 1005, 0x6b5931},
			{  424, 1022, 0x736139},
		})
		stommSleep(500)
		stomMultiColorTap("出征",{
			{  356,  705, 0xd6e7f7},
			{  356,  717, 0xd6e3f7},
			{  348,  757, 0xdeefef},
		})
		stommSleep(500)		
		stomMultiColorTap("确认出征",{
			{  103,  726, 0x845d29},
			{   99,  828, 0x8c6529},
			{  580,  530, 0xbddff7},
		})
		stommSleep(500)
	end
	stomMultiColorTap("完成任务",{
			{  423, 1115, 0xcef3de},
			{  441,  898, 0x08cf6b},
			{  402,  892, 0x08cb63},
		})
	stomMultiColorTap("点击任务",{
		{  465,  948, 0xa57d39},
		{  477,  908, 0x946939},
		{  468,  958, 0xf7e3bd},
		{  456,  998, 0xe7be52},
	})	
		stommSleep(500)
		touchDown(30,500)
	for i = 0, 510, 50 do
		touchMove(30+i,500)
		mSleep(70)
	end
		touchUp(540,500)
		stommSleep(2000)
	]]
	
end

function JZJ1463368792_fn_renwu3()
		if stomMultiColorTap("土地任务1.10",{
			{  509,  903, 0x294d84},
			{  536,  113, 0x73aade},
			{  538,  135, 0x73aade},
			{  537,  156, 0x73a6d6},
			{  531,  185, 0x7baad6},
			})	then
			stommSleep(500)
			stomMultiColorTap("出征",{
			{  327,  705, 0xd6e3ef},
			{  329,  719, 0xdee3ef},
			{  319,  757, 0xdeefe7},
			{  319,  777, 0x6b6d6b},
		})
		stommSleep(500)
		return true
	elseif stomMultiColorTap("土地任务2.1",{
			{  509,  903, 0x294d84},
			{  532,  146, 0x7baade},
			{  526,  175, 0x4a6d8c},
			{  525,  171, 0x73a2d6},
			{  538,  189, 0x73a2ce},
		})	then
			stommSleep(500)
			stomMultiColorTap("出征",{
			{  327,  705, 0xd6e3ef},
			{  329,  719, 0xdee3ef},
			{  319,  757, 0xdeefe7},
			{  319,  777, 0x6b6d6b},
		})
		stommSleep(500)
		return true
	elseif stomMultiColorTap("土地任务2.3",{
			{  509,  903, 0x294d84},
			{  537,  145, 0x7ba6d6},
			{  531,  146, 0x73a6d6},
			{  525,  146, 0x73aade},
			{  525,  176, 0x73a6d6},
			{  537,  174, 0x73aad6},
		})	or
		stomMultiColorTap("土地任务lv4",{
			{  503,  899, 0x29598c},
			{  530,  162, 0x7baade},
			{  536,  177, 0x73aade},
			{  527,  192, 0x73aade},
		})           
			then
			stommSleep(500)
			local ran =  math.random(0,10)
			if ran==1 then
				stomtap(258,  486)
				stommSleep(500)
				stomtap(268,  637)
			elseif ran==2 then
				stomtap(271,  653)
				stommSleep(500)
				stomtap(270,  836)				
			elseif ran==3 then
				stomtap(376,  634)
				stommSleep(500)
				stomtap(366,  830)				
			elseif ran==4 then
				stomtap(358,  490)
				stommSleep(500)
				stomtap(363,  643)				
			end
			stomMultiColorTap("出征",{
			{  327,  705, 0xd6e3ef},
			{  329,  719, 0xdee3ef},
			{  319,  757, 0xdeefe7},
			{  319,  777, 0x6b6d6b},
		})
		stommSleep(5000)
		return true
	end
	return false
end

function JZJ1463368792_fn_jianzao()
	if stomMultiColorTap("完成任务",{
			{  423, 1115, 0xcef3de},
			{  441,  898, 0x08cf6b},
			{  402,  892, 0x08cb63},
		}) then
		stommSleep(300)
	end
	if stomMultiColor("主线1-10",{
		{  342,  918, 0x42baef},
		{  343,  966, 0x317da5},
		{  329,  988, 0x18556b},
		{  311,  949, 0xcedfde},
	}) then
	stomMultiColorTap("点击部队",{
		{   49,  830, 0xd6e3f7},
		{   58,  836, 0x425dad},
		{   43,  859, 0x39456b},
		{   13,  855, 0xd6eff7},
	})
	stommSleep(2000)
		if stomMultiColorTap("点击部队1",{
				{  324,  486, 0x31415a},
				{  289,  480, 0x428abd},
				{  424,   59, 0x73aad6},
				{  423,   71, 0x7baade},
			}) then
				stommSleep(300)
			stomMultiColorTap("配置部队",{
				{   63,  420, 0x295584},
				{   65,  439, 0xbdefff},
				{   65,  458, 0x73aac6},
				{   68,  525, 0x214d84},
			})
				stommSleep(300)
				touchDown(140,  210)
				for i = 0, 300, 50 do
					touchMove(140+i,  210)
					stommSleep(70)
				end
				for j= 0, 700, 50 do
					touchMove(440,  210+j)
					stommSleep(70)
				end
				touchUp(440,910)
				stommSleep(300)
			stomMultiColorTap("关闭部队",{
				{  587, 1005, 0x8c9ebd},
				{  596,  996, 0xadbede},
				{  596, 1006, 0x293442},
				{  596, 1014, 0xadbede},
			})	
				stommSleep(500)
			end
		if stomMultiColorTap("点击部队2",{
			{  327, 1046, 0x31455a},
			{  339, 1022, 0x212c39},
			{  426,  604, 0x6392b5},
			{  428,  636, 0x7baade},
		}) then
			stommSleep(300)
		stomMultiColorTap("配置部队",{
			{   63,  420, 0x295584},
			{   65,  439, 0xbdefff},
			{   65,  458, 0x73aac6},
			{   68,  525, 0x214d84},
		})
		stommSleep(300)
			touchDown(140,  210)
			for i = 0, 300, 50 do
				touchMove(140+i,  210)
				stommSleep(70)
			end
			for j= 0, 700, 50 do
				touchMove(440,  210+j)
				stommSleep(70)
			end
			touchUp(440,910)
			stommSleep(300)
		stomMultiColorTap("关闭部队",{
			{  587, 1005, 0x8c9ebd},
			{  596,  996, 0xadbede},
			{  596, 1006, 0x293442},
			{  596, 1014, 0xadbede},
		})	
			stommSleep(500)
		end
		
		if stomMultiColorTap("点击部队3",{
			{  207,   35, 0x7baade},
			{  201,   73, 0x7baad6},
			{  201,  123, 0x7baad6},
		})	then
			touchDown(140,  210)
			for i = 0, 300, 50 do
				touchMove(140+i,  210)
				stommSleep(70)
			end
			for j= 0, 250, 50 do
				touchMove(440,  210+j)
				stommSleep(70)
			end
			touchUp(440,460)
			stommSleep(300)
			
			touchDown(140,  210)
			for i = 0, 300, 50 do
				touchMove(140+i,  210)
				stommSleep(70)
			end
			for j= 0, 450, 50 do
				touchMove(440,  210+j)
				stommSleep(70)
			end
			touchUp(440,660)
			stommSleep(1000)
			
			touchDown(140,  210)
			for i = 0, 300, 50 do
				touchMove(140+i,  210)
				stommSleep(70)
			end
			for j= 0, 700, 50 do
				touchMove(440,  210+j)
				stommSleep(70)
				touchUp(440,910)
				stommSleep(300)
			end

	stomMultiColorTap("关闭部队",{
		{  587, 1005, 0x8c9ebd},
		{  596,  996, 0xadbede},
		{  596, 1006, 0x293442},
		{  596, 1014, 0xadbede},
	})	
	stommSleep(300)
	end
	stomMultiColorTap("关闭部队2",{
		{  609, 1102, 0x849ebd},
		{  615, 1096, 0x9cbade},
		{  626, 1104, 0x212431},
	})
	stommSleep(500)
	if stomMultiColorTap("点击同盟",{
		{   46,  678, 0xdecf94},
		{   42,  679, 0xa57142},
		{   33,  680, 0x3969ad},
		{   57,  691, 0x846d4a},
	}) then
		stommSleep(300)
		stomtap(89,   46);stommSleep(300)
		stomtap(69,  902);stommSleep(300)
		stomMultiColorTap("同盟确认",{
		{  200,  652, 0x4a759c},
		{  199,  625, 0x295984},
		{  447,  534, 0xc6ebff},
		{  194,  432, 0x84384a},
	})		
		stomtap(166,   42);stommSleep(300)
		stomtap(69,  902);stommSleep(300)
		stomMultiColorTap("同盟确认",{
		{  200,  652, 0x4a759c},
		{  199,  625, 0x295984},
		{  447,  534, 0xc6ebff},
		{  194,  432, 0x84384a},
	})			
		stomtap(252,   46);stommSleep(300)
		stomtap(69,  902);stommSleep(300)
		stomMultiColorTap("同盟确认",{
		{  200,  652, 0x4a759c},
		{  199,  625, 0x295984},
		{  447,  534, 0xc6ebff},
		{  194,  432, 0x84384a},
	})			
		stomtap(332,   45);stommSleep(300)
		stomtap(69,  902);stommSleep(300)
		stomMultiColorTap("同盟确认",{
		{  200,  652, 0x4a759c},
		{  199,  625, 0x295984},
		{  447,  534, 0xc6ebff},
		{  194,  432, 0x84384a},
	})			
		stomtap(413,   45);stommSleep(300)
		stomtap(69,  902);stommSleep(300)
		stomMultiColorTap("同盟确认",{
		{  200,  652, 0x4a759c},
		{  199,  625, 0x295984},
		{  447,  534, 0xc6ebff},
		{  194,  432, 0x84384a},
	})	
		stomMultiColorTap("关闭同盟",{
		{  609, 1101, 0x8c9ebd},
		{  618,   38, 0xcee7f7},
		{  293,  583, 0x6b4539},
		{  236,  785, 0xa55d94},
	})
	end
	end
	--[[if stomMultiColor("同盟第四行",{
		{  334,  932, 0x392c18},
		{  334,  977, 0xefbe6b},
		{  332, 1006, 0xad924a},
		{  327, 1023, 0x423010},
	}) then
	
	end]]
	if stomMultiColor("学技能",{
		{  427,  969, 0x4abae7},
		{  428,  988, 0x31759c},
		{  418, 1020, 0x42baef},
		{  397,  981, 0xc6d3ce},
	}) then
		if stomMultiColorTap("武将",{
		{   57,  923, 0xbdd3e7},
		{   37,  917, 0x181829},
		{   14,  916, 0xcee7f7},
		{   13,  927, 0xbdcbd6},
		}) then
			stommSleep(300)
			stomtap(396,  337)
			stommSleep(2000)
			stomMultiColorTap("武将技能2",{
			{  382,  798, 0x739ac6},
			{  411,  798, 0x9ccbef},
			{  339,  787, 0x5aba31},
		}) 
			stommSleep(500)
			stomMultiColorTap("学习",{
			{   30,  838, 0x8c5d29},
			{   32,  875, 0xffefbd},
			{   39,  914, 0x734d21},
		}) 
			stommSleep(300)	
		end
	end

	if stomMultiColorTap("解锁技能",{
		{  397,  932, 0xbdd3d6},
		{  394,  979, 0x6b8284},
		{  354,  978, 0x8cbed6},
		{  346,  940, 0xaddbef},
	}) then
		stommSleep(300)	
		stomtap( 45,  762)--技能
		stommSleep(300)	
		stomtap(549,  216)
		stommSleep(300)	
		stomtap( 45,  762)
		stomMultiColorTap("解锁",{
		{   29,  844, 0x8c6129},
		{   31,  864, 0xffefbd},
		{   30,  910, 0x8c5d29},
	})
		stommSleep(300)	
		touchDown(307,  317);    
		stommSleep(60);
		touchMove(409,  413);    
		stommSleep(60);
		touchUp(409,  413);	
		stommSleep(300)	
		stomMultiColorTap("解锁",{
		{  105,  534, 0x846129},
		{  105,  556, 0xffefbd},
		{  104,  597, 0x846131},
		{  557,  559, 0xcee7ef},
	})
	end

	if stomMultiColor("研究技能",{
		{  423,  971, 0x4abaef},
		{  396,  917, 0xdeefef},
		{  377,  905, 0x5a86b5},
		{  354,  905, 0x5282b5},
	}) then
		stommSleep(300)	
		stomtap( 45,  762)--技能
		stommSleep(300)	
		stomMultiColorTap("强击",{
		{  401,  177, 0xefefef},
		{  340,  185, 0xc6efff},
		{  344,  200, 0xceebff},
		{  443,  153, 0x081018},
	})
		stommSleep(300)	
		stomMultiColorTap("研究",{
		{   28,  827, 0x846129},
		{   31,  875, 0xffefb5},
		{   31,  911, 0x8c5d21},
	})
		stommSleep(300)	
		touchDown(443,  625);    
		stommSleep(60);
		touchMove(360,  774);    
		stommSleep(60);
		touchUp(360,  774);
		stommSleep(200);

		touchDown(248,  611);    
		stommSleep(60);
		touchMove(360,  774);    
		stommSleep(60);
		touchUp(360,  774);
		stommSleep(200);
		stomMultiColorTap("确认",{
			{   36,  886, 0x295d8c},
			{   38,  917, 0xb5efff},
			{   38,  956, 0x29598c},
			{  620,  117, 0xceebf7},
		})
	end
	if stomMultiColor("加入同盟4行",{
	{  329,  975, 0xf7c35a},
	{  330,  999, 0xffcf5a},
	{  311,  986, 0x637573},
	{  313, 1008, 0xe7f7ef},
	}) then
	stomMultiColorTap("点击同盟",{
		{   46,  678, 0xdecf94},
		{   42,  679, 0xa57142},
		{   33,  680, 0x3969ad},
		{   57,  691, 0x846d4a},
	})
		stommSleep(300)
		stomtap(89,   46);stommSleep(300)
		stomtap(69,  902);stommSleep(300)
		stomMultiColorTap("同盟确认",{
		{  200,  652, 0x4a759c},
		{  199,  625, 0x295984},
		{  447,  534, 0xc6ebff},
		{  194,  432, 0x84384a},
	})		
		stomtap(166,   42);stommSleep(300)
		stomtap(69,  902);stommSleep(300)
		stomMultiColorTap("同盟确认",{
		{  200,  652, 0x4a759c},
		{  199,  625, 0x295984},
		{  447,  534, 0xc6ebff},
		{  194,  432, 0x84384a},
	})			
		stomtap(252,   46);stommSleep(300)
		stomtap(69,  902);stommSleep(300)
		stomMultiColorTap("同盟确认",{
		{  200,  652, 0x4a759c},
		{  199,  625, 0x295984},
		{  447,  534, 0xc6ebff},
		{  194,  432, 0x84384a},
	})			
		stomtap(332,   45);stommSleep(300)
		stomtap(69,  902);stommSleep(300)
		stomMultiColorTap("同盟确认",{
		{  200,  652, 0x4a759c},
		{  199,  625, 0x295984},
		{  447,  534, 0xc6ebff},
		{  194,  432, 0x84384a},
	})			
		stomtap(413,   45);stommSleep(300)
		stomtap(69,  902);stommSleep(300)
		stomMultiColorTap("同盟确认",{
		{  200,  652, 0x4a759c},
		{  199,  625, 0x295984},
		{  447,  534, 0xc6ebff},
		{  194,  432, 0x84384a},
	})	
		stomMultiColorTap("关闭同盟",{
		{  609, 1101, 0x8c9ebd},
		{  618,   38, 0xcee7f7},
		{  293,  583, 0x6b4539},
		{  236,  785, 0xa55d94},
	})
	end

	stomMultiColorTap("回城",{
		{   63, 1078, 0xa58639},
		{   49, 1078, 0x8c7531},
		{   16, 1078, 0xcee7f7},
		{   14, 1096, 0xc6dfef},
	})
end

function create_1463368792main()    --九州劫
	local tt1 = os.time()
	local time_cha =  math.random(10,15)*60
	local t1 = os.time()
	local t3 = os.time()
	local flag = 0--招募开关
	local loop = 1
	while (true) do
		OpenApp("com.liwei.m2q7")
		if loop==0 then
			loop=JZJ1463368792_fn_zhuxian()
			JZJ1463368792_fn_tanchuang()
			JZJ1463368792_fn_duihua()
			JZJ1463368792_fn_zhengbing2()
			JZJ1463368792_fn_wudaodahui()
			JZJ1463368792_fn_CZ()
			--JZJ1463368792_fn_kongxian()
			--stomLog(flag)
			if flag==0 then
				flag=JZJ1463368792_fn_zhaomu()
			end
		elseif loop==1 then 
			JZJ1463368792_fn_wudaodahui()
			JZJ1463368792_fn_kongxian()
			JZJ1463368792_fn_tanchuang()
			JZJ1463368792_fn_duihua()
			JZJ1463368792_fn_zhengbing2()
			JZJ1463368792_fn_jianzao()
			JZJ1463368792_fn_CZ()
			if flag==0 then
				flag=JZJ1463368792_fn_zhaomu()
			end
		end
		if stomMultiColor("1-4",{
			{  420,  989, 0xc69e5a},
			{  416, 1012, 0xce9e5a},
			{  421, 1029, 0x735d31},
			{  421, 1044, 0xefbe6b},
		}) 
			then 
			flag=0
		end
		t2 = os.time()
		if t2-t1 > 600 then--定时征兵
			--[[if loop==1 then
				JZJ1463368792_fn_renwu2()	
			end]]
			t1 = os.time()
			--zhengbing(1)
			flag=0
			stomLog(flag)
		end
		t4 = os.time()
		if t4-t3 > 60 then--定时征兵
		--	JZJ1463368792_fn_renwu2()
			t3 = os.time()
		end
		
		local tt2 = os.time()
		if os.difftime(tt2,tt1) > time_cha then
			return 0
		end
		--[[i=i+1
		if i>2 then
		
		i=0
		end]]
		--stomLog(loop)
		stommSleep(1500)
	end
end

--function creatTask()
--	stomLog("creatTask...");
--	if apple_bid == "jp.co.school.battletttt" then	--一騎学園
--		status = create_1249610247_test()
--	elseif apple_bid == "com.sanguosha.mjztttt" then	--三国杀名将传
--		status = create_1356464028()
--	elseif apple_bid == "com.liwei.m2q7" then	--九州劫
--		status = create_1463368792_main()



--	end
--	stomLog(apple_bid)
--	return status
--create_1463368792main()

function MXSJ_fn_CZ2()
	if stomMultiColorTap("商城",{
			{  571,  233, 0xffff63},
			{  560,  295, 0x429684},
			{  115,  741, 0x003473},
			{  117,  769, 0xffff63},
			}) or stomMultiColorTap("账号",{
			{  266,  500, 0x319673},
			{  519,  536, 0x525563},
			{  514,  641, 0x8cc7bd},
			{  103,  515, 0x29ba00},
			})then
		duoyi_fn_zhuce()
	end
end	

function MXSJ_fn_CZ()
	if stomMultiColorTap("商城",{
			{  571,  233, 0xffff63},
			{  560,  295, 0x429684},
			{  115,  741, 0x003473},
			{  117,  769, 0xffff63},
		}) or stomMultiColorTap("账号",{
			{  266,  500, 0x319673},
			{  519,  536, 0x525563},
			{  514,  641, 0x8cc7bd},
			{  103,  515, 0x29ba00},
		})then	
		stomtoast("进入充值模式")
		local choice = 0--dialogRet("请选择账号注册模式：", "自动", "手动", "", 5);
		stommSleep(300)
		local loop=0
		local flag=0
		local getloop = 0
		local num = 0
		local m = math.random(6,12) 
		local mima = myRand(3,m,2)
		local yanzhenma
		local fa = 0
		local messgwait =4000
		getPhoneType = "lx"
		docks = "1112"
		while (true) do
			--_mxdiaoyong()
			stomMultiColorTap("多益注册账号",{
				{  215,  430, 0x318aff},
				{  217,  444, 0x318aff},
				{  291,  511, 0x1086f7},
				{  444,  320, 0xd60010},
			})		
			if loop==0 then
				if choice==0 or choice==3 then
						stomLog("当前阶段。。。"..getloop)
						if getloop == 0 then	
							if num <= 8 then
								check_Rules = 1
								Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
							else	
							end
							if Telnum then
								stomLog(Telnum)
								getloop = 1
								num = 0
							else
								stomLog("重新获取号码中")
								stommSleep(2000)
								num = num + 1
							end
							--[[if num > 20 then
								stomLog("获取号码失败")
								stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
								stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
							end]]
						elseif getloop == 1 then
							phonenumber = Telnum
							if stomMultiColor("在注册界面",{
								{  535,  369, 0xefebe7},
								{  466,  710, 0x1086f7},
								{  537,  534, 0x000000},
								{  466,  647, 0xffffff},
							}) then 
								stomMultiColorTap("多益注册主界面点手机号",{
									{  473,  423, 0xb5aead},
									{  468,  435, 0xffffff},
									{  151,  488, 0x108af7},
									{  158,  643, 0x108aff},
								})
								if stomMultiColor("多益输入手机号",{
									{  467,  427, 0xffffff},
									{  468,  449, 0xffffff},
									{  463,  502, 0xffffff},
									{  470,  657, 0xffffff},
								}) then
									stommSleep(500) 
									stomInpuText(phonenumber)
									getloop=2
									stommSleep(500) 
								end
							end
						elseif getloop == 2 then
							if stomMultiColorTap("多益输手机号已填写关闭键盘",{
								{  541,  401, 0xefebe7},
								{  470,  653, 0x949694},
								{  470,  670, 0x949294},
								{  461,  661, 0x9c9694},
							}) then
								stommSleep(500)
								stomMultiColorTap("多益获取验证码",{
									{  461,  716, 0x108af7},
									{  485,  759, 0x1086f7},
									{  534,  659, 0xe7efef},
									{  458,  801, 0x108aff},
								})
							end
							stomMultiColorTap("多益输点击密码框",{
								{  312,  435, 0xffffff},
								{  311,  441, 0xadaead},
								{  313,  485, 0x84827b},
								{  309,  519, 0x9c9694},
							})					
							if stomMultiColor("多益输密码未输入",{
								{  420,  418, 0xffffff},
								{  420,  448, 0xffffff},
								{  414,  359, 0x605e5d},
								{  418,  385, 0x797b7c},
							}) or stomMultiColor("多益输密码未输入粗体",{
								{  423,  422, 0xffffff},
								{  424,  446, 0xffffff},
								{  424,  472, 0xffffff},
								{  415,  359, 0x8f8f92},
								{  436,  387, 0xaaa9a7},
							}) 
							then
								stommSleep(500)
								stomInpuText(mima)
								stommSleep(500)
							end
							if stomMultiColorTap("多益密码已输入关闭键盘",{
								{  350,  332, 0xf7f7f7},
								{  419,  419, 0x000000},
								{  420,  433, 0x000000},
								{  420,  447, 0x000000},
								{  500,  457, 0x9f9ea2},
							}) then
								getloop=3
							end
							stomMultiColorTap("多益密码已输入关闭键盘粗",{
								{  423,  319, 0xffffff},
								{  426,  423, 0x000000},
								{  428,  376, 0x000000},
								{  424,  471, 0x000000},
							}) 	
							if stomMultiColor("多益密码手机密码都输入",{
								{  474,  418, 0x000000},
								{  312,  423, 0x000000},
								{  310,  445, 0x000000},
								{  315,  468, 0x000000},
								{  538,  396, 0xefebef},
							}) then
								getloop=3
							end							
						elseif getloop == 3 then
							stomLog("获取短信..."..fa)
							messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
							stomMultiColorTap("多益密码已输入关闭键盘",{
								{  350,  332, 0xf7f7f7},
								{  419,  419, 0x000000},
								{  420,  433, 0x000000},
								{  420,  447, 0x000000},
								{  500,  457, 0x9f9ea2},
							})
							if messg then
								messgwait=300
								stomMultiColorTap("多益验证码开始输入",{
								{  391,  419, 0xffffff},
								{  388,  442, 0x848284},
								{  389,  457, 0xa59e9c},
								{  393,  495, 0xc6c3bd},
							})					
								--messg = string.gsub(messg,"30分","")
								--messg = string.sub(messg,9)
								yanzhenma = string.match(messg,"%d+")
								stomLog("yanzhenmaOK-"..yanzhenma)
								stomtoast(yanzhenma)
								getloop =5
								if stomMultiColor("多益验证码输入界面",{
									{  487,  331, 0x010101},
									{  498,  364, 0xbfc0bf},
									{  489,  427, 0xffffff},
									{  408,  420, 0x000000},
								}) or stomMultiColor("多益验证码输入界面B",{
									{  424,  420, 0xffffff},
									{  423,  329, 0x191a1a},
									{  428,  340, 0x9a949a},
									{  423,  364, 0x4a4d4a},  
								}) then
									stommSleep(300)
									stomInpuText(yanzhenma)
									stommSleep(100)			
									stomtap(413,  320) 
								end
								stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
								stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
							else
								stomtoast("getMegNo."..fa)
								stomLog("get sms")
								fa = fa +1
							end	
							if fa > 10 then
								stomLog("获取短信失败")
								stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
								stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
								getloop = 4
							end
							stommSleep(messgwait)
						elseif getloop == 6 then
								stomMultiColorTap("多益验证码开始输入",{
									{  391,  419, 0xffffff},
									{  388,  442, 0x848284},
									{  389,  457, 0xa59e9c},
									{  393,  495, 0xc6c3bd},
								})
								stomMultiColorTap("多益验证码开始输入粗",{
									{  389,  435, 0xffffff},
									{  392,  425, 0x8c9294},
									{  392,  439, 0x848684},
									{  394,  470, 0x848284},
								})
								if stomMultiColorTap("多益注册账号",{
									{  215,  430, 0x318aff},
									{  217,  444, 0x318aff},
									{  291,  511, 0x1086f7},
									{  444,  320, 0xd60010},
								}) then
									getloop=0
									fa = 0								
								end
								if stomMultiColor("多益验证码输入界面",{
									{  487,  331, 0x010101},
									{  498,  364, 0xbfc0bf},
									{  489,  427, 0xffffff},
									{  408,  420, 0x000000},
								}) or stomMultiColor("多益验证码输入界面粗",{
									{  485,  424, 0xffffff},
									{  622,  373, 0xe8efef},
									{  490,  330, 0x030303},
									{  499,  363, 0x0b0b0b},
								}) then
									stommSleep(300)
									stomInpuText(yanzhenma)
									stommSleep(300)			
									stomtap(413,  320) 
									getloop =5
								end
						elseif getloop == 4 then
							stomMultiColorTap("多益取消验证码输入",{
								{  475,  303, 0xffffff},
								{  487,  330, 0x080808},
								{  492,  339, 0x8c9294},
								{  498,  365, 0xbfc0bf},
							})
							stomMultiColorTap("返回",{
								{  536,  300, 0x848684},
								{  528,  306, 0x848684},
								{  544,  305, 0x84868c},
							})
							if stomMultiColorTap("多益注册账号",{
								{  215,  430, 0x318aff},
								{  217,  444, 0x318aff},
								{  291,  511, 0x1086f7},
								{  444,  320, 0xd60010},
							}) then
								getloop=0
								fa = 0								
							end
							if stomMultiColor("多益注册界面返回getloop0",{
								{  529,  534, 0x000000},
								{  254,  532, 0xf7f7f7},
								{  486,  707, 0x108aff},
								{  157,  647, 0x1086f7},
							}) then
								getloop=0
								fa = 0
							end							
						elseif getloop == 5 then
							if stomMultiColor("验证码未输入",{
								{  391,  425, 0x9c9a94},
								{  401,  426, 0x7b8284},
								{  391,  441, 0x84827b},
								{  400,  495, 0x7b8284},
							}) then
								stommSleep(500)
								stomtap(392,  458)
								stommSleep(500)
								stomInpuText(yanzhenma)
								stommSleep(500)
								stomtap(532,  151)								
							elseif stomMultiColor("立即注册",{
								{  161,  541, 0xffffff},
								{  161,  591, 0xffffff},
								{  161,  476, 0x108af7},
								{  156,  650, 0x1086f7},
								{  174,  570, 0x1086f7},
							}) then
								stommSleep(3000)
								stomtap(160,  547)
								stommSleep(3000)
								if stomMultiColor("绑定成功",{
									{  363,  402, 0x63ba63},
									{  368,  597, 0x000000},
									{  370,  648, 0x4a494a},
									{  542,  556, 0x9c9a9c},
								})	or stomMultiColor("绑定成功C",{
									{  363,  402, 0x63ba63},
									{  368,  597, 0x000000},
									{  370,  648, 0x4a494a},
									{  542,  556, 0x9c9a9c},
								})	or stomMultiColor("绑定成功B",{
									{  314,  413, 0x63ba63},
									{  535,  530, 0x000000},
									{  538,  831, 0x84868c},
									{   90,  531, 0xf7f7f7},
								})	then
									stomLog("绑定成功");stommSleep(3000)
									getloop = 99
								else getloop =4 
									stomLog("绑定失败")
								end
							end
						end
				end
				if stomMultiColor("绑定成功",{
					{  363,  402, 0x63ba63},
					{  368,  597, 0x000000},
					{  370,  648, 0x4a494a},
					{  542,  556, 0x9c9a9c},
				})	or stomMultiColor("绑定成功C",{
					{  363,  402, 0x63ba63},
					{  368,  597, 0x000000},
					{  370,  648, 0x4a494a},
					{  542,  556, 0x9c9a9c},
				})	or stomMultiColor("绑定成功B",{
					{  314,  413, 0x63ba63},
					{  535,  530, 0x000000},
					{  538,  831, 0x84868c},
					{   90,  531, 0xf7f7f7},
				})	
					then
					stomopenURL("prefs:root=STORE");
					loop=1
				end
				--[[if flag==0 then
					if stomMultiColor("已登录",{
						{   39,  332, 0x000000},
						{   76,   92, 0x007aff},
						{  105,  330, 0x060606},
						{  202,  331, 0xffffff},
					}) then
						stommSleep(300)
						local user = dialogRet("是否注销", "是", "否", "", 5);
						flag=1
						stommSleep(4000)
						if user==0 or user==3 then
						stomtap(250,250)
						elseif user==1 then
						OpenApp("com.hero.m2mx")					
						loop=1					
						end
					end
				end]]
				stomMultiColorTap("注销",{
					{  307,  610, 0x007aff},
					{  327,  604, 0x007aff},
					{  132,  375, 0xf7f7f7},
					{  279,  367, 0x000000},
				})	
				if stomMultiColor("未登录",{
					{   38,  237, 0x027bff},
					{   72,  244, 0x0f81ff},
					{  138,   84, 0x000000},
					{  271,  433, 0xffffff},
				})then
					OpenApp("com.hero.m2mx")					
					loop=1
				end
				-- 切换至游戏内充值界面
			elseif loop==1 then
				shopapplestore()
					stomMultiColorTap("单行密码已输入确认",{
						{  461,  489, 0x007aff},
						{   98,  397, 0x000000},
						{  114,  397, 0x000000},
						{  474,  305, 0x606668},
						{  192,  217, 0x000000},
					})
					stomMultiColorTap("无法连接IT横粗",{
						{  252,  559, 0x007aff},
						{  367,  393, 0x000000},
						{  373,  471, 0x8c999c},
						{  364,  578, 0xb7c2c7},
					})
					stomMultiColorTap("使用现有B",{
						{  343,  503, 0x007aff},
						{  249,  454, 0x007aff},
						{  173,  548, 0x007aff},
						{  466,  545, 0x242526},
					})
					stomMultiColorTap("设置纵粗",{
						{  444,  668, 0x007aff},
						{  428,  667, 0x007aff},
						{  224,  476, 0x000000},
						{  157,  667, 0x007aff},
						{  462,  562, 0x000000},
					})
				stomMultiColorTap("网络异常重登",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("无法连接IT纵粗",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				if stomMultiColor("纵向请输入M粗",{
					{  100,  396, 0xc7c7cd},
					{  200,  225, 0x000000},
					{  264,  232, 0x515151},
					{  462,  489, 0x007aff},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(500)
					stomMultiColorTap("登录",{
					{  462,  489, 0x007aff},
					{  100,  396, 0xc7c7cd},
					{  200,  225, 0x000000},
					{  264,  232, 0x515151},
				})
				end			
				stomMultiColorTap("验证失败再次粗",{
					{  652,  403, 0x007aff},
					{  510,  252, 0x000000},
					{  585,  251, 0x000000},
					{  763,  303, 0xd8dcda},
				})
				stomMultiColorTap("确认购买纵粗？？",{
					{  425,  666, 0x007aff},
					{  166,  483, 0x000000},
					{  422,  483, 0x616161},
					{  554,  678, 0xf9f9f9},
				})					
			stomMultiColorTap("使用现有",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("使用现有纵",{
					{  277,  537, 0x007aff},
					{  305,  430, 0x000000},
					{  334,  429, 0x595d5d},
					{  473,  635, 0xced2d2},
				})				
				if stomMultiColor("登录换行",{
					{   38,  968, 0x363737},
					{  581,  444, 0x4b4d4f},
					{  581,  481, 0x000000},
					{  437,  413, 0x007aff},
				})	then
					stommSleep(500)	
					stomMultiColorTap("登录换行",{
					{   38,  968, 0x363737},
					{  581,  444, 0x4b4d4f},
					{  581,  481, 0x000000},
					{  437,  413, 0x007aff},
				})	
					stommSleep(500)	
					if stomMultiColor("输入txt",{
						{  491,  348, 0xc7c7cd},
						{  485,  396, 0xffffff},
						{  270,  377, 0x605f60},
						{  365,  412, 0x007aff},
					})	then
						stomInpuText(applePWD)
						stommSleep(300)
						stomMultiColorTap("点击上行",{
							{  550,  688, 0xffffff},
							{  488,  688, 0xffffff},
							{  338,  518, 0xccced1},
						})		
						--复制 @163.com
					end
				end
				if stomMultiColor("登录换行纵向",{
					{  191,  196, 0x000000},
					{  232,  203, 0x585c5b},
					{  362,  292, 0xffffff},
					{  100,  345, 0xc7c7cd},
				}) or stomMultiColor("登录换行纵向B",{
					{   93,  321, 0xd0dafc},
					{  195,  232, 0x000000},
					{  175,  384, 0xffffff},
					{  106,  332, 0xffffff},
					{  262,  244, 0x000000},
				})  	then
					stommSleep(500)
					stomMultiColorTap("换行",{
					{  597, 1079, 0x353535},
					{  232,  203, 0x585c5b},
					{  362,  292, 0xffffff},
					{  100,  345, 0xc7c7cd},
				})
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(300)
					stomMultiColorTap("点击上行",{
						{  369,  298, 0xffffff},
						{  232,  203, 0x585c5b},
						{  362,  292, 0xffffff},
						{  100,  345, 0xc7c7cd},
					})		
						--复制 @163.com
				end
				stomMultiColorTap("设置",{
					{  217,  676, 0x007aff},
					{  401,  550, 0x636566},
					{  400,  579, 0x000000},
					{  405,  644, 0x000000},
				})	
				stomMultiColorTap("设置纵向",{
					{  472,  663, 0x007aff},
					{  375,  664, 0xccd0d1},
					{  221,  484, 0x000000},
					{  273,  488, 0x666869},
				})	
				stomMultiColorTap("15分钟后需要",{
					{  357,  705, 0x007aff},
					{  409,  704, 0x56a5fd},
					{  466,  704, 0x007aff},
					{  362,  448, 0x000000},
				})	
				if stomMultiColor("请输入M",{
					{  548,  493, 0x000000},
					{  427,  406, 0xffffff},
					{  425,  352, 0xcdcdd3},
					{  500,  715, 0x000000},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(500)
					stomMultiColorTap("登录",{
						{  367,  710, 0x007aff},
						{  367,  613, 0xcdd6dd},
						{  294,  600, 0x606669},
						{  519,  715, 0x000000},
					})
				end
				if stomMultiColor("纵向请输入M",{
						{  196,  225, 0x000000},
						{  465,  315, 0x1d1e1e},
						{  100,  396, 0xc7c7cd},
						{  101,  431, 0xcacccc},
					})then
				--[[纵向请输入M2{
					{  198,  225, 0x000000},
					{  461,  314, 0x000000},
					{   93,  395, 0x426bf2},
					{  123,  434, 0xf8f8f8},
				}--]]
					stomInpuText(applePWD)
					stommSleep(500)
					stomMultiColorTap("登录",{
						{  450,  486, 0x007aff},
						{  144,  435, 0xf8f8f8},
						{  198,  225, 0x000000},
						{  495,  314, 0x222222},
					})
				end
				stomMultiColorTap("无法连接IT",{
					{  437,  628, 0x007aff},
					{  472,  626, 0xabd1fb},
					{  146,  521, 0x000000},
					{  222,  531, 0x8f8f8f},
				})
				if stomMultiColorTap("购买完成",{
					{  548,  493, 0x000000},
					{  427,  406, 0xffffff},
					{  425,  352, 0xcdcdd3},
					{  500,  715, 0x000000},
				}) or stomMultiColorTap("购买完成B",{
					{  309,  644, 0x007aff},
					{  259,  491, 0x000000},
					{  411,  553, 0x000000},
					{  517,  556, 0xf9f9f9},
				})then
					stommSleep(500)					
					OpenApp("com.hero.m2mx")
				--else stomLog("notfound")
				end			

			end
				if stomMultiColor("创建组队",{
					{  560,  245, 0xffff6b},
					{  571,  274, 0x08387b},
					{  508,  543, 0x08a2ad},
					{   48,  807, 0x8cc3b5},
				}) or stomMultiColor("创建组队",{
					{  501,  369, 0x843818},
					{  502,  390, 0xfffb84},
					{   96,  873, 0x00347b},
					{  281,  960, 0x10a2a5},
				}) or stomMultiColor("短信",{
					{  278,   80, 0x000000},
					{  324,   77, 0x535353},
					{  383,  162, 0xf9f9f9},
					{  581,   88, 0x007aff},
				})then
					stomMultiColor("关闭宠物",{
					{  607,  996, 0xf76910},
					{  318,  643, 0x527d7b},
					{  147,  522, 0x39ae84},
					{  494,  177, 0x8cdfd6},
				})
					stommSleep(1000)
					stomMultiColor("个人属性关闭",{
						{  599,  997, 0xadf3ef},
						{  545,  566, 0x4aa6ef},
						{  392,  544, 0xde6984},
						{   82,  654, 0xe7c331},
					})
					stomtoast("充值流程结束")
						--购买升级所需物品
					break
				end	
				stomMultiColorTap("实名认证",{
						{  175,  511, 0xad1010},
						{  185,  583, 0xffff63},
						{  173,  622, 0xa51010},
						{  532,  520, 0xefb631},
					})
				if	stomMultiColorTap("请输入姓名",{
					{  307,  441, 0x84827b},
					{  305,  462, 0x7b8284},
					{  307,  486, 0x848284},
					{  300,  503, 0x7b8284},
				}) then
					nicheng = ZKQ_Word(zhangkq["姓氏"],1,1)..ZKQ_Word(zhangkq["名字"],2,3)
					stommSleep(999)
					stomInpuText(nicheng)
					stommSleep(999)
					stomtap(552,  173)
				elseif	stomMultiColorTap("请输入身份证",{
					{  228,  441, 0x84868c},
					{  225,  456, 0x848284},
					{  221,  472, 0x9c9a9c},
					{  222,  561, 0x7b8284},
				}) then
					stommSleep(999)
					stomInpuText("440282195610226964")
					stommSleep(999)
					stomtap(552,  173)
				else stomMultiColorTap("确认",{
					{  132,  568, 0x1086f7},
					{  122,  511, 0x108aff},
					{  128,  611, 0x108aff},
					{  132,  583, 0xffffff},
				}) 
				end	
				stomMultiColorTap("实名确认",{
					{  245,  690, 0x108af7},
					{  250,  646, 0x1086f7},
					{  249,  725, 0x1086f7},
					{  245,  487, 0x1086f7},
				})
			--stomLog(loop)
			stommSleep(300)
		end
	end
end


function LY1478720553_fn_tankuang()
	stomMultiColorTap("提示确定",{
		{  237,  599, 0x4c6467},
		{  430,  549, 0xffffff},
		{  427,  560, 0xe0e1e1},
		--请求服务器{  357,  522, 0xffffff},
	})	
	stomMultiColorTap("进入游戏",{
	{  129,  519, 0xffffff},
	{  127,  530, 0xd3d6d7},
	{  137,  576, 0x969797},
	{  158,  594, 0x93b9bf},
})
	stomMultiColorTap("公告",{
		{  515,  923, 0xc2e0d6},
		{  308,  213, 0xffffff},
		{  301,  213, 0xd2d2d2},
	})
	stomMultiColorTap("进入广告1",{
		{  516,  937, 0xc2e0d6},
		{  541,  933, 0x323130},
		{   86,  929, 0x7e6a51},
	})
	stomMultiColorTap("充值界面",{
		{  506, 1017, 0xe2cbbb},
		{  532,  596, 0xffffff},
		{  534,  645, 0xffffff},
	})
	stomMultiColorTap("跳过弹窗",{
		{  219,  653, 0xc7c6c3},
		{  232,  687, 0x837551},
		{  331,  569, 0x808081},
	})
	stomMultiColorTap("猎犬主力关闭",{
		{  512,  878, 0xd8d3c0},
		{  516,  514, 0x818181},
		{  518,  541, 0x9e9f9f},
		{  508,  567, 0xffffff},
	})
	if stomMultiColorTap("荆轲来袭",{
		{  146,  723, 0xe8e7e4},
		{  154,  751, 0x312b1d},
		{  142,  750, 0xd5d4d1},
	}) then
		return 1
	end
	for var= 1, 10 do
		if 
		stomMultiColorTap("对话 点击继续",{
			{   20,  964, 0xd7d6d6},
			{   26,  989, 0xf6f5f5},
			{   25, 1009, 0x756a6a},
			{   19, 1032, 0xd2cfcf},
		}) or
		stomMultiColorTap("对话 带箭头",{
			{   20,  966, 0xd7d6d6},
			{   25,  987, 0x766a6a},
			{   14, 1014, 0x9f9d9d},
			{   17, 1050, 0xffb200},
		}) then
			stommSleep(30)
		end
			-- body
	end
	stomMultiColorTap("关闭资源使用",{
		{  538,  929, 0xcccbc0},
		{  537,  532, 0x5e6767},
		{  547,  539, 0xb1b6b6},
		{  549,  559, 0x596363},
	})
	stomMultiColorTap("跳过右下角",{
		{   47, 1067, 0xffffff},
		{   52, 1079, 0xffffff},
		{   40, 1099, 0xe1e3e5},
		{   48, 1112, 0x616565},
	})
	stomMultiColorTap("开服冲榜",{
		{  587,  997, 0xe1d9c0},
		{  555,  151, 0xf9e7b5},
		{  558,  204, 0xfdf4c1},
	})
	stomMultiColorTap("关闭充值",{
		{  611, 1108, 0xe1d9c0},
		{  618, 1101, 0xe1d9c0},
		{  618,  182, 0xdedfdf},
		{  609,  212, 0xffffff},
	})

	stomMultiColorTap("跳过 白色",{
		{  257,  361, 0xe6e7d9},
		{  358,  520, 0x898982},
		{  358,  576, 0x000000},
		{  358,  607, 0x5e5e59},
	})

	stomMultiColorTap("关闭在线奖励",{
		{  547,  679, 0xe1d9c0},
		{  120,  535, 0x536b6d},
		{  436,  556, 0xffffff},
	})
	stomMultiColorTap("关闭抽奖",{
		{  617, 1102, 0xe1d9c0},
		{  606, 1114, 0xcccbc0},
		{   72,  384, 0x495d60},
		{   71,  309, 0x495d60},
	})
	stomMultiColorTap("在线等待",{
		{  547,  679, 0xe1d9c0},
		{  121,  502, 0x8c8c8c},
		{  117,  613, 0x666666},
	})
	--[[stomMultiColorTap("关闭抽奖2",{
		{  611, 1108, 0xe1d9c0},
		{  605, 1115, 0xd6d4b4},
		{   86,  659, 0x44565a},
		{   81,  754, 0x3a4a4c},
	})]]
	stomMultiColorTap("最强礼包",{
		{  522, 1032, 0xd7d2c0},
		{  537,  487, 0xe6624e},
		{  539,  534, 0xfeffff},
	})
	--[[stomMultiColorTap("放弃",{
		{  224,  449, 0xffffff},
		{  227,  452, 0x989898},
		{  215,  482, 0x7f8181},
		{  231,  519, 0x536b6d},
	})]]
	stomMultiColorTap("关闭升级！！",{
		{  520,  926, 0xd9d4c0},
		{  520,  906, 0xbcb6a1},
		{  136,  708, 0x49666b},
	})
	--[[if stomMultiColor("领取任务任务1",{
		{  304,  205, 0x55a955},
		{  334,   83, 0x4be944},
		{  330,  101, 0x2f6730},
		{  330,   52, 0x4def45},
	}) then
		stomtap(281,  582)
		if stomMultiColorTap("领取任务任务1",{
			{  316,  466, 0xc3d4da},
			{  294,  466, 0xa6c0c7},
		}) then
		stommSleep(100)
		end
	end--]]
	stomMultiColorTap("城外!!",{
	{   55, 1072, 0x1d211e},
	{   11, 1096, 0x2cb6ff},
})
	stomMultiColorTap("出征",{
		{   92,  958, 0x69634d},
		{  108,  948, 0xc0bfbe},
		{  101,  964, 0xc3c1bd},
		{  109,  972, 0xc6c6c3},
	})	
	stomMultiColorTap("搜索",{
		{  241, 1065, 0xffffff},
		{  249, 1065, 0x101110},
		{  265, 1075, 0x9ebbc7},
	})
	stomMultiColorTap("确定搜索",{
		{  153,  556, 0x0f1718},
		{  154,  561, 0xffffff},
		{  157,  577, 0xbbc0c1},
	})
	stomMultiColorTap("攻击",{
		{  154,  792, 0xa79f8c},
		{  158,  802, 0xdedbd3},
		{  150,  813, 0x625940},
	})
	stomMultiColorTap("升级队列弹窗",{
		{  557,  808, 0xdcd6c0},
		{  558,  531, 0xffffff},
		{  551,  540, 0x5a5b5b},
	})
	stomMultiColorTap("回城",{
		{   48, 1060, 0xffffff},
		{   56, 1057, 0x959896},
		{   64, 1089, 0xcacaca},
	})
	return 0
end

function LY1478720553_fn_do()

	stomMultiColorTap("征兵",{
		{   39,  674, 0x8e8f8f},
		{   47,  676, 0xffffff},
		{   51,  687, 0xd6dcdd},
		{   43,  694, 0x5e6162},
	})
	if stomMultiColor("建造do",{
		{  151,  681, 0x4a5f61},
		{  147,  706, 0xe6e7e7},
		{  149,  724, 0x616b6d},
		{  446,  664, 0x2f3d3e},
	})then
		if 	stomMultiColorTap("第二行條件限制",{
			{  193,  764, 0xfaeed6},
			{  193,  755, 0x4d646c},
			{  182,  769, 0x43555a},
		})then
		elseif 	stomMultiColorTap("木头不足",{
			{  327,  765, 0x4ce845},
			{  318,  763, 0x4def45},
			{  318,  789, 0x4def45},
			{  318,  816, 0x4def45},
		})then
		else stomMultiColorTap("建造",{
		{  151,  681, 0x4a5f61},
		{  147,  706, 0xe6e7e7},
		{  149,  724, 0x616b6d},
		{  446,  664, 0x2f3d3e},
		})
		end
	end
	if stomMultiColor("在资源使用界面",{
		{  547,  539, 0xb1b6b6},
		{  541,  553, 0xffffff},
		{  545,  585, 0x686b6b},
		{  566,  587, 0x4d4d4d},
	})then
		stomMultiColorTap("免费",{
			{  231,  862, 0x8e8e8e},
			{  224,  866, 0xffffff},
			{  235,  879, 0xabadad},
		})
			stommSleep(500)
			touchDown( 72,  628)
			for i = 0, 500, 50 do
				touchMove(72+i,500)
				stommSleep(70)
			end
			touchUp(572,628)
			stommSleep(2000)
				for var= 1, 10 do
				stomMultiColorTap("小包",{
					{  368,  837, 0x44565a},
					{  374,  864, 0x5a6769},
					{  370,  885, 0xffffff},
				})		
				stomMultiColorTap("普通包",{
					{  257,  836, 0x44565a},
					{  263,  864, 0x5a6769},
					{  261,  885, 0xffffff},
				})			
				end	
		end
	stomMultiColorTap("继续升级",{
		{  158,  681, 0x565a5b},
		{  162,  702, 0xefefef},
		{  160,  717, 0xdaddde},
		{  172,  740, 0x597274},
	})
end

function LY1478720553_fn_zhuxian(flag)
	if stomMultiColor("1步兵营",{
		{  333,   83, 0x848588},
		{  329,  102, 0xf1f1f1},
		{  334,  120, 0x6a7075},
		{  333,   52, 0xffffff},
	}) then
		stomtap(278,  573)
		stommSleep(300)
	end
	stomMultiColorTap("建造",{
	{   71,  729, 0xcdcfd0},
	{   68,  751, 0x52585a},
	{   59,  751, 0xcccdcd},
})
	stomMultiColorTap("免费",{
	{  373,  561, 0xd2d7db},
	{  375,  579, 0x616d65},
	{  373,  581, 0xffffff},
})
	stomMultiColorTap("进入游戏",{
		{  515,  923, 0xc2e0d6},
		{  308,  213, 0xffffff},
		{  301,  213, 0xd2d2d2},
	})
	if flag<2 then
	if stomMultiColorTap("二次先锋",{
		{  548,  701, 0xb66f46},
		{  539,  688, 0x8b8987},
		{  518,  701, 0xf50609},
	})then
		return 1
	else return 0
	end
	end
return 0
end

function LY1478720553_fn_zhuxian2()
	stomMultiColorTap("领取奖励",{
		{  307,  204, 0x66ab5c},
		{  300,  204, 0x55a955},
	})
	stomMultiColorTap("免费建造",{
		{  350,  552, 0xffffff},
		{  348,  562, 0x8d9a9f},
		{  346,  578, 0xffffff},
		{  344,  583, 0xcacdc6},
	})
	if stomMultiColorTap("建造任务",{
		{  339,   14, 0xa5abad},
		{  334,   22, 0xffffff},
		{  333,   41, 0x3d4047},
		{  324,   41, 0x5e6066},
	}) then
		stommSleep(300)
		stomMultiColorTap("升级操作",{
			{  290,  665, 0x8faeb5},
			{  293,  685, 0xbacdd4},
			{  271,  697, 0x445f63},
		}) 
	end
	stomMultiColorTap("弹窗升级！！",{
		{  130,  725, 0xe0e3e3},
		{  130,  727, 0x243032},
		{  134,  749, 0xb4bbbc},
	})
	stomMultiColorTap("建造！！",{
		{   72,  729, 0x859092},
		{   59,  735, 0xd4d5d5},
		{   68,  752, 0x515859},
	})
	stomMultiColorTap("2.3",{
		{  385,  543, 0xffeecc},
		{  390,  543, 0xffeeda},
		{  366,  563, 0xeedda7},
	})
	stomMultiColorTap("挑战",{
		{   68,  857, 0xd09a59},
		{   68,  897, 0xdcdbda},
		{   69,  909, 0xffffff},
	})
	if stomMultiColorTap("关闭战斗结束",{
		{  189,  953, 0xafaea6},
		{  189,  968, 0xf7f7f6},
		{  190,  967, 0x858172},
	}) then
		stommSleep(300)
	end
	stomMultiColorTap("2.4",{
		{  225,  749, 0xffeecd},
		{  219,  752, 0xffeed7},
		{  210,  760, 0xfff2d2},
	})
	stomMultiColorTap("2.5",{
		{  388,  745, 0xfffdec},
		{  380,  747, 0xffeed7},
		{  374,  753, 0xfeeec6},
	})
	stomMultiColorTap("2.6",{
		{  469,  846, 0xeedd95},
		{  476,  838, 0xeeddac},
		{  484,  830, 0xf5e9bd},
	})
	stomMultiColorTap("建造",{
		{  154,  703, 0x767f7f},
		{  141,  708, 0xa7acad},
		{  149,  724, 0x616b6d},
		{  141,  727, 0xbec1c2},
	})
	stomMultiColorTap("升级",{
		{  298,  661, 0x77969a},
		{  309,  661, 0x8faeb5},
		{  324,  661, 0xb9ccd3},
	})
	stomMultiColorTap("武將升级",{
		{   40,  736, 0x495d60},
		{   36,  768, 0x888b8b},
		{   34,  793, 0xffffff},
		{   55,  843, 0x991111},
	})
	--[[stomMultiColorTap("关闭战场",{
		{  611, 1108, 0xe1d9c0},
		{  609,  546, 0xffffff},
		{  619,  559, 0xffffff},
		{  620,  582, 0x9e9e9e},
	})]]

	stomMultiColorTap("打开第一张",{
		{  423,  151, 0x773300},
		{  399,  153, 0xeeeedd},
		{  385,  255, 0xeeeeee},
		{  384,  360, 0xeeeeee},
	})




	stomMultiColorTap("打开第一张",{
		{  423,  151, 0x773300},
		{  399,  153, 0xeeeedd},
		{  385,  255, 0xeeeeee},
		{  384,  360, 0xeeeeee},
	})
	
	
	if stomMultiColorTap("有主线做主线",{
		{  308,  188, 0x222222},
		{  359,   65, 0xdde2f1},
		{  300,  188, 0x222222},
	})	then
		stommSleep(400)
	end
end

function LY1478720553_fn_zhuxian3()
	stomMultiColorTap("点大锤",{
		{  238,   33, 0x0e1012},
		{  205,   53, 0xffffff},
		{  253,   37, 0x685241},
	})	
	stomMultiColorTap("mf1",{
		{  454,  884, 0x384749},
		{  454,  902, 0xffffff},
		{  454,  930, 0x242f31},
	})	
	stomMultiColorTap("mf2",{
		{  346,  884, 0x364546},
		{  347,  902, 0xffffff},
		{  347,  932, 0x203033},
	})			
	stomMultiColorTap("mf3",{
		{  247,  903, 0x294145},
		{  239,  902, 0xffffff},
		{  227,  902, 0x253234},
	})	
	stomMultiColorTap("mf4",{
		{  137,  882, 0x3a5055},
		{  137,  904, 0x2a3c3e},
		{  140,  916, 0xffffff},
	})	
	stomMultiColorTap("jz1",{
		{  459,  905, 0xfefcdd},
		{  454,  885, 0x658955},
		{  454,  922, 0x658955},
	})	
	stomMultiColorTap("jz2",{
		{  350,  904, 0xfefcda},
		{  348,  885, 0x658955},
		{  348,  922, 0x658955},
	})

	stomMultiColorTap("jz3",{
		{  240,  888, 0x658955},
		{  240,  904, 0xfefcd5},
		{  240,  917, 0x6b7c57},
	})	
	stomMultiColorTap("jz4",{
		{  131,  891, 0x72825c},
		{  135,  904, 0xfefcd9},
		{  133,  922, 0x658955},
	})
	stommSleep(200)

	stomMultiColorTap("取消不建造",{
		{  223,  502, 0x495d60},
		{  427,  521, 0x494c4e},
		{  428,  528, 0xffffff},
		{  429,  556, 0x66696b},
	})	
	stomMultiColorTap("zs1",{
		{  454,  910, 0xf8f2d2},
		{  432,  910, 0xcab084},
		{  473,  910, 0xdcc99c},
	})	
	stomMultiColorTap("立即完成",{
		{  335,  805, 0x3f5052},
		{  359,  803, 0x399edf},
		{  336,  845, 0x404f50},
	})
	stomMultiColorTap("不再提醒",{
		{  221,  624, 0x6e6041},
		{  220,  707, 0x5f5a45},
		{  279,  523, 0x659f5a},
		{  286,  645, 0x464646},
	})	
	stomMultiColorTap("点大锤",{
		{  238,   33, 0x0e1012},
		{  205,   53, 0xffffff},
		{  253,   37, 0x685241},
	})	
	stomMultiColorTap("点大锤",{
		{  238,   33, 0x0e1012},
		{  205,   53, 0xffffff},
		{  253,   37, 0x685241},
	})	
	
end	

function LY1478720553_fn_login()
	if	stomMultiColorTap("随机姓名",{
		{  221,  964, 0x221100},
		{  234,  958, 0xffffff},
		{  205,  964, 0xd1a15a},
	})then
		stommSleep(300)
	end
	stomMultiColorTap("账号注册",{
		{  433,  474, 0x49d2fb},
		{  436,  524, 0xffffff},
		{  288,  632, 0xffc154},
	})
	stomMultiColorTap("关闭键盘",{
		{  386,  545, 0xf86aff},
		{  364,  532, 0xffffff},
		{  518,  749, 0x49d2fb},
	})
	stomMultiColorTap("一键登录",{
		{   32,  548, 0x64c4e1},
		{   30,  568, 0x60c5e4},
		{   79,  593, 0xf86aff},
	})
	stomMultiColorTap("账号注册",{
		{  433,  474, 0x49d2fb},
		{  436,  524, 0xffffff},
		{  288,  632, 0xffc154},
	})
	stomMultiColorTap("账号注册B",{
		{   33,  514, 0x4dd3fb},
		{   31,  535, 0x4ad2fb},
		{   45,  609, 0xffffff},
	})
	stomMultiColorTap("选择女神",{
		{   46,  554, 0xffffff},
		{   46,  575, 0x978b82},
		{   54,  585, 0xffffff},
	})
	stomMultiColorTap("选择女神b",{
		{   33,  560, 0xc5bfbd},
		{   35,  586, 0x8a817a},
		{   64,  599, 0xde9d26},
	})
	stomMultiColorTap("开始游戏",{
		{  113,  763, 0xffffff},
		{  119,  765, 0x37393a},
		{  118,  810, 0x717273},
	})
	
	stomMultiColorTap("起名",{
		{  218,  592, 0x888868},
		{  380,  667, 0xeeffff},
		{  389,  711, 0x4488aa},
	})
	stomMultiColorTap("自动生成",{
		{  220,  627, 0xf2f1ee},
		{  200,  676, 0x383327},
		{  231,  718, 0x837551},
	})
	--[[stomMultiColorTap("四角黑则点击",{
		{  618, 1116, 0x000000},
		{  597,   64, 0x000000},
		{   41,   41, 0x000000},
		{   42, 1106, 0x000000},
	})]]
	stomMultiColorTap("跳过弹窗",{
		{  219,  653, 0xc7c6c3},
		{  232,  687, 0x837551},
		{  331,  569, 0x808081},
	})
	stomMultiColorTap("步兵高亮",{
		{  291,  554, 0xbdccce},
		{  318,  527, 0x37c7ff},
		{  335,  570, 0x4ee0ff},
	})
	stomMultiColorTap("步兵高亮1",{
		{  275,  566, 0xcb5c58},
		{  253,  526, 0x61b4fc},
		{  231,  582, 0xb6ffff},
	})
	--[[stomMultiColorTap("步兵高亮2",{
		{  219,  653, 0xc7c6c3},
		{  232,  687, 0x837551},
		{  331,  569, 0x808081},
	})--]]
	stomMultiColorTap("征兵",{
		{  299,  454, 0xa9c3ca},
		{  299,  467, 0xaac4cb},
		{  293,  477, 0x426770},
	})
	stomMultiColorTap("加速",{
		{   65,  792, 0xffffff},
		{   56,  819, 0xacacab},
		{   64,  807, 0x362f20},
	})
	stomMultiColorTap("征兵",{
		{   39,  674, 0x8e8f8f},
		{   47,  676, 0xffffff},
		{   51,  687, 0xd6dcdd},
		{   43,  694, 0x5e6162},
	})
	--[[if stomMultiColorTap("招募高亮",{
		{   55,  863, 0x3f4e54},
		{   88,  914, 0xa6191a},
		{   89,  905, 0xa72330},
	}) then
		stommSleep(600)
	end]]
	stomMultiColorTap("酒馆任务	",{
		{   61,  870, 0x999977},
		{   79,  872, 0xefeedd},
		{  104,  866, 0x41baf8},
	})	
	stomMultiColorTap("右侧招募",{
		{   78,  701, 0x364546},
		{   89,  783, 0x5f787b},
		{  112,  782, 0xfb2c29},
		{  115,  782, 0xfb2c29},
	})
	stomMultiColorTap("右侧招募B",{
		{   89,  676, 0x747778},
		{   95,  698, 0xffffff},
		{   49,  698, 0x49e241},
	})	
	stomMultiColorTap("先锋高亮",{
		{  572,  641, 0xff364d},
		{  569,  642, 0xff3041},
	})
	if	stomMultiColorTap("先锋高亮圈",{
		{  489,  699, 0x4ad2ff},
		{  608,  698, 0x45c6ff},
	})or stomMultiColorTap("先锋高亮圈B",{
	{  600,  648, 0x319cf2},
	{  502,  586, 0x3599ff},
	})then	
		stomtap(543,  696)
	end
	stomMultiColorTap("先锋高亮b",{
		{  571,  709, 0xffc99b},
		{  570,  719, 0xf82835},
		{  569,  724, 0xff2f40},
	})
	stomMultiColorTap("进攻",{
		{  155,  798, 0xe9e6e2},
		{  157,  806, 0x6d654e},
		{  155,  818, 0xbcb5a6},
		{  152,  822, 0x78725e},
	})
	stomMultiColorTap("先锋2次",{
	{  555,  620, 0xcdccb3},
	{  592,  621, 0x8cffff},
	})
	stomMultiColorTap("先锋2次",{
		{  554,  621, 0xbab9ac},
		{  607,  620, 0x2eacff},
	})
	stomMultiColorTap("上阵",{
		{  402,  481, 0x657071},
		{  394,  488, 0xcecfcf},
		{  403,  496, 0xa6a9a9},
		{  406,  509, 0x6f7172},
	})
	stomMultiColorTap("上阵B",{
		{  330,  496, 0x48953b},
		{  330,  504, 0x49953c},
		{  330,  510, 0x48953b},
	})
	stomMultiColorTap("挑战",{
		{   86,  850, 0xe0e0e0},
		{   90,  858, 0x0e1112},
		{   93,  869, 0xffffff},
	})
	stomMultiColorTap("关闭战斗结束",{
		{  189,  953, 0xafaea6},
		{  189,  968, 0xf7f7f6},
		{  190,  967, 0x858172},
	})

	stomMultiColorTap("拼死一战",{
		{  218,  628, 0xe8e6e3},
		{  230,  656, 0xcbc7be},
		{  222,  676, 0x0a0806},
	})
	stomMultiColorTap("拼死一战B",{
		{  216,  629, 0x80807e},
		{  224,  635, 0xe1dfdb},
		{  232,  634, 0x837551},
		{  229,  627, 0xb8b09c},
	})
	stomMultiColorTap("武将高亮",{
		{   74,  602, 0xddddcc},
		{   81,  560, 0x74ffff},
		{   80,  644, 0xadffff},
	})
	stomMultiColorTap("武将高亮2",{
		{   81,  569, 0x44b9ff},
		{   82,  634, 0x1da9ff},
	})
	stomMultiColorTap("武将高亮3",{
		{  501,  148, 0xede5d3},
		{  517,  138, 0x4d2656},
		{  521,  166, 0xfffff5},
	})
	stomMultiColorTap("武将高亮4",{
		{   48,  602, 0x384343},
		{   67,  602, 0xa9a998},
		{   98,  600, 0xa7ffff},
	})
	stomMultiColorTap("点击武将",{
		{  501,  148, 0xede5d3},
		{  318,  182, 0xf3f3f3},
		{  320,  225, 0xd0c4cc},
	})
	stomMultiColorTap("一键镶嵌",{
		{   48,  771, 0xe5e3df},
		{   56,  773, 0xa09d96},
		{   56,  791, 0x666562},
		{   44,  784, 0x8c8472},
	})
	stomMultiColorTap("一键镶嵌2",{
	{   57,  711, 0x9a8a60},
	{  269,  990, 0x65b361},
	{  295,  972, 0x3a8536},
})
	stomMultiColorTap("获取宝石",{
		{  301,  953, 0x665f15},
		{  298,  959, 0x8e840f},
		{  303,  965, 0xb4a713},
	})
	stomMultiColorTap("前往战斗",{
		{  344,  756, 0xf1f2f2},
		{  343,  765, 0x404242},
		{  344,  780, 0x818b8c},
		{  331,  785, 0xf0f0f0},
	})
	stomMultiColorTap("前往活动！！",{
		{  411,  493, 0x658955},
		{  412,  514, 0x658955},
		{  412,  534, 0x658955},
		{  449,  515, 0xcdcec7},
	})
	stomMultiColorTap("挑战",{
		{   67,  886, 0x6b6450},
		{   68,  890, 0xe6e5e2},
		{   68,  898, 0x171611},
		{   69,  909, 0xffffff},
	})
	stomMultiColorTap("升星",{
		{   43,  763, 0xe3dacb},
		{   43,  774, 0xebe5dc},
		{   41,  790, 0x7b7876},
	})
	stomMultiColorTap("日常",{
		{  168, 1032, 0x1875bd},
		{  194, 1100, 0x1e7ec8},
	})
	stomMultiColorTap("日常1",{
		{  166, 1036, 0x4a9dd8},
		{  129, 1072, 0x1f71b1},
	})
	stomMultiColorTap("日常2",{
		{  150, 1064, 0x020000},
		{  154, 1030, 0xa3ffff},
		{  179, 1113, 0x87ffff},
	})
	stomMultiColorTap("日常3",{
		{  156, 1063, 0xd9cbaf},
		{  203, 1074, 0x4aa8e9},
		{  128, 1071, 0x3986cc},
	})
	stomMultiColorTap("日常任务1",{
		{  418,  499, 0xffffff},
		{  414,  507, 0xcdd9c8},
		{  411,  516, 0x6a8d5a},
	})
	stomMultiColorTap("日常2.2",{
		{  451,  330, 0xfff0cc},
		{  438,  343, 0xeee8b7},
		{  463,  358, 0xfff0d0},
	})
	stomMultiColorTap("日常2.2B",{
		{  450,  331, 0xfeeec6},
		{  440,  341, 0xf9e8bf},
		{  438,  331, 0xeedd99},
	})
	stomMultiColorTap("日常2.2B",{
		{  447,  336, 0xfcebc9},
		{  443,  340, 0xf5ddb8},
		{  439,  343, 0xeedd9a},
	})
	stomMultiColorTap("日常2.2C",{
		{  442,  338, 0xffeed2},
		{  439,  332, 0xeedd9a},
		{  435,  347, 0xeedd89},
	})
	stomMultiColorTap("上阵2",{
		{  220,  379, 0x479439},
		{  220,  391, 0x479439},
		{  341,  491, 0x53bd5b},
	})
	--[[if stomMultiColor("手指",{
	{  295,  176, 0xead4c1},
	{  297,  174, 0xead2bb},
}) then
		stomtap( 323,  152)
		return 1
	end]]
	
	--[[if stomMultiColorTap("武将",{
		{   83,  602, 0xefeedd},
		{   78,  602, 0x353d3d},
		{   67,  602, 0xa9a998},
	}) then
		stommSleep(300)
	end
	
	if stomMultiColor("存在武将",{
		{  474,  285, 0x562d5b},
		{  462,  288, 0x533f2d},
		{  448,  282, 0x4a2754},
		{  604,  288, 0x252626},
	}) then
		
		stomMultiColorTap("关闭武将",{
		{  612, 1108, 0xcccbc0},
		{  607,  549, 0x787b7b},
		{  613,  574, 0xffffff},
	})
		return 1
	else 
		stomMultiColorTap("关闭武将",{
		{  612, 1108, 0xcccbc0},
		{  607,  549, 0x787b7b},
		{  613,  574, 0xffffff},
	})
		return 0
	end
	
	stomMultiColorTap("关闭小武将",{
	{  524,  907, 0xd3cfbd},
	{  530,  901, 0xddd5bd},
	{   68,  308, 0x676b6f},
	{  313,  961, 0xc5bc89},
})]]
	
	return 0
end

function LY1478720553_fn_loop1()
	if 	stomMultiColor("建筑队列",{
		{  581,  583, 0xffffff},
		{   63,  727, 0x495d60},
		{   65,  849, 0x918258},
		{   98,  883, 0x1371ca},
	}) then
	return 1
	end
	if 	stomMultiColor("手指任务",{
		{  291,  176, 0xead4c1},
		{  298,  171, 0xead4c1},
		{  287,  181, 0xead4c1},
		{  304,  144, 0x55a955},
	}) then
	return 1
	end	
	return 0
end

function LY1478720553_fn_loop2()
	if 	stomMultiColor("建筑队列12为灰色",{
		{  452,  893, 0x898989},
		{  452,  923, 0x898989},
		{  344,  918, 0x898989},
		{  344,  895, 0x898989},
	})or stomMultiColor("建筑队列1灰色,2要钱",{
		{  452,  889, 0x898989},
		{  452,  919, 0x898989},
		{  360,  913, 0xdcc99c},
	})
		then
		stomMultiColorTap("关闭建筑窗口",{
			{  579,  954, 0xd2cfc0},
			{  572,  948, 0xcfcebd},
		})
		return 1
	end
	if 	stomMultiColor("没有空闲队列",{
		{  341,  414, 0xa1a1a2},
		{  340,  446, 0x666667},
		{  340,  464, 0xffffff},
		{  341,  474, 0xa8a8a9},
	}) then
	stomMultiColorTap("关闭VIP",{
		{  428,  730, 0xcccbc1},
		{  341,  414, 0xa1a1a2},
		{  340,  446, 0x666667},
		{  340,  464, 0xffffff},
})
	stommSleep(500)
	stomMultiColorTap("关闭建筑窗口",{
		{  579,  954, 0xd2cfc0},
		{  572,  948, 0xcfcebd},
	})
		return 1
	end	

	return 0
end
function create_LY1478720553_main()    --洛阳
	local tt1
	local time_cha =  math.random(5,10)*60
	local t1 = os.time()-40
	--local t3 = os.time()
	local flag = 0
	local loop = 0
	while (true) do
		OpenApp("com.wuyufan.lytz")
		LY1478720553_fn_do()
		if loop==0 then
			LY1478720553_fn_login()
			loop=LY1478720553_fn_tankuang()
			loop=loop+LY1478720553_fn_loop1()
			flag=flag+LY1478720553_fn_zhuxian(flag)
		elseif loop==1 then
			LY1478720553_fn_tankuang()
			LY1478720553_fn_zhuxian2()
			loop=loop+LY1478720553_fn_loop1()
		elseif loop==2 then
			LY1478720553_fn_tankuang()
			LY1478720553_fn_zhuxian3()
			loop=loop-LY1478720553_fn_loop2()
		end

		t2 = os.time()
		if t2-t1 > 60 then--定时征兵
			stomMultiColorTap("点大锤",{
			{  238,   33, 0x0e1012},
			{  205,   53, 0xffffff},
			{  253,   37, 0x685241},
		})
			t1 = os.time()
		end

		
		local tt2 = os.time()
		if os.difftime(tt2,tt1) > time_cha then
			return 0
		end
		--[[i=i+1
		if i>2 then
		i=0
		end]]
		stomLog(loop)
		stommSleep(100)
	end
end

function GCGY_fn_login()
	if stomMultiColorTap("点击账号",{
		{  230,  466, 0xffffff},
		{  181,  624, 0xff0000},
		{  137,  756, 0xc30d23},
		{  138,  467, 0x000000},
	}) then 
		stommSleep(300)
	end
	if stomMultiColor("账号输入框",{
		{  227,  458, 0x426bf2},
		{  235,  464, 0xffffff},
		{  139,  464, 0x000000},
		{  366,  376, 0xfa4400},
	}) or stomMultiColor("账号输入框B",{
		{  227,  459, 0x426bf2},
		{  129,  467, 0x000000},
		{  369,  377, 0xfa4300},
		{  252,  468, 0xffffff},
	}) then
		m = math.random(7,10) 
		myRand(4,m,2)
		username = myRand(4,m,2)
		stomInpuText(username)
	end
	stomMultiColorTap("点击密码",{
		{  229,  548, 0xffffff},
		{  512,  461, 0xcccccc},
		{  133,  548, 0x000000},
		{  358,  375, 0xfa4600},
	})
	if stomMultiColor("密码输入框",{
		{  227,  542, 0x426bf2},
		{  240,  546, 0xffffff},
		{  133,  548, 0x000000},
		{  371,  379, 0xfb4000},
	}) then
		m = math.random(7,10) 
		myRand(4,m,2)
		psw = myRand(4,m,2)
		stomInpuText(psw)
	end
	stomMultiColorTap("开始游戏",{
		{  232,  629, 0xff0000},
		{  293,  626, 0xffffff},
		{  444,  548, 0xcccccc},
		{  372,  384, 0xfc3800},
	})

	if stomMultiColor("选择角色",{
		{   72,  895, 0xbffefe},
		{   58,  916, 0x0768a9},
		{   64,  984, 0x48070f},
		{   81,  981, 0xf3c8cb},
	}) then
		m = math.random(0,1) 
		if m==1 then
			stomMultiColorTap("男",{
			{   72,  895, 0xbffefe},
			{   58,  916, 0x0768a9},
		})
		else stomMultiColorTap("女",{
			{   64,  984, 0x48070f},
			{   81,  981, 0xf3c8cb},
		})
		end
		stommSleep(300)
	end
	stomMultiColorTap("创建角色",{
		{  259,  995, 0xdd833c},
		{  320,  995, 0xffffff},
		{  406, 1003, 0xe49245},
	})
	for var= 1, 10 do
		stomMultiColorTap("点击继续~",{
		{  405,  906, 0xf0cf77},
		{  484,  906, 0xf0cf77},
		{  550, 1083, 0xb49c5a},
		--{   22, 1084, 0xf0cf77},
		})
	end
	stomMultiColorTap("为父报仇",{
		{  237,  534, 0xb37c42},
		{  373,  521, 0xb78046},
		{  314,  536, 0x512f06},
		{  359,  565, 0x674521},
	})
	stomMultiColorTap("解锁经营",{
		{  109,  735, 0xccd5e5},
		{  176,  945, 0x97970f},
		{  210,  942, 0x4d4d0a},
		{  210,  704, 0xd6c1ab},
	})
	stomMultiColorTap("解锁经营2",{
		{  135,  795, 0x92553f},
		{  158,  780, 0xce803d},
		{  109,  820, 0xc26c17},
		{  136,  791, 0xfefdfc},
	})
	stomMultiColorTap("解锁经营3",{
		{  314,  790, 0xe1d0ca},
		{  330,  791, 0xfefdfc},
		{  351,  786, 0xb25c21},
		{  283,  819, 0xa15a16},
	})
	stomMultiColorTap("解锁经营4",{
		{  505,  790, 0xe1d0ca},
		{  517,  791, 0xffffff},
		{  503,  783, 0xae5a20},
		{  494,  820, 0xc56e17},
	})
	stomMultiColorTap("退出经营",{
		{  570,  258, 0xffffd4},
		{   88,  785, 0x8d271b},
		{  279,  789, 0x7c1810},
		{  472,  791, 0x7f1911},
	})
	stomMultiColorTap("门客高亮",{
		{   46, 1068, 0xfffffe},
		{   19, 1024, 0xf0ac44},
		{  113, 1064, 0xf0af48},
		{   32, 1128, 0xf3b447},
	})
	stomMultiColorTap("门客高亮2",{
		{   90,  285, 0xf6dcba},
		{  102,  172, 0xf9d96e},
		{  215,  283, 0xf1b047},
		{  107,  392, 0xfedd70},
	})
	if 	stomMultiColor("关卡内",{
		{  104,   85, 0x712a27},
		{  600,   83, 0xfdd170},
		{   43,  267, 0xb99970},
		{  576,  267, 0xba9a71},
	}) then
	stomMultiColorRegTap("战斗找图",0x060103, "1|-15|0x6d0200,29|-24|0x060605", 90, 25, 287, 618, 889)
	stomMultiColorRegTap("战斗找BoSS",0xf9cb36, "35|38|0x070001,73|5|0xe79c27", 90, 42, 284, 609, 533)
	end
	stomMultiColorTap("开始战斗~",{
		{  288,  576, 0xfffffe},
		{  351,  595, 0xf7fd7c},
		{  325,  659, 0xa92e30},
		{  283,  655, 0xc53b31},
	})
	stomMultiColorTap("战胜~",{
		{  314,  355, 0x2b242d},
		{  246,  352, 0xd7ba8d},
		{  385,  354, 0xcdae82},
		{  364,  296, 0xdf5666},
	})
	stomMultiColorTap("领取主线",{
		{  308,  764, 0xeadeda},
		{  332,  765, 0x6f1e00},
		{  265,  761, 0xb25c21},
		{  335,  790, 0xcc7218},
	})
	stomMultiColorTap("开战",{
		{  290,  518, 0xf4fe31},
		{  335,  536, 0xf0b01d},
		{  404,  521, 0x382116},
		{  232,  503, 0xd39e37},
	})
	if stomMultiColorTap("升级高亮",{
		{  478,  565, 0xc09234},
		{  430,  569, 0xf0ad43},
		{  596,  572, 0xf1b046},
		{  482,  603, 0xf9c95a},
	}) then
		stommSleep(500)
		stomMultiColorTap("关闭门客",{
		{  588,   41, 0x765e3c},
		{  589,   28, 0xd7b97e},
		{  576,   41, 0xf4dc95},
	})
		stommSleep(500)
		stomMultiColorTap("关闭门客2",{
		{  600,   98, 0xd35600},
		{  600,   82, 0xfdd170},
		{  587,   97, 0xf7bd5b},
	})		
	end
	stomMultiColorTap("出府高亮",{
		{  591,   30, 0xffecb9},
		{  550,   28, 0xf0ac44},
		{  551,   54, 0xd38b30},
		{  580,   38, 0xd57a3e},
	})
	stomMultiColorTap("关卡高亮",{
		{  559,  747, 0xd6c1ab},
		{  341,  739, 0xf0ad43},
		{  342,  822, 0xf0ad43},
		{  559,  769, 0xd6c1ab},
	})
	stomMultiColorTap("战斗1高亮",{
		{   84,  809, 0x6d0200},
		{  128,  814, 0xf1b048},
		{  128,  797, 0xf0b149},
	})
	stomMultiColorTap("开始战斗高亮",{
		{  297,  581, 0xfffeea},
		{  334,  600, 0xf4fa55},
		{  317,  508, 0xf9d96e},
		{  198,  575, 0xf0ad44},
	})
	stomMultiColorTap("战斗关闭高亮",{
		{  594,  217, 0xd7c38c},
		{  605,  211, 0x632a19},
		{  575,  199, 0xf0ac44},
		{  575,  220, 0xf0ad43},
	})
	stomMultiColorTap("战斗关闭高亮2",{
		{  584,   95, 0xf8bf5a},
		{  595,   93, 0xd35600},
		{  566,   78, 0xf0ac44},
		{  566,  101, 0xf0ad43},
	})
	stomMultiColorTap("回付高亮",{
		{  218,  454, 0xd6c1ab},
		{  218,  467, 0xd6c1ab},
		{  191,  437, 0xf0ad43},
		{  191,  476, 0xf0ad43},
	})
	stomMultiColorTap("角色高亮",{
		{  114,   76, 0xc9b9ac},
		{   43,  170, 0x5b412d},
		{  139,   89, 0xf0b149},
		{  139,  118, 0xf0af48},
	})
	stomMultiColorTap("升官高亮",{
		{  548,  432, 0x430f00},
		{  568,  417, 0x420f00},
		{  490,  390, 0xf0ac44},
		{  490,  467, 0xf0ad43},
	})
	stomMultiColorTap("升官高亮2",{
		{  274, 1077, 0xb25c21},
		{  325, 1079, 0xf3ecea},
		{  231, 1063, 0xf0ac44},
		{  231, 1096, 0xf0ad43},
	})
	stomMultiColorTap("升官成功",{
		{  211,   82, 0xffde7c},
		{  231,   87, 0x441501},
		{  276,   77, 0xfed889},
		{  259,   95, 0xc02819},
	})
	stomMultiColorTap("内宅高亮",{
		{   87,  401, 0x5c0609},
		{   89,  444, 0xd7c1aa},
		{  165,  395, 0xf0b149},
		{  165,  431, 0xf0b048},
	})
	stomMultiColorTap("女武将高亮",{
		{  220,  792, 0xff5688},
		{  276,  671, 0xf0b149},
		{  276,  701, 0xf0b149},
		{  276,  730, 0xf0af48},
	})
	stomMultiColorTap("传唤高亮",{
		{  475, 1092, 0xbb7f07},
		{  505, 1086, 0xffffff},
		{  447, 1072, 0xf0ab46},
		{  447, 1100, 0xf0ad43},
	})
	stomMultiColorTap("传唤",{
		{  473, 1090, 0xb77907},
		{  505, 1086, 0xffffff},
		{  492, 1091, 0xffffff},
		{  493, 1105, 0xd1a902},
	})
	stomMultiColorTap("贵子查看",{
		{  157,  893, 0xae5920},
		{  194,  900, 0xc6b0a9},
		{  194,  905, 0x722307},
		{  194,  924, 0xefc240},
	})
	stomMultiColorTap("赐名",{
		{  445,  766, 0x7f1810},
		{  487,  766, 0xfefcfc},
		{  511,  776, 0x6f1d00},
		{  525,  774, 0xffffff},
	})
	stomMultiColorTap("赐名B",{
		{  364,  613, 0xb45e20},
		{  448,  611, 0xbc6921},
		{  276,  533, 0x611719},
		{  414,  408, 0xe7b25f},
	})
	stomMultiColorTap("修改名称",{
		{  229,  548, 0xffffff},
		{  512,  461, 0xcccccc},
		{  133,  548, 0x000000},
		{  358,  375, 0xfa4600},
	})
	stomMultiColorTap("培养",{
		{  459,  768, 0xb86221},
		{  488,  766, 0xffffff},
		{  499,  769, 0xdfcdc7},
		{  516,  773, 0x702003},
	})
	stomMultiColorTap("出宅",{
		{  503,  307, 0x7e4217},
		{  503,  322, 0x5d1800},
		{  515,  328, 0xf9d65d},
		{  518,  308, 0xda812e},
	})
	stomMultiColorTap("主线高亮",{
		{   60,  944, 0x664b3b},
		{   75,  923, 0xf4c858},
		{  118,  923, 0xf9d96e},
		{   59,  946, 0x634738},
	})
	stomMultiColorTap("处理政务选1",{
		{  174,  702, 0x95583e},
		{   78,  318, 0xfedeb2},
		{   81,  413, 0x401b16},
		{  589,  276, 0xfdd06f},
	})
	stomMultiColorTap("点击密码",{
		{  229,  548, 0xffffff},
		{  512,  461, 0xcccccc},
		{  133,  548, 0x000000},
		{  358,  375, 0xfa4600},
	})
	stomMultiColorTap("点击密码",{
		{  229,  548, 0xffffff},
		{  512,  461, 0xcccccc},
		{  133,  548, 0x000000},
		{  358,  375, 0xfa4600},
	})
	stomMultiColorTap("点击密码",{
		{  229,  548, 0xffffff},
		{  512,  461, 0xcccccc},
		{  133,  548, 0x000000},
		{  358,  375, 0xfa4600},
	})

end

function GCGY_fn_zhuxian()
	local i
	if	stomMultiColor("主线",{
		{  262,  295, 0xffffd8},
		{  305,  304, 0xfff2b2},
		{  297,  757, 0x274b71},
	}) then
		if stomMultiColorTap("10级任务",{
			{  297,  757, 0x274b71},			
			{  210,  440, 0x3d150d},
			{  223,  442, 0x78564c},
			{  225,  449, 0x4a231b},
			{  233,  448, 0x3d150d},
			{  238,  444, 0x7a594f},
		}) or stomMultiColorTap("10级任务2",{
			{  297,  757, 0x274b71},			
			{  232,  440, 0x3d150d},
			{  245,  447, 0x836359},
			{  248,  443, 0x714e45},
			{  255,  443, 0x3d150d},
			{  260,  446, 0x88675e},
		}) then
			i=10
			stommSleep(500)			
			GCGY_fn_levelup(i)
		end
		
		stomMultiColorTap("处理政务",{
		{  298,  766, 0x2f5584},
		{  158,  443, 0x3d150d},
		{  156,  447, 0x84635a},
		{  182,  447, 0x3d150d},
		{  190,  450, 0x745248},
		})
	end
end
	
function GCGY_fn_levelup(i)
	local a=0
	if	stomMultiColor("升级界面",{
		{  267,   41, 0x362a22},
		{  300,   36, 0xfbe383},
		{  543,  526, 0xd4cbba},
		--{  477,  580, 0xc49204},
	}) then
		stommSleep(100)
		while (a<=i) do
			stommSleep(100)
			if stomMultiColorTap("升级",{
				{  481,  565, 0xc19232},
				{  481,  582, 0xc79903},
				{  528,  569, 0xfffefd},
				{  533,  577, 0xffffff},
			}) then
				stommSleep(400)
				a=a+1
			end
			stomLog(a)
		end
	end
end
	
function GCGY_fn_close()
	stomMultiColorTap("游戏公告",{
		{  602,  313, 0xd45600},
		{  326,  264, 0xffe09f},
		{  372,  263, 0xfee4a6},
		{  195,  263, 0x652622},
	})
	stomMultiColorTap("门客选择",{
		{  592,  148, 0x602718},
		{  254,  133, 0x470404},
		{  264,  133, 0xf2c67a},
		{  297,  130, 0x470404},
	})
	stomMultiColorTap("抓捕成功",{
		{  342,  750, 0xcfb380},
		{  294,  750, 0xd0b381},
		{  319,  774, 0xdbb072},
		{  349,  784, 0xebd592},
	})
	stomMultiColorTap("新关卡",{
		{  191,  245, 0xe9be72},
		{  234,  225, 0x983b32},
		{  297,  230, 0x330a08},
		{  514,  252, 0x85332f},
	})
	stomMultiColorTap("通关奖励",{
		{  222,  421, 0xf0cc77},
		{  252,  427, 0xf9d880},
		{  292,  400, 0x371800},
		{  292,  411, 0xddb365},
	})
	stomMultiColorTap("关闭升官",{
		{  601,   98, 0xd35600},
		{  581,   98, 0xf6bd5b},
		{  599,   82, 0xfdd170},
		--升官{  273,   78, 0xf4c99e},
	})
	stomMultiColorTap("关闭玩家信息",{
		{  578,   42, 0x775f3d},
		{  579,   30, 0xdcbf82},
		{  569,   33, 0x715837},
		--{  245,   36, 0xfbe393},
	})
	stomMultiColorTap("招募成功",{
		{  233,  326, 0xfcc45e},
		{  258,  325, 0x2f0c0c},
		{  299,  319, 0xfcd167},
		{  300,  338, 0xfeb04f},
	})
	stomMultiColorTap("关闭女武将",{
		{  156,  951, 0x756051},
		{  187,  951, 0x7a6353},
		{  234,  951, 0x8f735c},
		{  137,  242, 0x810904},
	})
	stomMultiColorTap("传唤结束",{
		{  115,  967, 0xa55d7a},
		{  121, 1008, 0xcdbfcc},
		{  520,  974, 0x8e6f81},
		{  500, 1063, 0xdedcdf},
	})
	stomMultiColorTap("关闭儿子",{
		{  595,   35, 0xfccb6a},
		{  595,   45, 0xd35600},
		{  595,   58, 0xecb653},
		{  111,   62, 0x2f1e17},
	})
	stomMultiColorTap("关闭门课",{
		{  588,   43, 0x775f3d},
		{  589,   28, 0xd7b97e},
		{  267,   39, 0x362a22},
		{  299,   37, 0xfbe17f},
	})
	stomMultiColorTap("关闭政务",{
		{  592,  277, 0xfccd6e},
		{  593,  290, 0xd55801},
		{   92,  389, 0xfedeb2},
		{  476,  774, 0xb45f20},
		{   87,  419, 0x401b16},
	})
	stomMultiColorTap("关闭查看儿子",{
		{  157,  591, 0x882c2a},
		{  169,  591, 0xf7f1f0},
		{  425,  483, 0xffffff},
		{  432,  482, 0x797976},
	})

end

function create_GCFY1434276525_main()    --官场风云
	local tt1 = os.time()
	local time_cha =  math.random(40,50)*60
	local t1 = os.time()-40
	--local t3 = os.time()
	local flag = 0
	local loop = 0
	while (true) do
		OpenApp("com.cg.gcfy.app")
		GCGY_fn_login()
		GCGY_fn_close()
		GCGY_fn_zhuxian()
		
	if stomMultiColorTap("进入区服",{
		{  228,  924, 0xdb803e},
		{  294,  934, 0x690000},
		{  423,  898, 0x0f0907},
		{  420,  927, 0xdd823b},
		}) then
			tt1 = os.time()
			time_cha =  math.random(5,8)*60
	end
		if loop==0 then


		elseif loop==1 then

		elseif loop==2 then

		end

		t2 = os.time()
		if t2-t1 > 60 then--定时征兵
			t1 = os.time()
		end

		
		local tt2 = os.time()
		if os.difftime(tt2,tt1) > time_cha then
			return 0
		end
		--[[i=i+1
		if i>2 then
		i=0
		end]]
		stomLog(tt2-tt1)
		stommSleep(300)
	end
end

function MRFZ1454663939_login()
	nicheng = ZKQ_Word(zhangkq["姓氏"],1,1)..ZKQ_Word(zhangkq["名字"],3,3)
	stomMultiColorTap("游客登录",{
	{  188,  710, 0x555555},
	{  184,  758, 0xe3e3e3},
	{  180,  778, 0xffffff},
	{  182,  831, 0x555656},
})
	stomMultiColorTap("同意许可",{
	{   89,  362, 0x070707},
	{   89,  421, 0xeeeeee},
	{   91,  433, 0xcfcec9},
	{   91,  468, 0x9c9c9c},
	{   79,  486, 0x070707},
})
	stomMultiColorTap("同意许可2",{
	{   37,  530, 0x225e78},
	{   37,  568, 0xf2f6f7},
	{   31,  611, 0x256480},
	{   93,  363, 0xf5f5f5},
})
	if stomMultiColorTap("起名",{
	{  273,  519, 0x474748},
	{  276,  456, 0xacacac},
	{  275,  473, 0x5b5b5d},
	{  267,  477, 0xacacac},
})then
		stommSleep(999)
		stomInpuText(nicheng)
		stommSleep(500)
		stomtap(526,  487)
	end
	
	stomMultiColorTap("起名失败",{
	{  185,  566, 0x121211},
	{  200,  566, 0xffffff},
	{  285,  570, 0x373636},
	{  345,  587, 0x5f5f5f},
})
	stomMultiColorTap("nameok",{
	{  190,  536, 0x414142},
	{  192,  573, 0xffffff},
	{  186,  577, 0xbfbfbf},
	{  173,  566, 0x919191},
})
	stomMultiColorTap("skip",{
	{  592, 1033, 0x515152},
	{  593, 1031, 0xc9c9c9},
	{  592, 1060, 0x727170},
	{  591, 1076, 0xffffff},
})
	stomMultiColorTap("skip2",{
	{  180,  775, 0x731510},
	{  181,  756, 0xffffff},
	{  351,  558, 0x333333},
	{  351,  606, 0x4e4e4e},
})
	stomMultiColorTap("游客登录",{
	{  188,  710, 0x555555},
	{  184,  758, 0xe3e3e3},
	{  180,  778, 0xffffff},
	{  182,  831, 0x555656},
})

end

function MRFZ1454663939_close()
	stomMultiColorTap("talk",{
	{  542,  193, 0x0e0c10},
	{  527,  179, 0x919291},
	{  553,  179, 0x989796},
	{  588,  221, 0x7f7f82},
})
	stomMultiColorTap("talk2",{
	{  553,  193, 0x0e0c0e},
	{  552,  179, 0x939393},
	{  565,  179, 0x989796},
	{  588,  219, 0x7f7f81},
})
	stomMultiColorTap("talk3",{
	{  158,  223, 0x0b0e0f},
	{  162,  209, 0x767773},
	{  148,  209, 0x777773},
	{  198,  226, 0xc5c5c5},
})
	stomMultiColorTap("ad",{
	{  608, 1084, 0xffffff},
	{  580, 1072, 0x2a2a2d},
	{  592, 1079, 0xc4c4c4},
	{  592, 1094, 0x727274},
})
	stomMultiColorTap("抽奖",{
	{  245,  628, 0xffffff},
	{  184, 1039, 0xffffff},
	{  210, 1112, 0x030302},
	{  213, 1050, 0x8e8e8d},
	{  221, 1068, 0xadadad},
})
	stomMultiColorTap("fightend",{
	{   76,  238, 0x827b71},
	{   91,  244, 0xffffff},
	{  103,  301, 0x757272},
	{   52,  314, 0x46403e},
})
	stomMultiColorTap("skip2",{
	{  592, 1076, 0xffffff},
	{  590, 1022, 0xe2e2e2},
	{  598, 1033, 0x5e5b5d},
	{  589, 1047, 0x808081},
})
	if 	stomMultiColorTap("skip2",{
		{  215, 1048, 0x868685},
		{  197, 1053, 0x0a0a07},
		{  184, 1068, 0xffffff},
		{  196, 1098, 0xf3f3f3},
	}) then
		stomtap(349,  690)
	end
	stomMultiColorTap("后退",{
	{  604,   34, 0xffffff},
	{  590,   30, 0x313131},
	{  613,   27, 0x313131},
	{  605,  171, 0x313131},
})
	stomMultiColorTap("关闭公告",{
	{  589, 1097, 0xc3c3c3},
	{  588, 1083, 0x585859},
	{  578, 1097, 0x585858},
	{  528,  420, 0x333333},
	{  535,  440, 0x353535},
})
end	

function MRFZ1454663939_do()
	if stomMultiColor("test1",{
	{  561,  572, 0xffffff},
	{  559,  733, 0x007eb7},
	{  563,  747, 0x0098dc},
	{  565,  780, 0x0098dc},
})then
		touchDown(40,  985)
		stommSleep(300)
		touchMove(260,  522)
		stommSleep(300)
		touchUp(260,  522)
	end
	if stomMultiColor("test2",{
	{  559,  494, 0x0097da},
	{  558,  572, 0x0098dc},
	{  567,  362, 0xfefefe},
	{  278,  516, 0xffa200},
})then
		touchDown(276,  514)
		stommSleep(300)
		touchMove(278,  737)
		stommSleep(300)
		touchUp(278,  737)
	end	
	if stomMultiColor("test3",{
	{  561,  543, 0xffffff},
	{  564,  599, 0x0093d5},
	{  554,  649, 0x0098dc},
	{   53, 1079, 0xffa200},
})then
		stommove(53, 1080,355,  625)
		--[[touchDown(53, 1080)
		stommSleep(300)
		touchMove(355,  625)
		stommSleep(300)
		touchUp(355,  625)]]
	end	
	if stomMultiColor("test4",{
	{  528,  285, 0x717171},
	{  524,  316, 0xfdfdfd},
	{  524,  345, 0xf8f8f8},
	{  377,  616, 0xffa200},
})then
		stommove(379,  618,364,  823)
		--[[touchDown(53, 1080)
		stommSleep(300)
		touchMove(355,  625)
		stommSleep(300)
		touchUp(355,  625)]]
	end		
	stomMultiColorTap("xstap1",{
	{  354,  413, 0x445465},
	{  359,  483, 0xe5e7ea},
	{  525,  268, 0x5e5f5f},
	{  560,  445, 0xaeaeae},
})
	stomMultiColorTap("xstap2",{
	{  225,  780, 0xc43431},
	{  269,  778, 0xfbfbfc},
	{  563,  341, 0x0098dc},
	{  568,  365, 0x004c6f},
})
	stomMultiColorTap("xstap3",{
	{   69,  818, 0xe7e7e7},
	{   79,  900, 0xffffff},
	{  121,  800, 0xffffff},
	{   62,  808, 0x313131},
})
	stomMultiColorTap("xstap4",{
	{  407,  500, 0x858585},
	{  351,  523, 0x181820},
	{  317,  499, 0xffffff},
	{  569,  461, 0x626263},
})
	stomMultiColorTap("xstap5",{
	{  367,  444, 0x1c1c1b},
	{  322,  431, 0xffffff},
	{  559,  263, 0x656565},
	{  569,  277, 0x646464},
})
	stomMultiColorTap("xstap6",{
	{   42, 1015, 0x0075a9},
	{   50, 1041, 0xffffff},
	{   41, 1078, 0x0075a9},
	{   85, 1040, 0xffffff},
})
	stomMultiColorTap("xstap7",{
	{  597,  296, 0x313131},
	{  604,  237, 0xd8d8d8},
	{  598,  142, 0xffffff},
	{  602,  341, 0xffffff},
})
	stomMultiColorTap("xstap8",{
	{  398,   81, 0x656463},
	{  408,   81, 0xffffff},
	{  421,   79, 0x6a6a6a},
	{  420,  110, 0xffffff},
})
	stomMultiColorTap("xstap9",{
	{  203,  471, 0x416578},
	{  120,  363, 0xffffff},
	{  563,  258, 0xdddddd},
	{  553,  289, 0x5f5e5e},
})
	stomMultiColorTap("xstap10",{
	{  338,  567, 0xffffff},
	{  333,  566, 0x363636},
	{  161,  447, 0x060607},
	{  342,  646, 0xffffff},
})
	stomMultiColorTap("xstap11",{
	{   50,  984, 0x0080bb},
	{   53,  919, 0xffffff},
	{   99, 1016, 0xffffff},
	{   29, 1053, 0x232323},
	{  565,  467, 0xb5b4b4},
})
	if stomMultiColorTap("xstap12",{
	{   98,  973, 0x792101},
	{  225,  982, 0x4a0a00},
	{   55,  963, 0xffffff},
	{  568,  263, 0x787975},
})then
		mode=1
	end
	stomMultiColorTap("领取奖励左下",{
	{   69,  294, 0xb4c2c1},
	{  100,  291, 0x355a71},
	{   63,  251, 0x677676},
	{   99,  181, 0x313131},
	{  122,  397, 0x3d9cda},
})
	stomMultiColorTap("领取奖励左下2",{
	{   78,  563, 0x383636},
	{   68,  578, 0x312f30},
	{   54,  567, 0x3b3838},
	{   72,  572, 0x928f7e},
	{   42,  166, 0x484746},
})

end	

function MRFZ1454663939_fight()
	if stomMultiColor("剧情2",{
		{  483,  315, 0xa92927},
		{  553,  238, 0xff463f},
		{  205,  870, 0x3b8dfa},
		{  205,  980, 0x398ff9},
	})then
		modo=2
	end
	if mode==1 then
		if stomMultiColor("1出场",{
			{   40,  609, 0x6c6d6c},
			{   55,  609, 0x6f6c6b},
			{  108,  704, 0x68696c},
			{   13,  609, 0x757679},
		}) then
			stommove(57,  667,313,  646)
			stommSleep(500)
			stommove(321,  650,341,  840)
		end
		if stomMultiColor("2出场",{
			{   20,  715, 0x6d6f70},
			{   40,  715, 0x636462},
			{   70,  715, 0x606265},
			{  108,  730, 0x67696d},
		}) then
			stommove(53,  763,372,  560)
			stommSleep(500)
			stommove(381,  568,401,  716)
		end	
		if stomMultiColor("3出场",{
			{   18,  820, 0x707178},
			{   29,  820, 0x727479},
			{   61,  820, 0x74777c},
			{  108,  834, 0x67696d},
		}) then
			stommove( 48,  872, 383,  632)
			stommSleep(500)
			stommove(395,  652,415,  837)
		end	
	elseif mode==2 then
		if stomMultiColor("1出场",{
			{   40,  609, 0x6c6d6c},
			{   55,  609, 0x6f6c6b},
			{  108,  704, 0x68696c},
			{   13,  609, 0x757679},
		}) then
			stommove(70,  974,408,  736)
			stommSleep(500)
			stommove(321,  650,341,  840)
		end
		if stomMultiColor("2出场",{
			{   20,  715, 0x6d6f70},
			{   40,  715, 0x636462},
			{   70,  715, 0x606265},
			{  108,  730, 0x67696d},
		}) then
			stommove(53,  763,372,  560)
			stommSleep(500)
			stommove(381,  568,401,  716)
		end			
		
	end
end

function create_MRFZ1454663939_main()    --明日方舟
	local tt1 = os.time()
	local time_cha =  math.random(10,15)*60
	local t1 = os.time()
	--local t3 = os.time()
	local flag = 0
	local loop = 0
	mode=0
	local isfrontnum = 0
	while (true) do
		isfront = stomisFrontApp("com.hypergryph.arknights")
		if isfront then
			if isfront == 0 then
				stomrunApp("com.hypergryph.arknights")
				isfrontnum=isfrontnum+1
			end
		else 
			stomrunApp("com.hypergryph.arknights")
			isfrontnum=isfrontnum+1
		end
		if isfrontnum > 5 then
			return 0
		end
		
	if stomMultiColorTap("进入游戏",{
		{   39,  567, 0xffd600},
		{   34,  547, 0xffd600},
		{   33,  588, 0xffd700},
		{   36,  575, 0x000000},
	}) then
			tt1 = os.time()
			time_cha =  math.random(2,4)*60
	end
		MRFZ1454663939_login()
		MRFZ1454663939_close()
		MRFZ1454663939_do()
		MRFZ1454663939_fight()	
		t2 = os.time()
		if t2-t1 > 60 then--定时征兵
			t1 = os.time()
		end

		
		local tt2 = os.time()
		if os.difftime(tt2,tt1) > time_cha then
			return 0
		end
		if stomMultiColorTap("已签到",{
			{  101,  901, 0x292929},
			{   93,  919, 0x786019},
			{  102,  950, 0x423b24},
			{  102,  956, 0xf4b800},
		}) then
			return 0
		end
		--[[i=i+1
		if i>2 then
		i=0
		end]]
		stomLog(tt2-tt1)
		stommSleep(300)
	end
end


function create_MFM_main()    --魔法门hero
	local tt1 = os.time()
	local time_cha =  math.random(40,50)*60
	local t1 = os.time()-40
	--local t3 = os.time()
	local flag = 0
	local loop = 0
	while (true) do
		--OpenApp("com.cg.gcfy.app")

		
	if stomMultiColorTap("进入游戏",{
		{  116,  501, 0xe2d9cb},
		{  113,  528, 0xded5c7},
		{  112,  554, 0xe1d8ca},
		{  104,  615, 0xbfb3a6},
	}) then
			tt1 = os.time()
			time_cha =  math.random(2,4)*60
	end
		
		if loop==0 then

		elseif loop==1 then

		elseif loop==2 then

		end

		t2 = os.time()
		if t2-t1 > 60 then--定时征兵
			t1 = os.time()
		end

		
		local tt2 = os.time()
		if os.difftime(tt2,tt1) > time_cha then
			return 0
		end
		--[[i=i+1
		if i>2 then
		i=0
		end]]
		--stomLog(tt2-tt1)
		stommSleep(300)
	end
end

function create_320479357()		--航班管家-注册
	apple_appid = "320479357"
	local loop = 0
	local t1 = os.time()
	local getloop = 0
	local xiago = 0
	local num = 0
	local fa = 0
	getPhoneType = "lx"
	docks = "1112"
	while (true) do
		stomLog("--com.openet.HBgj--"..loop)
		stommSleep(500);	
		if loop == 0 then
			stomMultiColorTap("跳过广告", {
			{  539,   83, 0x555858},
			{  499,   78, 0x9b9d9d},
			{  529,  114, 0x9b9d9d},
			{  577,   89, 0x787a7b},
		})
			stomMultiColorTap("同意", {
			{  383,  835, 0x1188ff},
			{  421,  851, 0xffffff},
			{  535,  872, 0x1188ff},
			{  265,  846, 0xffffff},
		})			
			stomMultiColorTap("我的", {
			{  560, 1063, 0xffffff},
			{  544, 1084, 0x262626},
			{  574, 1083, 0x262626},
			{  569, 1120, 0x2b2b2b},
		})
			stomMultiColorTap("注册",{
			{  130,  351, 0x1684f1},
			{   75,  337, 0x1e8ffa},
			{  167,  350, 0xffffff},
			{  244,  343, 0x076edf},
		})
			stomMultiColorTap("号码注册", {
			{   67,  373, 0xa9a9a9},
			{   99,  376, 0xafafaf},
			{   58,  157, 0x000000},
			{  181,  538, 0x1188ff},
		})
			if stomMultiColor("号码框11",{
			{  585,  369, 0xcccccc},
			{   56,  156, 0x000000},
			{  587,  381, 0xcccccc},
			{  129,  556, 0x1188ff},
		}) then
				loop = 1
			end
		elseif loop == 1 then
			stomLog("获取号码。。。"..getloop)
			if getloop == 0 then
				check_Rules = 1
				Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
				if Telnum then
					stomLog(Telnum)
					getloop = 1
					num = 0
				else
					stomLog("重新获取号码中")
					stommSleep(2000)
					num = num + 1
				end
				if num > 20 then
					stomLog("获取号码失败")
					return 1
				end
			elseif getloop == 1 then
				phonenumber = Telnum
					if stomMultiColor("号码框",{
					{  585,  369, 0xcccccc},
					{   56,  156, 0x000000},
					{  587,  381, 0xcccccc},
					{  129,  556, 0x1188ff},
				}) then
						stomLog("输入号码"..phonenumber)
						stommSleep(500) 
						stomInpuTextTap( 125,  376, phonenumber, 3)
						stommSleep(500)
					end
				if stomMultiColorTap("号码框已输入",{
					{  585,  369, 0xcccccc},
					{   56,  156, 0x000000},
					{  587,  381, 0xcccccc},
					{  129,  556, 0x1188ff},
					{  202,  556, 0x1188ff},
				}) then	
					xiago = xiago + 1
				end
				if xiago > 5 then
					stomLog("下一步卡点或网络问题")
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					return 1
				end
				if stomMultiColor("验证码界面",{
					{   34,   84, 0x000000},
					{   47,  164, 0x898989},
					{   45,  238, 0x666666},
					{  496,  177, 0xffffff},
				}) then
					getloop = 2
					
				end		
			elseif getloop == 2 then
				stomLog("获取短信...")
				messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
				if messg then
					--messg = string.gsub(messg,"30分","")
					--messg = string.sub(messg,9)
					stommSleep(200)
					yanzhenma = string.match(messg,"%d+")
					stomLog("yanzhenmaOK-"..yanzhenma)
					stomInpuTextTap(113,  438, yanzhenma,3);stommSleep(1000)
					stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)	
					
				else
					stomLog("get sms")
					fa = fa +1
				end	
				if fa > 30 then
					stomLog("获取短信失败")
					stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					return 1
				end
				stommSleep(500)
			end	
		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 300 then
			return 1
		end
	end

end
function userout()
	if stomMultiColor("已登录",{
		{   39,  332, 0x000000},
		{   76,   92, 0x007aff},
		{  105,  330, 0x060606},
		{  202,  331, 0xffffff},
	}) and outnum == 0 then
		stomtap(250,250)
		outnum = 1
		stommSleep(2000)
	end
	if stomMultiColor("已登录-12",{
		{   46,  320, 0x000000},
		{   70,  334, 0x101010},
		{  107,  330, 0x5d5d5d},
		{  149,  334, 0x000000},
	}) and outnum == 0 then
		stomtap(250,250)
		outnum = 1
		stommSleep(2000)
	end	
	
	if outnum == 1 then
		stomtoast("已注销,等待网络延迟")
		downloadloop=1
	end
	if stomMultiColor("注销",{
		{  261,  602, 0xf9f9fa},
		{  307,  600, 0x007aff},
		{  298,  621, 0x007aff},
	}) then
		stomtap(315,  637)
	end
	if stomMultiColor("注销-12",{
		{  265,  600, 0x007aff},
		{  302,  600, 0x007aff},
		{  338,  598, 0x007aff},
		{  370,  590, 0x007aff},
	}) then
		stomtap(315,  623)
	end
	if stomMultiColor("未登录",{
		{   36,  231, 0x007aff},
		{   43,  241, 0x007aff},
		{   43,  253, 0x037bff},
		{   87,  243, 0xffffff},
	}) then
		downloadloop=1
	end
	if stomMultiColor("未登录-12",{
		{   46,  236, 0x007aff},
		{   39,  236, 0x007aff},
		{   47,  241, 0x007aff},
		{   47,  255, 0x007aff},
		{   77,  228, 0x007aff},
	}) then
		downloadloop=1
	end	


	stomMultiColorTap("取消",{
		{  300,  712, 0x007aff},
		{  300,  723, 0x007aff},
		{  336,  716, 0x89a4ec},
		{  304,  441, 0x000000},
	})
	stomMultiColorTap("取消",{
		{  157,  464, 0x007aff},
		{  157,  477, 0x007aff},
		{  176,  479, 0x007aff},
		{  199,  251, 0x000000},
	})
	stomMultiColorTap("取消",{
		{  164,  647, 0x007aff},
		{  164,  660, 0x0b7dfe},
		{  337,  491, 0x000000},
		{  356,  498, 0x706c6d},
	})
	stomMultiColorTap("取消",{
		{  156,  432, 0x007aff},
		{  156,  444, 0x007aff},
		{  176,  444, 0x007aff},
		{  198,  223, 0x000000},
	})
	
	stomMultiColorTap("纵向设置",{
		{  442,  668, 0x007aff},
		{  428,  671, 0x007aff},
		{  471,  664, 0x007aff},
		{  472,  682, 0x007aff},
	})
	stomMultiColorTap("15分钟后需要",{
		{  357,  705, 0x007aff},
		{  409,  704, 0x56a5fd},
		{  466,  704, 0x007aff},
		{  362,  448, 0x000000},
	})	
	if stomMultiColor("储存密码",{
		{  376,  473, 0x000000},
		{  401,  468, 0x000000},
		{  437,  457, 0x656565},
		{  483,  467, 0x000000},
	})then
		stomtap(186,  679)
	end
end

function download()
	stomMultiColorTap("获取",{
			{  546,  322, 0x0080fc},
			{  546,  335, 0x0080fc},
			{  568,  326, 0x0080fc},
			{  583,  336, 0x0080fc},
		})
	stomMultiColorTap("安装",{
			{  548,  330, 0x19ab20},
			{  556,  330, 0x19ab20},
			{  576,  333, 0x19ab20},
			{  572,  324, 0x19ab20},
		})
	stomMultiColorTap("下载",{
			{  584,  342, 0x0080fc},
			{  584,  350, 0x0080fc},
			{  574,  340, 0x7f7f7f},
			{  595,  340, 0x7f7f7f},
		})	
	stomMultiColorTap("现有id",{
			{  240,  537, 0x097eff},
			{  278,  540, 0x007aff},
			{  445,  537, 0x0c7ffe},
			{  446,  550, 0x007aff},
		})
	if stomMultiColor("用户名未输入",{
		{   97,  297, 0xd2d2d7},
		{  111,  297, 0xc7c7cd},
		{  129,  296, 0xc7c7cd},
		{  143,  296, 0xc7c7cd},
	}) or stomMultiColor("用户名未输入EN",{
		{   99,  332, 0xc8c8ce},
		{  111,  333, 0xc7c7cd},
		{  135,  333, 0xc7c7cd},
		{  152,  333, 0xc7c7cd},
	}) then
		stommSleep(500)
		stomInpuText(userid)
		stommSleep(500)
	elseif stomMultiColor("用户密码未输入EN",{
		{  103,  371, 0xc7c7cd},
		{  104,  389, 0xc7c7cd},
		{  137,  380, 0xc7c7cd},
		{  138,  370, 0xc7c7cd},
	}) or stomMultiColor("用户密码未输入",{
		{  100,  345, 0xc7c7cd},
		{  103,  354, 0xc7c7cd},
		{  121,  343, 0xc7c7cd},
		{  137,  344, 0xc7c7cd},
	})then
		stommSleep(500)
		stomtap(604, 1108)
		stommSleep(500)
		stomInpuText(userpassword)
		stommSleep(500)
		stomtap(448,  475)
	end
	stomMultiColorTap("纵向设置",{
		{  442,  668, 0x007aff},
		{  428,  671, 0x007aff},
		{  471,  664, 0x007aff},
		{  472,  682, 0x007aff},
	})
	stomMultiColorTap("15分钟后需要",{
		{  357,  705, 0x007aff},
		{  409,  704, 0x56a5fd},
		{  466,  704, 0x007aff},
		{  362,  448, 0x000000},
	})	
	if stomMultiColor("储存密码",{
		{  376,  473, 0x000000},
		{  401,  468, 0x000000},
		{  437,  457, 0x656565},
		{  483,  467, 0x000000},
	})then
		stomtap(186,  679)
	end
	--[[stomMultiColorTap("再试一次",{
		{  404,  645, 0x007aff},
		{  403,  658, 0x007aff},
		{  445,  644, 0x007aff},
		{  445,  657, 0x007aff},
	})]]
	stomMultiColorTap("下载验证",{
		{  446,  649, 0x007aff},
		{  446,  666, 0x007aff},
		{  444,  551, 0x000000},
		{  481,  549, 0x000000},
	})
	if stomMultiColor("已登录",{
		{   39,  341, 0x000000},
		{   62,  329, 0x000000},
		{  127,  330, 0x6a6a6a},
		{  157,  335, 0xffffff},
	}) then
		stomopenURL(appurl..appid)
	end
	if stomMultiColor("只输密码",{
		{  103,  386, 0xc7c7cd},
		{  100,  396, 0xc7c7cd},
		{  137,  395, 0xc7c7cd},
		{  130,  395, 0xc7c7cd},
	}) then
		stommSleep(500)
		stomInpuText(userpassword)
		stommSleep(500)
		stomtap(461,  487)		
	end
	
	if stomMultiColor("只输密码-12",{
		{  129,  507, 0x8d8d93},
		{  154,  504, 0x8d8c92},
		{  165,  506, 0x8d8c92},
		{  497,  503, 0x898990},
		{  321,  581, 0x007aff},
	}) then
		stommSleep(500)
		stomInpuText(userpassword)
		stommSleep(500)
		stomtap(365,  606)		
	end	
	stomMultiColorTap("现有id-12",{
		{  240,  538, 0x007aff},
		{  239,  528, 0x027bff},
		{  281,  529, 0x007aff},
		{  447,  530, 0x007aff},
	})
	if stomMultiColor("用户名未输入-12",{
		{   96,  295, 0xc7c7cd},
		{  103,  295, 0xc7c7cd},
		{  111,  294, 0xc7c7cd},
		{  142,  285, 0xc7c7cd},
	}) or stomMultiColor("用户名未输入EN-12",{
		{   95,  333, 0xc7c7cd},
		{  103,  333, 0xc7c7cd},
		{  111,  333, 0xc7c7cd},
		{  142,  322, 0xc7c7cd},
	}) then
		stommSleep(500)
		stomInpuText(userid)
		stommSleep(500)
	--[[elseif stomMultiColor("用户密码未输入EN",{
		{  103,  371, 0xc7c7cd},
		{  100,  381, 0xc7c7cd},
		{  121,  379, 0xc7c7cd},
		{  137,  380, 0xc7c7cd},
	}) or stomMultiColor("用户密码未输入",{
		{  100,  342, 0xc7c7cd},
		{  104,  351, 0xc7c7cd},
		{  123,  333, 0xc7c7cd},
		{  137,  342, 0xc7c7cd},
	})then
		stommSleep(500)
		stomtap(604, 1108)
		stommSleep(500)
		stomInpuText(userpassword)
		stommSleep(500)
		stomtap(448,  475)]]
	end
	stomMultiColorTap("安装-12",{
		{  303, 1033, 0xffffff},
		{  270, 1012, 0x007aff},
		{  312, 1059, 0x007aff},
		{  369, 1020, 0x007aff},
	})
	if stomMultiColorTap("验证失败-12",{
		{  129,  507, 0x8d8d93},
		{  154,  504, 0x8d8c92},
		{  165,  506, 0x8d8c92},
		{  497,  503, 0x898990},
		{  321,  581, 0x007aff},
	}) or stomMultiColorTap("验证失败",{
		{  164,  644, 0x1e83fa},
		{  164,  656, 0x1e83fa},
		{  164,  660, 0x0b7dfe},
		{  336,  497, 0x000000},
		{  369,  492, 0x5a5858},
	})then
		logincount = logincount +1
	end	
	stomMultiColorTap("15分钟后需要",{
		{  356,  700, 0x007aff},
		{  356,  709, 0x007aff},
		{  367,  701, 0x007aff},
		{  548,  706, 0x007aff},
		{  550,  694, 0x007aff},
	})	
	
end

function hddownload(down_appid,down_userid,down_userpassword)
	appurl="https://apps.apple.com/cn/app/id"
	appid=down_appid
	userid=down_userid
	userpassword=down_userpassword
	downloadloop=0
	outnum = 0
	--count = 0
	logincount = 0
	stomopenURL("prefs:root=STORE");
	time_start=os.time()
	while (true) do
		if downloadloop == 0 then
			downloadstart=os.time()
			userout()
		elseif downloadloop == 1 then
			downloadstart=os.time()
			stomopenURL(appurl..appid)
			downloadloop=2
		elseif downloadloop == 2 then
			download()
		end
		downloadend=os.time()
		if downloadend-downloadstart >300 then
			downloadloop = 1
			--count = count +1
		end
		if stomMultiColor("下载中",{
			{  586,  326, 0x0080fc},
			{  586,  337, 0x0080fc},
			{  580,  337, 0x0080fc},
			{  580,  326, 0x0080fc},
			{  579,  307, 0x0080fc},
		}) then
			downloadloop=0
		end		
		if stomMultiColor("可以打开-12",{
			{  285,  292, 0x007aff},
			{  389,  290, 0x007aff},
			{  314,  294, 0xffffff},
			{  359,  293, 0xffffff},
			{  328,  306, 0xffffff},
		}) or stomMultiColor("可以打开",{
			{  548,  307, 0x0080fc},
			{  587,  307, 0x0080fc},
			{  608,  329, 0x0080fc},
			{  573,  330, 0x0080fc},
		})then
			return 0
		end
		time_end=os.time()
		if logincount >=3 or time_end - time_start > 1800 then
			return 1
		end
		stommSleep(1000)
	end
end

function hdtap(x,y)
	local ranx=math.random(-2,2)
	local rany=math.random(-2,2)
	stomtap(x+ranx,y+rany)
end

function DLDL_cz()
	if stomMultiColor("充值界面",{
		{  251,  243, 0xf57d0d},
		{  253,  440, 0xf5810f},
		{  512,  381, 0xf3c8a4},
		{  510,  479, 0xb6f653},
	}) then
		yanzhengtoast=0
		while (true) do
			stomLog("充值模式")
			shopapplestore()
			isfront = stomisFrontApp("com.apple.MobileSMS")
			if isfront==1 then
				break
			end
			if yanzhengtoast == 0 then
				stomopenURL("prefs:root=STORE");
				stomtoast("请检查是否需要注销并返回游戏")
				stommSleep(8000)
			end	
			isfront = stomisFrontApp("com.qidea.dldl.yuewen")
			if isfront==1 then
				yanzhengtoast =1
			end				

		end
	end
end
--[[
function DL1300066093_fn_do()
	stomMultiColorTap("跳过剧情",{
		{  586,  960, 0xffeebc},
		{  576,  946, 0x875f31},
		{  585,  924, 0x724523},
		{  584, 1021, 0xe2c072},
	})
	stomMultiColorTap("跳过剧情",{
		{  586,  960, 0xffeebc},
		{  576,  946, 0x875f31},
		{  585,  924, 0x724523},
		{  584, 1021, 0xe2c072},
	})
	stomMultiColorTap("跳过剧情",{
		{  586,  960, 0xffeebc},
		{  576,  946, 0x875f31},
		{  585,  924, 0x724523},
		{  584, 1021, 0xe2c072},
	})
	stomMultiColorTap("跳过剧情",{
		{  586,  960, 0xffeebc},
		{  576,  946, 0x875f31},
		{  585,  924, 0x724523},
		{  584, 1021, 0xe2c072},
	})
	stomMultiColorTap("跳过剧情",{
		{  586,  960, 0xffeebc},
		{  576,  946, 0x875f31},
		{  585,  924, 0x724523},
		{  584, 1021, 0xe2c072},
	})
	stomMultiColorTap("跳过剧情",{
		{  586,  960, 0xffeebc},
		{  576,  946, 0x875f31},
		{  585,  924, 0x724523},
		{  584, 1021, 0xe2c072},
	})
	stomMultiColorTap("跳过剧情",{
		{  586,  960, 0xffeebc},
		{  576,  946, 0x875f31},
		{  585,  924, 0x724523},
		{  584, 1021, 0xe2c072},
	})
	stomMultiColorTap("跳过剧情",{
		{  586,  960, 0xffeebc},
		{  576,  946, 0x875f31},
		{  585,  924, 0x724523},
		{  584, 1021, 0xe2c072},
	})
	stomMultiColorTap("跳过剧情",{
		{  586,  960, 0xffeebc},
		{  576,  946, 0x875f31},
		{  585,  924, 0x724523},
		{  584, 1021, 0xe2c072},
	})
	-- body
end--]]

function DL1300066093_fn_close()
	stomMultiColorTap("跳过剧情",{
		{  586,  960, 0xffeebc},
		{  576,  946, 0x875f31},
		{  585,  924, 0x724523},
		{  584, 1021, 0xe2c072},
	})
	stomMultiColorTap("zhuce1",{
	{   89,  519, 0xee9c0a},
	{   68,  515, 0xee9c0a},
	{   79,  515, 0xffffff},
})
	stomMultiColorTap("userlogin.1",{
	{   81,  345, 0xf5a623},
	{   93,  304, 0xf5a623},
	{   70,  319, 0xffffff},
	{  107,  321, 0xf5a623},
})
	stomMultiColorTap("userlogin.2",{
	{  227,  626, 0x007aff},
	{  218,  658, 0x007aff},
	{  226,  681, 0x007aff},
	{  224,  720, 0x007aff},
})
	stomMultiColorTap("游戏公告",{
		{   89,  561, 0xa84416},
		{  582,  530, 0xfde336},
		{  573,  584, 0xfbd140},
		{  575,  628, 0x91231f},
	})
	stomMultiColorTap("进入游戏",{
		{   81,  567, 0xdf5e07},
		{   89,  554, 0xfefbd3},
		{   81,  610, 0xfff6b8},
		{   95,  595, 0xf7e0b8},
	})
	stomMultiColorTap("游戏公告",{
	{   88,  564, 0xfbf5af},
	{  583,  460, 0x9f2f2e},
	{  582,  661, 0x9f2f2e},
})
	if stomMultiColor("对话",{
		{  187,  672, 0x8f6a52},
		{  187,  618, 0x8a664f},
		{  187,  585, 0x8a674f},
		{  187,  542, 0x8a6750},
	}) then
		stomtap(89,  395)
	end
	stomMultiColorTap("跳过剧情N",{
	{  585,  966, 0xffeebc},
	{  584,  923, 0xc9a97d},
	{  585,  974, 0xdac197},
	{  586,  995, 0x926848},
})
	stomMultiColorTap("跳过剧情2",{
		{  609, 1042, 0xefdcae},
		{  614, 1023, 0xc5b39c},
		{  607, 1072, 0x9b7953},
	})
	stomMultiColorTap("B级角色",{
		{  442,  901, 0x2a3b89},
		{  422,  901, 0x2d4091},
		{  400,  901, 0x2f459b},
		{  386,  901, 0x3148a0},
	})
	stomMultiColorTap("B级角色2",{
		{  447,  486, 0x45cfff},
		{  447,  494, 0x45cfff},
		{  447,  504, 0x45cfff},
		{  416,  481, 0x037dab},
	})
	stomMultiColorTap("后退高亮",{
		{  625,   83, 0x784b28},
		{  620,  650, 0x5d6969},
		{  624,  857, 0x536311},
	})
	stomMultiColorTap("B级角色获取",{
	{  548,  850, 0x2be6ff},
	{  546,  884, 0x2ae5ff},
	{  500,  870, 0x03a6e6},
	{  500,  849, 0x02a8e5},
})
	stomMultiColorTap("第一章引导",{
	{  483,  462, 0xffdd62},
	{  490,  462, 0xdecd73},
	{  484,  497, 0xdfbd51},
	{  483,  507, 0xa4802c},
})
	stomMultiColorTap("跳过剧情3",{
	{  592, 1010, 0x796342},
	{  593, 1036, 0xb69c73},
	{  586, 1050, 0x78552c},
	{  600, 1054, 0xdbceb3},
})
	--[[stomMultiColorTap("战斗快进",{
	{  331,  990, 0xfee9b0},
	{  309,  990, 0xd87a40},
	{  320,  990, 0xcf7137},
})]]
	stomMultiColorTap("1-2能打",{
	{  262,  278, 0x89461b},
	{  196,  125, 0x8b481c},
	{  295,  437, 0xbababa},
	{  213,  273, 0xf8f8f6},
})
	stomMultiColorTap("boss",{
	{  490,  129, 0xf0dd9a},
	{  467,  128, 0xedd68a},
	{  452,  141, 0xeed476},
	{  596,  117, 0x2dfffe},
})
	stomMultiColorTap("突破成功",{
	{  557,  752, 0xe2c47a},
	{  566,  812, 0xdec68f},
	{  555,  871, 0xdebf74},
	{  399,  648, 0x762227},
})
	stomMultiColorTap("游客登录",{
	{  215,  623, 0x007aff},
	{  206,  656, 0x007aff},
	{  413,  351, 0x010101},
})
	stomMultiColorTap("游戏公告",{
		{   89,  548, 0xffffdd},
		{  573,  574, 0xfdba0c},
		{  568,  564, 0x9d2d2c},
		{  579,  608, 0x9f2f2e},
	})
	stomMultiColorTap("进入游戏",{
	{   90,  554, 0xfefbd6},
	{   82,  512, 0xfff6ba},
	{   81,  500, 0xd44b00},
	{   81,  645, 0xd44b00},
})
	stomMultiColorTap("跳过剧情",{
	{  608, 1042, 0xffeebc},
	{  608, 1027, 0xffeebc},
	{  608, 1000, 0x562710},
	{  605, 1094, 0xd39a42},
})
	stomMultiColorTap("第一章引导",{
	{  483,  462, 0xffdd66},
	{  485,  499, 0xffee88},
	{  486,  536, 0xffdd66},
	{  477,  536, 0xffdd55},
})
	stomMultiColorTap("跳过剧情",{
	{  594, 1024, 0x532608},
	{  592, 1012, 0xffeebc},
	{  590,  985, 0x542606},
	{  591, 1082, 0xd39a42},
})

	if stomMultiColor("武魂殿",{
		{  437,  713, 0x562609},
		{  437,  735, 0x552507},
		{  438,  750, 0x764d33},
		{  460,  762, 0xfaeee4},
	}) then
		stomtap(121,  815)
	end
	if stomMultiColor("召唤1",{
		{  524,  433, 0x58290b},
		{  524,  442, 0x59290c},
		{  513,  461, 0x552507},
		{  516,  470, 0x8f6b54},
	}) then
		stomtap(285,  352)
	end
	if stomMultiColor("免费试用召唤",{
		{  138,  360, 0xfad4aa},
		{  138,  364, 0xffd7ac},
		{  132,  364, 0xffd7ac},
		{  612,  587, 0xf6d494},
	}) then
		stomtap( 74,  415)
	end
	if stomMultiColor("获得角色",{
	{  583,  583, 0xe4d2a8},
	{  578,  611, 0xddc589},
	{  577,  674, 0xdec686},
	{  573,  706, 0xa3302f},
}) then
		stomtap(69,  401)
	end
	if stomMultiColor("高级召唤",{
	{  521,  854, 0x96745e},
	{  516,  855, 0x9f7f69},
	{  520,  876, 0x552507},
	{  512,  870, 0x9a7963},
}) then
		stomtap(289,  799)
	end
	if stomMultiColor("抽奖结束返回",{
		{   72,  762, 0xffffff},
		{   72,  787, 0x978577},
		{   63,  806, 0xffffff},
		{   63,  821, 0xdbd4d0},
	}) then
		stommSleep(500)
		stomtap(617,  127)
	end
	if stomMultiColor("起名",{
	{  451,  707, 0xe96403},
	{  441,  707, 0xe96403},
	{  448,  732, 0xe96403},
	{  450,  759, 0x865436},
}) then
		stomtap(365,  784)
		stommSleep(500)
		stomtap(211,  638)		
	end
	if stomMultiColor("引导战斗任务",{
	{  466,  539, 0x552507},
	{  460,  537, 0x552507},
	{  462,  605, 0x552507},
	{  468,  630, 0x663a1e},
}) then
		stomtap(206,  558)
	end
	if stomMultiColor("战斗去第一章",{
	{  286,  472, 0xfff2c5},
	{  294,  492, 0xfff2c5},
	{  296,  513, 0xfff2c5},
	{  299,  529, 0x180701},
}) then
		stomtap(229,  249)
	end
	if stomMultiColor("1-1",{
	{  373,  259, 0x552507},
	{  367,  276, 0x6e4429},
	{  368,  308, 0x552507},
	{  370,  166, 0x94715b},
}) then
		stomtap(202,  128)
	end
	if stomMultiColor("灰色进入战斗",{
	{  179,   89, 0x60533f},
	{  174,  102, 0x675945},
	{  174,  110, 0x675945},
	{  179,  217, 0x5e661e},
}) or stomMultiColor("亮色进入战斗",{
	{  172,   89, 0xd5b98b},
	{  177,   89, 0x81734a},
	{  175,  102, 0xfbd9a7},
	{  177,  215, 0xd5f428},
})  then
		stomtap(138,  975)
	end
	if stomMultiColor("上阵",{
	{  330,  234, 0x552507},
	{  341,  234, 0x552507},
	{  339,  247, 0x866048},
	{  338,  300, 0x552507},
}) then
		stomtap(126,  152)
	end
	if stomMultiColor("上阵2",{
	{   95,  275, 0x2c6308},
	{  103,  275, 0x2c6308},
	{  167,  336, 0x517d35},
	{  167,  322, 0x558446},
})or stomMultiColor("无法开始战斗",{
	{  153, 1046, 0x623612},
	{   68, 1006, 0x623713},
	{   91, 1097, 0x5c2709},
	{  225,   59, 0x696566},
}) then
		stomtap(120,  333)
	end
	if stomMultiColor("开始战斗",{
	{  231,   75, 0xdc6633},
	{  225,   60, 0xfff5f9},
	{  218,   60, 0xfff5f9},
	{  229,  118, 0xca5527},
}) then
		stomtap(129, 1042)
	end
	if stomMultiColor("二技能",{
	{   13,  560, 0xff7f76},
	{   13,  564, 0xff7f75},
	{    6,  564, 0xed413b},
	{    6,  560, 0xe7433c},
}) then
		stomtap(82,  670)
	end
	if stomMultiColor("一技能",{
	{   13,  321, 0xff9886},
	{   13,  330, 0xff9886},
	{    6,  330, 0xff5144},
	{    6,  321, 0xff5145},
}) then
		stomtap(82,  433)
	end
	if stomMultiColor("战斗奖励",{
	{  274,  838, 0xffdd9d},
	{  282,  801, 0xd9c09c},
	{  273,  854, 0xc6995b},
	--{  275,  880, 0xc38c57},
}) then
		stomtap(74,  847)
	end
	if stomMultiColor("升级",{
	{  528,  586, 0xddc68f},
	{  547,  587, 0xfcfaf2},
	{  549,  662, 0xfdfcf5},
	{  524,  663, 0xdbc080},
}) then
		stomtap(74,  847)
	end
	if stomMultiColor("离开毒药",{
	{  473,  401, 0x734a2f},
	{  473,  424, 0x5c2d10},
	{  465,  426, 0x5c2d10},
	{  439,  338, 0x552507},
}) then
		stommove( 210,  208,326,  456)
	end
	if stomMultiColor("任务被拉出",{
	{  187, 1035, 0x957a4b},
	{  213, 1035, 0x927645},
	{  230, 1035, 0x8e7344},
	{  213,  273, 0x4b4b4a},
}) then
		stomtap(510, 1074)
	end	
	if stomMultiColor("1-2不能打",{
	{  213,  263, 0x696969},
	{  213,  272, 0x666665},
	{  205,  287, 0x696969},
	{  256,  273, 0x5f4b20},
}) then
		stomtap(590, 1080)
	end
	if stomMultiColor("人物界面",{
	{  130,   65, 0xa2f78b},
	{  129,   88, 0xa2f78b},
	{  127,  109, 0xa2f78b},
	{  126,  130, 0x599648},
}) then
		stomtap(300,  105)
	end
	if stomMultiColor("小舞1高亮",{
	{  548,  386, 0xa2f78b},
	{  542,  386, 0xa2f78b},
	{  555,  407, 0x386929},
	{  527,  160, 0xcf2e2e},
}) then
		stomtap(499,  122)
	end
	if stomMultiColor("突破",{
	{  258,  889, 0x552507},
	{  260,  911, 0x552507},
	{  258,  908, 0x5c2d10},
	{  256,  907, 0xa98b78},
}) then
		stomtap(83,  688)
	end
	if stomMultiColor("对话备用",{
	{   11,   93, 0x7b5f4c},
	{   11,  106, 0x7b5e4c},
	{   11,  118, 0x7b5e4c},
	{   11,  133, 0x7c604d},
}) then
		stomtap(133,  457)
	end
	if stomMultiColor("小舞突破不够退出",{
	{  155,  686, 0xb61010},
	{  155,  678, 0xb61010},
	{  155,  701, 0xb61010},
	{  500,  299, 0xa2f78b},
}) then
		stomtap(613,  134)
	end
	if stomMultiColor("进入副本",{
	{  243,  653, 0x87684d},
	{  243,  659, 0xe9e1c8},
	{  217,  655, 0xede6cd},
	{  225,  655, 0xede6cd},
}) then
		stomtap(209,  557)
	end
	if stomMultiColor("需要打1-2",{
	{  302,  437, 0x565656},
	{  189,  123, 0xe5b64d},
	{  239,  122, 0xfeee4f},
}) then
		stomtap(267,  274)
	end
	if stomMultiColor("1-3能打",{
	{  353,  613, 0xfdfdfd},
	{  263,  277, 0x8d4a1d},
	{  304,  274, 0xfeea3b},
	{  213,  274, 0xf8f8f6},
}) then
		stomtap(318,  438)
	end
	if stomMultiColor("1-4能打",{
	{  253,  384, 0xcfc5be},
	{  345,  387, 0xfeec35},
	{  240,  806, 0xb9b9b9},
	{  303,  389, 0x8b4b1f},
}) then
		stomtap(329,  572)
	end
	if stomMultiColor("1-5不能打",{
	{  198,  557, 0x696969},
	{  197,  567, 0x646362},
	{  205,  582, 0x626160},
	{  252,  572, 0x1c5758},
}) then
		local i = math.random(0,1) 	
		if i==0 then				
			hdtap(501, 1076)--任务
		else 
			hdtap(594, 1075)--列表
		end
		stomtap(594, 1075)
	end
	if stomMultiColor("1-5能打",{
	{  382,  317, 0xeeb034},
	{  429,  329, 0xfeec38},
	{  241,  729, 0x5d5d5d},
}) then
		local i = math.random(0,2) 	
		if i==0 then				
			hdtap(255,  563)--任务
		elseif i==1 then
			hdtap(594, 1075)--列表
		else
			hdtap(340,  446)--baoxiang
		end
		--stomtap(255,  563)
	end

	if stomMultiColor("装备2高亮",{
	{  546,  386, 0xa2f78b},
	{  552,  386, 0xa2f78b},
	{  555,  407, 0x386929},
	{  408,  160, 0xcf2e2e},
}) then
		stomtap(369,  121)
	end
	if stomMultiColor("突破任务2",{
	{  354,  635, 0x552407},
	{  351,  635, 0x552407},
	{  347,  635, 0x552407},
	{  501,  299, 0xa2f78b},
}) then
		stomtap(64,  690)
	end
	if stomMultiColor("装备3高亮",{
	{  230,  349, 0xcf2f2e},
	{  500,  299, 0xa2f78b},
	{  495,  299, 0xa2f78b},
	{  506,  299, 0xa2f78b},
}) or stomMultiColor("装备3高暗",{
	{  504,  299, 0x426639},
	{  498,  299, 0x426639},
	{  500,  297, 0x0f2109},
	{  505,  442, 0x65594b},
})then
		stomtap(189,  314)
	end
		if stomMultiColor("突破任务3",{
	{  347,  623, 0x552407},
	{  355,  623, 0x552407},
	{  355,  636, 0x552407},
	{  500,  299, 0xa2f78b},
	{  185,  687, 0x659917},	
}) or stomMultiColor("突破任务3高暗",{
	{  350,  457, 0x322213},
	{  353,  457, 0x322213},
	{  507,  299, 0x426639},
	{  501,  299, 0x426639},
})then
		stomtap( 80,  687)
	end
	if stomMultiColor("装备4高亮",{
	{  128,  349, 0xcf2e2e},
	{  507,  299, 0xa2f78b},
	{  502,  299, 0xa2f78b},
	{  498,  299, 0xa2f78b},
}) then
		stomtap(91,  310)
	end
	if stomMultiColor("魂师突破",{
	{  268,  872, 0x5e2f12},
	{  267,  888, 0x663a1e},
	{  257,  908, 0x5c2d10},
	{  258,  910, 0x997761},
}) then
		stomtap( 64,  863)
	end
	if stomMultiColor("击杀引导",{
	{  517,  867, 0x552507},
	{  515,  802, 0x552507},
	{  515,  823, 0x693d22},
	{  522,  824, 0x9f7f6a},
}) then
		stomtap(372, 1014)
	end
	if stomMultiColor("满",{
	{   50,  219, 0xffa400},
	{   56,  219, 0xffc000},
	{   56,  210, 0xffbc00},
	{   49,  210, 0xff9f00},
}) then
		local i = math.random(0,1) 	
		if i==0 then				
			hdtap(79,  283)--任务
		else
			hdtap(614,  133)--baoxiang
		end
		--stomtap( 64,  863)
	end
	if stomMultiColor("魂师突破",{
	{  268,  872, 0x5e2f12},
	{  267,  888, 0x663a1e},
	{  257,  908, 0x5c2d10},
	{  258,  910, 0x997761},
}) then
		stomtap(77,  279)
	end
	if stomMultiColor("1-2开始",{
	{  208,  130, 0x104346},
	{  278,  282, 0x104346},
	{  313,  444, 0x343434},
	{  213,  274, 0x4b4b4a},
}) then
		stomtap(508, 1079)
	end	
end



function creat_dl1300066093_main()
	applePWD = applePWDs or "Zxc112211"
	myosver = get1osver()
	dltime_cha =  math.random(20,25)*60
	local t1 = os.time()
	local loop = 0	--主线开关
	local dl_flag = false--判断是否进入游戏
	--zhuceflag = 0	--注册开关
	MODEsw=0--注册开关 =2时程序结束
	lilian =0 --历练开关(默认开)
	timestarts = os.time()
	local isfrontnum = 0
	bid="com.qidea.dldl.yuewen"
	while (true) do
		isfront = stomisFrontApp("com.qidea.dldl.yuewen")
		if isfront then
			if isfront == 0 then
				stommSleep(5000)
				stomLog("打开了游戏")
				stomrunApp("com.qidea.dldl.yuewen")
				isfrontnum=isfrontnum+1
			end
		else 
			stommSleep(5000)
			stomLog("打开了游戏")
			stomrunApp("com.qidea.dldl.yuewen")
			isfrontnum=isfrontnum+1
		end
		if isfrontnum > 7 then
			return 0
		end
		timeend =os.time()
		if loop==0 then
			DL1300066093_fn_close()
			--DL1300066093_fn_do()
			DLDL_cz()	
		elseif loop==1 then	

		end
		if timeend-timestarts < 10 then
			color1 = getColor(364,  380)
			color2 = getColor(331,  638)
			color3 = getColor(548,  568)
		end
		if timeend-timestarts >=30 and timeend-timestarts <= 31 or  timeend-timestarts >=60 and timeend-timestarts <= 61 then--卡顿比色
			color11 = getColor(364,  380)
			color22 = getColor(331,  638)
			color33 = getColor(548,  568)	
			if color1==color11 and  color2==color22 and color3==color3 then
				stomtap(488,  152)
				--SW1282917929_fn_renwujiance()
			end
			color1 = getColor(364,  380)
			color2 = getColor(331,  638)
			color3 = getColor(548,  568)
			stommSleep(2000)
		end		
		if timeend-timestarts > 61 then--定时升级技能
			timestarts = os.time()
			color11 = getColor(364,  380)
			color22 = getColor(331,  638)
			color33 = getColor(548,  568)	
			if color1==color11 and color2==color22 and color3==color3 then
				stomtap(600,1000)
				stommSleep(200)
			end
			stomMultiColorTap("长时间不动备用点击",{
			{  452,  964, 0xffff42},
		})
			--SW1282917929_fn_shengjiineng()
		end
		local t2 = os.time()
		swNowtime=t2-t1
		SW1282917929_fn_pro()
		if os.difftime(t2,t1) > dltime_cha then
			return 0
		end
		if stomMultiColor("服务器异常",{
			{  518,  525, 0xffef7b},
			{  513,  555, 0xffef73},
			{  454,  629, 0xe7cf39},
			{  377,  507, 0xefcf31},
			{  451,  486, 0x9c6910},
		}) or stomMultiColor("服务器维护重试2",{
			{  461,  420, 0x9c6910},
			{  461,  424, 0x9c6910},
			{  465,  438, 0x845510},
			{  454,  486, 0xe7cb31},
		})then
			return 0 	
		end
		if stomMultiColor("账号双重认证",{
			{  501,  547, 0x635d5a},
			{  502,  559, 0x000000},
			{  497,  611, 0x000000},
			{  199,  509, 0x1086f7},
		}) then
			slion_account_status=1
			return 0 
		end
		if stomMultiColor("使用第三方封号",{
			{  509,  225, 0x000000},
			{  543,  234, 0x000000},
			{  503,  282, 0x000000},
			{  529,  287, 0x716761},
			{  763,  286, 0x000000},
		})  then
			slion_account_status=2
			return 0 
		end
		if stomMultiColor("需要滑动验证",{
		   {  463,  283, 0x4a9ac6},
		   {  441,  761, 0x4a8ece},
		   {  159,  295, 0xe7c76b},
		   {  159,  753, 0x3179c6},
		  })  then
			--slion_game_level=3
			return 0 
		end
		if MODEsw==2 then
			return 0
		end
--------------

--------------
		stomLog("当前阶段"..loop)
		--if t4-t3>1200 then break end

		stommSleep(999)
	end
end
--creat_dl1300066093_main()