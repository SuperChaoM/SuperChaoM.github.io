os.execute = System.execute2
SLionLUA = {}
SLionLUA["SlionVersion"]= "191123.220752"
SLionLUA["debug"] = "1"
SLionLUA["status"] = 1
SLionLUA["xtbcon"] = 1
SLionLUA["Telnum"] = "0"
SLionLUA["createpasswd"] = "0"
SLionLUA["UserID"] = "45701"
SLionLUA["UserKey"] = "1DE9040BA593C651A470"
SLionLUA["docks"]= "F7E2BEBD74DFCC4"
SLionLUA["provinceOK"] = "000"
SLionLUA["ksuidOK"] = "000"
SLionLUA["VPN_variables"] = 1
SLionLUA["VER"] = "1912071320"



--[[
修改：System.isFrontApp

    local isFrontApp = System.isFrontApp("com.duoyi.shenwu3")
    stomLog(isFrontApp)
    
    返回 number
    1

添加  whoAmI()

    local isApp = whoAmI()
    stomLog(isApp)
    
    返回 number
    100
    
添加     System.putLog


    System.putLog("显示内容",int类型)
    System.putLog("显示内容",1)
    
    1, 警告
    0, 正常

    
 while 1 do
    System.putLog("测试10000 警告",1)
    Thread.sleep(5*1000)
    
    System.putLog("测试10000 正常",0)
    Thread.sleep(5*1000)
end

tasktype = 0,新增；1,留存
taskid
apple_appid
apple_bid


]]
