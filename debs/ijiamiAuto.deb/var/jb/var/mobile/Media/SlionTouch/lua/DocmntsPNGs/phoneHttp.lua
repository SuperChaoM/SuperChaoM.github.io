error_60ma = ""
function getTelnum_60ma_st(userID,userKey,docks1,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
	--userID,userKey 登录返回的 
	--docks 对接码组合 (请从客户端查看对接码) 支持组合项目(a,b)
	--province  指定省/直辖市代码 从 http://www.60ma.net/apiwiki/citycode-cn.html 获取  可空
	--city    指定市代码 与上面一样从网页获取  可空
	--operator  指定运营商代码 与上面一样  可空
	--telnumsection  指定的号码或号码段  可空
	--telback  排除的号码或号码段 支持多个(a,b)  可空
	--gettype  指定的卡商ID   可空
	error_60ma = ""
	--ts.setHttpsTimeOut(30) --安卓不支持设置超时时间
	stomLog("getPhoneRules...")
	if check_Rules ~= nil then
		--local result=httpGet("http://47.95.13.16/ver/getPhoneRules"..apple_appid..".json")
		local header_send = {}
		header_send["Cache-Control"] = 'no-cache'
		local body_send = {}
		--ts.setHttpsTimeOut(30) --安卓不支持设置超时时间
		local status_resp, header_resp ,result= stomhttpGet("http://47.95.13.16/ver/getPhoneRules"..apple_appid..".json",header_send, body_send)
		if status_resp == 200 then
			if result==false or result==nil or result=="" then
				error_60ma="连接getPhoneRules失败"
			else
				local jsonTable = json.decode(result)
				gettypetb = jsonTable.gettype
				docks = jsonTable.docks
				telnumsection = jsonTable.telnumsection
				telback = jsonTable.telback
				gettype = gettypetb[math.random(1,#gettypetb)]
				ksidback = jsonTable.ksidback
				operator = jsonTable.operator

				if provinceOK == "000" then
					if jsonTable.province == "999" then
						province = math.random(1,31)
					elseif jsonTable.province == "0" then
					else	
						province = jsonTable.province
					end
				else
					province = provinceOK
				end
				if ksuidOK ~= "000" then
					gettype = ksuidOK
				end	
				if telnumsection == "0" then
					telnumsection = Randtelnumsection2()
				elseif telnumsection == "1" then
					telnumsection = Randtelnumsection2(1)
				elseif telnumsection == "2" then
					telnumsection = Randtelnumsection2(1)
					telnumsection = telnumsection..math.random(0,9)
				end
				stomLog(docks)
				stomLog("telnumsection"..telnumsection)
				stomLog("telback"..telback)
				stomLog("gettype"..gettype)
			end
		end
	end

	if docks then
	else
		docks = docks1
	end
	local url="http://sms.60ma.net/newsmssrv?cmd=gettelnum&encode=utf-8&dtype=json&userid="..userID.."&userkey="..userKey.."&docks="..docks
	if province~=nil and province~="" then
		url=url.."&province="..province
	end
	if city~=nil and city~="" then
		url=url.."&city="..city
	end
	if operator~=nil and operator~="" then
		url=url.."&operator="..operator
	end
	if telnumsection~=nil and telnumsection~="" then
		url=url.."&telnumsection="..telnumsection
	end
	if telback~=nil and telback~="" then
		url=url.."&telback="..telback
	end
	if gettype~=nil and gettype~="" then
		url=url.."&gettype="..gettype
	end
	stomLog(url)
	--local result=httpGet(url)
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false
	end
	stomLog(result)
	local jsonTable = json.decode(result)
	if jsonTable.Return.Staus~="0" then
		error_60ma = jsonTable.Return.ErrorInfo
		return false
	else
		if ksidback then
			for i=1 ,#ksidback do
				if jsonTable.Return.ksuid == ksidback[i] then
					stomLog("卡商已拉黑")
					error_60ma = "卡商已拉黑"
					freeTelnum_60ma(UserID,UserKey,docks,jsonTable.Return.Telnum)
					return false
				end
			end
		end
	end
	if checkPhonenum ~= nil then
		if checkPhone(conmenttype,string.sub(jsonTable.Return.Telnum,1,7))  then
			return jsonTable.Return.Telnum, jsonTable.Return.ksuid, docks
		else
			freeTelnum_60ma(UserID,UserKey,docks,jsonTable.Return.Telnum)
			return false
		end
	end
	return jsonTable.Return.Telnum, jsonTable.Return.ksuid, docks
end
--获取短信
function GetSMS_60ma(UserID, UserKey, docks, telnum, reusing)
	stomLog("GetSMS60ma...")
	error_60ma = ""
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	if telnum then else stomdialog("未设置号码",0);stomlua_exit() end
	local url="http://sms.60ma.net/newsmssrv?cmd=getsms&encode=utf-8&dtype=json&userid="..UserID.."&userkey="..UserKey.."&dockcode="..docks.."&telnum="..telnum
	if reusing~=nil and reusing~="" then
		url=url.."&reusing="..reusing
	end
	if developer~=nil and developer~="" then
		url=url.."&developer=zk1013"
	end
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false
	end
	stomLog(url)
	--stomLog(result)
	local jsonTable=json.decode(result)
	if jsonTable.Return.Staus~="0" then
		error_60ma=jsonTable.Return.ErrorInfo
		return false
	end
	return jsonTable.Return.SmsContent
end
--释放一个号码
function freeTelnum_60ma(UserID, UserKey,docks,telnum)
	stomLog("freeTelnum_60ma...")
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	if telnum then
		local url="http://sms.60ma.net/newsmssrv?cmd=freetelnum&encode=utf-8&dtype=json&userid="..UserID.."&userkey="..UserKey.."&docks="..docks.."&telnum="..telnum
		local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
		if result==false or result==nil or result=="" or status_resp ~= 200 then
			error_60ma="连接短信平台服务器失败"
			return false
		end
--		local jsonTable=stomJsonDecode(result)
--		if jsonTable.Return.Staus~="0" then
--			error_60ma=jsonTable.Return.ErrorInfo
--			return false
--		end
		return true
	end
end

--拉黑一个号码
function addBlackTelnum_60ma(UserID, UserKey,docks,telnum)
	stomLog("addBlackTelnum_60ma...")
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local url="http://sms.60ma.net/newsmssrv?cmd=addblacktelnum&encode=utf-8&dtype=json&userid="..UserID.."&userkey="..UserKey.."&docks="..docks.."&telnum="..telnum
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false
	end
--	local jsonTable=stomJsonDecode(result)
--	if jsonTable.Return.Staus~="0" then
--		error_60ma=jsonTable.Return.ErrorInfo
--		return false
--	end
	return true
end
function upContentData(apitype,content,field1,field2,field3,logmsg)
	stomLog("upContentData...")
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	post={}
	local field1 = field1 or ""
	local field2 = field2 or ""
	local field3 = field3 or ""
	local logmsg = logmsg or ""
	local getjoburl = "http://59.110.162.157/Api/common/add.php?type="..apitype.."&content="..content.."&field1="..field1.."&field2="..field2.."&field3="..field3.."&msg="..logmsg
	local body_resp = ""
	local status_resp, header_resp ,body_resp= stomhttpGet(getjoburl,header_send, post)
	stomLog(body_resp)
	stomLog(getjoburl)
	--stommSleep(200)
	if status_resp == 200 then
		return 0
	end
	
end

------多米接口
function stomDM_Login(UserID, UserKey)
	stomLog("stomSMS_Login")
	dm_APIID = "6g0K40dr1f60j"
	dm_token = "fa94fca161c1829946094f5bac799491"
	
	
	
end


function stomDM_GetPhone(dm_token,docks1,vno,checkPhonenum)
	stomLog("stomDM_GetPhone")
	if dm_token then
	else
		dm_token = "fa94fca161c1829946094f5bac799491"
	end
	if vno then
	else
		vno = "0"
	end
	--sid=项目id&token=登录时返回的令牌&locationMatching=include|exclude&locationLevel=p|c&location=重庆
	local url="http://api.duomi01.com/api?action=getPhone&token="..dm_token.."&sid="..docks.."&vno="..vno
	stomLog(url)
	--local result=httpGet(url)
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false
	end
	stomLog(result)
	local jsonTable = stomsplit(result,"|")
	if jsonTable[1]=="1" then
		if checkPhonenum ~= nil then
			if checkPhone(conmenttype,string.sub(jsonTable.Return.Telnum,1,7))  then
				return jsonTable.Return.Telnum, jsonTable.Return.ksuid, docks
			else
				stomDM_FreePhone(dm_token,docks1,jsonTable.Return.Telnum)
				return false
			end
		end
		return jsonTable[2]
	else	
		error_60ma = result
		return false
	end
end

function stomDM_GetSMS(dm_token, docks, telnum)
	stomLog("stomDM_GetSMS")
	if dm_token then
	else
		dm_token = "fa94fca161c1829946094f5bac799491"
	end
	--"http://api.duomi01.com/api?action=getMessage&sid=项目id&phone=取出来的手机号&token=登录时返回的令牌"
	local url="http://api.duomi01.com/api?action=getMessage&token="..dm_token.."&sid="..docks.."&phone="..telnum
	stomLog(url)
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false
	end
	stomLog(result)
	local jsonTable = stomsplit(result,"|")
	if jsonTable[1]=="1" then
		return jsonTable[2]
	else	
		error_60ma = result
		return false
	end
end

function stomDM_FreePhone(dm_token, docks, telnum)
	stomLog("stomDM_FreePhone")
	if dm_token then
	else
		dm_token = "fa94fca161c1829946094f5bac799491"
	end
	local url="http://api.duomi01.com/api?action=cancelRecv&token="..dm_token.."&sid="..docks.."&phone="..telnum
	stomLog(url)
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false
	end
	stomLog(result)
	local jsonTable = stomsplit(result,"|")
	if jsonTable[1]=="1" then
		return jsonTable[2]
	else	
		error_60ma = result
		return false
	end
end

function stomDM_AddBlackPhone(dm_token, docks, telnum)
	stomLog("stomDM_AddBlackPhone")
	if dm_token then
	else
		dm_token = "fa94fca161c1829946094f5bac799491"
	end
	local url="http://api.duomi01.com/api?action=addBlacklist&token="..dm_token.."&sid="..docks.."&phone="..telnum
	stomLog(url)
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false
	end
	stomLog(result)
	local jsonTable = stomsplit(result,"|")
	if jsonTable[1]=="1" then
		return jsonTable[2]
	else	
		error_60ma = result
		return false
	end
end

function strSplitYiMa(str)
	if str then
		local t = strSplit(str,"|")
		return t
	end
end

--登录 参数 用户名,密码  返回success|003175560896928fe98a6670acd07752a7b5574e6701 or 1005
function login_YiMa(userName,password)
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = "http://i.fxhyd.cn:8080/UserInterface.aspx?action=login&username="..userName.."&password="..password
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false
	end
	local jsonTable=strSplitYiMa(result)
	if jsonTable[1] == "success" then
		error_60ma = "success"
		return jsonTable[2]
	end
	error_60ma = jsonTable[1]
	return false
end
--获取号码 参数 项目编号,token  返回  String/Bool(成功返回UserID失败返回false), String(成功返回UserKey失败返回nil)
function getPhonenum_YiMa(itemid,ym_token)
	if ym_token then
	else
		ym_token = "003175560896928fe98a6670acd07752a7b5574e6701"
	end
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = "http://i.fxhyd.cn:8080/UserInterface.aspx?action=getmobile&itemid="..itemid.."&token="..ym_token.."&excludeno=170.171.165"
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false,nil
	end
	local jsonTable=strSplitYiMa(result)
	if jsonTable[1] == "success" then
		error_60ma = "success"
		return jsonTable[2]
	end
	error_60ma = jsonTable[1]
	return false
end

--获取短信 参数 项目编号,token  返回  String/Bool(成功返回UserID失败返回false), String(成功返回UserKey失败返回nil)
function getSMS_YiMa(mobile,itemid,ym_token)
	if ym_token then
	else
		ym_token = "003175560896928fe98a6670acd07752a7b5574e6701"
	end
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = "http://i.fxhyd.cn:8080/UserInterface.aspx?action=getsms&mobile="..mobile.."&itemid="..itemid.."&token="..ym_token.."&release=1"
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false,nil
	end
	local jsonTable=strSplitYiMa(result)
	if jsonTable[1] == "success" then
		error_60ma = "success"
		return jsonTable[2]
	end
	error_60ma = jsonTable[1]
	return false
end
--释放号码 参数 项目编号,token  返回  String/Bool(成功返回UserID失败返回false), String(成功返回UserKey失败返回nil)
function freePhone_YiMa(mobile,itemid,ym_token)
	if ym_token then
	else
		ym_token = "003175560896928fe98a6670acd07752a7b5574e6701"
	end
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = "http://i.fxhyd.cn:8080/UserInterface.aspx?action=release&mobile="..mobile.."&itemid="..itemid.."&token="..ym_token.."&release=1"
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false,nil
	end
	local jsonTable=strSplitYiMa(result)
	if jsonTable[1] == "success" then
		error_60ma = "success"
		return jsonTable[2]
	end
	error_60ma = jsonTable[1]
	return false
end
--拉黑号码 参数 项目编号,token  返回  String/Bool(成功返回UserID失败返回false), String(成功返回UserKey失败返回nil)
function addBlackList_YiMa(mobile,itemid,ym_token)
	if ym_token then
	else
		ym_token = "003175560896928fe98a6670acd07752a7b5574e6701"
	end
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = "http://i.fxhyd.cn:8080/UserInterface.aspx?action=addignore&mobile="..mobile.."&itemid="..itemid.."&token="..ym_token.."&release=1"
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false,nil
	end
	local jsonTable=strSplitYiMa(result)
	if jsonTable[1] == "success" then
		error_60ma = "success"
		return jsonTable[2]
	end
	error_60ma = jsonTable[1]
	return false
end

--登录 参数 用户名,密码  返回success|003175560896928fe98a6670acd07752a7b5574e6701 or 1005
function login_XinMa(userName,password)
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = XinMa_ip.."/service.asmx/UserLoginStr?name="..userName.."&psw="..password
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false
	end
	if string.find(result,"hm=") then
		result = string.gsub(result,"hm=","")
		return stomtrim(result)
	end

	-- local jsonTable=strSplitYiMa(result)
	-- if jsonTable[1] == "success" then
	-- 	error_60ma = "success"
	-- 	return jsonTable[2]
	-- end
	-- error_60ma = jsonTable[1]
	return false
end
--获取号码 参数 项目编号,token  返回  String/Bool(成功返回UserID失败返回false), String(成功返回UserKey失败返回nil)
function getPhonenum_XinMa(itemid,ym_token)
	if ym_token then
	else
		ym_token = "C40FD0E669B26BCCE83C69312A8EB0AA"
	end
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = XinMa_ip.."/service.asmx/GetHM2Str?xmid="..itemid.."&token="..ym_token.."&sl=1&lx=6&a1=&a2=&pk=&ks=0&rj="
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false,nil
	end
	if string.find(result,"hm=") then
		result = string.gsub(result,"hm=","")
		return stomtrim(result)
	end
	

	return false
end

--获取短信 参数 项目编号,token  返回  String/Bool(成功返回UserID失败返回false), String(成功返回UserKey失败返回nil)
function getSMS_XinMa(mobile,itemid,ym_token)
	if ym_token then
	else
		ym_token = "C40FD0E669B26BCCE83C69312A8EB0AA"
	end
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = XinMa_ip.."/service.asmx/GetYzm2Str?hm="..mobile.."&xmid="..itemid.."&token="..ym_token.."&sf=1"
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false,nil
	end
	if string.len(result) > 4 then
		return result
	end
	return false
end
--释放号码 参数 项目编号,token  返回  String/Bool(成功返回UserID失败返回false), String(成功返回UserKey失败返回nil)
function freePhone_XinMa(mobile,itemid,ym_token)
	if ym_token then
	else
		ym_token = "C40FD0E669B26BCCE83C69312A8EB0AA"
	end
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = XinMa_ip.."/service.asmx/sfHmStr?hm="..mobile.."&token="..ym_token
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false,nil
	end
	return result
end
--拉黑号码 参数 项目编号,token  返回  String/Bool(成功返回UserID失败返回false), String(成功返回UserKey失败返回nil)
function addBlackList_XinMa(mobile,itemid,ym_token)
	if ym_token then
	else
		ym_token = "C40FD0E669B26BCCE83C69312A8EB0AA"
	end
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = XinMa_ip.."/service.asmx/Hmd2Str?hm="..mobile.."&xmid="..itemid.."&token="..ym_token.."&sf=1"
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false,nil
	end
	return result
end

-----------------爱尚
--登录 参数 用户名,密码  1|28d04d1910b15c335f936e62b23c9335
function login_AiShang(userName,password)
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = "http://i.fxhyd.cn:8080/UserInterface.aspx?action=login&username="..userName.."&password="..password
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false
	end
	local jsonTable=strSplitYiMa(result)
	if jsonTable[1] == "1" then
		error_60ma = "success"
		return jsonTable[2]
	end
	error_60ma = jsonTable[1]
	return false
end
--获取号码 参数 项目编号,token  返回  String/Bool(成功返回UserID失败返回false), String(成功返回UserKey失败返回nil)
function getPhonenum_AiShang(itemid,ym_token)
	aspid = nil
	if ym_token then
	else
		ym_token = "28d04d1910b15c335f936e62b23c9335"
	end
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = "http://v6.aishangpt.com:88/yhapi.ashx?act=getPhone&iid="..itemid.."&token="..ym_token.."&seq=2&did=&operator=&provi=&city=&mobile="
	--stomLog(url)
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false,nil
	end
	local jsonTable=strSplitYiMa(result)
	if jsonTable[1] == "1" then
		error_60ma = "success"
		aspid = jsonTable[2]
		return jsonTable[5]
	end
	error_60ma = jsonTable[1]
	return false
end

--获取短信 参数 项目编号,token  返回  String/Bool(成功返回UserID失败返回false), String(成功返回UserKey失败返回nil)
function getSMS_AiShang(mobile,itemid,ym_token)
	if ym_token then
	else
		ym_token = "28d04d1910b15c335f936e62b23c9335"
	end
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = "http://v6.aishangpt.com:88/yhapi.ashx?act=getPhoneCode&token="..ym_token.."&pid="..aspid
	--stomLog(url)
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false,nil
	end
	local jsonTable=strSplitYiMa(result)
	if jsonTable[1] == "1" then
		error_60ma = "success"
		return jsonTable[3]
	end
	error_60ma = jsonTable[1]
	return false
end
--释放号码 参数 项目编号,token  返回  String/Bool(成功返回UserID失败返回false), String(成功返回UserKey失败返回nil)
function freePhone_AiShang(mobile,itemid,ym_token)
	if ym_token then
	else
		ym_token = "28d04d1910b15c335f936e62b23c9335"
	end
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = "http://v6.aishangpt.com:88/yhapi.ashx?act=setRel&token="..ym_token.."&pid="..aspid
	--stomLog(url)
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false,nil
	end
	local jsonTable=strSplitYiMa(result)
	if jsonTable[1] == "1" then
		error_60ma = "success"
		return jsonTable[1]
	end
	error_60ma = jsonTable[1]
	return false
end
--拉黑号码 参数 项目编号,token  返回  String/Bool(成功返回UserID失败返回false), String(成功返回UserKey失败返回nil)
function addBlackList_AiShang(mobile,itemid,ym_token)
	if ym_token then
	else
		ym_token = "28d04d1910b15c335f936e62b23c9335"
	end
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = "http://v6.aishangpt.com:88/yhapi.ashx?act=addBlack&reason=used&token="..ym_token.."&pid="..aspid
	--stomLog(url)
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false,nil
	end
	local jsonTable=strSplitYiMa(result)
	if jsonTable[1] == "1" then
		error_60ma = "success"
		return jsonTable[1]
	end
	error_60ma = jsonTable[1]
	return false
end

-----------------来信
--登录 参数 用户名,密码  1|0kb66nkanlcqlq7aowboko56acvkn7cm
function login_LaiXin(userName,password)
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = "http://api.smskkk.com/api/do.php?action=loginIn&name="..userName.."&password="..password
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false
	end
	local jsonTable=strSplitYiMa(result)
	if jsonTable[1] == "1" then
		error_60ma = "success"
		return jsonTable[2]
	end
	error_60ma = jsonTable[1]
	return false
end
--获取号码 参数 项目编号,token  返回  String/Bool(成功返回UserID失败返回false), String(成功返回UserKey失败返回nil)
function getPhonenum_LaiXin(itemid,ym_token)
	aspid = nil
	if ym_token then
	else
		ym_token = "0kb66nkanlcqlq7aowboko56acvkn7cm"
	end
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = "http://api.smskkk.com/api/do.php?action=getPhone&sid="..itemid.."&token="..ym_token.."&vno=0"
	--stomLog(url)
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false,nil
	end
	local jsonTable=strSplitYiMa(result)
	if jsonTable[1] == "1" then
		error_60ma = "success"
		return jsonTable[2]
	end
	error_60ma = jsonTable[1]
	return false
end

--获取短信 参数 项目编号,token  返回  String/Bool(成功返回UserID失败返回false), String(成功返回UserKey失败返回nil)
function getSMS_LaiXin(mobile,itemid,ym_token)
	if ym_token then
	else
		ym_token = "0kb66nkanlcqlq7aowboko56acvkn7cm"
	end
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = "http://api.smskkk.com/api/do.php?action=getMessage&author=zk101310&sid="..itemid.."&token="..ym_token.."&phone="..mobile
	--stomLog(url)
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false,nil
	end
	local jsonTable=strSplitYiMa(result)
	if jsonTable[1] == "1" then
		error_60ma = "success"
		return jsonTable[2]
	end
	error_60ma = jsonTable[1]
	return false
end
--释放号码 参数 项目编号,token  返回  String/Bool(成功返回UserID失败返回false), String(成功返回UserKey失败返回nil)
function freePhone_LaiXin(mobile,itemid,ym_token)
	if ym_token then
	else
		ym_token = "0kb66nkanlcqlq7aowboko56acvkn7cm"
	end
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = "http://api.smskkk.com/api/do.php?action=cancelRecv&sid="..itemid.."&token="..ym_token.."&phone="..mobile
	--stomLog(url)
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false,nil
	end
	local jsonTable=strSplitYiMa(result)
	if jsonTable[1] == "1" then
		error_60ma = "success"
		return jsonTable[1]
	end
	error_60ma = jsonTable[1]
	return false
end
--拉黑号码 参数 项目编号,token  返回  String/Bool(成功返回UserID失败返回false), String(成功返回UserKey失败返回nil)
function addBlackList_LaiXin(mobile,itemid,ym_token)
	if ym_token then
	else
		ym_token = "0kb66nkanlcqlq7aowboko56acvkn7cm"
	end
	local header_send = {}
	header_send["Cache-Control"] = 'no-cache'
	local body_send = {}
	local url = "http://api.smskkk.com/api/do.php?action=addBlacklist&sid="..itemid.."&token="..ym_token.."&phone="..mobile
	--stomLog(url)
	local status_resp, header_resp ,result= stomhttpGet(url,header_send, body_send)
	if result==false or result==nil or result=="" or status_resp ~= 200 then
		error_60ma="连接短信平台服务器失败"
		return false,nil
	end
	local jsonTable=strSplitYiMa(result)
	if jsonTable[1] == "1" then
		error_60ma = "success"
		return jsonTable[1]
	end
	error_60ma = jsonTable[1]
	return false
end
-------统一接口
function stomSMS_Login(UserID, UserKey)
	stomLog("stomSMS_Login")
	dm_APIID = "6g0K40dr1f60j"
	dm_token = "fa94fca161c1829946094f5bac799491"
	as_token = "28d04d1910b15c335f936e62b23c9335"
	lx_token = "0kb66nkanlcqlq7aowboko56acvkn7cm"
	
end

function stomSMS_GetPhone(userID,userKey,docks1,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
	stomLog("stomSMS_GetPhone")
	if getPhoneType == "dm" then
		return stomDM_GetPhone(dm_token,docks1,vno,checkPhonenum)
	elseif getPhoneType == "ym" then
		return getPhonenum_YiMa(docks1,ym_token)
	elseif getPhoneType == "xm" then
		return getPhonenum_XinMa(docks1,ym_token)
	elseif getPhoneType == "as" then
		return getPhonenum_AiShang(docks1,ym_token)
	elseif getPhoneType == "lx" then
		return getPhonenum_LaiXin(docks1,ym_token)

	else
		return getTelnum_60ma_st(userID,userKey,docks1,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
	end
end

function stomSMS_GetSMS(UserID, UserKey, docks, telnum, reusing)
	stomLog("stomSMS_GetSMS")
	if getPhoneType == "dm" then
		return stomDM_GetSMS(dm_token, docks, telnum)
	elseif getPhoneType == "ym" then
		return getSMS_YiMa(telnum,docks,ym_token)
	elseif getPhoneType == "xm" then
		return getSMS_XinMa(telnum,docks,ym_token)
	elseif getPhoneType == "as" then
		return getSMS_AiShang(telnum,docks,ym_token)
	elseif getPhoneType == "lx" then
		return getSMS_LaiXin(telnum,docks,ym_token)


	else
		return GetSMS_60ma(UserID, UserKey, docks, telnum, reusing)
	end
end

function stomSMS_FreePhone(UserID, UserKey,docks,telnum)
	stomLog("stomSMS_FreePhone")
	if getPhoneType == "dm" then
		return stomDM_FreePhone(dm_token, docks, telnum)
	elseif getPhoneType == "ym" then	
		return freePhone_YiMa(telnum,docks,ym_token)
	elseif getPhoneType == "xm" then
		return freePhone_XinMa(telnum,docks,ym_token)
	elseif getPhoneType == "as" then
		return freePhone_AiShang(telnum,docks,ym_token)
	elseif getPhoneType == "lx" then
		return freePhone_LaiXin(telnum,docks,ym_token)

	else
		return freeTelnum_60ma(UserID, UserKey,docks,telnum)
	end
end

function stomSMS_AddBlackPhone(UserID, UserKey,docks,telnum)
	stomLog("stomSMS_AddBlackPhone")
	if getPhoneType == "dm" then
		return stomDM_AddBlackPhone(dm_token, docks, telnum)
	elseif getPhoneType == "ym" then
		return addBlackList_YiMa(telnum,docks,ym_token)
	elseif getPhoneType == "xm" then
		return addBlackList_XinMa(telnum,docks,ym_token)
	elseif getPhoneType == "as" then
		return addBlackList_AiShang(telnum,docks,ym_token)
	elseif getPhoneType == "lx" then
		return addBlackList_LaiXin(telnum,docks,ym_token)
	


	else
		return addBlackTelnum_60ma(UserID, UserKey,docks,telnum)
	end
end

