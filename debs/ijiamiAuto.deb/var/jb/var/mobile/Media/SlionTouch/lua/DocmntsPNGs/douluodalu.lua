function _登录dl()
	stomMultiColorTap(登录更多dl,"登录更多dl") 
	stomMultiColorTap(游客登录dl,"游客登录dl") 	
	stomMultiColorTap(继续游客登录dl,"继续游客登录dl") 
	stomMultiColorTap(跳过剧情dl,"跳过剧情dl") 
	stomMultiColorTap(跳过剧情2dl,"跳过剧情2dl")
	stomMultiColorTap(公告我知道了dl,"公告我知道了dl") 
	stomMultiColorTap(通关一到九广告dl,"通关一到九广告dl")
	
	stomMultiColorTap(点击换区dl,"点击换区dl")
	if stomMultiColorTap(推测服务器dl,"推测服务器dl")then
		stommSleep(1500)
		stomMultiColorTap(进入游戏dl,"进入游戏dl")				--。。。
	end

	
	stomMultiColorTap(广告首冲dl,"广告首冲dl")
	stomMultiColorTap(广告开服每日送十连dl,"广告开服每日送十连dl") 
	stomMultiColorTap(广告恭喜动画第二季dl,"广告恭喜动画第二季dl")

	
	stomMultiColorTap(系统提示确定dl,"系统提示确定dl")
end

function _引导dl()
	stomMultiColorTap(对话小舞dl,"对话小舞dl")
	stomMultiColorTap(少年唐三任意dl,"少年唐三任意dl")
	stomMultiColorTap(少年小舞任意dl,"少年小舞任意dl") 
	stomMultiColorTap(少年沫白任意dl,"少年沫白任意dl")
	stomMultiColorTap(恭喜获得唐三确定dl,"恭喜获得唐三确定dl")
	stomMultiColorTap(恭喜获得dl,"恭喜获得dl")
	stomMultiColorTap(恭喜获得手指确定dl,"恭喜获得手指确定dl")
	stomMultiColorTap(跳过剧情1dl,"跳过剧情1dl")
	if stomMultiColorTap(筛子dl,"筛子dl") then
		stommSleep(500)
		stomMultiColorTap(战队确定dl,"战队确定dl")
	end
	stomMultiColorTap(第几章剧情dl,"第几章剧情dl")
	stomMultiColorTap(装备鞋子dl,"装备鞋子dl") 
	stomMultiColorTap(手指选鞋子dl,"手指选鞋子dl")
	stomMultiColorTap(手指宝箱dl,"手指宝箱dl")
	stomMultiColorTap(手指突破dl,"手指突破dl")
	stomMultiColorTap(突破成功dl,"突破成功dl")
	stomMultiColorTap(恭喜获得宝箱dl,"恭喜获得宝箱dl")
	stomMultiColorTap(手指宝箱dl,"手指宝箱dl") 
	stomMultiColorTap(战斗奖励确定dl,"战斗奖励确定dl")
	stomMultiColorTap(第一章杠六dl,"第一章杠六dl") 
	stomMultiColorTap(第一章杠七dl,"第一章杠七dl")
	stomMultiColorTap(箭头开始dl,"箭头开始dl") 
	stomMultiColorTap(交叉开始dl,"交叉开始dl")
	
end

function DLDL_cz()
	if stomMultiColor("充值界面",{
	{  512,  378, 0xffdeb9},
	{  512,  384, 0xfeddb8},
	{  519,  575, 0xfddbb6},
	{  512,  585, 0xffdeb9},
}) then
		yanzhengtoast=0
		while (true) do
			stomLog("充值模式")
			shopapplestore()
			isfront = stomisFrontApp("com.apple.MobileSMS")
			if isfront==1 then
				break
			end
			if yanzhengtoast == 0 then
				stomopenURL("prefs:root=STORE");
				stomtoast("请检查是否需要注销并返回游戏")
				stommSleep(8000)
			end	
			isfront = stomisFrontApp("com.qidea.dldl.yuewen")
			if isfront==1 then
				yanzhengtoast =1
			end				

		end
	end
end
--	stomMultiColorTap(唐三技能dl,"唐三技能dl")

function create_1300066093()							--			斗罗大陆
	local t1 = os.time()
	local time_cha =  math.random(15,20)*60
	local loop = 0
	while (true) do
		OpenApp("com.qidea.dldl.yuewen")
		stomLog("什么情况？？？")
		stomMultiColorTap(恭喜升级dl,"恭喜升级dl")
		stomMultiColorTap(装备突破成功dl,"装备突破成功dl")
		stomMultiColorTap(小舞技能dl,"小舞技能dl")
		stomMultiColorTap(唐三技能dl,"唐三技能dl")
		stomMultiColorRegTap("带黄键手指",0xffd055, "-11|18|0x717266,-22|34|0xd98c0f,-8|45|0x030202,-22|34|0xd98c0f", 90, 0, 0, 639, 1135)
		stomMultiColorRegTap("唐三技能", 0x6be8f4, "2|-7|0xfefeff,62|31|0xffe28b,64|2|0xff7800,7|-36|0xff7800", 90, 16, 50, 156, 1029)
		stomMultiColorRegTap("铁手指",0xedeeea, "-29|20|0xf5b12a,-47|20|0x47473b,-35|19|0x5a5a4d,-42|-7|0x646559,-22|32|0xf8b730", 90, 0, 0, 639, 1135)
		stomMultiColorRegTap("底部铁手指",0xe7e7e1, "-22|35|0xf7b52e,-18|47|0xfabc35,-9|29|0x010101,-73|60|0x301501,-73|47|0x78410d", 90, 0, 0, 639, 1135)
		_登录dl()
		_引导dl()
		DLDL_cz()
		local t2 = os.time()
		if os.difftime(t2,t1) > time_cha then
			if tasktype == 0 then
				stomLog("超过10分钟")
				return 0
			else
				return 0
			end
		end
	stommSleep(500)
	end
	

end