--Thread.sleep(5*1000)
require("stomconfig")
require("stommain")
require("stomuntil")
require("until")
require("phoneHttp")
require("datiHttp")
require("hdgame")
require("dawang")


rstime = os.time()
vpn_status = true
	-- 检测下载是否完成  

function dumpApp(bundleID)
        io.popen("killall -9 IJMDaemon")
        Thread.sleep(500)
	    cmdString = "/usr/bin/IJMDaemon --BundleID "..bundleID
        stomLog(cmdString)
        System.execute(cmdString)
        stomLog("END")
        cleanApp(bundleID)
end

function cleanApp(bundleID)
    cmdString = "/usr/bin/SlionInstaller -k "..bundleID
    System.execute2(cmdString)
    cmdString = "/usr/bin/SlionInstaller -u "..bundleID
    System.execute2(cmdString)
end


function checkeAppInstallAfter(bundleID)
	 if stomcheckAPPisInstalled(bundleID) then
         stomLog("##App下载完成###")
         return 1
     else
     	 stomLog("##下载中###")
     	 return 0
	 end
     return 0
end

-- 获取下载point  
function getPoint()
 	 local pointDownInfo = stomplistRead("/var/SlionDaemon/pointDown.plist")
     Thread.sleep(2*1000)
	 if (pointDownInfo == nil ) then
         stomLog("点位nil")
         return 0
     else
     	 downPointX = pointDownInfo["pointX"]
         downPointY = pointDownInfo["pointY"]
     	 stomLog(pointDownInfo)
         stomLog("downPointX:")
         stomLog(downPointX)
         stomLog("downPointY:")
         stomLog(downPointY)
	 end
	 return 1
end	


-- 下载点击 
function PointDown()
     stomLog("PointDown")
 	 for i =1 ,10 do
		  if getPoint() == 1 then
              Thread.sleep(4*1000)
              if getPoint() == 1 then
                stomtap(downPointX ,downPointY)
                return 1
              end
		  else
             Thread.sleep(3*1000)
		  end
	end
    return 0
end


-- 获取验证码point  
function getGifPoint()
     local pointDownInfo = stomplistRead("/var/SlionDaemon/gifPointDown.plist")
     if (pointDownInfo == nil ) then
         stomLog("点位nil")
         return 0
     else
         local PointX = pointDownInfo["pointX"]
         local PointY = pointDownInfo["pointY"]
         local sh = pointDownInfo["sh"]
         local sw = pointDownInfo["sw"]
         stomLog("gifDownPointX:")
         stomLog(PointX)
         stomLog("gifDownPointY:")
         stomLog(PointY)
         stomtap(PointX,PointY)
         stomtap(PointX,PointY)
         math.randomseed(os.time())
         if(sh ~= "0" and  sw ~= "0") then
             for i =0 ,5 do
                Thread.sleep(500+100*(1%3))
                 ranPointX = sw/2 + (math.random(0,10))*10 - (math.random(0,20))
                 ranPointY = (sh-216) + (math.random(0,10))*5 - (math.random(0,5))
                 stomtap(ranPointX,ranPointY)
             end
         end
     end
     return 1
end

-- 动态验证码框
function GifPointDown()
     stomLog("GifPointDown")
     for i =1 ,10 do
          if getGifPoint() == 1 then
              break
          else
            if  stomcheckAppisInstall(bundleID) then
                stomLog("##正在安装中###")
                break
            end
            Thread.sleep(3*1000)
          end
    end
end 



function printfGifCode()
     stomLog("GifPointDown")
     for i =1 ,10 do
          if getGifPoint() == 1 then
  -- 等待动态验证码框输入完成:          
             for i =1 ,10 do
                Thread.sleep(3*1000)
                if  stomcheckAppisInstall(bundleID) then
                  stomLog("##正在安装中###")
                  break
                end
             end
             break
          else
             Thread.sleep(3*1000)
          end
    end
end 

function rmAppStorefiile()
 	    System.execute2("/bin/rm  /var/SlionDaemon/pointDown.plist")
        System.execute2("/bin/rm /var/SlionDaemon/com.AppListInfo.plist")
        System.execute2("/bin/rm /var/SlionDaemon/gifPointDown.plist")
end

-- kill进程
function killProcess()
        System.execute2("/usr/bin/killall -9  appstored AppStore itunesstored accountsd installd PassbookUIService")
        Thread.sleep(1*1000)
        System.execute2("/usr/bin/killall -9  appstored AppStore itunesstored accountsd installd PassbookUIService")
        Thread.sleep(3*1000)
end

function checkTaskOut(bundleID)
    for i=1,600 do
        Thread.sleep(10000)
        if checkeAppInstallAfter(bundleID) == 1 then
             stomLog("##完成安装中1###")
             killProcess()
             Thread.sleep(500)
             os.exit()
        end
    end
    os.exit(408)
end


function runlua()
	kaifa = SLionLUA["debug"]
	logName = "/private/var/mobile/Media/SlionTouch/log/"..os.time()..".txt"
	stomLog("####################==========>SLion LUA START <==========###################")
	rmAppStorefiile()
    TaskInfo = stomgetTaskInfo()
	openURL = TaskInfo["openURL"]
	bundleID = TaskInfo["bundleID"]
    stomLog(openURL)
    stomLog(bundleID)
 
    killProcess()

	if  stomrunApp(bundleID) then
	 	 stomLog("##App已下载###")
         Thread.sleep(500)
         stomcloseApp(bundleID)
         killProcess()
         os.exit()
    else
        if stomcheckAppisInstall(bundleID) then
            stomLog("##app正在安装中不需要重启appstore安装###")
            checkTaskOut(bundleID)
        else
            stomLog("##开始进程###")
            killProcess()
            stomopenURL(openURL)
            Thread.sleep(10*1000)
        end
    end

    local slionRunt = os.time()
    while true do
--超时时间
        if os.difftime(os.time(),slionRunt) > 200 then
          stomLog("超时200")
          os.exit(408)
        end

        for i =1 ,20 do
            Thread.sleep(5*1000)
            if stomcheckAppisInstall(bundleID) then
                stomLog("##正在安装中1###")
                break
            end
        end
        
		if stomcheckAppisInstall(bundleID) then
            stomLog("##正在安装中2###")
            break
        else
            stomLog("##重新进程###")
            killProcess()
            stomopenURL(openURL)
            Thread.sleep(60*1000)
        end
	end
    checkTaskOut(bundleID)

end




local iRet, sRet = pcall(function()	runlua() end)
if iRet == true then
	return sRet
else
	stomLog(sRet);
	stomLogPUT(sRet,3);
	return ""
end
