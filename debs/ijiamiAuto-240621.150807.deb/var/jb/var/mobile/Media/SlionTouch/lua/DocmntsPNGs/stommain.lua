function intmain()
	stomLog("intmain...")
	firstMainOK = 0
	nowSlionVersion = stomgetSlionVersion()
	if stomisFileExist("/var/mobile/Media/SlionTouch/lua/DocmntsPNGs/firstMain.lua") then
		nowSlionVersion = SLionLUA["SlionVersion"]
		firstMainOK = 1
	end
	if nowSlionVersion ~= SLionLUA["SlionVersion"] then
		stomLogPUT("更新Slion至:"..SLionLUA["SlionVersion"],3)
		for i =1 ,60 do
			if stomisFrontApp("com.saurik.Cydia") == 1 then
				stomtoast("更新Slion="..SLionLUA["SlionVersion"],3)
				stommSleep(60*1000)
			else
				stomrunApp("com.saurik.Cydia")
				stommSleep(10*1000)
			end
		end
		os.exit()
	end
	devicesinfo = {}
	stomgetDeviceInfoTB = stomgetDeviceInfo()
	devicesinfo['serial'] = stomgetDeviceInfoTB['serialNumber']
	devicesinfo['udid'] = stomgetDeviceInfoTB['UDID']
	devicesinfo['osversion'] = stomgetDeviceInfoTB['phoneVersion']
	devicesinfo['model'] =  stomgetDeviceInfoTB['phoneModel']
	devicesinfo['name'] =  stomgetDeviceInfoTB['name']
	if string.match(devicesinfo['osversion'],"12.") or
		string.match(devicesinfo['name'],"7010") or
		string.match(devicesinfo['name'],"7030") or 
		string.match(devicesinfo['name'],"7040") then
		require("httpmodel139")
	else
		require("httpmodel")
	end
	stomcheckser()
	if stomisFileExist("/usr/bin/zip")then
	else
		stomLogPUT("未安装 zip",1)
		stommSleep(10*1000)
		return false
	end
	if stomisFileExist("/usr/bin/unzip") then
	else
		stomLogPUT("未安装 unzip",1)
		stommSleep(10*1000)
		return false
	end
	
	System.execute2("/bin/cp /var/mobile/Media/SlionTouch/lua/DocmntsPNGs/hosts /etc/hosts")
	stomLog("intmain...OK")
	return true
end

function resetmain()
	math.randomseed(tonumber(tostring(os.time()):reverse():sub(1,6)))
	stomdelFile("/tmp/*.tmp")
	stomdelFile("/tmp/unzipTemp")
	
	--del plist
	local logfile = stomgetList("/private/var/mobile/Library/Preferences")
	if #logfile > 500 then
		stomLog("del plist="..#logfile)
		stomLogPUT("del plist="..#logfile,0)
		for i,v in ipairs(logfile) do
			if v then
				if string.match(v,".plist.") then
					local path = "/private/var/mobile/Library/Preferences/"..v
					stomdelFile(path)
				end
			end
		end
		stomLogPUT("del plist OK")
		os.exit()
	end
	
	randcreate = math.random(1,10)
	report_count = 0
	VPN_variables = SLionLUA["VPN_variables"]
	fileok = 0
	crok = 0
	slion_game_level = 0
end

function stommaingo()
	local loop = 0
	local crloop = 0
	local nocrcount = 0
	local slionRunt = os.time()
	while (true) do
		if loop == 0 then
			setvpn("discon")
			if intmain() then
				loop = 1
			end
		elseif loop == 1 then
			ret = registrationequipment_json()
			if ret == 0 then
				loop = 2
			else
				--注册失败
				stommSleep(60*1000)
			end
		elseif loop == 2 then
			slionRunt = os.time()
			setvpn("discon")
			ret = Acquisitiontask_json()
			if ret == 0 then
				stomLogPUT("Start id "..taskid,0)
				resetmain()
				if getTaskConfig(apple_appid) == 0 then
					stomcloseApp(apple_bid);stommSleep(3*1000)
					if firstMainOK == 0 then
						if taskConfigTable["clientVer"] ~= SLionLUA["VER"] then
							stomLog("更新LUA")
							stomLog(taskConfigTable["clientVer"])
							stomLog(SLionLUA["VER"])
							stomLogPUT("需要更新Lua="..taskConfigTable["clientVer"],1)
							stommSleep(1000)
							os.exit()
						end
					end
					if stomcheckAppisInstall(apple_bid) then
						if check_updateRes() then
							loop = 3
						end
					else
						stomLogPUT("APP未安装",1)
						loop = 201
					end
				end
			else
				--没有任务
				stommSleep(60*1000)
			end
		elseif loop == 3 then
			fakeinfoTB = getFakeinfo()
			g_now_idfa = fakeinfoTB['idfa']
			updataCpaKeyUDID(g_now_idfa,apple_appid,apple_bid)
			if tasktype == 1 then
				recPath ="/private/var/mobile/Media/Slion/"..filename
				stomdelFile(recPath)
				stomLog("download:"..filename)
				stomLogPUT("Download BackFile",0)
				if stomdownloadZip(SLionLUA["downZipURL"], apple_appid, recPath) then
					if stomisFileExist(recPath) then
						System.execute2("/bin/chmod -R 777 /tmp/unzipTemp")
						stomLogPUT("Recovery",0)
						if slionappRecover(apple_bid, filename) then
							local appPath = stomgetSandboxPath(apple_bid)
							local g_idfa = string.gsub(filename,".zip","")
							stomLog("download_"..g_idfa.."_CpaKeyUDID.plist")
							recPath2 ="/private/var/mobile/Media/Slion/"..g_idfa.."_CpaKeyUDID.plist"
							stomdownloadZip(SLionLUA["downZipURL"], apple_appid, recPath2)
							System.execute2("/bin/chmod -R 777 "..recPath2)
							local path2 = stomgetSandboxPath("com.duoyi.shenwu3").."/Documents/"..g_idfa.."_CpaKeyUDID.plist"
							local cmd = "/bin/cp "..recPath2.." "..stomgetSandboxPath("com.duoyi.shenwu3").."/Documents/CpaKeyUDID.plist"
							System.execute(cmd)
							System.execute2("/bin/chmod -R 777 "..stomgetSandboxPath("com.duoyi.shenwu3").."/Documents/CpaKeyUDID.plist")
							fileok = 1
							crok = 1
							stomLog("fileok")
						end
					end
				else
					stomLogPUT("backFile Error",1)
					stomLog("backFile flase")
					stomtoast("download backfile flase",5)
					stommSleep(5000)
				end
			end
			if fileok == 0 and tasktype == 1 then
				stomLog("fileok==0")
				report_notice()
				report_count = report_count + 1
				loop = 2
			else
				if tasktype == 0 then
					if taskConfigTable["cr"] ~= "0" then
						docrCount = math.modf(1/taskConfigTable["cr"])
						stomLogPUT(taskid.." CR="..docrCount,0)
						if doClcikCr(docrCount) == 0 then
							crok = 1
						end
					else
						crok = 1
					end
				end
				if crok == 1 then
					stomLog("ip setting")
					setvpn("con");stommSleep(5*1000)
					icode, newip, latitude, longitude = getipus()
					if icode == 200 then
						g_now_ip = newip
						stomLog(g_now_ip)
						if tasktype == 0 then
							stomLogPUT("cleaning",0)
							if slionclearApp(apple_bid) then
								loop = 4
								crloop = 0
							end
							stomLog(g_now_idfa)
						else
							loop = 5
							crloop = 0
						end
					else
						setvpn("discon");stommSleep(3*1000)
					end
				else
					loop = 2
				end
			end
		elseif loop == 4 then
			stomLog("crloop="..crloop)
			if crloop == 0 then
				--stomcloseApp("com.apple.mobilesafari")
				clearMobilesafari()
				if durl ~= "none" and tasktype == 0 then
					stomLog("new_durl")
					callbackURL = SLionLUA["callbackURL"].."?idfa="..g_now_idfa.."&"..callbackURLdata
					callbackURL = urlEncode(callbackURL)
					new_durl = string.gsub(durl, "{idfa}", g_now_idfa)
					new_durl = string.gsub(new_durl, "{ClickID}", g_now_idfa)
					new_durl = string.gsub(new_durl, "{CID}", apple_appid)
					new_durl = string.gsub(new_durl, "{IDFA}", g_now_idfa)
					new_durl = string.gsub(new_durl, "{ip}", g_now_ip)
					new_durl = string.gsub(new_durl, "{taskid}", taskid)
					new_durl = string.gsub(new_durl, "{appid}", apple_appid)
					new_durl = string.gsub(new_durl, "{runid}", runid)
					local dl ,dj = string.find(new_durl,"&aff_sub={callback}")
					if dl then
						new_durl = string.gsub(new_durl, "&aff_sub={callback}", "")
						new_durl = new_durl.."&aff_sub="..callbackURL
					end
					stomLog(new_durl)
					nocrcount = 0
					crloop = 2
				else
					loop = 5
				end
			elseif crloop == 2 then
				stomopenURL(new_durl)
				stommSleep(3000)
				for ii3 = 1 , 30 do
					if stomisFrontApp("com.apple.AppStore")== 1 or 
						stomisFrontApp(apple_bid) == 1 then
						loop = 5
						break
					else
						stomMultiColorTap("尚亦城",{
							{  299,  987, 0x00499d},
							{  215, 1025, 0xffffff},
							{  465, 1025, 0x00499d},
							{  375,  515, 0x0c5cb7},
						})
						local x1,y1,x2,y2 = 415, 491, 611, 805
						stomColorInRegTap("dakai",0x007aff, 90, x1,y1,x2,y2)
						stomLog("no FrontApp="..nocrcount)
						stommSleep(1000)
					end
				end
				nocrcount = nocrcount + 1
				if nocrcount >= 3 then
					stomLog("nocrcount > 2")
					loop = 2
				end
			end
		elseif loop == 5 then
			if tasktype == 0 then 
				if click_notice() then
					click_ok = 1
				end
			else
				click_ok = 1
			end
			if apple_bid == "com.apple.mobilesafari" then
				if apple_appid == "1912020001" then
					creat_benpao()
				end
				report_notice()
				click_ok = 0
			end
			if click_ok == 1 then
				local fkplist_path = "/private/var/mobile/Library/Preferences/com.capstar.FakeInfo.plist"
				if stomisFileExist(fkplist_path) then
					local ftb = stomplistRead(fkplist_path)
					ftb["MobileIP"] = "110.100."..math.random(100,150).."."..math.random(100,240)
					local str = json.encode(ftb)
					stomplistWrite(str,fkplist_path)
				else
					stomLog("no FakeInfo.plist")
				end
				clicktime = taskConfigTable["clicktime"]
				if clicktime ~= "0" then
					ctime = math.random(clicktime,clicktime+30)*1000
					stommSleep(ctime)
				end
				status = 1
				if tasktype == 0 then 	--0新增;1留存
					if durl ~= "none" and string.find(durl,"aff_sub4") then
						report_notice()
						report_count = report_count + 1
					end
				end
				stomLogPUT("Run App "..taskid,0)
				t1111 = os.time()
				if string.find(taskname,"-注册") then
					if apple_appid =="1282917929" then
						--checkfiles1282917929()
						tar_updateRes()
					end
					status = creatTaskSlion()
					status = creatTask()
					
				else
					status = 0
					stomLog("no注册")
				end
				opentime = loopnum
				stomcloseApp(apple_bid);stommSleep(3000)
				while (true) do
					stomLog("wati...")
					t2 = os.time()
					OpenApp(apple_bid)
					stommSleep(5*1000)
					if os.difftime(t2,t1111) >= opentime then
						stomLog("game over...")
						break
					end
				end
				stomcloseApp(apple_bid);stommSleep(3000)
				loop = 6
			else
				loop = 2
			end
		elseif loop == 6 then
			if isdau == 1 and tasktype == 0 then
				-- rmname ={".tmp",".png",".log",".jpg",".JPEG",".mp3",".mp4",".jpeg",".JPG",".AAC",".m4a",".m4r",".zip",".gz",".tar"}
				-- closeApp(apple_bid);
				-- mSleep(1000);
				-- for var= 1, #rmname do
				-- 	cmd = "find "..appDataPath(apple_bid).." -name '*"..rmname[var].."' | xargs rm -rf '*"..rmname[var].."'"
				-- 	myLog(cmd)
				-- 	os.execute(cmd)
				-- end
				-- os.execute("rm -rf "..appDataPath(apple_bid).."/tmp/*")
				-- os.execute("rm -rf "..appDataPath(apple_bid).."/Library/Caches/*")
				delAppResourcesFile()
				filename = g_now_idfa..".zip"
				stomLogPUT("Backup",0)
				if slionappBackup(apple_bid,filename) then
					loop = 7
				else
					stomLogPUT("Backup False",1)
					loop = 7
				end
			else
				loop = 7
			end
		elseif loop == 7 then
			setvpn("discon");stommSleep(3*1000)
			report_notice()
			report_count = report_count + 1
			fakeinfoTB = getFakeinfo()
			g_now_idfa = fakeinfoTB['idfa']
			if isdau == 1 and tasktype == 0 then
				updataSandboxFiles(g_now_idfa,apple_appid)
			end
			updataCpaKeyUDID(g_now_idfa,apple_appid,apple_bid)
			loop = 8
		elseif loop == 8 then
			--完成
			loop = 2
		elseif loop == 201 then
--			Askdata()
--			if hddownload(apple_appid,down_userid,down_userpassword) > 0 then
--				upAskdata("2")
--			end
			stomopenURL("itms-appss://apps.apple.com/cn/app/id"..apple_appid);
			for i = 1, 30 do
				if stomisFrontApp(apple_bid) == 1 then
					loop = 2
				else
					stomtoast("请下载APP",2)
					stommSleep(5*1000);
				end
			end
		end
		if stomisFrontApp("com.cpa.slion") == 0 and 
			stomisFrontApp("com.saurik.Cydia") == 0 and 
			stomisFrontApp("com.apple.mobilesafari") == 0 then
			stomrunApp("com.cpa.slion")
		end
		stommSleep(100)
		if os.difftime(os.time(),slionRunt) > 120*1000 then
			stomLog("超时180")
			os.exit()
		end
	end
	
end




function nnnnnnn()
	-- body
end