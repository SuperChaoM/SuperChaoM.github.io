require ("xiaowang")
function stommove(x1,x2,y1,y2,time)
	if time then
		sleeptime=time
	else
		sleeptime=500
	end
	touchDown(x1, x2)
	stommSleep(sleeptime)
	touchMove(y1,  y2)
	stommSleep(sleeptime)
	touchUp(y1,  y2)
end

zhangkq={
	["姓氏"]="周李王彭吕张闫岳杜戴赵马郝姚文江胡刘陈邓江毛习曹司钟任徐宁冯苗祁梅秋方邱狄童职朱祝",
	["名字"]="香莹旭敏疏影歌涛章杰伦恩来泽东进平思丝丽颖美艳学友宝川马"..
	"照师欣新乔恩启紫修小琴青庆晴清倾箐沁进金锦华琪鱼花布珠露"..
	"明光千永兆环丰良祺珍曲书沛琪仙之竹向识益女北未自作宜冰伦"..
	"封风峰冯丰锋烽嘉游有佑悠幽攸莲涟爱琴勤钦建剑壮锦尽劲津巾"..
	"瑾矜静华桦符福赋刚余鱼于雨玉宇语羽欲预俞域御育郁渝裕於峪"
	
}

shenfenhao = {
		"130602198805219415","431123199607039297","510104198708229677","430124199106072510","32061119910920438x","510601197001111003",
		"360200198610067739","460200198703302367","513029199210253361","340301197111284054","210211197910271960","432501197403183014",
		"432522196905213751","432522197004104595","430721197510165502","432503197601116114","432503197908236217","432501198812150015",
		"432503198007076353","432522197810254053","43252219810824743X","43012419780315917X","43250319850824225X","432502198806105433",
	}
	
	

function ZKQ_Word(strs,i,Szzd)
	function GetDeviceSeed()	--根据设备ID 产生不同的值
		mSleep(100)
		local SJ = 0; for l=1,string.len(getDeviceID()) do SJ=string.byte(getDeviceID():sub(l,l))+SJ end
		return SJ
	end
	local RetStr,Length,Seed="",1,0
	if string.byte(strs:sub(1,1))>=0x80 then
		Length = 3
	end
	math.randomseed(tostring(os.time()):reverse():sub(1, 6) + GetDeviceSeed() + (Seed or 0))	--叠加时间参数确保任何数值不同
	math.random(string.len(strs)/Length)
	for i=1, i do
		Seed=math.random(string.len(strs)/Length)
		RetStr = RetStr..string.sub(strs,(Seed*Length)-(Length-1),(Seed*Length))
	end
	return(RetStr)
end

 --  nicheng = ZKQ_Word(zhangkq["姓氏"],1,1)..ZKQ_Word(zhangkq["名字"],3,3)
A = math.random(1,#shenfenhao)
	sfznum = shenfenhao[A]

function sgs_chongzhi()				--	三国杀名将传 充值
	stomstomtoast("开始充值模式")
	stomLog("开始充值模式")
	local loop = 1
	while (true) do
		stommSleep(200)
		stomMultiColorTap("孤知道了", {
			{  113,  562, 0xffe67f},
			{  114,  582, 0xbf4212},
			{  103,  582, 0xe8b06e},
			{  132,  583, 0xffda53},
			{  585,  528, 0x955720},
		})
		stomMultiColorTap("进入游戏",{
			{  107,  565, 0xfed64d},
			{  200,  656, 0xffe7b2},
			{  187,  681, 0x8a541f},
			{   90,  554, 0xfffbd0},
			{   61,  576, 0xc53105},
		})
		if loop == 0 then
			openURL("prefs:root=STORE");
			stommSleep(2000)
--			isfront = stomisFrontApp("com.apple.MobileSMS")
--			if isfront==1 then
--				stomstomtoast("充值流程结束",1)
--				stomLog("充值模式结束")
--				return 0
--			end
			
		elseif loop == 1 then
		
			stomMultiColorTap(输入名字框sg,"输入名字框sg")
			if stomMultiColor(键输入名字框sg,"键输入中文名字框sg")or 
				stomMultiColorTap("键英文名字框",{
				{  363,   58, 0xffffff},
				{  351,  102, 0x808080},
				{  359,  140, 0x808080},
				{  357,  974, 0x157efb},
				{  374, 1007, 0x5fa2f1},
			})then
				stomMultiColorTap(键输入名字框sg,"键输入名字框sg")
				stomMultiColorTap(键1号输入名字框sg,"键1号输入名字框sg")
				stommSleep(500)
				nicheng1 = ZKQ_Word(zhangkq["姓氏"],1,1)..ZKQ_Word(zhangkq["名字"],2,2)
				stomInpuText(nicheng1)
				stommSleep(500)
				
			end 
			stomMultiColorTap(键确定sg,"键确定中文名字sg")
			stomMultiColorTap("键确定英文名字",{
				{  359, 1004, 0x157efb},
				{  356,  974, 0x157efb},
				{  369, 1008, 0x4d98f4},
				{  359,  136, 0xffffff},
				{  350,  170, 0xffffff},
			})
			if stomMultiColor(输入身份框sg,"输入身份框sg") then
				stommSleep(1000)
				 stomMultiColorTap(输入身份框sg,"输入身份框sg")
			end
			
			stomMultiColorTap("键中文身份确定",{
				{  427,  974, 0x157efb},
				{  423,  963, 0x72a8ec},
				{  433, 1003, 0x4d97f2},
				{  421, 1076, 0x157efb},
				{  428, 1066, 0x89b4e8},
				{  414,  164, 0xffffff},
				{  414,  127, 0xffffff},
			})	
			
			if stomMultiColor(键输入身份框sg,"键输入身份框sg")or 
			stomMultiColorTap("键英文身份框",{
				{  365,   79, 0xffffff},
				{  350,  169, 0x828282},
				{  364,  974, 0x157efb},
				{  369, 1008, 0x4d98f4},
			}) then
				stomMultiColorTap(键输入身份框sg,"键输入身份框sg")
				stommSleep(500)
				A = math.random(1,#shenfenhao)
				sgfnum = shenfenhao[A]
				stomInpuText(sgfnum)
				stommSleep(500)
				
			end
			
			if stomColorInReg( "有身份输入", 0x7f541b, 90, 311, 663, 331, 679)then
				stomMultiColorTap(提交注册sg,"提交注册sg")
			end
		end

	
		isfront = stomisFrontApp("com.apple.MobileSMS")
		if isfront==1 then
			stomtoast("充值流程结束",1)
			stomLog("充值模式结束")
			return 0
		end
				
	end

end

function zhang_1356464028()							--			三国杀名将传
	local t1 = os.time()
	local time_cha = math.random(10,15)*60
	local loop = 0
	local denglu = 0
	local tiaojian = 0
	
	while (true) do
		OpenApp("com.sanguosha.mjz")
		if stomMultiColor("充值界面",{
			{  588,  517, 0xf6ead6},
			{  508,  850, 0xffac54},
			{  357,  216, 0xfff889},
			{  440,  288, 0xd53e37},
			{  575,  226, 0x31406f},
		})then
			sgs_chongzhi()	
		end
		stomMultiColorTap("孤知道了", {
			{  113,  562, 0xffe67f},
			{  114,  582, 0xbf4212},
			{  103,  582, 0xe8b06e},
			{  132,  583, 0xffda53},
			{  585,  528, 0x955720},
		})
	
		stomMultiColorTap("游卡登录", {
			{  192,  700, 0xca5155},
			{  195,  718, 0xfdf8f8},
			{  286,  758, 0xce2230},
			{  466,  819, 0xc4c4c4},
			{  472,  509, 0x060606},
		})
		
		stomMultiColorTap("立即注册",{
			{  173,  699, 0xffffff},
			{  173,  715, 0xce2230},
			{  166,  692, 0xce2230},
			{  465,  819, 0xc4c4c4},
			{  459,  573, 0xea3239},
		})
		
		
		if stomMultiColor("账号框", {
			{  394,  474, 0xffffff},
			{  389,  677, 0xd5d5da},
			{  399,  667, 0xd4d4da},
			{  420,  632, 0xbdbdbd},
			{  261,  579, 0xce2230},
			{  117,  573, 0xfed846},
		}) then
			stommSleep(2000)
			stomMultiColorTap("账号框", {
			{  394,  474, 0xffffff},
			{  389,  677, 0xd5d5da},
			{  399,  667, 0xd4d4da},
			{  420,  632, 0xbdbdbd},
			{  261,  579, 0xce2230},
			{  117,  573, 0xfed846},
			})
		end
	
		
		if stomMultiColorTap("账号框", {
			{  479,  474, 0xffffff},
			{  475,  672, 0xc8c8ce},
			{  448,  657, 0xbdbdbd},
			{  434,  649, 0xbdbdbd},
			{  545,  573, 0xea3239},
			{  546,  593, 0x262626},
		}) then
			stommSleep(1000)
			r = math.random(7,11) 
			myRand(4,r,2)
			zhanghao = myRand(4,r,2)
			t = math.random(2,4) 
			myRand(4,t,2)
			zhanghao1 = myRand(4,t,2)
			stomInpuText(zhanghao..zhanghao1)
			stommSleep(1000)
		end

		if stomMultiColor("键账号初始", {
			{  468,  738, 0xcccccc},
			{  551,  819, 0xc4c4c4},
			{  475,  668, 0xffffff},
			{  539,  507, 0x1e1e1e},
			{  544,  573, 0xea3239},
			})then
				stommSleep(500)
				stomtap(482, 1007)
				stommSleep(500)
		end
		
		if stomMultiColor("密码框",{
			{  322,  473, 0xffffff},
			{  318,  676, 0xcacad0},
			{  259,  756, 0xce2230},
			{  111,  564, 0xfed74c},
			{  348,  691, 0xbdbdbd},
			{  291,  677, 0xbdbdbd},
			{  459,  573, 0xea3239},
		}) then
			stommSleep(2000)
			stomMultiColorTap("密码框",{
			{  322,  473, 0xffffff},
			{  318,  676, 0xcacad0},
			{  259,  756, 0xce2230},
			{  111,  564, 0xfed74c},
			{  348,  691, 0xbdbdbd},
			{  291,  677, 0xbdbdbd},
			{  459,  573, 0xea3239},
			})
		end
		
		if stomMultiColorTap("密码框",{
			{  425,  474, 0xffffff},
			{  420,  675, 0xc8c8ce},
			{  360,  757, 0xce2230},
			{  568,  819, 0xc4c4c4},
			{  562,  573, 0xea3239},
			})then
			stommSleep(1000)
			e = math.random(9,12)
			mima = myRand(4,e,2)
			stomLog("密码="..mima)
			stomInpuText(mima)
			stommSleep(1000)
		end
		
		if stomMultiColor("键密码框初始",{
			{  414,  737, 0xcccccc},
			{  568,  819, 0xc4c4c4},
			{  562,  573, 0xea3239},
			{  423,  433, 0x000000},
			{  362,  579, 0xce2230},
			})then
			stommSleep(500)
			stomtap(447,  992)
			stommSleep(500)
		end
		
		if stomMultiColorTap("注册并登录",{
			{  258,  566, 0xce2230},
			{  238,  537, 0xffffff},
			{  233,  547, 0xf8dcde},
			{  320,  433, 0x000000},
			{  389,  676, 0xffffff},
			}) then
			stommSleep(5000)
			denglu = denglu + 1
		end
		
		if stomMultiColorTap("进入游戏",{
			{  107,  565, 0xfed64d},
			{  200,  656, 0xffe7b2},
			{  187,  681, 0x8a541f},
			{   90,  554, 0xfffbd0},
			{   61,  576, 0xc53105},
		}) then
			stommSleep(5000)
			
		end
		if denglu > 2 then
			if stomMultiColorTap("退出注册界面",{
				{  465,  300, 0xc4c4c4},
				{  454,  508, 0x212625},
				{  459,  573, 0xea3239},
				{  466,  819, 0xc4c4c4},
				{  319,  433, 0x000000},
				{  217,  563, 0xce2230},
			}) then
				denglu = 0
				return 0
			end
			
		end
		
		
		stomMultiColorTap("进入游戏",{
			{  107,  565, 0xfed64d},
			{  200,  656, 0xffe7b2},
			{  187,  681, 0x8a541f},
			{   90,  554, 0xfffbd0},
			{   61,  576, 0xc53105},
		})
		
		stomMultiColorTap("游卡桌游接受",{
			{   79,  696, 0x78c83d},
			{   75,  669, 0xffffff},
			{   77,  727, 0xb5e097},
			{   72,  473, 0xdb7073},
			{   76,  436, 0xc9242a},
		})
		
		stomMultiColorTap("跳过剧情",{
			{  619, 1066, 0xc68b1c},
			{  623, 1014, 0xe2aa31},
			{  615, 1079, 0x844503},
			{  619, 1111, 0xf9e55b},
		})
		stomMultiColorTap("任意点击继续",{
			{  146,  598, 0x3e0400},
			{   48,  564, 0x5a240e},
			{  357,  555, 0xfdab38},
			{  430,  627, 0xfdab38},
		})
		
		if stomMultiColor("创建角色界面",{
			{  446,   66, 0xfffae5},
			{  544,   71, 0xfff9e4},
			{   55,  216, 0xf6aea7},
			{   70,  101, 0xe2a5a6},
			{   46,   78, 0x4e1d3d},
		}) then
			tby = {99,228}
			aa = math.random(1,#tby)
			y1 = tby[aa]
			stomtap(73,y1)
			stommSleep(1000)
		end
		
		if stomMultiColorTap("筛子",{
			{  167, 1106, 0xfefefa},
			{  166, 1098, 0xab3c37},
			{   73, 1087, 0xe0b45c},
			{   91, 1096, 0x775f52},
			{  111,  954, 0xf7ee8c},
			{   41,  949, 0xb53408},
			})then
			stommSleep(1000)
			stomMultiColorTap("创建进入游戏",{
				{   54,  961, 0xf7951b},
				{   69,  953, 0xfffbd1},
				{   41,  955, 0xb73a09},
				{  166, 1099, 0xab3c37},
				{  111,  960, 0xf7ee8c},
			})
		end
		
		stomMultiColorTap("第一回任意点击",{
			{  364,  486, 0xfdab38},
			{  423,  419, 0xdd9616},
			{  427,  415, 0x7e3600},
			{  426,  479, 0x7e3600},
			{  466,  479, 0xfee15d},
		})
		stomMultiColorTap("完胜任意点击",{
			{  385,  858, 0xfedd3e},
			{  526,  851, 0xffe62d},
			{  458,  833, 0x8a2e00},
			{  557,  837, 0xd4bec8},
		})
		
		stomMultiColorTap("升级啦",{
			{  415,  561, 0xffffff},
			{  498,  565, 0xfffd5f},
			{  458,  471, 0x912016},
			{  487,  661, 0xfff569},
			{  476,  654, 0xd79f38},
		})
		
		stomMultiColorTap("招募前往查看",{
			{   94,  542, 0xfff2a8},
			{  105,  608, 0xb62b03},
			{  293,  557, 0xe37924},
			{  542,  565, 0xfff756},
		})
		
		stomMultiColorTap("招募图标",{
			{   60,  248, 0xf5463f},
			{   87,  234, 0xf82935},
			{   56,  191, 0x729696},
			{   16,  230, 0xdda222},
			{  186,  507, 0xfffdef},
		})
		if stomMultiColor("紫免费招募",{			--		任意点击
			{  107,  645, 0xde9a65},
			{  386,  977, 0xcbb5ca},
			{  391, 1073, 0xdb901c},
			{  395,  647, 0xfeeb63},
			{  518,  405, 0xfeea62},
			{  280, 1052, 0xed3e44},
		})or 
		stomMultiColor("紫免费招募",{
			{  520,  476, 0xf3ae09},
			{  555,  537, 0xfff763},
			{  509,  606, 0xfd4911},
			{  533,  657, 0xd37b28},
			{  492,  564, 0xffffff},
		})or 
		stomMultiColor("突破成功",{
			{  569,  475, 0xffd026},
			{  567,  499, 0xa92e16},
			{  576,  557, 0xffffff},
			{  589,  642, 0xfff668},
			{  576,  736, 0xff9e12},
		})or 
		stomMultiColor("第一回通关",{
			{  554,  426, 0xeeb536},
			{  551,  433, 0x8a4505},
			{  550,  501, 0xeaaf2f},
			{  471,  760, 0xcaf400},
			{  533,  420, 0xde9716},
		})or 
		stomMultiColor("第二回开始",{
			{  445,  422, 0xeeb638},
			{  448,  430, 0x7d3500},
			{  445,  483, 0xeeb638},
			{  425,  486, 0xa26905},
			{  460,  478, 0x602801},
			{  464,  483, 0xfcd155},
		})then
			x = math.random(1,639)
			y = math.random(1,1135)
			stomtap(x,y)
		end
		
		stomMultiColorTap("紫免费招募",{
			{  129,  619, 0xffbd6a},
			{  127,  573, 0xff8822},
			{  279,  608, 0xfe69f4},
			{   82,  687, 0xfac996},
			{  263,  249, 0x2e9cd1},
		})
		
		stomMultiColorTap("任意关银屏",{
			{  152,  953, 0xd9e1e1},
			{  113, 1007, 0xdc9e45},
			{  553,  110, 0xffffff},
			{  386,  431, 0x6abb3f},
			{  464,  526, 0xf8b1ab},
		})
		
		stomMultiColorTap("任意获得关银屏",{
			{  109,  570, 0xdd9865},
			{  566,  548, 0xb8189d},
			{  580,  536, 0xfde329},
			{  576,  536, 0x8c050f},
			{  617,  537, 0xffe13e},
		})
		
		stomMultiColorTap("对话张星彩",{
			{  129,  288, 0x461d15},
			{  359,  230, 0xfdd8c6},
			{  272,  217, 0xbc50c3},
			{  269,  237, 0xfd459a},
			{  450,   79, 0x6c9e19},
		},-80,50)
		
		stomMultiColorTap("手指返回",{
			{  618,   86, 0xfadd80},
			{  568,   69, 0xfbce9a},
			{  550,   94, 0x4af7c0},
			{  630,   69, 0xe99868},
		})
		
		stomMultiColorTap("手指上阵关银屏",{
			{  277,  325, 0xffffff},
			{  303,  332, 0x97cf1e},
			{  239,  362, 0xfcce9b},
			{  245,  396, 0xf9c590},
		})
		
		stomMultiColorTap("手指上阵",{
			{  457,  449, 0xffb759},
			{  370,  559, 0xfdd564},
			{  494,  121, 0xda31ff},
			{  564,  609, 0x7086be},
		})
		
		stomMultiColorTap("手指征战",{
			{   59, 1048, 0xf2e4d6},
			{  232, 1108, 0xff587c},
			{  225, 1050, 0xfffdef},
			{  103,  983, 0xf5bb85},
		})
	
		stomMultiColorTap("合击激活任意",{
			{  343,  567, 0x5ba903},
			{  343,  548, 0x7bd402},
			{  338,  504, 0xfff78b},
			{  352,  501, 0xe43fff},
			{  498,  589, 0xfff63d},
		})
		
		
		
		stomMultiColorTap("手指第一回英雄",{
			{  256,  223, 0x83a165},
			{  232,  282, 0xf5f8ee},
			{  193,  324, 0xfacb99},
			{  276,  122, 0x99490f},
			{  308,  119, 0xac6730},
			{  357,  169, 0xfe8ae7},
		})
		
		stomMultiColorTap("手指精锐军",{
			{  222,  564, 0xffffff},
			{  261,  562, 0xffdea9},
			{  343,  547, 0x705723},
			{  131,  467, 0xff587c},
			{  116,  445, 0xfffdef},
		})
		
		stomMultiColorTap("手指挑战",{
			{  148,  828, 0xffea7c},
			{  372,  785, 0x774208},
			{   66,  923, 0xfbda79},
			{  540,  948, 0x435595},
		})
		
		
		stomMultiColorTap("手指精锐军",{
			{  222,  564, 0xffffff},
			{  261,  562, 0xffdea9},
			{  343,  547, 0x705723},
			{  131,  467, 0xff587c},
			{  116,  445, 0xfffdef},
		})
		
		stomMultiColorTap("半手指突破",{
			{   73,  915, 0xffe970},
			{   22,  979, 0xf6bc86},
			{  619,  960, 0xffed2f},
			{  611,   22, 0x8e201d},
			{  476,   49, 0x3f4f8f},
		})
		
		
		
		
		
		
		stomMultiColorRegTap("手指向上",0xf3b077, "-48|-2|0xc46b48,-52|49|0x4af7c0,-46|56|0xfede7d,-65|38|0x8c4e23", 90, 0, 0, 639, 1135)
		stomMultiColorRegTap("手指向下",0xeea972, "49|4|0xc36946,76|-42|0x935d33,56|-54|0x4af7c0,49|-61|0xfede7d", 90, 0, 0, 639, 1135)
		local t2 = os.time()
		if os.difftime(t2,t1) > time_cha then
			if tasktype == 0 then
				stomLog("超过10分钟")
				return 0
			else
				return 0
			end
		end
	
	end
	
end


--													黑暗充值





function hadl_充值()
	stomLog("进入充值模式")
	stomtoast("进入充值模式")
	while (true) do
	
	shopapplestore()
	isfront = stomisFrontApp("com.apple.MobileSMS")
		if isfront==1 then
			stomtoast("充值流程结束",1)
			stomLog("充值模式结束")
			return 0
		end
	
	
	
	
	
	
	end

end




function zhang_1467863426()							--			黑暗大陆
	local t1 = os.time()
	local time_cha =  math.random(10,15)*60
	local loop = 0
	local zhucebug = 0
	
	while (true) do
		OpenApp("com.darklandhadlsdfs")
		
		stomMultiColorTap("用户注册",{
			{  308,  554, 0xf9da6f},
			{  300,  554, 0xffffff},
			{  270,  577, 0xf89440},
			{   83,  305, 0xa52910},
			{  502,  571, 0x2055b5},
		})
		
		if stomMultiColor(任意装备突破成功ha,"任意装备突破成功ha")or
		stomMultiColor(任意突破成功ha,"任意突破成功ha")or
		stomMultiColor(任意恭喜获得ha,"任意恭喜获得ha")then	
			
			x = math.random(1,639)	
			y = math.random(1,1135)
			stomtap(x,y)
		end
		
		if stomMultiColorTap("账号框",{
			{  440,  445, 0xf4d19f},
			{  434,  432, 0xff9933},
			{  437,  508, 0xfda84e},
			{  391,  462, 0xffffff},
			{  551,  541, 0x996600},
			})or
			stomMultiColorTap("账号框10*",{
				{  427,  405, 0xf4d19f},
				{  457,  516, 0xff9933},
				{  469,  529, 0xffffff},
				{  550,  509, 0x996600},
				{  312,  345, 0xcc9966},
			})then
			stommSleep(1000)
		end
		
		if stomMultiColorTap("键账号框",{
			{  599,  444, 0xf4d19f},
			{  597,  512, 0xfda84e},
			{  607,  505, 0xff9933},
			{  628,  502, 0xffffff},
			{  448,  346, 0xcc9966},
			})or
			stomMultiColorTap("键账号框10*",{
				{  587,  407, 0xf4d19f},
				{  617,  517, 0xff9933},
				{  629,  530, 0xffffff},
				{  508,  542, 0xffffff},
				{  448,  342, 0xcc9966},
			})then
			stommSleep(1000)
			 m = math.random(6,8) 
			 mima = myRand(4,m,2)
			n = math.random(3,5) 
			mima1 = myRand(4,n,2) 
			stomInpuText(mima..mima1)
			stommSleep(2000)
			stomtap(472,  950)
		end
	
		if stomMultiColorTap("密码框",{
			{  319,  439, 0xf4d19f},
			{  313,  511, 0xff9933},
			{  327,  509, 0xff9933},
			{  289,  346, 0xcc9966},
			{  295,  796, 0xcf9d6a},
			{  136,  624, 0xc84a31},
		})or
			stomMultiColorTap("密码框10*",{
				{  307,  407, 0xf4d19f},
				{  330,  505, 0xff9c39},
				{  288,  343, 0xcc9966},
				{  148,  412, 0xca5038},
				{  551,  539, 0x996600},
			})then
			stommSleep(1000)
		end
		
		if stomMultiColorTap("键密码框",{
			{  479,  439, 0xf4d19f},
			{  473,  511, 0xff9933},
			{  487,  509, 0xff9933},
			{  454,  796, 0xcc9966},
			{  508,  710, 0xffffff},
		})or
		stomMultiColorTap("键密码框10*",{
			{  469,  407, 0xf4d19f},
			{  490,  506, 0xff9c39},
			{  448,  342, 0xcc9966},
			{  508,  573, 0xffffff},
			{  548,  568, 0xf8dd6d},
			{  550,  588, 0xffffff},
		})then
			stommSleep(1000)
			 n = math.random(6,9) 
			 zhanghao = myRand(3,n,2)
			stomInpuText(zhanghao)
			stommSleep(2000)
			stomtap(472,  950)
		end
		
		if stomMultiColor("注册",{
			{  142,  617, 0xc84a31},
			{  148,  584, 0xffffff},
			{  153,  576, 0xeac4bf},
			{  309,  392, 0x990000},
			{  548,  593, 0x996600},
		})then
			stommSleep(1000)
			stomMultiColorTap("注册",{
				{  142,  617, 0xc84a31},
				{  148,  584, 0xffffff},
				{  153,  576, 0xeac4bf},
				{  309,  392, 0x990000},
				{  548,  593, 0x996600},
			})
			zhucebug = zhucebug + 1
		end
		if zhucebug > 2 then
			stomtoast("注册失败，重来")
			if stomMultiColorTap(退出注册界面ha,"退出注册界面ha") then
				zhucebug = 0
			end
		end
		
		stomMultiColorTap("进入游戏",{
			{   80,  548, 0x2e9457},
			{  101,  510, 0xffffff},
			{   74,  516, 0x335522},
			{   56,  606, 0x301b06},
			{   54,  583, 0x956a36},
			{  176,  743, 0xfefffe},
		})
		
		stomMultiColorTap("本王知道了暗",{
			{   89,  576, 0x1e5f37},
			{   87,  582, 0x5c6e4e},
			{   87,  546, 0x1e3d1e},
			{  587,  483, 0x6e190f},
			{  573,  574, 0x927444},
		})

		stomMultiColorTap("绑定手机号",{
			{  559,  807, 0xcc9966},
			{  364,  835, 0xc84a31},
			{  551,  660, 0x996600},
			{  114,  572, 0xf3cbbe},
			{  136,  325, 0xc6a889},
		})
		
		stomMultiColorTap("本王知道了",{
			{   91,  563, 0xffffcc},
			{   87,  532, 0x336633},
			{   99,  626, 0x417948},
			{  114,  566, 0x386f3e},
			{  115,  558, 0x271200},
		})
		
		stomMultiColorTap("跳过",{
			{  618,   67, 0xfefef5},
			{  616,   67, 0xc2977d},
			{  598,   68, 0xffd015},
			{  595,   66, 0x873300},
		})
		
		if stomMultiColorTap("摇色子sg",{
			{  338,  840, 0xf35b23},
			{  327,  836, 0xf7dc95},
			{  311,  849, 0x4e0608},
			{  234,  740, 0x38a862},
		}) then
			stommSleep(1000)
			stomMultiColorTap("确定进入游戏sg",{
				{  221,  706, 0x2e9457},
				{  252,  715, 0x386f3e},
				{  337,  840, 0xf35b23},
				{  311,  839, 0xd28c2c},
			})
			stommSleep(5000)
		end
		
		stomMultiColorTap("小娜娜对话",{
			{  133,  727, 0xe6d0b6},
			{  111,  819, 0x902400},
			{  131,  939, 0xd15900},
			{  141,  877, 0x621600},
		})
	
		stomMultiColorTap("指引酒馆",{
			{  126,  909, 0x67371a},
			{  153,  908, 0x47bad3},
			{  227,  894, 0xd0d6c6},
			{  213,  850, 0x804d28},
		})
		
		stomMultiColorTap("绿色英雄",{
			{  298,  369, 0xfef8e1},
			{  382,  355, 0xd5ccca},
			{  433,  368, 0xcad9c4},
			{  507,  702, 0xd200f8},
			{  503,  711, 0xec9334},
		})
		
		stomMultiColorTap("购买一次",{
			{  300,  362, 0x1b92de},
			{  290,  372, 0x222222},
			{  207,  356, 0xc9cfc3},
			{   90,  362, 0xc7d5e5},
		})
		
		stomMultiColorTap("法师任意点击",{
			{   85,  577, 0x2c1e15},
			{  217,  820, 0xf7de7a},
			{  219,  324, 0xf7db76},
			{  241,  575, 0x131006},
		})
		
		stomMultiColorTap("恭喜获得法师任意",{
			{   55,  555, 0x010000},
			{  577,  488, 0xffffd2},
			{  581,  496, 0x0f0901},
			{  542,  525, 0xeebc21},
			{  509,  390, 0x53009d},
		})
			
		stomMultiColorTap("指引获得法师确定",{
			{   48,  780, 0x115dae},
			{   63,  772, 0xffffff},
			{   59,  755, 0xa5b19f},
			{  152,  778, 0xc6c5c4},
			{   32,  546, 0xb18752},
		})
		
		stomMultiColorTap("战士点击购买",{
			{  279,  779, 0x635392},
			{  187,  765, 0xd87212},
			{  365,  784, 0xfaf6fb},
			{  540,  775, 0xfee7c2},
			{   72,  791, 0x7b049e},
		})
		
		stomMultiColorTap("战士购买一次",{
			{  286,  796, 0x1367bd},
			{  292,  800, 0x222222},
			{  182,  783, 0xc8c5c9},
			{  127,  775, 0xcce8f3},
			{  539,  785, 0xf5c754},
		})
		
		stomMultiColorTap("指引返回主界面",{
			{  598,  149, 0xf0d17e},
			{  592,  150, 0x744605},
			{  574,  150, 0x482e17},
			{  505,  148, 0xc7c6c5},
		})
		
		stomMultiColorTap("指引副本",{
			{  296,  654, 0x000000},
			{  225,  647, 0xffcc83},
			{  236,  669, 0xfff0cc},
			{  301,  759, 0xf6e0e6},
		})
		
		stomMultiColorTap("指引第一章",{
			{  216,  195, 0x883d00},
			{   92,  153, 0xffcb44},
			{  222,  261, 0xe9e3d7},
			{  200,  198, 0xd49941},
		})
		
		stomMultiColorTap("指引1-1",{
			{  299,  184, 0x03eaf3},
			{  292,  161, 0xac7b44},
			{  297,  256, 0xcdd6d2},
			{  289,  168, 0xa47642},
		})
		
		stomMultiColorTap("消耗体力箭头",{
			{  103,  910, 0xe6b55b},
			{  121,  913, 0xffffe4},
			{  102,  922, 0x54472d},
			{  159,  981, 0xf8d76e},
			{  211,  959, 0x8df529},
		})
		
		stomMultiColorTap("指引派遣战士",{
			{  115,  161, 0xfeefd3},
			{   87,  146, 0xfdfc77},
			{  175,  141, 0xc9c9c6},
			{  201,  149, 0xe0d6cf},
			{  143,  182, 0xfd2b06},
		})
		
		stomMultiColorTap("指引派遣法师",{
			{   99,  300, 0xfeebdc},
			{  143,  333, 0xfc2604},
			{  174,  291, 0xc9c8c6},
			{  211,  284, 0xe1d8d0},
		})
		
		stomMultiColorTap("双剑开始战斗",{
			{   92, 1045, 0xfef5a5},
			{   81, 1050, 0xdfa147},
			{  142, 1108, 0xb88b54},
			{   77,  174, 0x36d400},
		})
		
		stomMultiColorTap("剑刃大师对话",{
			{  108,  707, 0xe6d0b6},
			{  115,  199, 0xdb6100},
			{  121,  189, 0x621600},
			{   98,  291, 0x54b704},
		})
		
		if stomMultiColor("滑动英雄走位",{
			{  336,  148, 0xdedad0},
			{  385,  176, 0x5a666a},
			{  212,  549, 0x62c40b},
			{  393,  184, 0xe6fafa},
		})then
			stommove( 203,  398, 424,  155)
		end
		
		stomMultiColorTap("指引释放战士技能",{
			{   64,  684, 0xffffff},
			{   50,  662, 0xffea78},
			{  165,  673, 0xd3d1ca},
			{   58,  435, 0x474746},
		})
		
		stomMultiColorTap("箭头下一关",{
			{  307,  998, 0xebc474},
			{  320, 1056, 0xffffde},
			{  286, 1055, 0x542c11},
			{  272,  983, 0xd38018},
		})
	
		stomMultiColorTap("恶魔猎手对话",{
			{  111,  648, 0xe7d1b7},
			{  119,  952, 0xdf6500},
			{  100,  861, 0x54b704},
			{  228,  649, 0xe7d1b7},
		})
		
		stomMultiColorTap("指引恶魔技能",{
			{  104,  865, 0xfef2a8},
			{  115,  865, 0xfe1c09},
			{   96,  857, 0xe6bb62},
			{  184,  861, 0xd2cbc7},
		})
		
		stomMultiColorTap("战争奖励箭头",{
			{  123,  887, 0xe9bd6c},
			{  143,  906, 0xffffea},
			{  140,  951, 0xffffde},
			{   95,  942, 0x542c11},
			{   84,  889, 0x542c11},
			{  509,  423, 0xcc7b00},
		})
		
		stomMultiColorTap("战队升级",{
			{  507,  547, 0xffe269},
			{  478,  543, 0xdc6000},
			{  499,  574, 0x873300},
			{  376,  652, 0x26b801},
		})
		
		stomMultiColorTap("指引进入菜单",{
			{  597, 1081, 0xf6e290},
			{  576, 1062, 0x4d321a},
			{  603, 1081, 0x8b7f76},
			{  589, 1002, 0xded2cd},
		})
		
		stomMultiColorTap("指引请点击英雄",{
			{  488, 1074, 0x2a0d09},
			{  512, 1080, 0xfdf8e1},
			{  474, 1086, 0x854a31},
			{  496,  994, 0xc7c7c7},
		})
		stomMultiColorTap(指引剑刃大师ha,"指引剑刃大师ha")
		stomMultiColorTap(指引锤头ha,"指引锤头ha")
		stomMultiColorTap(指引副本开启路途ha,"指引副本开启路途ha")
		stomMultiColorTap(二位法师技能ha,"二位法师技能ha")
		stomMultiColorTap(指引法师技能ha,"指引法师技能ha")
		stomMultiColorTap(指引龙龟据点ha,"指引龙龟据点ha")
		stomMultiColorTap(二位战士技能ha,"二位战士技能ha")
		stomMultiColorTap(指引手镯装备ha,"指引手镯装备ha")
		stomMultiColorTap(指引突破装备ha,"指引突破装备ha")
		stomMultiColorTap(指引铠甲ha,"指引铠甲ha")
		stomMultiColorTap(指引靴子ha,"指引靴子ha")
		stomMultiColorTap(小娜娜对话ha,"小娜娜对话ha")
		stomMultiColorTap(指引英雄突破ha,"指引英雄突破ha")
		stomMultiColorTap(指引返回主城ha,"指引返回主城ha")
		stomMultiColorTap(指引副本旅途ha,"指引副本旅途ha")
		stomMultiColorTap(指引领取宝箱ha,"指引领取宝箱ha")
		stomMultiColorTap(指引冲锋目标ha,"指引冲锋目标ha")
		stomMultiColorTap(指引星宝箱ha,"指引星宝箱ha")
		stomMultiColorTap(锤头装备突破ha,"锤头装备突破ha")
		
		if stomMultiColor(充值界面ha,"充值界面ha") then
			
			hadl_充值()
		end
		
		
		stomMultiColorRegTap("指引攻击据点",0x03eaf3, "-10|-15|0xa47642,-20|-14|0x895c2d,-2|64|0xcbd3d1,-18|98|0x9da9a5", 90, 0, 0, 639, 1135)
		stomMultiColorRegTap("攻击据点",0x03eaf3, "-7|-23|0xac7b44,-15|-28|0x70481d,35|-7|0xe0f0e9,27|2|0xffd854", 90, 0, 0, 639, 1135)
		
	

--		stomMultiColorTap(锤头装备突破ha,"锤头装备突破ha")
	

	
		local t2 = os.time()
		if os.difftime(t2,t1) > time_cha then
			if tasktype == 0 then
				stomLog("超过10分钟")
				return 0
			else
				return 0
			end
		end
	stommSleep(500)
	end
	

end



function shopapplestore()		-- 						充值后设置按键
		applePWD="Zxc112211"
				if stomMultiColor("sw设置界面",{
					{  295,  424, 0x215da5},
					{  283,  441, 0x295d9c},
					{  307,  444, 0x215da5},
					{  299,  494, 0xb5d7f7},
				})	then
					stomtap(414,34)
				end
				stomMultiColorTap("绿色对勾绑定成功",{
				{  537,  830, 0x848684},
				{  541,  530, 0x000000},
				{  540,  536, 0x100c10},
				{  541,  560, 0x393c42},
			})
				stomMultiColorTap("进入商城1",{
				{  417,   26, 0xc65921},
				{  404,   20, 0xe7c763},
				{  403,   41, 0xf7d363},
				{  398,   34, 0xe7b64a},
			})
				stomMultiColorTap("进入商城2",{
				{  478,   26, 0xc65521},
				{  472,   19, 0xe7c763},
				{  471,   40, 0xefd363},
				{  465,   23, 0xe7b242},
			})
			--if myosver < 11 then
				if stomMultiColor("横向只输密码",{
					{  437,  348, 0xc7c7cd},
					{  437,  357, 0xc7c7cd},
					{  428,  382, 0xcdcdd3},
					{  420,  371, 0xcbcbd1},
				}) then
					stommSleep(300)
					stomInpuText(applePWD)
					stommSleep(300)
					stomtap(368,  692)
				end
				stomMultiColorTap("横向长账号设置",{
					{  203,  691, 0x007aff},
					{  204,  718, 0x007aff},
					{  189,  712, 0x007aff},
					{  425,  485, 0x000000},
				})
				if stomMultiColor("长账号纵支付密码",{
					{   99,  402, 0xc7c7cd},
					{  106,  402, 0xc7c7cd},
					{  104,  421, 0xc7c7cd},
					{  126,  415, 0xd0d0d5},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(300)
					stomMultiColorTap("确认密码",{
						{  455,  505, 0x007aff},
						{  458,  505, 0x007aff},
						{  462,  505, 0x007aff},
					})
				end
				if stomMultiColor("长账号横支付密码",{
					{  544,  768, 0x676f73},
					{  506,  550, 0x17191a},
					{  427,  348, 0xc7c7cd},
					{  420,  373, 0xc7c7cd},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(300)
					stomMultiColorTap("确认密码",{
						{  367,  706, 0x007aff},
						{  367,  709, 0x007aff},
						{  367,  713, 0x007aff},
					})
				end
				if stomMultiColor("账号和密码横向CN",{
					{  191,  196, 0x000000},
					{  230,  196, 0x000000},
					{  400,  270, 0x9d9dad},
					{   99,  343, 0xd4d4d9},
				}) or stomMultiColor("账号和密码横向EN",{
				{  188,  232, 0x000000},
				{  229,  232, 0x000000},
				{  410,  331, 0xffffff},
				{  100,  380, 0xc7c7cd},
				})then
					stommSleep(500)
					stomtap(598, 1109)
					stomInpuText(applePWD)
					stommSleep(500)
					stomtap(353,  332)
				end	
				if 	stomMultiColor("账号和密码横向CN",{
					{  567,  436, 0x000000},
					{  582,  481, 0x000000},
					{  500,  620, 0xffffff},
					{  431,  690, 0x007aff},
				}) or stomMultiColor("账号和密码横向EN",{
					{  444,  348, 0xc7c7cd},
					{  435,  344, 0xc7c7cd},
					{  436,  352, 0xc7c7cd},
					{  445,  378, 0xc7c7cd},
				})then
					stommSleep(500)
					stomtap(27, 1055)
					stomInpuText(applePWD)
					stommSleep(500)
					stomtap(545,  344)
				end		
				
			--end
					stomMultiColorTap("纵向设置",{
					{  442,  668, 0x007aff},
					{  428,  671, 0x007aff},
					{  471,  664, 0x007aff},
					{  472,  682, 0x007aff},
				})		
					stomMultiColorTap("注册完成关闭多益账号显示",{
						{  437,  831, 0x8c8684},
						{  221,  389, 0x528af7},
						{  280,  484, 0x1086f7},
						{  443,  311, 0xde0010},
					})				
					stomMultiColorTap("单行密码已输入确认",{
						{  461,  489, 0x007aff},
						{   98,  397, 0x000000},
						{  114,  397, 0x000000},
						{  474,  305, 0x606668},
						{  192,  217, 0x000000},
					})
					stomMultiColorTap("无法连接IT横粗",{
						{  252,  559, 0x007aff},
						{  367,  393, 0x000000},
						{  373,  471, 0x8c999c},
						{  364,  578, 0xb7c2c7},
					})
					stomMultiColorTap("使用现有B",{
						{  343,  503, 0x007aff},
						{  249,  454, 0x007aff},
						{  173,  548, 0x007aff},
						{  466,  545, 0x242526},
					})
					stomMultiColorTap("使用现有纵",{
						{  241,  538, 0x007aff},
						{  240,  547, 0x0c80ff},
						{  278,  536, 0x007aff},
						{  446,  539, 0x007aff},
					})
					stomMultiColorTap("设置纵粗",{
						{  444,  668, 0x007aff},
						{  428,  667, 0x007aff},
						{  224,  476, 0x000000},
						{  157,  667, 0x007aff},
						{  462,  562, 0x000000},
					})
				stomMultiColorTap("网络异常重登",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("无法连接IT纵粗",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("验证失败再次粗",{
					{  652,  403, 0x007aff},
					{  510,  252, 0x000000},
					{  585,  251, 0x000000},
					{  763,  303, 0xd8dcda},
				})
				stomMultiColorTap("确认购买纵粗？？",{
					{  425,  666, 0x007aff},
					{  166,  483, 0x000000},
					{  422,  483, 0x616161},
					{  554,  678, 0xf9f9f9},
				})			
				stomMultiColorTap("使用现有",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("使用现有纵",{
					{  277,  537, 0x007aff},
					{  305,  430, 0x000000},
					{  334,  429, 0x595d5d},
					{  473,  635, 0xced2d2},
				})				
				if stomMultiColor("登录换行",{
					{   38,  968, 0x363737},
					{  581,  444, 0x4b4d4f},
					{  581,  481, 0x000000},
					{  437,  413, 0x007aff},
				})	then
					stommSleep(500)	
					stomMultiColorTap("登录换行",{
					{   38,  968, 0x363737},
					{  581,  444, 0x4b4d4f},
					{  581,  481, 0x000000},
					{  437,  413, 0x007aff},
				})	
					stommSleep(500)	
					if stomMultiColor("输入txt",{
						{  491,  348, 0xc7c7cd},
						{  485,  396, 0xffffff},
						{  270,  377, 0x605f60},
						{  365,  412, 0x007aff},
					})	then
						stomInpuText(applePWD)
						stommSleep(300)
						stomMultiColorTap("点击上行",{
							{  550,  688, 0xffffff},
							{  488,  688, 0xffffff},
							{  338,  518, 0xccced1},
						})		
						--复制 @163.com
					end
				end
				--[[if stomMultiColor("登录换行纵向",{
					{  191,  196, 0x000000},
					{  232,  203, 0x585c5b},
					{  362,  292, 0xffffff},
					{  100,  345, 0xc7c7cd},
				}) or stomMultiColor("登录换行纵向B",{
					{   93,  321, 0xd0dafc},
					{  195,  232, 0x000000},
					{  175,  384, 0xffffff},
					{  106,  332, 0xffffff},
					{  262,  244, 0x000000},
				})  	then
					stommSleep(500)
					stomMultiColorTap("换行",{
					{  597, 1079, 0x353535},
					{  232,  203, 0x585c5b},
					{  362,  292, 0xffffff},
					{  100,  345, 0xc7c7cd},
				})
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(300)
					stomMultiColorTap("点击上行",{
						{  369,  298, 0xffffff},
						{  232,  203, 0x585c5b},
						{  362,  292, 0xffffff},
						{  100,  345, 0xc7c7cd},
					})		
						--复制 @163.com
				end]]
				stomMultiColorTap("设置",{
					{  217,  676, 0x007aff},
					{  401,  550, 0x636566},
					{  400,  579, 0x000000},
					{  405,  644, 0x000000},
				})	
				stomMultiColorTap("设置纵向",{
					{  472,  663, 0x007aff},
					{  375,  664, 0xccd0d1},
					{  221,  484, 0x000000},
					{  273,  488, 0x666869},
				})	
				stomMultiColorTap("15分钟后需要",{
					{  357,  705, 0x007aff},
					{  409,  704, 0x56a5fd},
					{  466,  704, 0x007aff},
					{  362,  448, 0x000000},
				})	
				if stomMultiColor("请输入M横向-long",{
					{  570,  509, 0x000000},
					{  550,  766, 0x5d6568},
					{  502,  546, 0x000000},
					{  418,  347, 0xc7c7cd},
					{  418,  355, 0xc7c7cd},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(500)
					stomMultiColorTap("登录",{
					{  363,  656, 0xd8e6f0},
					{  361,  694, 0x007aff},
					{  366,  709, 0x007aff},
					{  369,  764, 0xe6eaeb},
				})
				end				
				stomMultiColorTap("无法连接IT",{
					{  437,  628, 0x007aff},
					{  472,  626, 0xabd1fb},
					{  146,  521, 0x000000},
					{  222,  531, 0x8f8f8f},
				})
				--[[if stomMultiColorTap("购买完成",{
					{  548,  493, 0x000000},
					{  427,  406, 0xffffff},
					{  425,  352, 0xcdcdd3},
					{  500,  715, 0x000000},
				}) or stomMultiColorTap("购买完成B",{
					{  309,  644, 0x007aff},
					{  259,  491, 0x000000},
					{  411,  553, 0x000000},
					{  517,  556, 0xf9f9f9},
				})then
					stommSleep(500)					
					OpenApp("com.duoyi.shenwu3")
				--else stomLog("notfound")
			end		--]]	
end


function duoyi_zhang_zhuce()					--			梦想世界3D充值
	stomtoast("进入注册模式")
	fn_zhucestart=os.time()
	--while (true) do
	local getloop =0
	local loop = 0
	local num = 0
	local m = math.random(6,8) 
	local mima = myRand(3,m,2)
	local yanzhenma
	local BlackPhone=0
	local getphonenum=0
	local messgwait=4000
	local inputphone=0
	local testzhuce=0
	fa = 0
	getPhoneType = "lx"
	docks = "1112"--1156--2292
	while (true) do
		--if loop == 0 then
		stomLog("当前阶段.."..getloop)
		
		if stomMultiColorTap("请输入姓名-实名",{
				{  307,  440, 0x7b8284},
				{  307,  443, 0x84827b},
				{  302,  470, 0xa59e9c},
				{  299,  470, 0x9ca2a5},
				{  307,  334, 0x101418},
				}) then
				getloop = 2
				
			end
		if stomMultiColor("密码未输入",{
				{  308,  422, 0x8c8a8c},
				{  310,  453, 0xadb2b5},
				{  311,  519, 0x9c9694},
				{  311,  594, 0x949694},
				{  311,  646, 0x848684},
				}) then
			stommSleep(500)
			stomMultiColorTap("多益输点击密码框",{
					{  312,  435, 0xffffff},
					{  311,  441, 0xadaead},
					{  313,  485, 0x84827b},
					{  309,  519, 0x9c9694},
				})
			stommSleep(500)
			stomInpuText(mima)
			stommSleep(999)
		end
		if stomMultiColorTap("多益密码已输入关闭键盘",{
				{  350,  332, 0xf7f7f7},
				{  419,  419, 0x000000},
				{  420,  433, 0x000000},
				{  420,  447, 0x000000},
				{  500,  457, 0x9f9ea2},
				}) then
			stommSleep(500)
		end
		if getloop == 0 then
			--stomtoast(error_60ma)
			if getphonenum==0 then
				if num <= 4 then
					check_Rules = 1
					Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
					num = num + 1
				else
					--return 1
				end
				if Telnum then
					stomLog(Telnum)
					phonenumber = Telnum
					num = 0
					getphonenum=1
				else
					stomLog("重新获取号码中")
					stommSleep(2000)
					num = num + 1
				end
			end
			if getphonenum==1 then
				if stomMultiColor("手机号未输入",{
						{  467,  417, 0x8c8684},
						{  466,  422, 0x8c8a8c},
						{  465,  432, 0x848a8c},
						{  465,  451, 0x8c8684},
						{  476,  451, 0xa5a6ad},
						}) then
					stomMultiColorTap("多益注册主界面点手机号",{
							{  473,  423, 0xb5aead},
							{  468,  435, 0xffffff},
							{  151,  488, 0x108af7},
							{  158,  643, 0x108aff},
						})
					stommSleep(1000)
					if inputphone==0 then
						stomInpuText(Telnum)
						inputphone=1
					else
						stomInpuStr(Telnum)
						inputphone=0
					end
					stommSleep(300)
					phoneok=1
				end
			end
			if phoneok==1 and stomMultiColorTap("手机号已输且验证码能获取",{
					{  455,  709, 0x1086f7},
					{  455,  736, 0x108af7},
					{  455,  764, 0x108af7},
					{  455,  785, 0x1086f7},
					}) then
				phoneok=2
			end					
			if stomMultiColorTap("多益获取验证码",{
					{  453,  712, 0x73797b},
					{  453,  734, 0x73797b},
					{  453,  762, 0x73797b},
					{  453,  784, 0x73797b},
					}) and phoneok==2 then
				stommSleep(8888)
				messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)							
				getloop=1
			end
			stomMultiColorTap("多益输手机号已填写关闭键盘",{
					{  541,  401, 0xefebe7},
					{  470,  653, 0x949694},
					{  470,  670, 0x949294},
					{  461,  661, 0x9c9694},
				}) 
		elseif getloop == 1 then
			stomLog("获取短信..."..fa)
			if messg then
				stomtoast(yanzhenma)
				if BlackPhone==0 then
					testzhuce=testzhuce+1
					BlackPhone=1
					messgwait=300
					stomtoast("已收验证码 正在处理",3)
					yanzhenma = string.match(messg,"%d+")
					stomLog("yanzhenmaOK-"..yanzhenma)
				else 
					stomtoast(yanzhenma)
				end
				if stomMultiColorTap("多益验证码未输入开始输入",{
						{  394,  525, 0x8c9294},
						{  396,  548, 0x948e94},
						{  390,  561, 0x84868c},
						{  383,  572, 0x7b8284},
						})then	
					stommSleep(500)
					stomInpuText(yanzhenma)
					stommSleep(2000)
					stomtap(568,  375)
					--stommSleep(300)
					--stomtap(389,  928)
				end
				if stomMultiColor("多益验证码未输入不操作",{
						{  394,  525, 0x8c9294},
						{  396,  548, 0x948e94},
						{  390,  561, 0x84868c},
						{  383,  572, 0x7b8284},
						})then
				else
					stommSleep(60)
					if stomMultiColor("立即注册",{
							{  172,  463, 0x108aff},
							{  172,  662, 0x1086f7},
							{  243,  714, 0xf7f7f7},
							{  525,  458, 0xefefef},
							}) then
						stommSleep(2000)
						stomMultiColorTap("立即注册",{
								{  172,  463, 0x108aff},
								{  172,  662, 0x1086f7},
								{  243,  714, 0xf7f7f7},
								{  525,  458, 0xefefef},
							}) 
						stommSleep(15000)
						if stomMultiColor("绑定成功",{
								{  363,  402, 0x63ba63},
								{  368,  597, 0x000000},
								{  370,  648, 0x4a494a},
								{  542,  556, 0x9c9a9c},
								})	or stomMultiColor("绑定成功C",{
								{  363,  402, 0x63ba63},
								{  368,  597, 0x000000},
								{  370,  648, 0x4a494a},
								{  542,  556, 0x9c9a9c},
								})	or stomMultiColor("绑定成功B",{
								{  314,  413, 0x63ba63},
								{  535,  530, 0x000000},
								{  538,  831, 0x84868c},
								{   90,  531, 0xf7f7f7},
								})  or	stomMultiColor("红色已绑定",{
									{  437,  315, 0xd60008},
									{  221,  390, 0x4a8ef7},
									{  223,  458, 0x73aaff},
									{  299,  494, 0x108af7},
								})	then
								stomLog("绑定成功")
								stomtoast("识图后跳转")
								getloop = 99
								break
							--stomopenURL("prefs:root=STORE");
							stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
							stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)	
							--loop=1
						else 
							stomtoast("注册失败3秒后跳转")
							stommSleep(3000)
							stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
							stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)	
							stomLog("绑定失败")	
							czendtime=os.time()
							--[[if testzhuce>=3 then
								return 1
							end]]
							--[[if czendtime-czstartime<90 then
								stomtoast("冻结操作，second="..(90-czendtime+czstartime),(90-czendtime+czstartime))
								stommSleep((90-czendtime+czstartime)*1000)
							end]]
							getloop=99
							MODEsw=2
							return 1
							--stomLog("return了1")
							--do return 1 end
						end	
					end	
				end
			else
				messgwait=4000
				messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
				stomLog("get sms")
				stomtoast("GetMegNO."..fa,4)
				fa = fa +1
			end
			if fa > 10 then
				stomLog("获取短信失败")
				stomtoast("get短信")
				stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
				stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
				getloop = 2
			end
			stommSleep(messgwait)
		elseif getloop == 2 then
			czstartime= os.time()
			stommSleep(999)
			fa = 0	
			BlackPhone=0
			getphonenum=0
			inputphone=0
			stomMultiColorTap("账号",{
					{  302,  583, 0x3165ad},
					{  289,  432, 0x295da5},
					{  294,  439, 0xb5d3f7},
					{  299,  446, 0x295da5},
					{  444,  524, 0xe7cb63},
				})
			stomMultiColorTap("取消表单",{
					{  537,  299, 0x8c8684},
					{  529,  305, 0x8c8684},
					{  544,  305, 0x84868c},
					{  537,  533, 0x080400},
					{  537,  559, 0x000000},
				})
			stomMultiColorTap("取消表单B",{
					{  537,  300, 0x848684},
					{  528,  306, 0x848684},
					{  530,  488, 0xefebef},
					{  252,  834, 0xf7f7f7},
				})
			if stomMultiColorTap("多益点账号注册",{
					{  215,  430, 0x318aff},
					{  217,  444, 0x318aff},
					{  291,  511, 0x1086f7},
					{  444,  320, 0xd60010},
					}) then
				getloop = 0
			end		
	
			stomMultiColorTap("圆形实名",{
					{  138,  628, 0xefbe18},
					{  583,  415, 0x4aaade},
					{  554,  453, 0xb5dbff},
					{  558,  543, 0xefbe4a},
				})
			if stomMultiColorTap("键中文姓名框",{
					{  486,  440, 0xffffff},
					{  483,  407, 0x000000},
					{  488,  327, 0x5c5e61},
					{  484,  357, 0x6f6f6f},
					{  485,  346, 0x414041},
				})then
				nicheng = ZKQ_Word(zhangkq["姓氏"],1,1)..ZKQ_Word(zhangkq["名字"],2,3)
				stommSleep(1999)
				stomInpuText(nicheng)
				stommSleep(999)
				stomtap(552,  173)
			end
			
			if	stomMultiColorTap("请输入姓名",{
					{  307,  440, 0x7b8284},
					{  307,  443, 0x84827b},
					{  302,  470, 0xa59e9c},
					{  299,  470, 0x9ca2a5},
					{  307,  334, 0x101418},
					}) then
				nicheng = ZKQ_Word(zhangkq["姓氏"],1,1)..ZKQ_Word(zhangkq["名字"],2,3)
				stommSleep(1999)
				stomInpuText(nicheng)
				stommSleep(999)
				stomtap(552,  173)
			elseif stomMultiColorTap("请输入身份证",{
					{  220,  437, 0x8c8e94},
					{  225,  457, 0x8c8a84},
					{  224,  472, 0xadaaad},
					{  226,  559, 0x9ca2a5},
					{  226,  380, 0x000000},
					}) then
				stommSleep(999)
				stomInpuText("440282195610226964")
				stommSleep(999)
				stomtap(552,  173)
			else stomMultiColorTap("确认",{
						{  126,  515, 0x108aff},
						{  128,  567, 0x108aff},
						{  128,  610, 0x1086f7},
						{  138,  578, 0xffffff},
					}) 
			end	
			stomMultiColorTap("确认提交",{
					{  245,  648, 0x108af7},
					{  322,  482, 0x7b757b},
					{  324,  508, 0x080408},
					{  410,  499, 0xe7efef},
				})
			if stomMultiColor("身份证有误",{
					{  480,  375, 0x313439},
					{  471,  383, 0xe7dfde},
					{  474,  451, 0x8c8e8c},
					{  472,  612, 0x737173},
					{  476,  635, 0x848a8c},
					}) then
				--重启游戏
				stomcloseApp("com.duoyi.shenwu3")
				stommSleep(5000)
				stomrunApp("com.duoyi.shenwu3")
			end	
			if stomMultiColor("绑定成功",{
				{  363,  402, 0x63ba63},
				{  368,  597, 0x000000},
				{  370,  648, 0x4a494a},
				{  542,  556, 0x9c9a9c},
				})	or stomMultiColor("绑定成功C",{
				{  363,  402, 0x63ba63},
				{  368,  597, 0x000000},
				{  370,  648, 0x4a494a},
				{  542,  556, 0x9c9a9c},
				})	or stomMultiColor("绑定成功B",{
				{  314,  413, 0x63ba63},
				{  535,  530, 0x000000},
				{  538,  831, 0x84868c},
				{   90,  531, 0xf7f7f7},
				})  or	stomMultiColor("红色已绑定",{
					{  437,  315, 0xd60008},
					{  221,  390, 0x4a8ef7},
					{  223,  458, 0x73aaff},
					{  299,  494, 0x108af7},
				})	then
				stomopenURL("prefs:root=STORE");
				getloop = 3
			end
		elseif getloop == 3 then
			fn_zhucesend=os.time()
			isfront = stomisFrontApp("com.apple.MobileSMS")
				if isfront==1 then
					break
				end
			
			shopapplestore()
			
			
			
		end
	stommSleep(300)
	fn_zhucesend=os.time()
	isfront = stomisFrontApp("com.apple.MobileSMS")
		if isfront==1 then
			break
		end
--	if fn_zhucesend-fn_zhucestart>=60*7 then
--		return 1
--	end
	end
end

function zhang_1249610247()							--			梦想世界3D
	local t1 = os.time()
	local time_cha =  math.random(10,15)*60
	local loop = 0
	while (true) do
		OpenApp("com.duoyi.m2mx3")
		stomLog("loop="..loop)
		stomMultiColorTap({
			{  235,  575, 0x007aff},
			{  247,  592, 0x007aff},
			{  235,  544, 0x7eb1ef},
			{  224,  540, 0x72abef},
			{  380,  512, 0x696d6e},
			{  396,  523, 0x000000},
		},"下载失败")
		if stomMultiColor({
			{  576,  247, 0xf7ef9c},
			{  509,  211, 0xf7e339},
			{  558,  484, 0x215594},
			{  424,  375, 0xce4118},
			{  521,  324, 0x427db5},
		},"充值界面") then
			toast("充值界面",1)
			loop = 9
		end
		if loop == 9 then
			
			if stomMultiColorTap({
				{  215,  430, 0x318aff},
				{  217,  444, 0x318aff},
				{  291,  511, 0x1086f7},
				{  444,  320, 0xd60010},
			},"多益注册账号") then
				stomLog("进入充值模式")
				toast("进入充值模式",1)
				chongfu = 0
				messgcon = 0
				loops = 0
				fa = 0
			end
			if stomMultiColorTap("请输入姓名-实名",{
				{  307,  440, 0x7b8284},
				{  307,  443, 0x84827b},
				{  302,  470, 0xa59e9c},
				{  299,  470, 0x9ca2a5},
				{  307,  334, 0x101418},
				}) then
				getloop = 2
				duoyi_zhang_zhuce()
				
			end
			if stomMultiColor(号码框jz,"号码框jz")then   
				duoyi_zhang_zhuce()
			end
		end
		
		if stomMultiColorTap(多益网络协议mx3d,"多益网络协议mx3d")then
			t1 = os.time()
		end
		stomMultiColorTap(提交评价mx3d,"提交评价")
		stomMultiColorTap(提交评价1mx3d,"提交评价1mx3d")
		stomMultiColorTap(留存选择角色mx3d,"留存选择角色mx3d", 0,-180)
		stomMultiColorTap(孟逸对话mx3d,"孟逸对话mx3d")
		if stomMultiColorTap(十一级领取mx3d,"十一级领取mx3d")then
			stomtap(560,  982)
		end
		stomMultiColorTap(背包界面关闭mx3d,"背包界面关闭mx3d")
		stomMultiColorTap(消消乐mx3d,"消消乐mx3d")
		if stomMultiColorTap(游客登录3D,"游客登录3D") then
			stommSleep(1000)
		end
		stomMultiColorTap(跳过3D,"跳过3D")
		stomMultiColorTap(主线剧情3D,"主线剧情3D") 
		stomMultiColorTap(正式主线剧情3D,"正式主线剧情3D")	
		stomMultiColorTap(手指点击对话3D,"手指点击对话3D")
		stomMultiColorTap(自动战斗3D,"自动战斗3D")
		stomMultiColorTap(获得宠物3D,"获得宠物3D")
		stomMultiColorTap(左对话框3D,"左对话框3D",-50,50)  
		stomMultiColorTap(云梦对话3D,"云梦对话3D")
		stomMultiColorTap(王大锤的对话3D,"王大锤的对话3D",-50,50)
		stomMultiColorTap(关闭恭喜获得伙伴3D,"关闭恭喜获得伙伴3D")
		stomMultiColorTap(左对话框改3D,"左对话框改3D",-50,50)
		stomMultiColorTap(使用3D,"使用3D")
		stomMultiColorTap(使用礼包的3D,"使用礼包的3D")
		stomMultiColorTap(任务栏寻物3D,"任务栏寻物3D")
		stomMultiColorTap(购买3D,"购买3D")
		stomMultiColorTap(十一级领取3D,"十一级领取3D")
		stomMultiColorTap(十一领取完关闭3D,"十一领取完关闭3D")
		
		if stomMultiColor(师门任务3D,"师门任务3D") or stomMultiColor(师门mx3d,"师门mx3d")then
			stommSleep(2000)
			stomMultiColorTap(师门任务3D,"师门任务3D")
			stomMultiColorTap(师门mx3d,"师门mx3d")
		else
			stomMultiColorTap(主线剧情3D,"主线剧情3D") 
			stommSleep(3000)
			stomMultiColorTap(正式主线剧情3D,"正式主线剧情3D")	
			
		end
		stomMultiColorTap(等级领取礼包3D,"等级领取礼包3D")
		stomMultiColorTap(关签到奖励3D,"关签到奖励3D")
		stomMultiColorTap(关闭梦想企鹅3D,"关闭梦想企鹅3D")
		stomMultiColorTap(药店购买3D,"药店购买3D")
		stomMultiColorTap(关闭加入帮派3D,"关闭加入帮派3D")
		stomMultiColorTap(引导背包3D,"引导背包3D")
		stomMultiColorTap(翅膀3D,"翅膀3D")
		stomMultiColorTap(强化3D,"强化3D")
		if stomMultiColorTap(关闭翅膀界面3D,"关闭翅膀界面3D") then
			stommSleep(1000)
			stomMultiColorTap(关闭背包界面3D,"关闭背包界面3D")
		end
		stomMultiColorTap(关闭升级礼包3D,"关闭升级礼包3D")
		
		
		
		
	--	stomMultiColorTap(关闭升级礼包3D,"关闭升级礼包3D")
--		if stomMultiColorTap(摇色子sg,"摇色子sg") then
--			stommSleep(1000)
--			stomMultiColorTap(确定进入游戏sg,"确定进入游戏sg")
--		end
		if stomMultiColor(创建角色3D,"创建角色3D")then
			tbX = {438,362,511,286,214,134}
			aa = math.random(1,#tbX)
			X1 = tbX[aa]
			stomtap(X1,52)
			stommSleep(1000)
			stomMultiColorTap(创建角色3D,"摇色子")
			stommSleep(1000)
			stomMultiColorTap(开始游戏3D,"开始游戏3D")
		end

		
		local t2 = os.time()
		if os.difftime(t2,t1) > time_cha then
			if tasktype == 0 then
				stomLog("超过10分钟")
				return 0
			else
				return 0
			end
		end
	stommSleep(500)
	end
	

end







function mx_shiming()			--								梦想实名
	 --  
	stomMultiColorTap(点击认证mx,"点击认证mx")
	if stomMultiColor(梦想姓名框mx,"梦想姓名框mx") then
		stommSleep(1000)
		stomMultiColorTap(梦想姓名框mx,"梦想姓名框mx")
	end
	stomMultiColorTap(关闭国子监祭酒mx,"关闭国子监祭酒mx")
	if stomMultiColorTap(键中文姓名框mx,"键中文姓名框mx") then
		stommSleep(1000)
		n = math.random(1,2)
		sfzname = ZKQ_Word(zhangkq["姓氏"],1,1)..ZKQ_Word(zhangkq["名字"],n,3)
		stomInpuText(sfzname)
		stommSleep(1000)
		stomtap(490,  158)
	end

	if stomMultiColor(身份证框mx,"身份证框mx")then
		stommSleep(1500)
		stomMultiColorTap(身份证框mx,"身份证框mx")
	end
	if stomMultiColorTap(键身份证框mx,"键身份证框mx") then
		stommSleep(1000)
		A = math.random(1,#shenfenhao)
		sfznum = shenfenhao[A]
		stomInpuText(sfznum)
		stommSleep(1000)
		stomtap(490,  158)
	end
	
	if stomColorInReg("有身份证",0x000000, 90, 216, 656, 234, 674)then
		stommSleep(1000)
		stomMultiColorTap(实名认证确定mx,"实名认证确定mx")
	end
	if stomMultiColorTap(认证提示确定mx,"认证提示确定mx") then
		return 0
	end
	
	
		
	
--	stomMultiColorTap(认证提示确定mx,"认证提示确定mx")
	
end



function MXSJ_fn_CZ()			--								梦想充值
	if stomMultiColorTap("商城",{
			{  571,  233, 0xffff63},
			{  560,  295, 0x429684},
			{  115,  741, 0x003473},
			{  117,  769, 0xffff63},
		}) or stomMultiColorTap("账号",{
			{  266,  500, 0x319673},
			{  519,  536, 0x525563},
			{  514,  641, 0x8cc7bd},
			{  103,  515, 0x29ba00},
		})then	
		stomtoast("进入充值模式")
		local choice = 0--dialogRet("请选择账号注册模式：", "自动", "手动", "", 5);
		stommSleep(300)
		local loop=0
		local flag=0
		local getloop = 0
		local num = 0
		local m = math.random(6,12) 
		local mima = myRand(3,m,2)
		local yanzhenma
		local fa = 0
		local messgwait =4000
		getPhoneType = "lx"
		docks = "1112"
		while (true) do
			--_mxdiaoyong()
			stomMultiColorTap("多益注册账号",{
				{  215,  430, 0x318aff},
				{  217,  444, 0x318aff},
				{  291,  511, 0x1086f7},
				{  444,  320, 0xd60010},
			})	
			
			if loop==0 then
				if choice==0 or choice==3 then
						stomLog("当前阶段。。。"..getloop)
						if getloop == 0 then	
							if num <= 8 then
								check_Rules = 1
								Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
							else	
							end
							if Telnum then
								stomLog(Telnum)
								getloop = 1
								num = 0
							else
								stomLog("重新获取号码中")
								stommSleep(2000)
								num = num + 1
							end
							--[[if num > 20 then
								stomLog("获取号码失败")
								stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
								stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
							end]]
						elseif getloop == 1 then
							phonenumber = Telnum
							if stomMultiColor("在注册界面",{
								{  535,  369, 0xefebe7},
								{  466,  710, 0x1086f7},
								{  537,  534, 0x000000},
								{  466,  647, 0xffffff},
							}) then 
								stomMultiColorTap("多益注册主界面点手机号",{
									{  473,  423, 0xb5aead},
									{  468,  435, 0xffffff},
									{  151,  488, 0x108af7},
									{  158,  643, 0x108aff},
								})
								if stomMultiColor("多益输入手机号",{
									{  467,  427, 0xffffff},
									{  468,  449, 0xffffff},
									{  463,  502, 0xffffff},
									{  470,  657, 0xffffff},
								}) then
									stommSleep(500) 
									stomInpuText(phonenumber)
									getloop=2
									stommSleep(500) 
								end
							end
						elseif getloop == 2 then
							if stomMultiColorTap("多益输手机号已填写关闭键盘",{
								{  541,  401, 0xefebe7},
								{  470,  653, 0x949694},
								{  470,  670, 0x949294},
								{  461,  661, 0x9c9694},
							}) then
								stommSleep(500)
								stomMultiColorTap("多益获取验证码",{
									{  461,  716, 0x108af7},
									{  485,  759, 0x1086f7},
									{  534,  659, 0xe7efef},
									{  458,  801, 0x108aff},
								})
							end
							stomMultiColorTap("多益输点击密码框",{
								{  312,  435, 0xffffff},
								{  311,  441, 0xadaead},
								{  313,  485, 0x84827b},
								{  309,  519, 0x9c9694},
							})					
							if stomMultiColor("多益输密码未输入",{
								{  420,  418, 0xffffff},
								{  420,  448, 0xffffff},
								{  414,  359, 0x605e5d},
								{  418,  385, 0x797b7c},
							}) or stomMultiColor("多益输密码未输入粗体",{
								{  423,  422, 0xffffff},
								{  424,  446, 0xffffff},
								{  424,  472, 0xffffff},
								{  415,  359, 0x8f8f92},
								{  436,  387, 0xaaa9a7},
							}) 
							then
								stommSleep(500)
								stomInpuText(mima)
								stommSleep(500)
							end
							if stomMultiColorTap("多益密码已输入关闭键盘",{
								{  350,  332, 0xf7f7f7},
								{  419,  419, 0x000000},
								{  420,  433, 0x000000},
								{  420,  447, 0x000000},
								{  500,  457, 0x9f9ea2},
							}) then
								getloop=3
							end
							stomMultiColorTap("多益密码已输入关闭键盘粗",{
								{  423,  319, 0xffffff},
								{  426,  423, 0x000000},
								{  428,  376, 0x000000},
								{  424,  471, 0x000000},
							}) 	
							if stomMultiColor("多益密码手机密码都输入",{
								{  474,  418, 0x000000},
								{  312,  423, 0x000000},
								{  310,  445, 0x000000},
								{  315,  468, 0x000000},
								{  538,  396, 0xefebef},
							}) then
								getloop=3
							end							
						elseif getloop == 3 then
							stomLog("获取短信..."..fa)
							messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
							stomMultiColorTap("多益密码已输入关闭键盘",{
								{  350,  332, 0xf7f7f7},
								{  419,  419, 0x000000},
								{  420,  433, 0x000000},
								{  420,  447, 0x000000},
								{  500,  457, 0x9f9ea2},
							})
							if messg then
								messgwait=300
								stomMultiColorTap("多益验证码开始输入",{
								{  391,  419, 0xffffff},
								{  388,  442, 0x848284},
								{  389,  457, 0xa59e9c},
								{  393,  495, 0xc6c3bd},
							})					
								--messg = string.gsub(messg,"30分","")
								--messg = string.sub(messg,9)
								yanzhenma = string.match(messg,"%d+")
								stomLog("yanzhenmaOK-"..yanzhenma)
								toast(yanzhenma)
								getloop =5
								if stomMultiColor("多益验证码输入界面",{
									{  487,  331, 0x010101},
									{  498,  364, 0xbfc0bf},
									{  489,  427, 0xffffff},
									{  408,  420, 0x000000},
								}) or stomMultiColor("多益验证码输入界面B",{
									{  424,  420, 0xffffff},
									{  423,  329, 0x191a1a},
									{  428,  340, 0x9a949a},
									{  423,  364, 0x4a4d4a},
								}) then
									stommSleep(300)
									stomInpuText(yanzhenma)
									stommSleep(100)			
									stomtap(413,  320) 
								end
								stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
								stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
							else
								stomtoast("getMegNo."..fa)
								stomLog("get sms")
								fa = fa +1
							end	
							if fa > 10 then
								stomLog("获取短信失败")
								stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
								stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
								getloop = 4
							end
							stommSleep(messgwait)
						elseif getloop == 6 then
								stomMultiColorTap("多益验证码开始输入",{
									{  391,  419, 0xffffff},
									{  388,  442, 0x848284},
									{  389,  457, 0xa59e9c},
									{  393,  495, 0xc6c3bd},
								})
								stomMultiColorTap("多益验证码开始输入粗",{
									{  389,  435, 0xffffff},
									{  392,  425, 0x8c9294},
									{  392,  439, 0x848684},
									{  394,  470, 0x848284},
								})
								if stomMultiColorTap("多益注册账号",{
									{  215,  430, 0x318aff},
									{  217,  444, 0x318aff},
									{  291,  511, 0x1086f7},
									{  444,  320, 0xd60010},
								}) then
									getloop=0
									fa = 0								
								end
								if stomMultiColor("多益验证码输入界面",{
									{  487,  331, 0x010101},
									{  498,  364, 0xbfc0bf},
									{  489,  427, 0xffffff},
									{  408,  420, 0x000000},
								}) or stomMultiColor("多益验证码输入界面粗",{
									{  485,  424, 0xffffff},
									{  622,  373, 0xe8efef},
									{  490,  330, 0x030303},
									{  499,  363, 0x0b0b0b},
								}) then
									stommSleep(300)
									stomInpuText(yanzhenma)
									stommSleep(300)			
									stomtap(413,  320) 
									getloop =5
								end
						elseif getloop == 4 then
							stomMultiColorTap("多益取消验证码输入",{
								{  475,  303, 0xffffff},
								{  487,  330, 0x080808},
								{  492,  339, 0x8c9294},
								{  498,  365, 0xbfc0bf},
							})
							stomMultiColorTap("返回",{
								{  536,  300, 0x848684},
								{  528,  306, 0x848684},
								{  544,  305, 0x84868c},
							})
							if stomMultiColorTap("多益注册账号",{
								{  215,  430, 0x318aff},
								{  217,  444, 0x318aff},
								{  291,  511, 0x1086f7},
								{  444,  320, 0xd60010},
							}) then
								getloop=0
								fa = 0								
							end
							if stomMultiColor("多益注册界面返回getloop0",{
								{  529,  534, 0x000000},
								{  254,  532, 0xf7f7f7},
								{  486,  707, 0x108aff},
								{  157,  647, 0x1086f7},
							}) then
								getloop=0
								fa = 0
							end							
						elseif getloop == 5 then
							if stomMultiColor("验证码未输入",{
								{  391,  425, 0x9c9a94},
								{  401,  426, 0x7b8284},
								{  391,  441, 0x84827b},
								{  400,  495, 0x7b8284},
							}) then
								stommSleep(500)
								stomtap(392,  458)
								stommSleep(500)
								stomInpuText(yanzhenma)
								stommSleep(500)
								stomtap(532,  151)								
							elseif stomMultiColor("立即注册",{
								{  161,  541, 0xffffff},
								{  161,  591, 0xffffff},
								{  161,  476, 0x108af7},
								{  156,  650, 0x1086f7},
								{  174,  570, 0x1086f7},
							}) then
								stommSleep(3000)
								stomtap(160,  547)
								stommSleep(3000)
								if stomMultiColor("绑定成功",{
									{  363,  402, 0x63ba63},
									{  368,  597, 0x000000},
									{  370,  648, 0x4a494a},
									{  542,  556, 0x9c9a9c},
								})	or stomMultiColor("绑定成功C",{
									{  363,  402, 0x63ba63},
									{  368,  597, 0x000000},
									{  370,  648, 0x4a494a},
									{  542,  556, 0x9c9a9c},
								})	or stomMultiColor("绑定成功B",{
									{  314,  413, 0x63ba63},
									{  535,  530, 0x000000},
									{  538,  831, 0x84868c},
									{   90,  531, 0xf7f7f7},
								})	then
									stomLog("绑定成功");stommSleep(3000)
									getloop = 99
								else getloop =4 
									stomLog("绑定失败")
								end
							end
						end
				end
				if stomMultiColor("绑定成功",{
					{  363,  402, 0x63ba63},
					{  368,  597, 0x000000},
					{  370,  648, 0x4a494a},
					{  542,  556, 0x9c9a9c},
				})	or stomMultiColor("绑定成功C",{
					{  363,  402, 0x63ba63},
					{  368,  597, 0x000000},
					{  370,  648, 0x4a494a},
					{  542,  556, 0x9c9a9c},
				})	or stomMultiColor("绑定成功B",{
					{  314,  413, 0x63ba63},
					{  535,  530, 0x000000},
					{  538,  831, 0x84868c},
					{   90,  531, 0xf7f7f7},
				})	
					then
					stomopenURL("prefs:root=STORE");
					loop=1
				end
				--[[if flag==0 then
					if stomMultiColor("已登录",{
						{   39,  332, 0x000000},
						{   76,   92, 0x007aff},
						{  105,  330, 0x060606},
						{  202,  331, 0xffffff},
					}) then
						stommSleep(300)
						local user = dialogRet("是否注销", "是", "否", "", 5);
						flag=1
						stommSleep(4000)
						if user==0 or user==3 then
						stomtap(250,250)
						elseif user==1 then
						OpenApp("com.hero.m2mx")					
						loop=1					
						end
					end
				end]]
				stomMultiColorTap("注销",{
					{  307,  610, 0x007aff},
					{  327,  604, 0x007aff},
					{  132,  375, 0xf7f7f7},
					{  279,  367, 0x000000},
				})	
				if stomMultiColor("未登录",{
					{   38,  237, 0x027bff},
					{   72,  244, 0x0f81ff},
					{  138,   84, 0x000000},
					{  271,  433, 0xffffff},
				})then
					OpenApp("com.hero.m2mx")					
					loop=1
				end
				-- 切换至游戏内充值界面
			elseif loop==1 then
				shopapplestore()
					stomMultiColorTap("单行密码已输入确认",{
						{  461,  489, 0x007aff},
						{   98,  397, 0x000000},
						{  114,  397, 0x000000},
						{  474,  305, 0x606668},
						{  192,  217, 0x000000},
					})
					stomMultiColorTap("无法连接IT横粗",{
						{  252,  559, 0x007aff},
						{  367,  393, 0x000000},
						{  373,  471, 0x8c999c},
						{  364,  578, 0xb7c2c7},
					})
					stomMultiColorTap("使用现有B",{
						{  343,  503, 0x007aff},
						{  249,  454, 0x007aff},
						{  173,  548, 0x007aff},
						{  466,  545, 0x242526},
					})
					stomMultiColorTap("设置纵粗",{
						{  444,  668, 0x007aff},
						{  428,  667, 0x007aff},
						{  224,  476, 0x000000},
						{  157,  667, 0x007aff},
						{  462,  562, 0x000000},
					})
				stomMultiColorTap("网络异常重登",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("无法连接IT纵粗",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				if stomMultiColor("纵向请输入M粗",{
					{  100,  396, 0xc7c7cd},
					{  200,  225, 0x000000},
					{  264,  232, 0x515151},
					{  462,  489, 0x007aff},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(500)
					stomMultiColorTap("登录",{
					{  462,  489, 0x007aff},
					{  100,  396, 0xc7c7cd},
					{  200,  225, 0x000000},
					{  264,  232, 0x515151},
				})
				end			
				stomMultiColorTap("验证失败再次粗",{
					{  652,  403, 0x007aff},
					{  510,  252, 0x000000},
					{  585,  251, 0x000000},
					{  763,  303, 0xd8dcda},
				})
				stomMultiColorTap("确认购买纵粗？？",{
					{  425,  666, 0x007aff},
					{  166,  483, 0x000000},
					{  422,  483, 0x616161},
					{  554,  678, 0xf9f9f9},
				})					
			stomMultiColorTap("使用现有",{
					{  345,  435, 0x007aff},
					{  343,  465, 0x007aff},
					{  391,  486, 0x26363e},
					{  453,  550, 0x4a4b4c},
				})
				stomMultiColorTap("使用现有纵",{
					{  277,  537, 0x007aff},
					{  305,  430, 0x000000},
					{  334,  429, 0x595d5d},
					{  473,  635, 0xced2d2},
				})				
				if stomMultiColor("登录换行",{
					{   38,  968, 0x363737},
					{  581,  444, 0x4b4d4f},
					{  581,  481, 0x000000},
					{  437,  413, 0x007aff},
				})	then
					stommSleep(500)	
					stomMultiColorTap("登录换行",{
					{   38,  968, 0x363737},
					{  581,  444, 0x4b4d4f},
					{  581,  481, 0x000000},
					{  437,  413, 0x007aff},
				})	
					stommSleep(500)	
					if stomMultiColor("输入txt",{
						{  491,  348, 0xc7c7cd},
						{  485,  396, 0xffffff},
						{  270,  377, 0x605f60},
						{  365,  412, 0x007aff},
					})	then
						stomInpuText(applePWD)
						stommSleep(300)
						stomMultiColorTap("点击上行",{
							{  550,  688, 0xffffff},
							{  488,  688, 0xffffff},
							{  338,  518, 0xccced1},
						})		
						--复制 @163.com
					end
				end
				if stomMultiColor("登录换行纵向",{
					{  191,  196, 0x000000},
					{  232,  203, 0x585c5b},
					{  362,  292, 0xffffff},
					{  100,  345, 0xc7c7cd},
				}) or stomMultiColor("登录换行纵向B",{
					{   93,  321, 0xd0dafc},
					{  195,  232, 0x000000},
					{  175,  384, 0xffffff},
					{  106,  332, 0xffffff},
					{  262,  244, 0x000000},
				})  	then
					stommSleep(500)
					stomMultiColorTap("换行",{
					{  597, 1079, 0x353535},
					{  232,  203, 0x585c5b},
					{  362,  292, 0xffffff},
					{  100,  345, 0xc7c7cd},
				})
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(300)
					stomMultiColorTap("点击上行",{
						{  369,  298, 0xffffff},
						{  232,  203, 0x585c5b},
						{  362,  292, 0xffffff},
						{  100,  345, 0xc7c7cd},
					})		
						--复制 @163.com
				end
				stomMultiColorTap("设置",{
					{  217,  676, 0x007aff},
					{  401,  550, 0x636566},
					{  400,  579, 0x000000},
					{  405,  644, 0x000000},
				})	
				stomMultiColorTap("设置纵向",{
					{  472,  663, 0x007aff},
					{  375,  664, 0xccd0d1},
					{  221,  484, 0x000000},
					{  273,  488, 0x666869},
				})	
				stomMultiColorTap("15分钟后需要",{
					{  357,  705, 0x007aff},
					{  409,  704, 0x56a5fd},
					{  466,  704, 0x007aff},
					{  362,  448, 0x000000},
				})	
				if stomMultiColor("请输入M",{
					{  548,  493, 0x000000},
					{  427,  406, 0xffffff},
					{  425,  352, 0xcdcdd3},
					{  500,  715, 0x000000},
				})then
					stommSleep(500)
					stomInpuText(applePWD)
					stommSleep(500)
					stomMultiColorTap("登录",{
						{  367,  710, 0x007aff},
						{  367,  613, 0xcdd6dd},
						{  294,  600, 0x606669},
						{  519,  715, 0x000000},
					})
				end
				if stomMultiColor("纵向请输入M",{
						{  196,  225, 0x000000},
						{  465,  315, 0x1d1e1e},
						{  100,  396, 0xc7c7cd},
						{  101,  431, 0xcacccc},
					})then
				--[[纵向请输入M2{
					{  198,  225, 0x000000},
					{  461,  314, 0x000000},
					{   93,  395, 0x426bf2},
					{  123,  434, 0xf8f8f8},
				}--]]
					stomInpuText(applePWD)
					stommSleep(500)
					stomMultiColorTap("登录",{
						{  450,  486, 0x007aff},
						{  144,  435, 0xf8f8f8},
						{  198,  225, 0x000000},
						{  495,  314, 0x222222},
					})
				end
				stomMultiColorTap("无法连接IT",{
					{  437,  628, 0x007aff},
					{  472,  626, 0xabd1fb},
					{  146,  521, 0x000000},
					{  222,  531, 0x8f8f8f},
				})
				if stomMultiColorTap("购买完成",{
					{  548,  493, 0x000000},
					{  427,  406, 0xffffff},
					{  425,  352, 0xcdcdd3},
					{  500,  715, 0x000000},
				}) or stomMultiColorTap("购买完成B",{
					{  309,  644, 0x007aff},
					{  259,  491, 0x000000},
					{  411,  553, 0x000000},
					{  517,  556, 0xf9f9f9},
				})then
					stommSleep(500)					
					OpenApp("com.hero.m2mx")
				--else stomLog("notfound")
				end			

			end
				if stomMultiColor("创建组队",{
					{  560,  245, 0xffff6b},
					{  571,  274, 0x08387b},
					{  508,  543, 0x08a2ad},
					{   48,  807, 0x8cc3b5},
				}) or stomMultiColor("创建组队",{
					{  501,  369, 0x843818},
					{  502,  390, 0xfffb84},
					{   96,  873, 0x00347b},
					{  281,  960, 0x10a2a5},
				}) or stomMultiColor("短信",{
					{  278,   80, 0x000000},
					{  324,   77, 0x535353},
					{  383,  162, 0xf9f9f9},
					{  581,   88, 0x007aff},
				})then
					stomMultiColor("关闭宠物",{
					{  607,  996, 0xf76910},
					{  318,  643, 0x527d7b},
					{  147,  522, 0x39ae84},
					{  494,  177, 0x8cdfd6},
				})
					stommSleep(1000)
					stomMultiColor("个人属性关闭",{
						{  599,  997, 0xadf3ef},
						{  545,  566, 0x4aa6ef},
						{  392,  544, 0xde6984},
						{   82,  654, 0xe7c331},
					})
					stomtoast("充值流程结束")
						--购买升级所需物品
					break
				end	
				
				stomMultiColorTap(点击认证mx,"点击认证mx")
				if stomMultiColor(梦想姓名框mx,"梦想姓名框mx") then
					stommSleep(1000)
					stomMultiColorTap(梦想姓名框mx,"梦想姓名框mx")
				end
				stomMultiColorTap(关闭国子监祭酒mx,"关闭国子监祭酒mx")
				if stomMultiColorTap(键中文姓名框mx,"键中文姓名框mx")or stomMultiColorTap(键中文姓名框无窗mx,"键中文姓名框无窗mx") then
					stommSleep(1000)
					n = math.random(1,2)
					sfzname = ZKQ_Word(zhangkq["姓氏"],1,1)..ZKQ_Word(zhangkq["名字"],n,3)
					stomInpuText(sfzname)
					stommSleep(1000)
					stomtap(490,  158)
				end
				
				if stomMultiColor(身份证框mx,"身份证框mx")then
					stommSleep(1500)
					stomMultiColorTap(身份证框mx,"身份证框mx")
				end
				if stomMultiColorTap(键身份证框mx,"键身份证框mx")or stomMultiColorTap(键中文身份框无窗mx,"键中文身份框无窗mx") then
					stommSleep(1000)
					A = math.random(1,#shenfenhao)
					sfznum = shenfenhao[A]
					stomInpuText(sfznum)
					stommSleep(1000)
					stomtap(490,  158)
				end
				
				if stomColorInReg("有身份证",0x000000, 90, 216, 656, 234, 674)then
					stommSleep(1000)
					stomMultiColorTap(实名认证确定mx,"实名认证确定mx")
				end
				if stomMultiColorTap(认证提示确定mx,"认证提示确定mx") then
				
				end
				
			--stomLog(loop)
			stommSleep(300)
		end
	end
end








function zhang_977975413()			--							梦想世界
	local t1 = os.time()
	local tasktype = 0
	local getloop = 0
	local zhiyin = 0
	local time_out =  math.random(15,20)*60
	while (true) do
		stomLog("getloop.."..getloop)
			OpenApp("com.hero.m2mx")
		
		MXSJ_fn_CZ()
		if stomMultiColor(加载界面mx,"加载界面mx") then
			stomtoast("脚本版本:".."  ".."1.0.3",1)
			stommSleep(10000)
		end
		if stomMultiColor(下载补丁失败mx,"下载补丁失败mx") then
			stomtoast("下载补丁失败重新开始",1)
			stommSleep(1000)
			lua_restart()
		end	
		stomMultiColorTap(签到奖励mx,"签到奖励mx") 
		stomMultiColorTap(职业技能mx,"职业技能mx") 
		stomMultiColorTap(日程活动mx,"日程活动mx") 
		stomMultiColorTap(装备招式mx,"装备招式mx") 
		stomMultiColorRegTap("领取奖励",0x49a3ef, "-1|54|0xcceeff,0|-42|0x7ec9f5,-24|21|0xf8f5c8,23|28|0xf3f0bf", 90, 150, 786, 458, 948)
		if getloop == 0 then
			stomMultiColorTap(多益服务协议同意jz,"多益服务协议同意jz")
			stomMultiColorTap(游客登录mx,"游客登录mx") 
			stomMultiColorTap(游客登录卡点mx,"游客登录卡点mx") 
			if stomMultiColorTap(开始游戏mx,"开始游戏mx") then
				t1 = os.time()
			end
			
			stomMultiColorTap(开始游戏卡点mx,"开始游戏卡点mx")
			stomMultiColorTap(跳过mx,"跳过mx")	
			if stomMultiColorReg("自动寻路",0xda7000, "-3|0|0xaf4c00,6|18|0xdfc200,4|-2|0x412400,-4|25|0xd75800", 90, 269, 496, 290, 542)then
				stommSleep(3000)
			else
				if stomMultiColorTap(主线mx,"主线mx") then
					stommSleep(2000)
				else
					if stomMultiColorTap(招募伙伴mx,"招募伙伴mx") then
						stommSleep(1000)
					else
						if stomMultiColorRegTap("招募伙伴二",0xff8800, "0|11|0xff7700,-3|43|0xc46309,7|28|0xf07b02,-7|10|0xff8800", 90, 176, 965, 474, 1037) then
							stommSleep(1000)
						else
							if stomMultiColorReg("引导摆摊",0xff8800, "7|0|0xff8800,15|5|0xff8800,9|11|0xf37c03,10|26|0xff7700,14|19|0xff8800", 90, 197, 909, 473, 964) then
								stommSleep(1000)
							else
								if stomMultiColorTap(主线剧情任务mx,"主线剧情任务mx")or
									stomMultiColorRegTap("自动寻路",0xff8800, "-3|7|0xff8800,6|11|0xff8800,-1|23|0xfe8800,-7|30|0xff7700,7|31|0xff8800", 90, 282, 909, 467, 960)then
									stommSleep(1000)
								else
									if stomMultiColorTap(职业任务mx,"职业任务mx")then
										stommSleep(1000)
									else
										if stomMultiColorRegTap("支线任务",0xff8800, "-2|23|0xff8800,-6|25|0xff8800,-1|28|0xff8800,-9|15|0xff8800,-8|0|0xff8800", 90, 196, 910, 466, 958)then
											stommSleep(1000)
										else
											if zhiyin == 0 then
												if stomMultiColorRegTap("指引任务",0xff7700, "7|15|0xff8800,2|25|0xf57d03,1|34|0xff8800,4|44|0xff8800", 90, 195, 912, 465, 996) or stomMultiColorTap(指引师徒mx,"指引师徒mx")then
													stommSleep(500)
													stomMultiColorRegTap("手指引导",0xffffee, "-38|-10|0xffbba2,-42|10|0xdd9777,-42|23|0xe6eec6,-68|26|0x112255,-64|32|0x55b29a,-66|58|0x773366", 90, 4, 6, 630, 1126)
												end
											end
										end
									end
								end
							end
						end	
					end
				end
			end
			if stomMultiColorRegTap("手指引导",0xffffee, "-40|-6|0xffd2c1,-57|52|0xccaa11,-59|43|0xcc3388,-50|34|0x44bbdd,-18|36|0xffddcc", 90, 4, 6, 630, 1126)then
				stommSleep(1000)
			end
			if stomMultiColor(酒馆格鲁关闭mx,"酒馆格鲁关闭mx")then 
				stommSleep(1000)
				stomtap(611, 1000)
			end
			stomMultiColorTap(扑朔mx,"扑朔mx")
			stomMultiColorTap(关闭成长历程mx,"五级关闭成长历程mx") 
			stomMultiColorTap(十六关闭成长历程mx,"十六关闭成长历程mx")
			stomMultiColorTap(姻缘一线牵mx,"姻缘一线牵mx") 
			stomMultiColorTap(宠物商店购买mx,"宠物商店购买mx")
			stomMultiColorTap(关闭我的伙伴界面mx,"关闭我的伙伴界面mx")  
			stomMultiColorTap(小霸王mx,"小霸王mx")
			stomMultiColorTap(关闭酒馆mx,"关闭酒馆mx")
			stomMultiColorRegTap("领取奖励",0x830d0d, "-3|-5|0xb6413a,8|-19|0xffff66,16|-17|0x0d3567,30|-5|0xe37864", 90, 258, 806, 552, 932)
			stomMultiColorTap(关闭成长历程界面mx,"关闭成长历程界面mx")
			stomMultiColorTap(关闭成长历程界面1mx,"关闭成长历程界面1mx")
			stomMultiColorTap(我要选择职业mx,"我要选择职业mx")
			stomMultiColorTap(职业确定选择mx,"职业确定选择mx")
			stomMultiColorTap(关闭职业指引人mx,"关闭职业指引人mx")
			stomMultiColorTap(十级领取mx,"十级领取mx")
			stomMultiColorTap(关闭升级礼包界面mx,"关闭升级礼包界面mx")
			stomMultiColorTap(使用mx,"使用mx")
			stomMultiColorTap(职业任务mx,"职业任务mx")
			stomMultiColorTap(购买mx,"购买mx")
			stomMultiColorTap(招募确定mx,"招募确定mx")
			stomMultiColorTap(了解师徒系统mx,"了解师徒系统mx")
			stomMultiColorTap(师徒规则我知道了mx,"师徒规则我知道了mx")
			stomMultiColorTap(职业寻物mx,"职业寻物mx") 
			stomMultiColorTap(不需要职业导师mx,"不需要职业导师mx") 
			stomMultiColorTap(装备天赋mx,"装备天赋mx")
			stomMultiColorTap(装备天赋确定mx,"装备天赋确定mx") 
			stomMultiColorTap(已装备天赋mx,"已装备天赋mx")
			stomMultiColorTap(关闭天赋界面mx,"关闭天赋界面mx") 
			stomMultiColorTap(宠物商店购买mx,"宠物商店购买mx") 
			stomMultiColorTap(宝图游方道士mx,"宝图游方道士mx") 
			stomMultiColorTap(伙伴加技能了关闭mx,"伙伴加技能了关闭mx") 
			if stomMultiColor(技能天赋界面mx,"技能天赋界面mx")then
				if stomMultiColorRegTap("领取奖励",0x0fa8bf, "47|-2|0x0f80ad,22|27|0x0f97b7", 90, 96, 177, 599, 952)then
					stomMultiColorTap(技能天赋界面mx,"技能天赋界面mx")
				end
			end		
			if stomMultiColorTap(送我回去mx,"送我回去mx")then
				
				
			end
			if stomMultiColor(点击认证mx,"点击认证mx")then
				getloop = 1
			end	
			if stomMultiColorTap(一键申请mx,"一键申请mx")then
				stommSleep(1000)
				stomMultiColorTap(关闭加入帮派mx,"关闭加入帮派mx")
			end
			
			stomMultiColorTap(提示身份确认无误mx,"提示身份确认无误mx")
			stomMultiColorTap(提示信息无误确定mx,"提示信息无误确定mx")
			stomMultiColorTap(关闭绑定账号mx,"关闭绑定账号mx") 
			stomMultiColorTap(职业任务做完取消mx,"职业任务做完取消mx")
			stomMultiColorTap(免费改名mx,"免费改名mx")
			stomMultiColorTap(二十级领取mx,"二十级领取mx") 
			stomMultiColorTap(对话窗口无选择关闭mx,"对话窗口无选择关闭mx")
			if stomMultiColorTap(除魔师没空mx,"除魔师没空mx") then
				zhiyin = 1
			end
			
			
			
			if stomMultiColorRegTap("手指引导",0xffffee, "-40|-6|0xffd2c1,-57|52|0xccaa11,-59|43|0xcc3388,-50|34|0x44bbdd,-18|36|0xffddcc", 90, 4, 6, 630, 1126)then
				stommSleep(1000)
			end
			stomMultiColorTap(扑朔mx,"扑朔mx")
			stomMultiColorRegTap("引导摆摊",0xff8800, "7|0|0xff8800,15|5|0xff8800,9|11|0xf37c03,10|26|0xff7700,14|19|0xff8800", 90, 197, 909, 473, 964)
			stomMultiColorTap(摆摊栏mx,"摆摊栏mx")
			stomMultiColorTap(水果选定mx,"水果选定mx")
			stomMultiColorTap(选定批量上架mx,"选定批量上架mx") 
			stomMultiColorTap(批量上架mx,"批量上架mx") 
			if stomMultiColor(批量上架窗口mx,"批量上架窗口mx") then
				for var= 1, 2 do
					stommSleep(500)
					stomMultiColorRegTap("选定物品",0x395c5b, "14|-1|0xb0e9df,33|65|0x335454,7|66|0x98f6e4", 90, 437, 312, 517, 550)
				end
				stommSleep(1000)
				stomMultiColorTap(关闭批量上架窗口mx,"关闭批量上架窗口mx")
			end
			stomMultiColorTap(保存伙伴天赋mx,"保存伙伴天赋mx")
			if stomMultiColorTap(关闭摆摊界面mx,"关闭摆摊界面mx")or stomMultiColorTap(关闭我的伙伴界面mx,"关闭我的伙伴界面mx")or stomMultiColorTap(关闭成长历程界面1mx,"关闭成长历程界面1mx")then
				getloop = 0 
			end
			if stomMultiColor(摆摊界面呦mx,"摆摊界面呦mx")then
				if stomColorInReg("有物品上架",0xfffb31, 90, 458, 368, 480, 388)then
					stomtap(610, 1006)
					stommSleep(500)
					getloop = 0 
				end
			end
		elseif getloop == 1 then
			if mx_shiming() == 0 then
				getloop = 0
			end
		elseif getloop == 2 then
			if stomMultiColorRegTap("手指引导",0xffffee, "-40|-6|0xffd2c1,-57|52|0xccaa11,-59|43|0xcc3388,-50|34|0x44bbdd,-18|36|0xffddcc", 90, 4, 6, 630, 1126)then
				stommSleep(1000)
			end
			stomMultiColorTap(扑朔mx,"扑朔mx")
			stomMultiColorRegTap("引导摆摊",0xff8800, "7|0|0xff8800,15|5|0xff8800,9|11|0xf37c03,10|26|0xff7700,14|19|0xff8800", 90, 197, 909, 473, 964)
			stomMultiColorTap(摆摊栏mx,"摆摊栏mx")
			stomMultiColorTap(水果选定mx,"水果选定mx")
			stomMultiColorTap(选定批量上架mx,"选定批量上架mx") 
			stomMultiColorTap(批量上架mx,"批量上架mx") 
			if stomMultiColor(批量上架窗口mx,"批量上架窗口mx") then
				for var= 1, 2 do
					stommSleep(500)
					stomMultiColorRegTap("选定物品",0x395c5b, "14|-1|0xb0e9df,33|65|0x335454,7|66|0x98f6e4", 90, 437, 312, 517, 550)
				end
				stommSleep(1000)
				stomMultiColorTap(关闭批量上架窗口mx,"关闭批量上架窗口mx")
			end
			stomMultiColorTap(保存伙伴天赋mx,"保存伙伴天赋mx")
			if stomMultiColorTap(关闭摆摊界面mx,"关闭摆摊界面mx")or stomMultiColorTap(关闭我的伙伴界面mx,"关闭我的伙伴界面mx")or stomMultiColorTap(关闭成长历程界面1mx,"关闭成长历程界面1mx")then
				getloop = 0 
			end
			if stomMultiColor(摆摊界面呦mx,"摆摊界面呦mx")then
				if stomColorInReg("有物品上架",0xfffb31, 90, 458, 368, 480, 388)then
					stomtap(610, 1006)
					stommSleep(500)
					getloop = 0 
				end
			end
			
		end
		local t2 = os.time()
		
		if os.difftime(t2,t1) > time_out then
			stommSleep(5000)
			stomLog("超过20分钟")
			return 0
		end
		
	end
end

















--													1	剑侠风云录



function zhang_1479644244()							
	local t1 = os.time()
	local time_cha =  math.random(150,200)*60
	local loop = 0
	local youkebug = 0
	
	while (true) do
		OpenApp("Jcom.man.xjfyl")
		if stomMultiColor(战斗胜利jy,"战斗胜利jy")or
		stomMultiColor(恭喜获得jy,"恭喜获得jy")or
		stomMultiColor(战斗胜利无星jy,"战斗胜利无星jy")or
		stomMultiColor(等级提升jy,"等级提升jy")or
		stomMultiColor(通关第多章jy,"通关第多章jy")or
		stomMultiColor(激活成功太微jy,"激活成功太微jy")or
		stomMultiColor(猪脚突破成功jy,"猪脚突破成功jy")or
		stomMultiColor(小师妹jy,"小师妹jy")or
		stomMultiColor(激活成功菩提绝jy,"激活成功菩提绝jy")or
		stomMultiColorTap(少校对话jy,"少校对话jy")or
		stomMultiColorTap(飞飞对话jy,"飞飞对话jy")then	 
			x = math.random(1,639)	
			y = math.random(1,1135)
			stomtap(x,y)
		end
		if stomMultiColor(充值界面jy,"充值界面jy") then
			
			hadl_充值()
		end
		stomMultiColorTap(二次立即登录jy,"二次立即登录jy")
		stomMultiColorTap(公告确定jy,"公告确定jy")
		stomMultiColorTap(剑侠注册账号jy,"剑侠注册账号jy")
		stomMultiColorTap(用户名框jy,"用户名框jy")
		if stomMultiColorTap(键用户名框jy,"键用户名框jy")then
			stommSleep(2000)
			 m = math.random(6,8) 
			 mima = myRand(4,m,2)
			n = math.random(2,4) 
			mima1 = myRand(4,n,2) 
			stomInpuText(mima..mima1)
			stommSleep(2000)
			stomtap( 55,  423)
		end
		if stomMultiColorTap(密码框jy,"密码框jy") then
			stommSleep(2000)
			 m = math.random(6,11) 
			 mima = myRand(4,m,2)
			stomInpuText(mima)
			stommSleep(2000)
			stomtap( 45,  519)
		end
		
		
		if stomColorInReg("有账号",0x0b0b0b, 90, 153, 456, 177, 479)then
			stommSleep(1000)
			stomMultiColorTap(注册确定jy,"注册确定jy")
		end
		if stomMultiColorTap(进入游戏jy,"进入游戏jy")then
			stommSleep(3000)
		end
		stomMultiColorTap(白字跳过jy,"白字跳过jy")
		stomMultiColorTap(跳过jy,"跳过jy")
		if stomMultiColorTap(筛子jy,"筛子jy") then
			stommSleep(1000)
			stomMultiColorTap(创建角色jy,"创建角色jy")
		end
		stomMultiColorTap(跳过1jy,"跳过1jy")
		stomMultiColorTap(战况回顾jy,"战况回顾jy")
		stomMultiColorTap(参悟五次菩提决jy,"参悟五次菩提决jy")
		if stomMultiColor(关闭参悟获取途径jy,"关闭参悟获取途径jy") then
			loop = 1
		end	
		if loop == 1 then
			stomMultiColorTap(关闭参悟获取途径jy,"关闭参悟获取途径jy")
			if stomMultiColorTap(去首页jy,"去首页jy") then
				loop = 0
			end
		end
	
--		stomMultiColorTap(二次立即登录jy,"二次立即登录jy")
	
	for var= 1, 10 do
	
		if stomMultiColorRegTap("下右手指",0xfffefe, "117|1|0xfffefe,60|-56|0xfffefe,151|86|0xfde6cc,181|107|0x3e292d", 90, 0, 0, 639, 1135,65,0)then
			toast("下右手指",1)
		end
		if stomMultiColorRegTap("下左手指",0xfffefe, "124|-4|0xfffefe,63|-63|0xfffefe,-41|92|0xfde6cc,-65|117|0x2f1b1a", 90, 0, 0, 639, 1135,70,0)then
			toast("下左手指",1)
		end
		if stomMultiColorRegTap("上右手指",0xfffefe, "122|0|0xfffefc,60|-60|0xfffefe,137|-69|0xfde8cf,160|-92|0x2f1b1a", 90, 0,0,639,1135,65,-10)then
			toast("上右手指",1)
		end
		if stomMultiColorRegTap("上左手指",0xfffefe, "114|5|0xfffefe,57|-53|0xfffefe,-24|-68|0xfde5cb,-52|-92|0x402c31", 90, 0, 0, 639, 1135,65,-10)then
			toast("上左手指",1)
		end
		stomMultiColorTap(指引返回jy,"指引返回jy")
		stomMultiColorTap(指引添加人物jy,"指引添加人物jy")
		stomMultiColorTap(指引阵容jy,"指引阵容jy")
		stomMultiColorTap(指引返回1jy,"指引返回1jy")
		stomMultiColorTap(指引快速挑战jy,"指引快速挑战jy")
		stomMultiColorTap(指引副本jy,"指引副本jy")
		stomMultiColorTap(指引返回2jy,"指引返回2jy")
		stomMultiColorTap(指引一键装备jy,"指引一键装备jy")
		stomMultiColorTap(指引一键强化jy,"指引一键强化jy")
		stomMultiColorTap(一键领取宝箱条jy,"一键领取宝箱条jy")
		stomMultiColorTap(指引第三位宝宝jy,"指引第三位宝宝jy")
		stomMultiColorTap(指引首页jy,"指引首页jy")
		stomMultiColorTap(指引托管jy,"指引托管jy")
	end	
		local t2 = os.time()
		if os.difftime(t2,t1) > time_cha then
			if tasktype == 0 then
				stomLog("超过10分钟")
				return 0
			else
				return 0
			end
		end
	stommSleep(500)
	end
	

end




--												2		剑影



function zhang_1483002843()							
	local t1 = os.time()
	local time_cha =  math.random(150,200)*60
	local loop = 0
	local youkebug = 0
	
	while (true) do
		OpenApp("Jian.ying.A")
		if stomMultiColor(战斗胜利jy,"战斗胜利jy")or
		stomMultiColor(恭喜获得jy,"恭喜获得jy")or
		stomMultiColor(战斗胜利无星jy,"战斗胜利无星jy")or
		stomMultiColor(等级提升jy,"等级提升jy")or
		stomMultiColor(通关第多章jy,"通关第多章jy")or
		stomMultiColor(激活成功太微jy,"激活成功太微jy")or
		stomMultiColor(猪脚突破成功jy,"猪脚突破成功jy")or
		stomMultiColor(小师妹jy,"小师妹jy")or
		stomMultiColor(激活成功菩提绝jy,"激活成功菩提绝jy")or
		stomMultiColorTap(少校对话jy,"少校对话jy")or
		stomMultiColorTap(飞飞对话jy,"飞飞对话jy")then	 
			x = math.random(1,639)	
			y = math.random(1,1135)
			stomtap(x,y)
		end
		if stomMultiColor(充值界面jy,"充值界面jy") then
			
			hadl_充值()
		end
		stomMultiColorTap(二次立即登录jy,"二次立即登录jy")
		stomMultiColorTap(公告确定jy,"公告确定jy")
		stomMultiColorTap(剑影我要注册jy,"剑影我要注册jy")
		if stomMultiColorTap(剑影用户名框jy,"剑影用户名框jy")then
			stommSleep(1000)
			stomMultiColorTap(剑影用户名框jy,"剑影用户名框jy")
			stommSleep(1000)
			 m = math.random(6,8) 
			 mima = myRand(4,m,2)
			n = math.random(2,4) 
			mima1 = myRand(4,n,2) 
			stomInpuText(mima..mima1)
			stommSleep(2000)
			stomtap( 55,  423)
		end
		if stomMultiColorTap(剑影密码框jy,"剑影密码框jy") then
			stommSleep(1000)
			stomMultiColorTap(剑影密码框jy,"剑影密码框jy")
			 m = math.random(6,11) 
			 mima = myRand(4,m,2)
			stomInpuText(mima)
			stommSleep(2000)
			stomtap( 45,  519)
		end

		if stomColorInReg("有账号",0x000000, 90, 228, 447, 258, 467)then
			stommSleep(1000)
			stomMultiColorTap(剑影注册确定jy,"剑影注册确定jy") 
		end
		if stomMultiColor(剑影用户名已存在jy,"剑影用户名已存在jy") then
			loop = 2
		end
		if loop == 2 then
			stomMultiColorTap(剑影用户名已存在jy,"剑影用户名已存在jy")
			stommSleep(1000)
			if stomMultiColorTap(退出注册界面jy,"退出注册界面jy") then
				loop = 0
			end
		end
		if stomMultiColorTap(进入游戏jy,"进入游戏jy")then
			stommSleep(3000)
		end
		stomMultiColorTap(白字跳过jy,"白字跳过jy")
		stomMultiColorTap(跳过jy,"跳过jy")
		stomMultiColorTap(少校对话jy,"少校对话jy")
		stomMultiColorTap(飞飞对话jy,"飞飞对话jy")
		if stomMultiColorTap(筛子jy,"筛子jy") then
			stommSleep(1000)
			stomMultiColorTap(创建角色jy,"创建角色jy")
		end
		stomMultiColorTap(跳过1jy,"跳过1jy")
		stomMultiColorTap(战况回顾jy,"战况回顾jy")
		stomMultiColorTap(参悟五次菩提决jy,"参悟五次菩提决jy")
		if stomMultiColor(关闭参悟获取途径jy,"关闭参悟获取途径jy") then
			loop = 1
		end	
		if loop == 1 then
			stomMultiColorTap(关闭参悟获取途径jy,"关闭参悟获取途径jy")
			if stomMultiColorTap(去首页jy,"去首页jy") then
				loop = 0
			end
		end

--		stomMultiColorTap(指引点击夫人一jy,"指引点击夫人一jy")
	
	for var= 1, 10 do
	
		if stomMultiColorRegTap("下右手指",0xfffefe, "117|1|0xfffefe,60|-56|0xfffefe,151|86|0xfde6cc,181|107|0x3e292d", 90, 0, 0, 639, 1135,65,0)then
			toast("下右手指",1)
		end
		if stomMultiColorRegTap("下左手指",0xfffefe, "124|-4|0xfffefe,63|-63|0xfffefe,-41|92|0xfde6cc,-65|117|0x2f1b1a", 90, 0, 0, 639, 1135,70,0)then
			toast("下左手指",1)
		end
		if stomMultiColorRegTap("上右手指",0xfffefe, "122|0|0xfffefc,60|-60|0xfffefe,137|-69|0xfde8cf,160|-92|0x2f1b1a", 90, 0,0,639,1135,65,-10)then
			toast("上右手指",1)
		end
		if stomMultiColorRegTap("上左手指",0xfffefe, "114|5|0xfffefe,57|-53|0xfffefe,-24|-68|0xfde5cb,-52|-92|0x402c31", 90, 0, 0, 639, 1135,65,-10)then
			toast("上左手指",1)
		end
		stomMultiColorTap(指引返回jy,"指引返回jy")
		stomMultiColorTap(指引添加人物jy,"指引添加人物jy")
		stomMultiColorTap(指引阵容jy,"指引阵容jy")
		stomMultiColorTap(指引返回1jy,"指引返回1jy")
		stomMultiColorTap(指引快速挑战jy,"指引快速挑战jy")
		stomMultiColorTap(指引副本jy,"指引副本jy")
		stomMultiColorTap(指引返回2jy,"指引返回2jy")
		stomMultiColorTap(指引一键装备jy,"指引一键装备jy")
		stomMultiColorTap(指引一键强化jy,"指引一键强化jy")
		stomMultiColorTap(一键领取宝箱条jy,"一键领取宝箱条jy")
		stomMultiColorTap(指引第三位宝宝jy,"指引第三位宝宝jy")
		stomMultiColorTap(指引首页jy,"指引首页jy")
		stomMultiColorTap(指引点击夫人一jy,"指引点击夫人一jy")
		stomMultiColorTap(指引托管jy,"指引托管jy")
	end	
		local t2 = os.time()
		if os.difftime(t2,t1) > time_cha then
			if tasktype == 0 then
				stomLog("超过10分钟")
				return 0
			else
				return 0
			end
		end
	stommSleep(500)
	end
	

end






error_60ma = ""
UserID, UserKey, developer, error_60ma= "45701", "31C0C9B95104555DE650", "zk1013", ""

function creatTask()
	stomLog("creatTask...");
	status = "1"

	if apple_bid == "com.sanguosha.mjz" then	--三国杀名将传
		status = zhang_1356464028()
	elseif apple_bid == "com.darklandhadlsdfs" then	--暗黑大陆
		status = zhang_1467863426()
	elseif apple_bid == "com.duoyi.m2mx3" then	--梦想世界3D
		status = zhang_1249610247()
	elseif apple_bid == "com.hero.m2mx" then	--梦想世界
		status = zhang_977975413()	
	elseif apple_bid == "com.qidea.dldl.yuewen" then	--斗罗大陆		hd
		status = creat_dl1300066093_main()	
	elseif apple_bid == "Jian.ying.A" then		--	剑影江湖
		status = zhang_1483002843()	
	elseif apple_bid == "com.man.xjfyl" then		--	剑侠风云录
		status = zhang_1479644244()	
	
		
		
		
		
end
	stomLog(apple_bid)
	return status
end	