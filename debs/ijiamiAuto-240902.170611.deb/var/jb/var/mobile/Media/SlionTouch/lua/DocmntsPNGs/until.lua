inpay  = 0
function getPayStatus()
	if stomisFrontApp("com.apple.mobilephone") == 1 then
		inpay = inpay + 1
	end
	if inpay > 2 then
		stomLog("进入充值")
		stomLogPUT("进入充值")
		payAppSore()
	end
end

function payAppSore()
	--com.apple.mobilephone			--进入充值
	--com.apple.MobileSMS			--完成充值
	local t1 = os.time()
	local payok = 0
	local payno = 0
	while (true) do
		stomLog("payAppSore")
		if stomisFrontApp("com.apple.MobileSMS") == 1 then
			payok = payok + 1
		end
		if payok > 2 then
			stomLog("完成充值")
			stomLogPUT("完成充值")
			return 0
		end
		stommSleep(5*1000)
	end
	
end


function clearMobilesafari()
--	os.execute("killall -9 MobileSafari Preferences");
--    os.execute("rm -rf /private/var/mobile/Library/Caches/com.apple.mobilesafari");
--    os.execute("rm -rf /private/var/mobile/Library/Caches/Safari");
--    os.execute("rm -rf /private/var/mobile/Library/WebKit");
--    os.execute("rm -rf /private/var/mobile/Library/Cookies/Cookies.binarycookies");
--    os.execute("rm -rf /private/var/root/Library/Cookies/Cookies.binarycookies");
--    os.execute("rm -rf /private/var/mobile/Library/Safari/History.plist");
--    os.execute("rm -rf /private/var/mobile/Library/Safari/SuspendState.plist");
--    os.execute("rm -rf /private/var/mobile/Library/Safari/RecentSearches.plist");
--    os.execute("rm -rf /private/var/mobile/Library/Safari/SyncedTabsMetadata.plist");

----    os.execute("rm  -rf /private/var/mobile/Library/Safari/Bookmarks.db");
----    os.execute("rm  -rf /private/var/mobile/Library/Safari/Bookmarks.db-shm");
----    os.execute("rm  -rf /private/var/mobile/Library/Safari//Bookmarks.db-wal");
--    os.execute("rm  -rf /private/var/mobile/Library/Safari/SyncedTabsMetadata.plist");
--    os.execute("rm  -rf /private/var/mobile/Library/Safari/com.apple.Bookmarks.lock");
	os.execute("/usr/bin/STask -cleanSafariCaches");
	stommSleep(2000)
end
function doClcikCr(docrCount)
	stomLog("doClcikCr="..docrCount)
	local ipcount = 0
	local loop = 0
	local okcount = 0
	local nocount = 0
	while true do
		stomLog("okcount="..okcount)
		if loop == 0 then
			clearMobilesafari()
			setvpn("discon")
			loop = 1
		elseif loop == 1 then	
			stomLog("ipset")
			setvpn("con")
			stommSleep(2*1000)
			--code, newip = getipcn()
			code, newip, latitude, longitude = getipus()
			if code == 200 and newip ~= nil then
				cr_now_ip = newip
				ipcount = 0
				loop = 2
			else
				stomtoast("ip==nil",1)
				setvpn("discon")
			end
			stommSleep(1000)
			ipcount = ipcount + 1
			if ipcount > 2 then
				setvpn("discon")
				ipcount = 0
			end
		elseif loop == 2 then
			toast("ok "..okcount,1)
			for i =1 ,3 do
				clearMobilesafari()
				cr_now_idfa = myRand(9,8,1)
				--callbackURL = "http://121.42.27.96:1111/stom/cpa/callback_notice?idfa="..cr_now_idfa.."&appid="..apple_appid.."&tid="..taskid
				callbackURL = SLionLUA["callbackURL"].."?idfa="..cr_now_idfa.."&"..callbackURLdata
				callbackURL = urlEncode(callbackURL)
				durl_new = string.gsub(durl, "{idfa}", cr_now_idfa)
				durl_new = string.gsub(durl_new, "{ClickID}", apple_appid)
				durl_new = string.gsub(durl_new, "{CID}", apple_appid)
				durl_new = string.gsub(durl_new, "{IDFA}", cr_now_idfa)
				durl_new = string.gsub(durl_new, "{ip}", cr_now_ip)
				durl_new = string.gsub(durl_new, "{taskid}", taskid)
				durl_new = string.gsub(durl_new, "{appid}", apple_appid)
				local dl ,dj = string.find(durl_new,"&aff_sub={callback}")
				if dl then
					stomLog("need callback")
					durl_new = string.gsub(durl_new, "&aff_sub={callback}", "")
					durl_new = durl_new.."&aff_sub="..callbackURL
				end
				durl_new = string.gsub(durl_new, "{", "")
				durl_new = string.gsub(durl_new, "}", "")
				stomLog(durl_new)
				stomopenURL(durl_new)
				stommSleep(3000)
				for i = 1 , 10 do
					-- fmt("dakaiappstore",378, 477, 524, 708)
					if stomisFrontApp("com.apple.AppStore") == 1 or 
						stomisFrontApp(apple_bid) == 1 then
						okcount = okcount + 1
						nocount = 0
						break
					else
						local x1,y1,x2,y2 = 415, 491, 611, 805
						stomColorInRegTap("dakai",0x007aff, 90, x1,y1,x2,y2)
						stomLog("no stomisFrontApp")
						stommSleep(1000)
					end
				end
				nocount = nocount + 1
				loop = 0
			end
		end
		if okcount >= docrCount then
			return 0
		end
		if nocount >= 10 then
			return 1
		end
	end
end

function randwmac()
	tmpmactb={}
	for i1=1,6 do
		local k =""
		for i=1,2 do
			b_p = math.random(1,16)
			rnd_batter=string.sub("0123456789abcdefd",b_p,b_p)
			k = rnd_batter..k
		end
		table.insert(tmpmactb,k)
	end

	mac_2 = table.concat(tmpmactb,':')	--4位
	return mac_2
end
function randssid()
	local t1 = {"TP-LINK","D-LINK","Asus","Linksys","HUAWEI","Cisco","NETGEAR","UBNT","Moto","Bselkin","Buffalo","ATT","Verz"}
	local t2 = {"_5G_"..myRand(6,4,1),"_"..myRand(6,4,1)}
	local ssid = t1[math.random(1,#t1)]..t2[math.random(1,#t2)]
	return ssid
end
function randsystemtime(os)
	local t = {}
	t["9.1"]="1445443200"
	t["9.2"]="1449590400"
	t["9.2.1"]="1453219200"
	t["9.3"]="1458576000"
	t["9.3.1"]="1459440000"
	t["9.3.2"]="1463414400"
	t["9.3.3"]="1468857600"
	t["9.3.4"]="1470326400"
	t["9.3.5"]="1472140800"
	t["9.3.6"]="1563811200"
	t["10.0"]="1474128000"
	t["10.0.1"]="1473696000"
	t["10.0.2"]="1474560000"
	t["10.0.3"]="1476633600"
	t["10.1"]="1477238400"
	t["10.1.1"]="1477843200"
	t["10.2"]="1481472000"
	t["10.2.1"]="1485100800"
	t["10.3"]="1490544000"
	t["10.3.1"]="1491148800"
	t["10.3.2"]="1494777600"
	t["10.3.3"]="1500393600"
	t["10.3.4"]="1563811200"
	t["11.0"]="1505750400"
	t["11.0.1"]="1506355200"
	t["11.0.2"]="1506960000"
	t["11.0.3"]="1507651200"
	t["11.1"]="1509379200"
	t["11.1.1"]="1510156800"
	t["11.1.2"]="1510761600"
	t["11.2.0"]="1512144000"
	t["11.2.1"]="1513094400"
	t["11.2.2"]="1515340800"
	t["11.2.5"]="1516636800"
	t["11.2.6"]="1518969600"
	t["11.3"]="1522252800"
	t["11.3.1"]="1524499200"
	t["11.4"]="1527523200"
	t["11.4.1"]="1531065600"
	t["12.0"] = "1537372800"
	t["12.0.1"] = "1539100800"
	t["12.1"] = "1544371200"
	t["12.1.1"] = "1547049600"
	t["12.1.2"] = "1547049600"
	t["12.1.3"] = "1550160000"
	t["12.1.4"] = "1550160000"
	t["12.2"] = "1555257600"
	t["12.3"] = "1557849600"
	t["12.3.1"] = "1560528000"
	local t2 = math.random(1000,99999)
	if t[os] then
		return tostring(tonumber(t[os]) + t2)
	else
		return tostring(tonumber(devicesinfo['osversion']) + t2)
	end
end

function createFakeDeviveInfo()
	stomLog("createFakeDeviveInfo")
	g_now_idfa = myRand(9,8,1)
	f_bidTB={apple_bid}
	ipLocationtb={}
	ipLocationtb["latitude"] = math.modf(latitude)..".".. math.random(10000,999999)
	ipLocationtb["longitude"] = math.modf(longitude)..".".. math.random(10000,999999)
	faketb = {}
	local carnamenum = math.random(1,3)
	if carnamenum == 1 then
		carname = "中国电信"
		carnameEN = "CTCC"
		f_mnc = "03"
	elseif carnamenum == 2 then
		carname = "中国联通"
		carnameEN = "CUCC"
		f_mnc = "01"
	elseif carnamenum == 3 then
		carname = "中国移动"
		carnameEN = "CMCC"
		f_mnc = "02"
	end

	f_country = "cn"
	f_mcc = "460"
	f_isBuonds = "0"
	f_language = "zh-cn"
	f_model = "iPhone"..math.random(9,10)..","..math.random(1,2)
	f_name = "iPhone"
	if taskConfigTable["fakeos"][1] ~= "0" then
		f_OS = taskConfigTable["fakeos"][math.random(1,#taskConfigTable["fakeos"])]
		--sendos = fakeos
	else
		f_OS = devicesinfo['osversion']
	end
	local idfv = myRand(9,8,1)
	faketb["bid"] = f_bidTB
	faketb["BSSID"] = randwmac()
	faketb["Lip"] = "192.168."..math.random(0,10).."."..math.random(2,250)
	faketb["OS"] = f_OS
	faketb["SSID"] = randssid()
	faketb["boottime"] = os.time()-(math.random(1,10)*86400)
	faketb["carrierName"] = carname
	faketb["country"] = f_country
	faketb["devicetoken"] = myRand(6,64,2)
	faketb["idfa"] = g_now_idfa
	faketb["idfv"] = idfv
	faketb["ipLocation"] = ipLocationtb
	faketb["isBuonds"] = f_isBuonds
	faketb["language"] = f_language
	faketb["mcc"] = f_mcc
	faketb["mnc"] = f_mnc
	faketb["model"] = f_model
	faketb["name"] = f_name
	faketb["systemtime"] = randsystemtime(f_OS)
	faketb["voiptoken"] = myRand(6,64,2)
	faketb["udid"] = myRand(6,40,2)
	faketb["MobileIP"] = "110.100."..math.random(100,150).."."..math.random(100,240)
	return faketb
end

function setvpn_jp(status,region)
	for i=1, 10 do
		stomLog("vpn_status="..tostring(vpn_status))
		if VPN_variables == 1 then
			if status == "con" then
				if getVPN("1",region) then
					vpn_status = true
					return true
				end
			else	
				if vpn_status then
					if getVPN("0",region) then
						stommSleep(1000)
						vpn_status = false
						return true
					end
				else
					return true
				end
			end
		else
			return true
		end
		stommSleep(3000)
	end
end

function setvpn(status)
	setvpn_jp(status)	
end

function slionclearApp(bid)
	stomLog("slionclearApp")
	stomcloseApp(apple_bid)
	stomgetSystem("/usr/bin/STask -cleanSafariCaches");
	System.execute2("su mobile -c uicache");
	slionAppNew_info = createFakeDeviveInfo()
	local t = {}--stomplistRead(fkplist_path)
	t["bid"] = slionAppNew_info["bid"]
	t["BSSID"] = slionAppNew_info["BSSID"]
	t["Lip"] = slionAppNew_info["Lip"]
	t["OS"] = slionAppNew_info["OS"]
	t["SSID"] = slionAppNew_info["SSID"]
	t["boottime"] = slionAppNew_info["boottime"]
	t["carrierName"] = slionAppNew_info["carrierName"]
	t["country"] = slionAppNew_info["country"]
	t["devicetoken"] = slionAppNew_info["devicetoken"]
	t["idfa"] = slionAppNew_info["idfa"]
	t["idfv"] = slionAppNew_info["idfv"]
	t["ipLocation"] = slionAppNew_info["ipLocation"]
	t["isBuonds"] = slionAppNew_info["isBuonds"]
	t["language"] = slionAppNew_info["language"]
	t["mcc"] = slionAppNew_info["mcc"]
	t["mnc"] = slionAppNew_info["mnc"]
	t["model"] = slionAppNew_info["model"]
	t["name"] = slionAppNew_info["name"]
	t["systemtime"] = slionAppNew_info["systemtime"]
	t["voiptoken"] = slionAppNew_info["voiptoken"]
	t["MobileIP"] = slionAppNew_info["MobileIP"]
	local str = json.encode(t)
	stomLog(str)
	local fkplist_path = "/private/var/mobile/Library/Preferences/com.capstar.FakeInfo.plist"
	stomplistWrite(str,fkplist_path)
	local res = System.execute("/usr/bin/STask -clearApp -b \""..bid.."\"")
	res = stomtrim(res)
	if string.match(res,"success") then
		return true
	end
	stomLog(res)
	return false
end

function slionappBackup(bid,filename)
	stomLog("slionappBackup")
	stomcloseApp(apple_bid)
	stomLog(filename)
	local res = System.execute("/usr/bin/STask -appBackup -b \""..bid.."\" -p \""..filename.."\"")
	res = stomtrim(res)
	if string.match(res,"success") then
		return true
	end
	stomLog(res)
	return false
end

function slionappRecover(bid,filename)
	stomLog("slionappRecover")
	System.execute("/usr/bin/STask -clearApp -b "..bid)
	stommSleep(1000)
	local res = System.execute("/usr/bin/STask -appRecover -b \""..bid.."\" -p \""..filename.."\"")
	res = stomtrim(res)
	if string.match(res,"success")then
		stomLog("slionappRecover success")
		return true
	end
	stomLog("slionappRecover false")
	stomLog(res)
	return false
end


function getFakeinfo()
	local t = {}
	local fkplist_path = "/private/var/mobile/Library/Preferences/com.capstar.FakeInfo.plist"
	if stomisFileExist(fkplist_path) then
		t = stomplistRead(fkplist_path)
	end
	return t
end

function updataSandboxFiles(idfa,apple_appid)
	stomLogPUT("updataSandboxZIP",0)
	backfilepath = "private/var/mobile/Media/Slion/"..idfa..".zip"
	if stomisFileExist(backfilepath) then
		for i =1 , 3 do
			stomLog("updataSandboxZIP....")
			if stomuploadZip(SLionLUA["upZipURL"],apple_appid,backfilepath) then
				stomdelFile(backfilepath)
				stomLog("updataSandboxZIP OK")
				return true
			else
				stomLog("uploadZip False")
				stomLogPUT("uploadZip False",1)
				stommSleep(50000)
			end
		end
		return false
	else
		stomLog("ZIP不存在")
		return true	
	end
end

function updataCpaKeyUDID(idfa,apple_appid,apple_bid)
	stomLog("upCpaKeyUDID....")
	stomLogPUT("upCpaKeyUDID",0)
	CpaKeyUDIDPath = stomgetSandboxPath(apple_bid).."/Documents/CpaKeyUDID.plist"
	if idfa == nil then
		stomdelFile(CpaKeyUDIDPath)
		stomLog("idfa nil")
	end
	if stomisFileExist(CpaKeyUDIDPath) then
		for i =1 , 3 do
			local path2 = stomgetSandboxPath(apple_bid).."/Documents/"..idfa.."_CpaKeyUDID.plist"
			local cmd = "/bin/cp "..CpaKeyUDIDPath.." "..path2
			System.execute(cmd)
			stomLog(cmd)
			if stomuploadZip(SLionLUA["upZipURL"],apple_appid,path2) then
				stomdelFile(path2)
				stomdelFile(CpaKeyUDIDPath)
				stomLog("upCpaKeyUDID OK")
				return true
			else
				stomLog("upCpaKeyUDID False")
				stomLogPUT("upCpaKeyUDID False",1)
				stommSleep(5000)
			end	
		end
		return false
	else
		stomLog("CpaKeyUDID不存在")
		return true
	end
end
function down_installDeb(url)
	
end
function OpenApp(bid)
	local res = stomisFrontApp(bid)
	if res == 1 then
		return true
	else
		stommSleep(5000)
		stomrunApp(bid)
	end
	stommSleep(2000)
end
function sendYingYuPhonenumber(url,body_send)
	stomLog("sendYingYuPhonenumber...")
	stomLog(UserAgent)
	requestHeaders ={}
	requestHeaders["Content-Type"] = 'application/json'
	requestHeaders["Accept-Encoding"] = 'gzip, deflate'
	requestHeaders["Connection"] = 'keep-alive'
	requestHeaders["Accept"] = '*/*'
	requestHeaders["User-Agent"] = UserAgent
	requestHeaders["Accept-Language"] = 'zh;q=1'
	body_send_js = json.encode(body_send)
	for i =1 , 3 do
		stomLog(body_send_js)
		stomLog(url)
		local code , resHeaders, response = stomhttpsPost(url, 10, requestHeaders, body_send_js)
		--stomLog("send2")
		stomLog(response)
		stomLog(code)
		if code ~= nil then
			if code == 200 or code == 204 or code == 201 then
				yyrestb = json.decode(response)
				return 0
			elseif code >= 400 then
				yyrestb = json.decode(response)
				return 1
			end
		end
		stommSleep(1000)
	end
	return 1
end
function sendWeiKeChuanQi(url,body_send)
	stomLog("sendWeiKeChuanQi...")
	requestHeaders ={}
	requestHeaders["Content-Type"] = 'application/json;charset=UTF-8'
	requestHeaders["Accept-Encoding"] = 'gzip, deflate'
	requestHeaders["Connection"] = 'keep-alive'
	requestHeaders["Accept"] = '*/*'
	requestHeaders["User-Agent"] = UserAgent
	requestHeaders["Accept-Language"] = 'zh-Hans-CN;q=1, en-CN;q=0.9'
	body_sendstr = json.encode(body_send)
	
	for i =1 , 3 do
		--stomLog("send")
		local code , resHeaders, response = stomhttpsPost(url, 10, requestHeaders, body_sendstr)
		--stomLog("send22")
		if code ~= nil and code == 200 then
			--stomLog(response)
			yyrestb = json.decode(response)
			return 0
		end
		stommSleep(1000)
	end
	return 1
end
function CheckYingYuPhonenumber(phone)
	stomLog("CheckYingYuphone...")
	local sDeviceId = myRand(6,40,2)
	local timestampSec = os.time()
	local s0 = "lingome-app"..timestampSec
	local s1 = stomsha1(s0)
	local s2 = phone..s1
	local sig = stomsha1(s2)
	local codeParams = {
			["sig"] = sig,
			["mobile"] = phone,
			["timestampSec"] = timestampSec}
	local body_send = {
			["authFlow"] = "RESET_PWD",
			["poolId"] = "lingome-app",
			["isSignup"] = false,
			["deviceId"] = sDeviceId,
			["clientPlatform"] = "IOS",
			["codeParams"] = codeParams}
		
	local url = "https://account.llsapp.com/api/v2/initiate_auth"
	requestHeaders ={}
	requestHeaders["Content-Type"] = 'application/json'
	requestHeaders["Accept-Encoding"] = 'gzip, deflate'
	requestHeaders["Connection"] = 'keep-alive'
	requestHeaders["Accept"] = '*/*'
	requestHeaders["User-Agent"] = UserAgent
	requestHeaders["Accept-Language"] = 'zh;q=1'
	body_send_js = json.encode(body_send)
	stomLog(body_send_js)
	local code , resHeaders, response = stomhttpsPost(url, 10, requestHeaders, body_send_js)
	stomLog(response)
	stomLog(code)
	if code == 404 then
		local data = json.decode(response)
		if data.code == "1001" then
			return 0
		end
	elseif code == 200 then
		return 1
	end
	return 2
end
function create_424598114()	--苏宁易购
	apple_appid = "424598114"
	local loop = 0
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	createpasswd = myRand(4,10,1)
	while (true) do
		stomLog("createSuNing--"..loop)
		stommSleep(500);
		if loop == 0 then
			stomMultiColorTap("同意",    {{  501, 1079, 0xff5800},
					{  383, 1079, 0xff7800},
					{  267, 1071, 0xf2f2f2},
					{  115, 1069, 0xf2f2f2},
					{  575, 1071, 0xff4100},})
			stomMultiColorTap("我的易购",    {{  590, 1087, 0x666666},
					{  576, 1076, 0x666666},
					{  576, 1067, 0xffffff},
					{  457, 1088, 0x666666},})
			stomMultiColorTap("新用户注册",{{  321,  659, 0xffffff},
					{   97,  513, 0xff7900},
					{  553,  555, 0xff9900},
					{  317,  348, 0x000000},
					{  319,  337, 0xffffff},})
			stomMultiColorTap("登录注册",{{  577,   80, 0xffffff},
					{   75,  655, 0xffc999},
					{  557,  703, 0xffd699},
					{  357,  285, 0xf7b403},
					{  384,  259, 0xfff5dc},})
			stomMultiColorTap("同意并继续",{{  325, 1101, 0xff7100},
					{   85, 1067, 0xff8900},
					{  607, 1061, 0xff5500},
					{  197, 1079, 0xff7e00},
					{  281,  342, 0x222222},})
			if stomMultiColor("注册灰",{
					{  111,  435, 0xffca99},
					{  535,  443, 0xffd699},
					{  239,  445, 0xffce99},
					{   40,  335, 0xffffff},}) then
				loop = 1
			end
		elseif loop == 1 then
			stomLog("获取号码。。。"..getloop)
			if getloop == 0 then
				check_Rules = 1
				Telnum, ksuid = getTelnum_60ma_st(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
				if Telnum then
					stomLog(Telnum)
					getloop = 1
					num = 0
				else
					stomLog("重新获取号码中")
					stommSleep(2000)
					num = num + 1
				end
				if num > 20 then
					stomLog("获取号码失败")
					return 1
				end
			elseif getloop == 1 then
				phonenumber = Telnum
				if stomMultiColorTap("注册按钮OK",
						{{  271,  445, 0xff8600},
						{   55,  423, 0xff7800},
						{  575,  461, 0xff9900},
						{   42,  311, 0x222222},}) then
					yanzm = yanzm + 1
					stommSleep(500) 
				else
					if stomMultiColor("注册灰",{
					{  111,  435, 0xffca99},
					{  535,  443, 0xffd699},
					{  239,  445, 0xffce99},
					{   40,  335, 0xffffff},}) then
						stomLog("输入号码"..phonenumber)
						stommSleep(500) 
						stomInpuTextTap(40,  321, phonenumber, 1)
						stommSleep(500)
					end
				end
				if yanzm > 10 then
					stomLog("注册按钮OK次数过多")
					return 1
				end
				if stomMultiColor("验证码框xe",{
						{   82,  441, 0xff6600},
						{  111,  203, 0x222222},
						{  251,  409, 0xffffff},}) then
					getloop = 2
				end
				if stomMultiColor("需要验证",{
						{   81,  499, 0xffc999},
						{  589,  563, 0xffd699},
						{  233,  379, 0xe8e8e8},
						{  233,  371, 0xffffff},
					}) then
					return 1
				end
			elseif getloop == 2 then
				stomLog("获取短信...")
				stomMultiColorTap("注册按钮OK",
						{{  271,  445, 0xff8600},
						{   55,  423, 0xff7800},
						{  575,  461, 0xff9900},
						{   42,  311, 0x222222},})
				messg = GetSMS_60ma(UserID,UserKey,docks,phonenumber)
				if messg then
					messg = string.gsub(messg,"30分","")
					messg = string.sub(messg,9)
					yanzhenma = string.match(messg,"%d+")
					stomLog("验证码####"..yanzhenma)
					--stomInpuTextTap(86,  419, yanzhenma, 0);mSleep(1000)
					
					yanzhenmalist = stringToList(yanzhenma)
					isnext = 0
					for i =1, 4 do
						if i == 4 then
							isnext = 1
						end
						stomInpuTextTap(86+(150*(i-1)),  419, yanzhenmalist[i], isnext);mSleep(1000)
					end
				else
					stomLog("get sms")
					fa = fa +1
				end	
				if fa > 30 then
					stomLog("获取短信失败")
					addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
					freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
					return 1
				end
				stommSleep(500)
				if stomMultiColor("提交注册灰",{{  561,  441, 0xffd699},
							{   61,  429, 0xffc999},
							{  219,  443, 0xffcd99},
							{  405,  471, 0xffd399},}) then
					loop = 3
				end
				--if stomColorInReg("直接登录", 0xff7a20, 90, 361, 573, 535, 675) then
					--return 1
				--end
			end
			
		elseif loop == 3 then
			if stomMultiColorTap("提交注册OK",{{  191,  449, 0xff8000},
				{  427,  443, 0xff9300},
				{   67,  427, 0xff7800},}) then
			else
				if stomMultiColor("提交注册灰",{{  561,  441, 0xffd699},
							{   61,  429, 0xffc999},
							{  219,  443, 0xffcd99},
							{  405,  471, 0xffd399},}) then
					stomInpuTextTap(91,  317, createpasswd, 1)
					stommSleep(1000)
				end
			end
			
			if stomMultiColorTap("立即认证",{{  181,  567, 0xff7f00},
				{  487,  553, 0xff9600},
				{   71,  533, 0xff7800},
				{  319,  175, 0xf7b400},}) or
					stomMultiColor("立即认证2",{
				{  103,  511, 0xff7a00},
				{  589,  549, 0xff9900},
				{  285,  549, 0xff8800},
				{  315,  309, 0x000000},
			}) then
				return 0
			else
				stomLog("NO 立即认证")
			end
			
			
			
		end
		t2 = os.time()
		if os.difftime(t2,t1) > 600 then
			return 1
		end
	end
end
function create_424598114_new()	--苏宁易购
	apple_appid = "424598114"
	local loop = 0
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	createpasswd = myRand(4,10,1)
	while (true) do
		stomLog("createSuNing--"..loop)
		stommSleep(500);
		if loop == 0 then
			stomMultiColorTap("同意",    {{  501, 1079, 0xff5800},
					{  383, 1079, 0xff7800},
					{  267, 1071, 0xf2f2f2},
					{  115, 1069, 0xf2f2f2},
					{  575, 1071, 0xff4100},})
			stomMultiColorTap("我的易购",    {{  590, 1087, 0x666666},
					{  576, 1076, 0x666666},
					{  576, 1067, 0xffffff},
					{  457, 1088, 0x666666},})
			stomMultiColorTap("新用户注册",{{  321,  659, 0xffffff},
					{   97,  513, 0xff7900},
					{  553,  555, 0xff9900},
					{  317,  348, 0x000000},
					{  319,  337, 0xffffff},})
			stomMultiColorTap("登录注册",{{  577,   80, 0xffffff},
					{   75,  655, 0xffc999},
					{  557,  703, 0xffd699},
					{  357,  285, 0xf7b403},
					{  384,  259, 0xfff5dc},})
			stomMultiColorTap("同意并继续",{{  325, 1101, 0xff7100},
					{   85, 1067, 0xff8900},
					{  607, 1061, 0xff5500},
					{  197, 1079, 0xff7e00},
					{  281,  342, 0x222222},})
			if stomMultiColor("注册灰",{
					{  565,  268, 0xffffff},
					{   91,  395, 0xff8a00},
					{  545,  413, 0xff5a00},
					{  315,  441, 0xff7200},
				}) then
				loop = 1
			end
		elseif loop == 1 then
			stomLog("获取号码。。。"..getloop)
			if getloop == 0 then
				check_Rules = 1
				Telnum, ksuid = getTelnum_60ma_st(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
				if Telnum then
					stomLog(Telnum)
					getloop = 1
					num = 0
				else
					stomLog("重新获取号码中")
					stommSleep(2000)
					num = num + 1
				end
				if num > 20 then
					stomLog("获取号码失败")
					return 1
				end
			elseif getloop == 1 then
				phonenumber = Telnum
				if stomMultiColorTap("注册按钮OK",{
						{  305,  391, 0xff7300},
						{  565,  268, 0x999999},
						{   91,  395, 0xff8a00},
						{  545,  413, 0xff5a00},
						{  315,  441, 0xff7200},
					}) then
					yanzm = yanzm + 1
					stommSleep(500) 
				else
					if stomMultiColor("注册灰",{
							{  565,  268, 0xffffff},
							{   91,  395, 0xff8a00},
							{  545,  413, 0xff5a00},
							{  315,  441, 0xff7200},
						}) then
						stomLog("输入号码"..phonenumber)
						stommSleep(500) 
						stomInpuTextTap(43,  265, phonenumber, 1)
						stommSleep(500)
					end
				end
				if yanzm > 10 then
					stomLog("注册按钮OK次数过多")
					return 1
				end
				if stomMultiColor("输验证码框",{
						{  127,  329, 0xff5500},
						{  248,  173, 0x101010},
						{  552,   90, 0xff5500},
					}) then
					getloop = 2
				end
--				if stomMultiColor("需要验证",{
--						{  503,  355, 0xe8e8e8},
--						{  283,  393, 0xe8e8e8},
--						{  123,  487, 0xff8600},
--						{  543,  547, 0xff5b00},
--					}) then
--					return 1
--				end
			elseif getloop == 2 then
				stomLog("获取短信...")
				stomMultiColorTap("注册按钮OK",
						{{  271,  445, 0xff8600},
						{   55,  423, 0xff7800},
						{  575,  461, 0xff9900},
						{   42,  311, 0x222222},})
				messg = GetSMS_60ma(UserID,UserKey,docks,phonenumber)
				if messg then
					messg = string.gsub(messg,"30分","")
					messg = string.sub(messg,9)
					yanzhenma = string.match(messg,"%d+")
					stomLog("验证码####"..yanzhenma)
					--stomInpuTextTap(86,  419, yanzhenma, 0);mSleep(1000)
					
					yanzhenmalist = stringToList(yanzhenma)
					isnext = 0
					for i =1, 4 do
						if i == 4 then
							isnext = 1
						end
						stomInpuTextTap(97+(150*(i-1)),  307, yanzhenmalist[i], isnext);mSleep(1000)
					end
				else
					stomLog("get sms")
					fa = fa +1
				end	
				if fa > 30 then
					stomLog("获取短信失败")
					addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
					freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
					return 1
				end
				stommSleep(500)
--				if stomMultiColor("提交注册灰",{{  561,  441, 0xffd699},
--							{   61,  429, 0xffc999},
--							{  219,  443, 0xffcd99},
--							{  405,  471, 0xffd399},}) then
				if stomColorInRegTap("同意", 0xff7111, 90, 391, 821, 477, 869) then
					loop = 3
				end
				
				if stomMultiColor("需要验证",{
						{  503,  355, 0xe8e8e8},
						{  283,  393, 0xe8e8e8},
						{  123,  487, 0xff8600},
						{  543,  547, 0xff5b00},
					}) then
					return 1
				end
			end
			
		elseif loop == 3 then
--			if stomMultiColorTap("提交注册OK",{{  191,  449, 0xff8000},
--				{  427,  443, 0xff9300},
--				{   67,  427, 0xff7800},}) then
--			else
--				if stomMultiColor("提交注册灰",{{  561,  441, 0xffd699},
--							{   61,  429, 0xffc999},
--							{  219,  443, 0xffcd99},
--							{  405,  471, 0xffd399},}) then
--					stomInpuTextTap(91,  317, createpasswd, 1)
--					stommSleep(1000)
--				end
--			end
			
			if stomMultiColorTap("我的易购",{
					{  574, 1077, 0xff9f00},
					{   85,  145, 0xf7b501},
					{   69,  185, 0xf8fff6},
					{  117,  159, 0xf7b501},
				}) or
					stomMultiColor("立即认证2",{
				{  103,  511, 0xff7a00},
				{  589,  549, 0xff9900},
				{  285,  549, 0xff8800},
				{  315,  309, 0x000000},
			}) then
				return 0
			else
				stomLog("NO 立即认证")
			end
			
			stomMultiColorTap("关闭通知",{
				{  610,  369, 0xffffff},
				{  443,  493, 0xff3745},
				{  295,  463, 0xffb600},
				{  199,  487, 0x36dd6a},
			})
			
			
			
			
		end
		t2 = os.time()
		if os.difftime(t2,t1) > 600 then
			return 1
		end
	end
end
function create_597364850_60ma()		--英语流利说
	apple_appid = "597364850"
	local loop = 0
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	local issms = 0
	createpasswd = myRand(4,10,1)
	conmenttype = "Yingyulls"
	
	getPhoneType = "dm"
	docks = "16539"
	
	while (true) do
		stomLog("nnnncreateYingYulls--"..loop)
		stommSleep(500);
		if loop == 0 then
--			stomMultiColorTap("开始学习", {
--				{  285, 1079, 0x4fcb19},
--				{   69, 1041, 0x4fcb19},
--				{  553, 1035, 0x4fcb19},
--				{  413, 1053, 0x4fcb19},
--			})
			if stomMultiColorTap("准备输入号码",{
					{  264,  375, 0xffffff},
					{   69,  655, 0x4eca19},
					{  571,  725, 0x4eca19},
					{  337,  655, 0x4eca19},
					{   55,  491, 0x4fcb1a},
				}) then
				loop = 1
			end
		elseif loop == 1 then
			stomLog("获取号码。。。"..getloop)
			if getloop == 0 then
				check_Rules = 1
				Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
				phonenumber = Telnum
				if Telnum then
					if needcheck == 1 then
						checkcode = CheckYingYuPhonenumber(Telnum)
					else
						checkcode = 0
					end
					if checkcode == 0 then
						stomLog(Telnum)
						getloop = 1
						num = 0
					elseif checkcode == 1 then
						upContentData(conmenttype,Telnum,ksuid,field2,field3,"notnew")
						stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
						stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					else
						upContentData(conmenttype,Telnum,ksuid,field2,field3,"needcheck")
						stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
						return 1
					end
				else
					stomLog("重新获取号码中")
					stommSleep(5000)
					num = num + 1
				end
				if num > 30 then
					stomLog("获取号码失败")
					return 1
				end
			elseif getloop == 1 then
				phonenumber = Telnum
				if stomMultiColorTap("获取短信",{
						{   91,  679, 0x4eca19},
						{  537,  693, 0x4eca19},
						{   51,  487, 0x4fcb1a},
						{  264,  375, 0x212121},
					}) then
					yanzm = yanzm + 1
					stommSleep(500) 
				else
					if stomMultiColor("注册灰",{
							{  265,  373, 0xffffff},
							{  107,  671, 0x4eca19},
							{  553,  661, 0x4eca19},
						}) then
						stomLog("输入号码"..phonenumber)
						stommSleep(500) 
						stomInpuTextTap(244,  350, phonenumber, 3)
						stommSleep(500)
					end
				end
				if stomMultiColorTap("获取短信",{
						{   91,  679, 0x4eca19},
						{  537,  693, 0x4eca19},
						{   51,  487, 0x4fcb1a},
						{  264,  375, 0x212121},
					}) then
					stommSleep(5000)
				end
				if stomMultiColor("需要验证",{
					{117,  683, 0x66d200, 85}, 
					{189,  695, 0xdfe1e2, 85}, 
					{143,  681, 0x66d200, 85},
					{106,  786, 0x7e7e7e, 85}}) or
					stomColorInReg("好", 0x007aff, 90, 261, 605, 371, 653) then
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					upContentData(conmenttype,phonenumber,ksuid,field2,field3,"needcheck")
					return 1
				end
				if yanzm > 10 then
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					upContentData(conmenttype,phonenumber,ksuid,field2,field3,"yanzm10")
					return 1
				end
				if stomMultiColor("输入验证码",{
						{   62,   28, 0x757575},
						{  315,  216, 0x2c2b02},
						{   61,  216, 0x2c2b02},
						{  307,  655, 0xffffff},
					}) then
					getloop = 2
				end
--				if stomMultiColor("输入验证码",{{ 208, 177,0x212121},{ 408, 206,0x212121},{ 137,1091,0xd2d5db},{ 491,1051,0xd2d5db},}) then
--					getloop = 2
--				end
			elseif getloop == 2 then
				stomLog("获取短信...")
				stomMultiColorTap("获取按钮OK",{
						{  253,  473, 0x4fcb19},
						{  362,  460, 0x4fcb19},
						{  177,  336, 0x212121},
						{  171,  361, 0xffffff},
					})
				stomMultiColorTap("获取按钮OK2",{
					{  253,  473, 0x4fcb19},
					{  362,  460, 0x4fcb19},
					{  240,  341, 0x212121},
					{  235,  361, 0xffffff},
				})
				if issms == 0 then
					messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
				end
				if messg then
					messg = string.gsub(messg,"30分","")
					messg = string.sub(messg,9)
					yanzhenma = string.match(messg,"%d+")
					stomLog("yanzhenmaOK="..yanzhenma)
					issms = 1
					stomInpuTextTap(53,  395, yanzhenma,2);mSleep(1000)
					upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"1")
					getloop = 200
				else
					stomLog("get sms")
					fa = fa +1
				end	
				if fa > 20 then
					stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					if issms == 0 then
						stomLog("获取短信失败")
						stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
						stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
						upContentData(conmenttype,phonenumber,ksuid,field2,field3,"getsms60")
						return 10
					else
						upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"neterror")
						return 1
					end
				end
				
				stommSleep(5000)
			elseif getloop == 200 then	
				
				if stomColorInRegTap("女孩",0xff6f96, 90, 105, 387, 227, 493) then
					getloop = 3
				end
				
				if stomMultiColor("立即测试",{
						{  171,  809, 0x4fcb19},
						{  471,  829, 0x4fcb19},
						{  351,  795, 0x4fcb19},
					}) or
				stomMultiColor("立即测试红",{
					 {  409,  945, 0x4fcb19},
					 {   88,  941, 0x4fcb19},
					 {   81,  972, 0xffffff},
					}) or
				stomMultiColor("学姐快来",{
					{  313,  917, 0x4fcb19},
					{  155,  881, 0x4fcb19},
					{  495,  875, 0x4fcb19},
				}) or 
				stomMultiColor("添加课程",{
					{   63,  967, 0x4fcb19},
					{  565,  953, 0x4fcb19},
					{  323, 1005, 0x4fcb19},
				}) or stomMultiColor("学习",{
					{  144, 1080, 0x4fcb19},
					{  172, 1080, 0x4fcb19},
					{  192, 1080, 0xffffff},
					{  450, 1076, 0xffffff},
				}) then
					upContentData(conmenttype,phonenumber,ksuid,field2,field3,"notnew")
					return 1
				end

			elseif getloop == 3 then
				stomColorInRegTap("女孩",0xff6f96, 90, 105, 387, 227, 493)
				stomColorInRegTap("大学",0x648cf9, 90, 73, 385, 191, 553)
				if stomMultiColor("日常",{
						{  173, 1081, 0xa7e58c},
						{  533, 1075, 0xa7e58c},
					}) then
					stommSleep(100)
					stomtap(121,  423)
				end
				stomMultiColorTap("完成",{
					{  205, 1079, 0x4fcb19},
					{  467, 1051, 0x4fcb19},
					{  243, 1045, 0x4fcb19},
				})
				stomMultiColorTap("麦克风",{
					{   74,   67, 0x787878},
					{  265,  997, 0x4fcb19},
					{  369,  977, 0x4fcb19},
				})
				stomMultiColorTap("跳过",{
					{  251,  641, 0xffffff},
					{  233,  495, 0x4fcb19},
					{  409,  501, 0x4fcb19},
					{  391,  661, 0xffffff},
				})
				stomMultiColorTap("暂停",{
					{   58,   59, 0x787878},
					{   58,   69, 0x787878},
					{   73,   70, 0x787878},
					{   74,   61, 0x787878},
				})

				if stomMultiColor("学姐快来",{
					{  313,  917, 0x4fcb19},
					{  155,  881, 0x4fcb19},
					{  495,  875, 0x4fcb19},
				}) or 
				stomMultiColor("添加课程",{
					{   63,  967, 0x4fcb19},
					{  565,  953, 0x4fcb19},
					{  323, 1005, 0x4fcb19},
				}) or stomMultiColor("学姐快来2",{
					{  239,  919, 0x2f7a0f},
					{  139,  881, 0x2f7a0f},
					{  503,  885, 0x2f7a0f},
					{  289,  815, 0x999999},
				})or stomMultiColor("学习",{
					{  144, 1080, 0x4fcb19},
					{  172, 1080, 0x4fcb19},
					{  192, 1080, 0xffffff},
					{  450, 1076, 0xffffff},
				})	then
					stommSleep(5000)
					return 0
				end
				
			
			
			
			
			end
			
			
		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 300 then
			return 1
		end
	end

end
function create_597364850_60()		--英语流利说
	stomLog("create_597364850")
	apple_appid = "597364850"
	local loop = 0
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0

	stomLog(appVersion)
	stomLog(fakeos)
	createpasswd = myRand(4,10,1)
	UserAgent = 'Lingome/'..appVersion..' (iPhone; iOS '..fakeos..'; Scale/2.00)'
	stomLog("getphyylls60ma...")
	damauser,damapasswd = "zk1013","ekcom8888"
	docks1 = "F7E2BEBD74DFCC4"
	conmenttype = "Yingyulls"
	local getpcon = 0
	local num = 0
	while (true) do	
		stomLog("获取号码。。。"..getpcon)
		stomMultiColorTap("开始学习", {
			{  285, 1079, 0x4fcb19},
			{   69, 1041, 0x4fcb19},
			{  553, 1035, 0x4fcb19},
			{  413, 1053, 0x4fcb19},
		})
		if getpcon == 10 then
			local url = "http://119.29.29.29/d?ttl=1&dn=apineo.llsapp.com"
			local status_resp, header_resp ,result = stomhttpGet(url,header_send, body_send)
			if status_resp == 200 then
				--stomLog(result)
				sertb = stomsplit(result,";")
				YYIP = stomtrim(sertb[1])
				getpcon = 0
			end
			
		elseif getpcon == 0 then
			--telnumsection = Randtelnumsection()
			
			check_Rules = 1
			Telnum, ksuid = getTelnum_60ma_st(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
			if Telnum then
				if needcheck == 1 then
					checkcode = CheckYingYuPhonenumber(Telnum)
				else
					checkcode = 0
				end
				if checkcode == 0 then
					stommSleep(3000)
					phonenumber = Telnum
					stomLog(Telnum)
					stomInpuTextTap(244,  350, Telnum, 3)
					getpcon = 1
				elseif checkcode == 1 then
					upContentData(conmenttype,Telnum,ksuid,field2,field3,"notnew")
					freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
				else
					upContentData(conmenttype,Telnum,ksuid,field2,field3,"needcheck")
					freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
					return 1
				end
			else
				stomLog("重新获取号码中")
				ksuidOK = "000"
				stommSleep(2000)
			end
		elseif getpcon == 1 then
			--[[
			if stomColorInRegTap("获取短信", 0x4fcb19, 90, 216, 442, 412, 504) then
				yanzm = yanzm + 1
				stommSleep(1000) 
			else
				if stomMultiColor("注册灰",{
					{  432,  209, 0xf2f2f2},
					{  212,  190, 0xf2f2f2},
					{   99, 1087, 0xd2d5db},
					{  593, 1073, 0xd2d5db},
					{  292,  479, 0xcccccc},
				}) then
					stomLog("输入号码"..phonenumber)
					stommSleep(500) 
					stomInpuTextTap(244,  350, phonenumber, 3)
					stommSleep(500)
				end
			end
			if stomColorInReg("获取", 0x4fcb19, 90, 393, 617, 513, 641) then
				stommSleep(5000)
			end
			if stomMultiColor("需要验证",{
				{117,  683, 0x66d200, 85}, 
				{189,  695, 0xdfe1e2, 85}, 
				{143,  681, 0x66d200, 85},
				{106,  786, 0x7e7e7e, 85}}) or
				stomColorInReg("好", 0x007aff, 90, 261, 605, 371, 653) then
				freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
				upContentData(conmenttype,phonenumber,ksuid,field2,field3,"needcheck")
				return 1
			end
			if yanzm > 10 then
				freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
				upContentData(conmenttype,phonenumber,ksuid,field2,field3,"yanzm10")
				return 1
			end

			if stomMultiColor("输入验证码",{{ 208, 177,0x212121},{ 408, 206,0x212121},{ 137,1091,0xd2d5db},{ 491,1051,0xd2d5db},}) then
				stommSleep(2000)
			end
			]]
			phonenumber = Telnum
			sDeviceId = System.getLLSDeviceId()
			stomLog(sDeviceId)
			if sDeviceId ~= "NoFound" then
				local timestampSec = os.time()
				local s0 = "lingome-app"..timestampSec
				local s1 = stomsha1(s0)
				local s2 = phonenumber..s1
				local sig = stomsha1(s2)
				local smsCodeParams = {
							["mobile"] = phonenumber,
							["timestampSec"] = timestampSec,
							["sig"] = sig
						}
				local body = {
						["clientPlatform"] = "IOS",
						["smsCodeParams"] = smsCodeParams,
						["authFlow"] = "SMS_CODE",
						["isSignup"] = false,
						["deviceId"] = sDeviceId,
						["poolId"] = "lingome-app"
					}
				--stomLog(YYIP)
				url = "https://account.llsapp.com/api/v2/initiate_auth"
				res = ""
				stomLog(url)
				local res = sendYingYuPhonenumber(url,body)
				if res == 0 and yyrestb.session then
					yysession = yyrestb.session
					break
				elseif yyrestb.error_code ~= nil then
					num = 100
				else
					stomLog(Telnum.."失败"..res)
					upContentData(conmenttype,phonenumber,ksuid,field2,field3,"notnew")
					freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
					getpcon = 10
					
				end
			end
			
		end
		num = num + 1
		if num > 100 then
			--stomtoast("获取号码失败", 5)
			stomLog("获取号码失败")
			freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
			return 1
		end
		
		
	end

	stommSleep(1000)
	local fa=0
	while (true) do
		stomLog("获取短信。。。")
		messg = GetSMS_60ma(UserID,UserKey,docks,phonenumber)
		if messg then
			freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
			upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"1")
			break
		else
			stomLog("重新获取短信中"..Telnum)
		end
		fa = fa +1
		if fa > 20 then
			stomLog("获取短信失败")
			freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
			upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"getsms60")
			return 1
		end
		
		
		stommSleep(3000)
	end

	if fa >= 0 then
		--tap(64,  263);mSleep(1000)
		yanzhenma = string.match(messg,"%d+")
		stomLog("yanzhenma="..yanzhenma)
		--inputText(yanzhenma);mSleep(3000)
		local aa = addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
		for i =1 , 40 do
--			if mct({{211,490,0xffffff},
--					{466,513,0x653927},
--					{150,596,0x303030},},"女生男生") then
--				return 0
--			elseif cflag("lv1", 0x1f510a, 90, 20, 760, 599, 1131) or
--			cflag("lv1", 0x4fcb19, 90, 20, 760, 599, 1131) then
--				return 1
--			end
			local body = {
				["isSignup"] = false,
				["clientPlatform"] = "IOS",
				["deviceId"] = sDeviceId,
				["poolId"] = "lingome-app",
				["session"] = yysession,
				["smsResp"]= {
					["mobile"] = phonenumber,
					["code"] = yanzhenma
				},
				["challengeType"] = "SMS_CODE"
			}
			url = "https://account.llsapp.com/api/v2/respond_to_auth_challenge"
			local res = sendYingYuPhonenumber(url,body)
			if res == 0 and yyrestb.authenticationResult then
				authenticationResult = yyrestb.authenticationResult
				yyllstoken = authenticationResult.accessToken
				if authenticationResult.isNewRegister then
					break
				else
					return 1
				end	
				
			end
		end
	end
	
	local body = {}
	body["sDeviceId"]= sDeviceId
	body["appVer"]= "6"
	body["appId"]= "lls"
	body["token"]= yyllstoken
	body["type"]= "first_login"
	body["deviceId"]= sDeviceId
	url = "https://apineo.llsapp.com/api/v1/sessions/callback"
	local res = sendYingYuPhonenumber(url,body)

	local body = {}
	body["sDeviceId"]= sDeviceId
	body["appVer"]= "6"
	body["appChannel"] = "AppStore"
	body["appId"]= "lls"
	body["token"]= yyllstoken
	body["traceName"]= "data_error"
	body["deviceId"]= sDeviceId
	body["uuid"]= idfa
	url = "https://apineo.llsapp.com/api/v1/trace"
	local res = sendYingYuPhonenumber(url,body)

	--url = "https://54.222.153.215/api/v1/reminders/study/tutors?appId=lls&appVer=6&deviceId="..sDeviceId.."&sDeviceId="..sDeviceId.."&token="..yyllstoken
	local body = {}
	body["sDeviceId"]= sDeviceId
	body["appVer"]= "6"
	body["appId"]= "lls"
	body["token"]= yyllstoken
	body["action"]= "register"
	body["deviceId"]= sDeviceId
	body["uuid"]= idfa
	body["appChannel"] = "AppStore"
	url = "https://apineo.llsapp.com/api/personas/uuid"
	local res = sendYingYuPhonenumber(url,body)
	provinceOK = province
	
	
	
	return 0


end
function create_597364850()		--英语流利说
	stomLog("create_597364850")
	apple_appid = "597364850"
	local loop = 0
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	
	stomLog(appVersion)
	stomLog(fakeos)
	createpasswd = myRand(4,10,1)
	UserAgent = 'Lingome/'..appVersion..' (iPhone; iOS '..fakeos..'; Scale/2.00)'
	stomLog("getphyylls60ma...")
	damauser,damapasswd = "zk1013","ekcom8888"
	ksuid = ""
	
	getPhoneType = "dm"
	docks = "16539"
	
	conmenttype = "Yingyulls"
	local loop = 0
	local num = 0
	while (true) do	
		stomLog("Yingyulls="..loop)
		if loop == 10 then
			local url = "http://119.29.29.29/d?ttl=1&dn=apineo.llsapp.com"
			local status_resp, header_resp ,result = stomhttpGet(url,header_send, body_send)
			if status_resp == 200 then
				--stomLog(result)
				sertb = stomsplit(result,";")
				YYIP = stomtrim(sertb[1])
				loop = 0
			end
		elseif loop == 0 then
			check_Rules = 1
			Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
			phonenumber = Telnum
			if Telnum then
				if needcheck == 1 then
					checkcode = CheckYingYuPhonenumber(Telnum)
				else
					checkcode = 0
				end
				if checkcode == 0 then
					stomLog(Telnum)
					stomInpuTextTap(244,  350, Telnum, 3)
					t1 = os.time()
					loop = 1
				elseif checkcode == 1 then
					upContentData(conmenttype,Telnum,ksuid,field2,field3,"notnew")
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
				else
					upContentData(conmenttype,Telnum,ksuid,field2,field3,"needcheck")
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					return 1
				end
			else
				stomLog("重新获取号码中")
				ksuidOK = "000"
				stommSleep(5000)
			end
			num = num + 1
			if num > 50 then
				--stomtoast("获取号码失败", 5)
				stomLog("获取号码失败")
				stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
				return 10
			end
			stommSleep(3000)
		elseif loop == 1 then
			phonenumber = Telnum
			sDeviceId = System.getLLSDeviceId()
			stomLog(sDeviceId)
			if sDeviceId ~= "NoFound" then
				local timestampSec = os.time()
				local s0 = "lingome-app"..timestampSec
				local s1 = stomsha1(s0)
				local s2 = phonenumber..s1
				local sig = stomsha1(s2)
				local smsCodeParams = {
					["mobile"] = phonenumber,
					["timestampSec"] = timestampSec,
					["sig"] = sig
				}
				local body = {
					["clientPlatform"] = "IOS",
					["smsCodeParams"] = smsCodeParams,
					["authFlow"] = "SMS_CODE",
					["isSignup"] = false,
					["deviceId"] = sDeviceId,
					["poolId"] = "lingome-app"
				}
				--stomLog(YYIP)
				url = "https://account.llsapp.com/api/v2/initiate_auth"
				res = ""
				stomLog(url)
				local res = sendYingYuPhonenumber(url,body)
				if res == 0 and yyrestb.session then
					yysession = yyrestb.session
					loop = 2
				elseif yyrestb.error_code ~= nil then
					num = 100
				else
					stomLog(Telnum.."失败"..res)
					upContentData(conmenttype,phonenumber,ksuid,field2,field3,"notnew")
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					loop = 10
				end
			end
		elseif loop == 2 then	
			stomLog("获取短信。。。")
			messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
			if messg then
				--stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
				upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"1")
				loop = 3
			else
				stomLog("重新获取短信中"..Telnum)
			end
			fa = fa +1
			if fa > 20 then
				stomLog("获取短信失败")
				stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
				stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
				upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"getsms60")
				return 1
			end
			stommSleep(5000)

		elseif loop == 3 then
			yanzhenma = string.match(messg,"%d+")
			stomLog("yanzhenma="..yanzhenma)
			local body = {
				["isSignup"] = false,
				["clientPlatform"] = "IOS",
				["deviceId"] = sDeviceId,
				["poolId"] = "lingome-app",
				["session"] = yysession,
				["smsResp"]= {
					["mobile"] = phonenumber,
					["code"] = yanzhenma
				},
				["challengeType"] = "SMS_CODE"
			}
			url = "https://account.llsapp.com/api/v2/respond_to_auth_challenge"
			local res = sendYingYuPhonenumber(url,body)
			if res == 0 and yyrestb.authenticationResult then
				authenticationResult = yyrestb.authenticationResult
				yyllstoken = authenticationResult.accessToken
				if authenticationResult.isNewRegister then
					loop = 4
				else
					upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"notnew")
				end	
			end
		elseif loop == 4 then
			local body = {}
			body["sDeviceId"]= sDeviceId
			body["appVer"]= "6"
			body["appId"]= "lls"
			body["token"]= yyllstoken
			body["type"]= "first_login"
			body["deviceId"]= sDeviceId
			url = "https://apineo.llsapp.com/api/v1/sessions/callback"
			local res = sendYingYuPhonenumber(url,body)

			local body = {}
			body["sDeviceId"]= sDeviceId
			body["appVer"]= "6"
			body["appChannel"] = "AppStore"
			body["appId"]= "lls"
			body["token"]= yyllstoken
			body["traceName"]= "data_error"
			body["deviceId"]= sDeviceId
			body["uuid"]= idfa
			url = "https://apineo.llsapp.com/api/v1/trace"
			local res = sendYingYuPhonenumber(url,body)

			--url = "https://54.222.153.215/api/v1/reminders/study/tutors?appId=lls&appVer=6&deviceId="..sDeviceId.."&sDeviceId="..sDeviceId.."&token="..yyllstoken
			local body = {}
			body["sDeviceId"]= sDeviceId
			body["appVer"]= "6"
			body["appId"]= "lls"
			body["token"]= yyllstoken
			body["action"]= "register"
			body["deviceId"]= sDeviceId
			body["uuid"]= idfa
			body["appChannel"] = "AppStore"
			url = "https://apineo.llsapp.com/api/personas/uuid"
			local res = sendYingYuPhonenumber(url,body)
			provinceOK = province
			return 0
		end
		
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 300 then
			return 1
		end

	end


end
function randusername()
	a = myRand(4,math.random(6,8),2)
	b = Rnd_Word(zf["姓氏"],1,1)
	c = Rnd_Word(zf["名字"],math.random(1,2),math.random(1,2))
	nn={a..b,a.."_"..c,b..a, b..c,c.."_"..a}
	return nn[math.random(1,#nn)]
end
function create_507097717()		--阿里巴巴
	apple_appid = "507097717"
	conmenttype = "1688"
	local loop = 0
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	mimacunt = 0
	namecunt = 0
	while (true) do
		stomLog("createAliBaba--"..loop)
		stommSleep(500);
		stomMultiColorTap("关闭翻牌",{
			{  556,   86, 0xfefefe},
			{  157,  757, 0x6a301c},
			{  369,  751, 0x6b2d1b},
			{  571,  757, 0x6c2f1b},
		})
		if loop == 0 then
			--stomsnapshotfull("Documents/main.png")
			stomMultiColorTap("我的白",{
				{  575, 1079, 0x333333},
				{  570, 1079, 0x333333},
				{  539, 1081, 0xffffff},
				{  197, 1070, 0x333333},
			})
			stomMultiColorTap("不允许", {
				{  151,  742, 0xffffff},
				{   43,  373, 0xff5000},
				{  557,  369, 0xff7a13},
				{  205,  455, 0xff8742},
			})
			stomMultiColorTap("立即领取", {
				{  235,  831, 0xf5dacd},
				{  409,  817, 0xeec1ae},
				{  157,  775, 0xe26262},
				{  507,  789, 0xc44043},
			})
			stomMultiColorTap("我的",{
				{  575, 1078, 0x333333},
				{   65, 1077, 0xff6601},
				{   65, 1111, 0xff5000},
				{  330, 1071, 0x333333},
			})
			stomMultiColorTap("快速注册",{
				{  221,  866, 0xffffff},
				{  129,  739, 0xc3c3c3},
				{  517,  797, 0xc3c3c3},
				{  331,  209, 0xbda07d},
				{  401,  137, 0x060814},
			})
			stomMultiColorTap("快速注册2",{
				{  443,  717, 0x333333},
				{   49,  537, 0xff9622},
				{  579,  595, 0xff5901},
				{  347,  269, 0xff5900},
				{  309,  441, 0xffffff},
			})
			stomMultiColorTap("快速注册3",{
				{  475,  828, 0x333333},
				{   61,  633, 0xff9622},
				{  587,  725, 0xff5802},
				{  209,  313, 0xff5800},
				{  431,  307, 0xfe5900},
			})
			stomMultiColorTap("个人账户",{
				{  301,  812, 0x007aff},
				{  301,  927, 0x007aff},
				{  285, 1060, 0x007aff},
				{  271,  223, 0x0a0c13},
				{  319,  213, 0x74624c},
			})
			stomMultiColorTap("开",{
				{  303,  775, 0xf0c1b1},
				{  359,  421, 0xff4801},
				{  149,  321, 0xf87775},
			})
			if stomMultiColor("准备输入号码",{
				{  170,  260, 0xffffff},
				{   69,  629, 0xff7300},
				{  591,  675, 0xff7300},
				{  315,  652, 0xff9640},
			}) then
				loop = 1
				
			end
		elseif loop == 1 then
			stomLog("获取号码。。。"..getloop)
			if getloop == 0 then
				check_Rules = 1
				Telnum, ksuid = getTelnum_60ma_st(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
				if Telnum then
					stomLog(Telnum)
					getloop = 1
					num = 0
				else
					stomLog("重新获取号码中")
					stommSleep(2000)
					num = num + 1
				end
				if num > 20 then
					stomLog("获取号码失败")
					--addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
					--freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
					return 1
				end
			elseif getloop == 1 then
				phonenumber = Telnum
				if stomMultiColorTap("下一步OK",{
						{  319,  656, 0xff7300},
						{   37,  615, 0xff7300},
						{  170,  264, 0x000000},
						{  170,  272, 0x000000},
					}) or 
					stomMultiColorTap("获取按钮OK2",{
						{  253,  473, 0x4fcb19},
						{  362,  460, 0x4fcb19},
						{  240,  341, 0x212121},
						{  235,  361, 0xffffff},
					}) then
					yanzm = yanzm + 1
					stommSleep(500) 
				else
					if stomMultiColor("准备输入号码",{
						{  170,  260, 0xffffff},
						{   69,  629, 0xff7300},
						{  591,  675, 0xff7300},
						{  315,  652, 0xff9640},
					}) then
						stomLog("输入号码"..phonenumber)
						stommSleep(500) 
						stomInpuTextTap(169,  263, phonenumber, 3)
						stommSleep(500)
					end
				end
				if yanzm > 10 then
					stomLog("获取按钮OK次数过多")
					return 1
				end
				
				if stomMultiColor("需要验证",{
						{   81,  341, 0xffffff},
						{  595,  305, 0xdddddd},
						{  163,  385, 0xdddddd},
						{   71,  196, 0x333333},
					}) then
					mSleep(1000)
					moveToMulti222(69,  357, 607,  341)
					--stommoveTo(69,  357, 607,  341)
					mSleep(3000)
				end

				if stomMultiColor("验证码框xe",{
						{  351,  460, 0xffa286},
						{   33,  417, 0xff4400},
						{  613,  503, 0xff4400},
						{  329,  337, 0xffffff},
					}) or 
					stomMultiColor("验证码框xe2",{
						{  187,  327, 0x051b28},
						{   57,  517, 0xff4400},
						{  581,  601, 0xff4400},
						{  188,  353, 0x051b28},
					})then
					getloop = 2
				end
				if stomMultiColorTap("刷新",{
						{  135,  489, 0x999999},
						{  451,  498, 0x999999},
						{  319,  493, 0xcccccc},
						{  471,  633, 0xa7a7a7},
					}) then
					stommSleep(5000)
				end
			elseif getloop == 2 then
				stomLog("获取短信...")
				stommSleep(3000)
				
--				stomMultiColorTap("获取按钮OK2",{
--					{  253,  473, 0x4fcb19},
--					{  362,  460, 0x4fcb19},
--					{  240,  341, 0x212121},
--					{  235,  361, 0xffffff},
--				})
				
				if messg then
					messg = string.gsub(messg,"30分","")
					messg = string.sub(messg,9)
					yanzhenma = string.match(messg,"%d+")
					stomLog("yanzhenmaOK="..yanzhenma)
					--stomInpuTextTap(173,  333, yanzhenma,2);mSleep(1000)
					addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
					freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
					getloop = 901
					--[[
					yanzhenmalist = stringToList(yanzhenma)
					isnext = 0
					for i =1, 4 do
						if i == 4 then
							isnext = 1
						end
						stomInpuTextTap(86+(150*(i-1)),  419, yanzhenmalist[i], isnext);mSleep(1000)
					end
					]]
					
				else
					stomLog("get sms")
					messg = GetSMS_60ma(UserID,UserKey,docks,phonenumber)
					fa = fa +1
				end	
				if fa > 20 then
					stomLog("获取短信失败")
					upContentData(conmenttype,Telnum,ksuid,field2,field3,"nosms")
					addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
					freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
					return 1
				end
				
			elseif getloop == 901 then
				stomLog("yanzhenmaOK="..yanzhenma)
				stomMultiColorTap("已输入验证码",{
						{  313,  483, 0xff4400},
						{   57,  429, 0xff4400},
						{  343,  321, 0xcccccc},
						{  343,  351, 0xcccccc},
						{  603,  501, 0xff4400},
					})
				if stomMultiColorTap("设置密码",{
						{  133,  583, 0xff4400},
						{  605,  669, 0xff4400},
						{  517,  203, 0xff5000},
					}) then
					loop = 2
				else
					stomColorInRegTap("完成", 0x007aff, 90, 555, 531, 623, 645)
					if stomMultiColor("k2",{
							{   61,  509, 0xff4400},
							{  599,  602, 0xff4400},
							{  159,  390, 0xffffff},
						}) then
						k2num = 100
						stomInpuTextTap(173,  333+k2num, yanzhenma,4)
						stommSleep(1000)
					end
					if stomMultiColor("k1",{
							{   54,  416, 0xff4400},
							{  595,  508, 0xff4400},
							{  187,  234, 0x051b28},
						}) then
						k2num = 0
						stomInpuTextTap(173,  333+k2num, yanzhenma,4)
						stommSleep(1000)
					end
				end
				
				if stomMultiColor("立即登录",{
						{   65,  619, 0xff4400},
						{  329,  691, 0xff4400},
						{  599,  617, 0xff4400},
						{  323,  265, 0xed7a2f},
					}) then
					upContentData(conmenttype,phonenumber,ksuid,field2,field3,"notnew")
					return 1
				end
				if stomMultiColor("支付宝",{
					{  273,  249, 0x1296dc},
					{  327,  327, 0x1496da},
					{  329,  289, 0xeeeeee},
				}) then
					upContentData(conmenttype,phonenumber,ksuid,field2,field3,"notnew")
					return 1
				end
			end
		elseif loop == 2 then
			if stomColorInRegTap("完成", 0x007aff, 90, 555, 531, 623, 645) then
				stommSleep(3000)
			else
				stomLog("no完成")
				if mimacunt == 1 and namecunt == 1 then
					loop = 3
					upContentData(conmenttype,Telnum,ksuid,field2,field3,"1")
					t1 = os.time()
				end
				createpasswd = myRand(4,15,1)
				username1688 = randusername()
				stomLog(createpasswd)
				stomLog(username1688)
				if mimacunt == 0 then
					if stomColorInRegTap("完成", 0x007aff, 90, 555, 531, 623, 645) then
						stommSleep(1000)
					else
						if stomMultiColorReg("密码OK",0xff5000, "4|47|0xff5000,41|25|0x999999,-318|23|0x333333,-297|23|0x333333", 90, 187, 119, 615, 279) then
							mimacunt = 1
						else	
							stomLog("输密码")
							stomInpuTextTap(219,  201, createpasswd,4)
							stommSleep(1000)
							stomColorInRegTap("完成", 0x007aff, 90, 555, 531, 623, 645)
							--mimacunt = 1
						end
					end
				end
				
				if namecunt == 0 then
					if stomColorInRegTap("完成", 0x007aff, 90, 555, 531, 623, 645) then
						stommSleep(1000)
					else
						if stomColorInReg("nameOK", 0x333333, 90, 165, 335, 247, 407) then
							namecunt = 1
						else
							stomLog("输name")
							stomInpuTextTap(185,  379, username1688,4)
							stommSleep(1000)
							stomColorInRegTap("完成", 0x007aff, 90, 555, 531, 623, 645)
							--namecunt = 1
						end
					end
				end
			end
		elseif loop == 3 then
			stomColorInRegTap("完成", 0x007aff, 90, 555, 531, 623, 645)
			stomMultiColorTap("确定",{
				{  177,  609, 0xff4400},
				{  579,  627, 0xff4400},
				{  335,  583, 0xff4400},
				{  317,  671, 0xff4400},
				{  515,  199, 0xff5000},
			})
			mSleep(300)
			stomMultiColorTap("tongyijihuo",{
				{   97,  351, 0xff4400},
				{  591,  415, 0xff4400},
				{  315,  353, 0xff4400},
			})
			stomColorInRegTap("确定2",0x157dfc, 90, 99, 635, 255, 861)
			stomMultiColorTap("知道了",{
				{  339,  857, 0xf0c4b3},
				{  471,  789, 0xc93f42},
				{  487,  485, 0xd2494a},
				{  527,  207, 0x23120f},
			})
			stomMultiColorTap("我的白",{
				{  575, 1079, 0x333333},
				{  570, 1079, 0x333333},
				{  539, 1081, 0xffffff},
				{  197, 1070, 0x333333},
			})
			stomMultiColorTap("返回",{
				{   41,   83, 0x999999},
				{   67, 1071, 0xff5e00},
				{   94, 1089, 0xff6000},
				{  617,  137, 0xe4cab5},
			})
			if stomMultiColor("我的红",{
				{  581, 1087, 0xff4000},
				{  575, 1087, 0xff4a00},
				{   84,  171, 0xffd8c5},
				{  579,   87, 0xff3a00},
				{  199, 1070, 0x333333},
			}) then
				main1path="Documents/"..idfa.."-1.PNG"
				stomsnapshotfull(main1path)
				loop = 4
			end
		elseif loop == 4 then
			stomMultiColorTap("huiyuan",{
				{   85,  175, 0xffd9c0},
				{  497,  137, 0xdf3500},
				{  571, 1095, 0xff4a00},
				{  533, 1085, 0xffffff},
			})
			if stomMultiColor("huiyuanzx",{
				{  545,  171, 0xd33302},
				{  567,  345, 0xe85503},
				{  473,  297, 0xfe7d25},
				{  477,  589, 0xf3f3f4},
				{  362,  689, 0xe14011},
			}) then
				main2path="Documents/"..idfa.."-2.PNG"
				stomsnapshotfull(main2path)
				loop = 5
			end
		elseif loop == 5 then	
			stommSleep(500)
			url = "https://api.ojbknet.com/api/postfile.php?appid="..apple_appid..os.date("%Y%m%d",os.time())
			stomLog(postImage(url,main1path))
			stommSleep(500)
			stomLog(postImage(url,main2path))
			return 0
			
		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 300 then
			return 1
		end
	end

end
function create_1153192044()		--雅思流利说-注册
	stomLog("createYaSills")
	apple_appid = "1153192044"
	local loop = 0
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	local mimaok = 0
	local nichengok = 0
	local needcheck = 1
	createpasswd = myRand(4,math.random(8,12),1)
	createnickname = myRand(4,math.random(8,12),1)
	getPhoneType = "dm"
	docks = "16539"
	stomLog("createYaSills")
	while (true) do
		stomLog("createYaSills--"..loop)
		stommSleep(500);
		if loop == 0 then
			if stomMultiColor("注册灰yslls",{
				{  143,  623, 0x9ba3a7},
				{  399,  631, 0x9ba3a7},
				{  583,  183, 0x37474f},
				{  215,   97, 0x455a64},
			}) then
				loop = 1
			end
		elseif loop == 1 then
			stomLog("获取号码。。。"..getloop)
			if getloop == 0 then
				check_Rules = 1
				Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
				if Telnum then
					if needcheck == 1 then
						checkcode = CheckYingYuPhonenumber(Telnum)
					else
						checkcode = 0
					end
					if checkcode == 0 then
						stomLog(Telnum)
						t1 = os.time()
						getloop = 1
					elseif checkcode == 1 then
						upContentData(conmenttype,Telnum,ksuid,field2,field3,"notnew")
						stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
						stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
					else
						upContentData(conmenttype,Telnum,ksuid,field2,field3,"needcheck")
						stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
						return 1
					end
					
				else
					stomLog("重新获取号码中")
					stommSleep(2000)
					num = num + 1
				end
				if num > 20 then
					stomLog("获取号码失败")
					return 1
				end
			elseif getloop == 1 then
				phonenumber = Telnum
				if stomMultiColorTap("获取短信",{
						{  487,  311, 0xffffff},
						{  549,  261, 0xffffff},
						{  276,  169, 0xffffff},
						{  467,   97, 0x455a64},
						{  575,  193, 0x37474f},
					}) then
					yanzm = yanzm + 1
					stommSleep(500) 
				else
					if stomMultiColor("注册灰yslls",{
						{  143,  623, 0x9ba3a7},
						{  399,  631, 0x9ba3a7},
						{  583,  183, 0x37474f},
						{  215,   97, 0x455a64},
					}) then
						stomLog("输入号码"..phonenumber)
						stommSleep(500) 
						stomInpuTextTap(281,  177, phonenumber, 3)
						stommSleep(500)
					end
				end
				
				if stomMultiColor("正在获取yslls",{
						{  525,  265, 0x5f6c72},
						{  145,  621, 0x9ba3a7},
						{  555,  671, 0x9ba3a7},
						{  591,  301, 0x5f6c72},
					}) then
					getloop = 101
					
				end
			elseif getloop == 101 then
				stomMultiColorTap("获取短信",{
					{  487,  311, 0xffffff},
					{  549,  261, 0xffffff},
					{  276,  169, 0xffffff},
					{  467,   97, 0x455a64},
					{  575,  193, 0x37474f},
				})
				if stomMultiColor("密码OK", {
						{  139,  386, 0xffffff},
						{  147,  411, 0x37474f},
					}) then
					mimaok = 1
				else
					stomLog("输入密码"..createpasswd)
					stommSleep(500) 
					stomInpuTextTap(113,  389, createpasswd, 1)
					stommSleep(1000)
				end
				if stomColorInReg("昵称OK", 0xffffff, 90, 127, 475, 211, 511) then
					nichengok = 1
				else
					stomLog("输入昵称"..createnickname)
					stommSleep(500) 
					stomInpuTextTap(117,  489, createnickname, 3)
					stommSleep(1000)
				end
				
				if mimaok == 1 and nichengok == 1 then
					getloop = 2
				end
			elseif getloop == 2 then
				stomLog("获取短信...")
				--[[
				stomMultiColorTap("获取按钮OK",{
						{  253,  473, 0x4fcb19},
						{  362,  460, 0x4fcb19},
						{  177,  336, 0x212121},
						{  171,  361, 0xffffff},
					})]]
				if stomMultiColorTap("注册红",{
						{  319,  615, 0xe8524f},
						{   93,  603, 0xe8524f},
						{  583,  609, 0xe8524f},
						{  587,  573, 0x37474f},
						{  535,  179, 0x37474f},
					}) then
				mSleep(5000)
					loop = 3
				end
				messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
				if messg then
					--messg = string.gsub(messg,"30分","")
					messg = string.sub(messg,9)
					yanzhenma = string.match(messg,"%d+")
					stomLog("yanzhenmaOK="..yanzhenma)
					stomInpuTextTap(109,  279, yanzhenma,2);mSleep(1000)
					
				else
					stomLog("get sms")
					fa = fa +1
				end	
				if fa > 30 then
					stomLog("获取短信失败")
					stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					return 1
				end
				stommSleep(500)
			end	
		elseif loop == 3 then
			stomMultiColorTap("我的", {
				{  533, 1089, 0xffffff},
				{   86, 1087, 0xe8524f},
				{  123, 1087, 0xe8524f},
				{   59,  105, 0x445560},
			})
			if stomMultiColorTap("登录", {
					{  317,  211, 0xebebeb},
					{  319,  291, 0xebebeb},
					{  531, 1063, 0xe8524f},
					{  529, 1093, 0xe8524f},
				}) then
				stommSleep(1000)
			end
			stomMultiColorTap("注册红",{
				{  319,  615, 0xe8524f},
				{   93,  603, 0xe8524f},
				{  583,  609, 0xe8524f},
				{  587,  573, 0x37474f},
				{  535,  179, 0x37474f},
			})
			if stomMultiColor("退出登录",{
					{  325,  819, 0xe8524f},
					{  115,  767, 0xe8524f},
					{  545,  769, 0xe8524f},
					{  189,  177, 0xefeff5},
				}) then
				provinceOK = province
				ksuidOK = ksuid
				mSleep(5000)
				return 0
			end
			if stomMultiColor("注册灰yslls",{
					{  143,  623, 0x9ba3a7},
					{  399,  631, 0x9ba3a7},
					{  583,  183, 0x37474f},
					{  215,   97, 0x455a64},
				}) then
				return 1
			end

		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 300 then
			return 1
		end
	end

end

function create_901858272()								--克鲁赛德战记
	apple_appid = "901858272"
	local loop = 0
	local t1 = os.time()
	local name = myRand(4,math.random(6,9),1)
	while (true) do
		logR,logG, logB = getColorRGB(456,  501)
		stomLog(logR..","..logG..","..logB.."--com.nhnent.SKQUEST--"..loop)
		stommSleep(500);
		stomMultiColorTap("点击开始游戏",{
			{   80,  547, 0xdfbbb3},
			{   65,  552, 0x9a6053},
			{   14,  536, 0xf1dacc},
			{   32,  642, 0x864a45},
		})
		if loop == 0 then
			stomMultiColorTap("Game Center",   {
				{  603,   65, 0x5856d6},
				{  481,  533, 0xfc3587},
				{  433,  582, 0xa720eb},
				{  460,  633, 0x07b1ff},
				{  604,  583, 0x000000},
			})
			stomMultiColorTap("GEUST",{
				{  266,  558, 0xd2c59b},
				{  296,  561, 0xff9933},
				{  359,  567, 0x44ccee},
				{  374,  850, 0x332c0d},
			})
			
			stomMultiColorTap("警告游客身份",{
				{  150,  708, 0x48c8e4},
				{  157,  550, 0xfe7e4d},
				{  157,  557, 0xb8390c},
				{  355,  557, 0xeeeedd},
				{  388,  567, 0xee4422},
			})
			stomMultiColorTap("下载数据",{
				{  137,  679, 0x48c8e4},
				{  132,  550, 0xfe7e4d},
				{  135,  557, 0xb8390c},
				{  512,  515, 0xd2b442},
			})
			stomMultiColorTap("小视频",{
				{  546,   72, 0x9b9ca0},
				{   55,  161, 0xdedee1},
				{   59,  960, 0x4d4f56},
				{  547, 1056, 0xa9acb1},
			})
			stomMultiColorTap("下载语音",{
				{  145,  544, 0xfe7e4d},
				{  154,  557, 0xb8390c},
				{  154,  588, 0x48c8e4},
				{  486,  522, 0xd4b643},
				{  467,  616, 0xd4b643},
			})
			stomMultiColorTap("语音下载失败",{
				{  174,  571, 0x48c8e4},
				{  140,  594, 0x428087},
				{  484,  556, 0xd4b643},
				{  176,  662, 0x2da3be},
			})
			if stomMultiColor("跳过",{
				{  604,  947, 0x776655},
				{  604, 1101, 0x776655},
				{  602,  858, 0x000000},
				{  612,  836, 0xddcc99},
				{  616,  836, 0xffeedd},
			}) then
				loop = 1
			end
		elseif loop == 1 then
			stomLog("游戏引导。。。")
			stomMultiColorTap("跳过",{
				{  604,  947, 0x776655},
				{  604, 1101, 0x776655},
				{  602,  858, 0x000000},
				{  612,  836, 0xddcc99},
				{  616,  836, 0xffeedd},
			})
			stomMultiColorTap("蕾德那斯",{
				{  410,  291, 0xffeeaa},
				{  503,  311, 0xffee77},
				{  235,  169, 0x112244},
				{  201,  308, 0x776666},
			})
			if stomMultiColor("签订契约书",{
				{  323,  484, 0x443322},
				{  297,  497, 0x665544},
				{  287,  497, 0xccbb99},
				{  207,  494, 0x999988},
				{  504,  522, 0x3c3324},
			})then
				loop = 2 
			end
			stomMultiColorRegTap("下白手指",0xffffff, "-3|-5|0xddcccc,-3|-8|0x999988,18|-8|0x887777,35|-39|0x999988", 90, 0, 0, 639, 1135)
			stomMultiColorRegTap("剑技能", 0x001111, "3|-5|0x117788,-9|-12|0xffffaa,-11|-20|0x663333,-35|-11|0x003344,-40|-9|0x663333", 90, 6, 8, 121, 1085)
			stomMultiColorRegTap("枪技能",0xffffaa, "5|-9|0x44cc55,4|26|0x117788,16|58|0xcc6622,-22|26|0xffcc66", 90, 6, 8, 121, 1085)
			stomMultiColorRegTap("光技能",0xffffee, "12|0|0x33ffff,4|-29|0x0044ff,-16|-48|0xffff77,-29|-32|0x1188ff", 90, 6, 8, 121, 1085)
		elseif loop == 2 then
			stomLog("输入名字。。。")
			if stomMultiColorTap("签订契约书",{
				{  323,  484, 0x443322},
				{  297,  497, 0x665544},
				{  287,  497, 0xccbb99},
				{  207,  494, 0x999988},
				{  504,  522, 0x3c3324},
			})then
				stomLog("输入昵称"..name)
				stommSleep(500) 
				stomInpuTextTap(117,  489, name, 3)
				stommSleep(1000)
				
			end
			if stomMultiColorTap("签订确定",{
				{  190,  529, 0x44ccee},
				{  171,  583, 0x40828d},
				{  147,  566, 0xa3967a},
				{  307,  573, 0x443322},
			})then
				loop = 3
			end
		
		elseif loop == 3 then
			stomLog("开始游戏。。。")
			stomMultiColorRegTap("下白手指",0xffffff, "-3|-5|0xddcccc,-3|-8|0x999988,18|-8|0x887777,35|-39|0x999988", 90, 0, 0, 639, 1135)
			stomMultiColorRegTap("剑技能", 0x001111, "3|-5|0x117788,-9|-12|0xffffaa,-11|-20|0x663333,-35|-11|0x003344,-40|-9|0x663333", 90, 6, 8, 121, 1085)
			stomMultiColorRegTap("枪技能",0xffffaa, "5|-9|0x44cc55,4|26|0x117788,16|58|0xcc6622,-22|26|0xffcc66", 90, 6, 8, 121, 1085)
			stomMultiColorRegTap("光技能",0xffffee, "12|0|0x33ffff,4|-29|0x0044ff,-16|-48|0xffff77,-29|-32|0x1188ff", 90, 6, 8, 121, 1085)
			
		end
		t2 = os.time()
		if os.difftime(t2,t1) > 600 then
			return 1
		end
	end
end

function create_515199321()		--高铁管家-注册
	apple_appid = "515199321"
	local loop = 0
	local t1 = os.time()
	local getloop = 0
	local xiago = 0
	local num = 0
	local fa = 0
	getPhoneType = "dm"
	docks = "11842"
	while (true) do
		stomLog("--com.openet.gtgj--"..loop)
		stommSleep(500);
		if loop == 0 then
			stomMultiColorTap("我的11", {
				{  575, 1071, 0xffffff},
				{  593, 1063, 0xff8000},
				{   63, 1083, 0x499efc},
				{  411,   82, 0x4889db},
				{  372,   77, 0x333333},
			})
			stomMultiColorTap("注册11", {
				{   98,  173, 0xc4cedb},
				{  135,  177, 0xdbe2ea},
				{  214,  181, 0x000000},
				{  575, 1071, 0x499efc},
				{   65, 1084, 0xffffff},
			})
			stomMultiColorTap("注册11.1",{
				{  139,  290, 0x469cfe},
				{  576, 1071, 0x489efc},
				{  218,  290, 0x2e93ff},
				{   75,  532, 0xfae8c4},
				{   65,  525, 0xfffbf5},
			})
			stomMultiColorTap("号码注册", {
				{  164,  358, 0xffffff},
				{   57,  381, 0x7bb2f8},
				{   40,  482, 0x6ed851},
				{  111,  201, 0x000000},
			})
			if stomMultiColor("号码框11",{
				{   72,  359, 0xffffff},
				{  111,  200, 0x000000},
				{  257,  622, 0xd8d8d8},
				{  605,  621, 0xd8d8d8},
				{  461,  200, 0x000000},
			}) then
				loop = 1
			end
		elseif loop == 1 then
			stomLog("获取号码。。。"..getloop)
			if getloop == 0 then
				check_Rules = 1
				Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
				if Telnum then
					stomLog(Telnum)
					getloop = 1
					num = 0
				else
					stomLog("重新获取号码中")
					stommSleep(2000)
					num = num + 1
				end
				if num > 20 then
					stomLog("获取号码失败")
					return 1
				end
			elseif getloop == 1 then
				phonenumber = Telnum
				if stomMultiColorTap("下一步",{
					{  428,  643, 0x4889db},
					{  464,  619, 0xffffff},
					{  574,  357, 0xcccccc},
					{   43,  352, 0x000000},
				}) then
					xiago = xiago + 1
					stommSleep(1000)
				else
					if stomMultiColor("号码框11",{
						{   72,  359, 0xffffff},
						{  111,  200, 0x000000},
						{  257,  622, 0xd8d8d8},
						{  605,  621, 0xd8d8d8},
						{  461,  200, 0x000000},
					}) then
						stomLog("输入号码"..phonenumber)
						stommSleep(500) 
						stomInpuTextTap(99,  357, phonenumber, 3)
						stommSleep(500)
					end
				end	
				if xiago > 5 then
					stomLog("下一步卡点或网络问题")
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					return 1
				end
				stomMultiColorTap("底部下一步",{
					{  426, 1083, 0x4889db},
					{  463, 1051, 0xffffff},
					{   43,  350, 0x000000},
					{  607, 1054, 0x4889db},
				})
				if stomMultiColor("验证码框",{
					{   52,  469, 0xffffff},
					{   56,  503, 0xd7d7d7},
					{  503,  192, 0x000000},
					{  602,  623, 0xffffff},
				}) then
					getloop = 2
					
				end
			
			elseif getloop == 2 then
				stomLog("获取短信...")
				messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
				if messg then
					messg = string.gsub(messg,"30分","")
					messg = string.sub(messg,9)
					yanzhenma = string.match(messg,"%d+")
					stomLog("yanzhenmaOK-"..yanzhenma)
					stomInpuTextTap(52,  469, yanzhenma,3);mSleep(1000)
					
				else
					stomLog("get sms")
					fa = fa +1
				end	
				if fa > 30 then
					stomLog("获取短信失败")
					stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					return 1
				end
				stommSleep(500)
			end	
			
			if stomMultiColor("普通会员", {
				{   79,  190, 0xc4cedb},
				{  111,  185, 0xdbe2ea},
				{  170,  176, 0x333333},
				{  576, 1071, 0x489efc},
				{   84,  457, 0x95aacd},
			}) then
				provinceOK = province
				ksuidOK = ksuid
				mSleep(5000)
				return 0
			end

		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 300 then
			return 1
		end
	end

end
function create_1329364068()		--微课传奇
	apple_appid = "1329364068"
	local loop = 0
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	createpasswd = myRand(4,10,1)
	username1688 = randusername()
	appversion = "4.0.9"
	YYIP = "www.wkcq365.com"
	UserAgent = 'GYThinkingEducation/'..appversion..' (iPhone; iOS '..fakeos..'; Scale/2.00)'
	stomLog("getphyylls60ma...")
	damauser,damapasswd = "zk1013","ekcom8888"
	docks1 = "F7E2BEBD74DFCC4"

	local getpcon = 0
	local num = 0

	while (true) do	
		stomLog("获取号码。。。"..getpcon)
		if getpcon == 0 then
			--telnumsection = Randtelnumsection()
			check_Rules = 1
			Telnum, ksuid = getTelnum_60ma_st(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
			if Telnum then
				stomLog(Telnum)
				getpcon = 1
			else
				stomLog("重新获取号码中")
				ksuidOK = "000"
				stommSleep(2000)
			end
		elseif getpcon == 1 then
			phonenumber = Telnum
			local clientTime = os.time()..math.random(100,999)
			local signstr = strtomd5("IOSclientTime="..clientTime.."9e615c8a150a21f44a0eac71d82e19f20c1a49ff")
			local body = {}
			body["caller"]= "IOS"
			body["sign"]= signstr
			body["clientTime"]= clientTime
			body["data"]= {['type']=1,['mobile']=phonenumber,['mobileZone']="86"}
			body["mobile"]= phonenumber
			body["version"]= appversion
			url = "https://"..YYIP.."/api/mobileCode/sendNoReg"
			res = ""
			local res = sendWeiKeChuanQi(url,body)
			if res == 0 and yyrestb.code == "200000" then
				break
			elseif res == 0  and yyrestb.code == '300000' then
				num = 100
			else
				freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
				getpcon = 10
				
			end
			
		end
		num = num + 1
		if num > 100 then
			stomLog("获取号码失败")
			freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
			return 1
		end
		
	end

	mSleep(1000)
	local fa=0
	while (true) do
		stomLog("获取短信。。。")
		messg = GetSMS_60ma(UserID,UserKey,docks,phonenumber)
		if messg then
			freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
			break
		else
			stomLog("重新获取短信中"..Telnum)
		end
		fa = fa +1
		if fa > 15 then
			stomLog("获取短信失败")
			freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
			return 1
		end
		
		
		mSleep(3000)
	end

	if fa >= 0 then
		--tap(64,  263);mSleep(1000)
		messg = string.gsub(messg,"5分","")
		messg = string.sub(messg,9)
		yanzhenma = string.match(messg,"%d+")
		--inputText(yanzhenma);mSleep(3000)
		local aa = addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
		for i =1 , 3 do
			local clientTime = os.time()..math.random(100,999)
			local signstr = strtomd5("IOSclientTime="..clientTime.."9e615c8a150a21f44a0eac71d82e19f20c1a49ff")
			local body = {}
			body["caller"]= "IOS"
			body["sign"]= signstr
			body["clientTime"]= clientTime
			body["data"]= {
					['mobile']=phonenumber,
					['mac'] = "02:00:00:00:00:00",
					['code']= yanzhenma,
					['mobileZone']="86",
					['ifa'] = idfa,
					['registerChannel'] = "app_store",
					['devicesn']="",
					['pwd']=strtomd5(createpasswd)
				}
			body["version"] = appversion
			url = "https://"..YYIP.."/api/user/mobile/registerV4"
			local res = sendWeiKeChuanQi(url,body)
			if res == 0 and yyrestb.code == "200000" then
				yyllstoken = yyrestb.data.token
				yyllsuserid = yyrestb.data.userId
				if yyllstoken then
					break
				else
					return 1
				end	
				
			end
		end
	end
	--[[
	local body = {}
	local clientTime = os.time()..math.random(100,999)
	local signstr = strtomd5("IOSclientTime="..clientTime.."9e615c8a150a21f44a0eac71d82e19f20c1a49ff")
	body["caller"]= "IOS"
	body["sign"]= signstr
	body["clientTime"]= clientTime
	body["data"]= {
		["userId"]=yyllsuserid,
		["city"]= "秦皇岛市",
		["realName"]=username1688,
		["age"]= math.random(1990,2015).."-0"..math.random(1,9).."-"..math.random(10,28),
		["token"]= yyllstoken,
		["sex"]=  math.random(1,2),
		["province"]= "河北省"
	}
	body["version"] = appversion

	url = "https://"..YYIP.."/api/user/mobile/registerV4"
	local res = sendYingYuPhonenumber(url,body)
	stomLog(res)




	local body = {}
	body["sDeviceId"]= sDeviceId
	body["appVer"]= "6"
	body["appId"]= "lls"
	body["token"]= yyllstoken
	body["traceName"]= "data_error"
	body["deviceId"]= sDeviceId
	body["uuid"]= g_now_idfa
	url = "https://"..YYIP.."/api/v1/trace"
	local res = sendWeiKeChuanQi(url,body)
	

	--url = "https://54.222.153.215/api/v1/reminders/study/tutors?appId=lls&appVer=6&deviceId="..sDeviceId.."&sDeviceId="..sDeviceId.."&token="..yyllstoken
	local body = {}
	body["sDeviceId"]= sDeviceId
	body["appVer"]= "6"
	body["appId"]= "lls"
	body["token"]= yyllstoken
	body["action"]= "register"
	body["deviceId"]= sDeviceId
	body["uuid"]= g_now_idfa
	url = "https://"..YYIP.."/api/personas/uuid"
	local res = sendYingYuPhonenumber(url,body)
	provinceOK = province
	]]
	
	

	return 0


end
function create_1322331084()		--新氧APP
	apple_appid = "1322331084"
	local loop = 0
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	local issms = 0
	createpasswd = myRand(4,10,1)
	conmenttype = "xinyang"
	while (true) do
		stomLog("createxinyang--"..loop)
		stommSleep(500);
		if loop == 0 then
			stomMultiColorTap("注册", {
				{  399,  881, 0x3fd4c3},
				{  519,  883, 0x3fd3c3},
				{  463,  885, 0x3ed4c3},
			})
						
			if stomMultiColor("准备输入号码",{
				{  207,  501, 0xffffff},
				{  131,  771, 0xdedede},
				{  499,  979, 0xf3604b},
				{  183,  971, 0x40cf57},
				{  343,  977, 0x12a3e8},
			}) then
				loop = 1
			end
		elseif loop == 1 then
			stomLog("获取号码。。。"..getloop)
			if getloop == 0 then
				check_Rules = 1
				Telnum, ksuid = getTelnum_60ma_st(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
				if Telnum then
					stomLog(Telnum)
					getloop = 1
					num = 0
				else
					stomLog("重新获取号码中")
					stommSleep(5000)
					num = num + 1
				end
				if num > 20 then
					stomLog("获取号码失败")
					return 1
				end
			elseif getloop == 1 then
				phonenumber = Telnum
				if stomColorInReg("有号码",0x333333, 90, 311, 477, 365, 503) then
					yanzm = yanzm + 1
					stommSleep(500) 
					stomColorInRegTap("获取验证码",0xff82a3, 90, 399, 475, 493, 513)
				else
					stomLog("输入号码"..phonenumber)
					stommSleep(500) 
					stomInpuTextTap(207,  500, phonenumber, 3)
					stommSleep(500)
				end
				
--				if stomMultiColor("需要验证",{
--					{117,  683, 0x66d200, 85}, 
--					{189,  695, 0xdfe1e2, 85}, 
--					{143,  681, 0x66d200, 85},
--					{106,  786, 0x7e7e7e, 85}}) or
--					stomColorInReg("好", 0x007aff, 90, 261, 605, 371, 653) then
--					freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
--					upContentData(conmenttype,phonenumber,ksuid,field2,field3,"needcheck")
--					return 10
--				end
				if yanzm > 5 then
					freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
					upContentData(conmenttype,phonenumber,ksuid,field2,field3,"yanzm10")
					return 1
				end

				if stomMultiColorReg("已输手机号",{
						{  206,  497, 0x424242},
						{  167,  965, 0x40cf57},
						{  343,  973, 0x12a3e8},
						{  463,  959, 0xf3604b},
						{  395,  795, 0xdedede},
					}) then
					getloop = 2
				end
			elseif getloop == 2 then
				stomLog("获取短信...")
				messg = GetSMS_60ma(UserID,UserKey,docks,phonenumber)
				if messg then
					messg = string.gsub(messg,"30分","")
					messg = string.gsub(messg,phonenumber,"")
					messg = string.sub(messg,9)
					yanzhenma = string.match(messg,"%d+")
					stomLog("yanzhenmaOK="..yanzhenma)
					stomInpuTextTap(105,  631, yanzhenma,3);stommSleep(1000)
					issms = 1
					addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
					freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
				else
					stomLog("get sms")
					fa = fa +1
				end	
				if fa > 60 then
					addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
					freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
					if issms == 0 then
						stomLog("获取短信失败")
						upContentData(conmenttype,phonenumber,ksuid,field2,field3,"getsms60")
						return 10
					else
						upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"neterror")
						return 1
					end
				end
				
				stommSleep(1000)
				
				
				if stomMultiColorTap("注册",{
						{  161,  687, 0x45d8c1},
						{  439,  683, 0x48dac2},
						{  311,  669, 0x4ddec0},
					}) then
					getloop = 3
					provinceOK = province
					ksuidOK = ksuid
					upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"1")
				end
				
				if stomMultiColor("被封",{
					{  325,  367, 0xffc84b},
					{  303,  413, 0xf17906},
					{  415,  788, 0x2cc7c5},
				}) then
					upContentData(conmenttype,phonenumber,ksuid,field2,field3,"notnew")
					return 1
				end
				
--				if stomColorInReg("重新发送",0xff6600, 90, 227, 471, 409, 509) then
--					addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
--					freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
--					upContentData(conmenttype,phonenumber,ksuid,field2,field3,"nosms")
--					return 10
--				end
				
			elseif getloop == 3 then
				stomColorInRegTap("女孩",0xff6f96, 90, 105, 387, 227, 493)
				stomColorInRegTap("大学",0x648cf9, 90, 73, 385, 191, 553)
				if stomMultiColor("被封",{
					{  325,  367, 0xffc84b},
					{  303,  413, 0xf17906},
					{  415,  788, 0x2cc7c5},
				}) then
					upContentData(conmenttype,phonenumber,ksuid,field2,field3,"notnew")
					return 1
				end
				
				if stomMultiColor("学姐快来",{
					{  313,  917, 0x4fcb19},
					{  155,  881, 0x4fcb19},
					{  495,  875, 0x4fcb19},
				}) or 
				stomMultiColor("添加课程",{
					{   63,  967, 0x4fcb19},
					{  565,  953, 0x4fcb19},
					{  323, 1005, 0x4fcb19},
				}) 	then
					stommSleep(5000)
					return 0
				end
				
			
			
			
			
			end
			
			
		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 300 then
			return 1
		end
	end

end
function create_387682726()	--taobao
	apple_appid = "387682726"
	local loop = 0
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	local issms = 0
	local clicksend = 0
	createpasswd = myRand(4,10,1)
	conmenttype = "taobao"
	while (true) do
		stomLog("taobao--"..loop)
		stommSleep(500);
		if loop == 0 then
			stomMultiColorTap("聚划算入口",{
				{  319,  971, 0xa3a3a3},
				{  169,  141, 0xff8601},
				{  495,  155, 0xff5900},
			})
			stomMultiColorTap("注册/登录",{
				{  547, 1013, 0xff6e00},
				{  487,  975, 0xff7f00},
				{  601,  993, 0xff5900},
				{   69, 1065, 0xff6c00},
				{  579, 1087, 0xf5f4f4},
			})
			stomMultiColorTap("注册", {
				{  574,  751, 0x4f4f4f},
				{   93,  631, 0xffd1a2},
				{  565,  677, 0xffc1a2},
				{  313,  267, 0xff5000},
				{  315,  163, 0xff7206},
			})
			stomMultiColorTap("立即抢",{
				{  257,  869, 0xfedc25},
				{  387,  863, 0xffde2a},
				{  323,  853, 0xffdb1c},
			})
			if stomMultiColor("手机注册2",{
				{   73,  573, 0xffd2a3},
				{  299,  631, 0xffcaa2},
				{  583,  585, 0xffc1a2},
				{  259,  235, 0x000000},
			}) then
				freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
				return 1
			end
			if stomMultiColorTap("注册AN", {
					{   77,  575, 0xffd3a5},
					{  571,  651, 0xffc4a7},
					{  305,   73, 0x000000},
					{  321,  639, 0xffc9a2},
				}) then
				loop = 1
			end
		elseif loop == 1 then
			stomLog("获取号码。。。")
			check_Rules = 1
			Telnum, ksuid = getTelnum_60ma_st(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
			if Telnum then
				phonenumber = Telnum
				loop = 2
				t1 = os.time()
			else
				num = num + 1
				stomtoast(error_60ma)
				mSleep(5000)
			end
			if num > 20 then
				stomtoast("获取号码失败")
				stomLog("获取号码失败")
				return 1
			end
		elseif loop == 2 then
			if stomMultiColor("no号码",{
				{   52,  357, 0xffffff},
				{   87,  577, 0xffd1a3},
				{  555,  647, 0xffc1a2},
				{  275,  643, 0xffcba2},
			}) then
				stommSleep(500) 
				stomInpuTextTap(52,  357, phonenumber, 3)
			end
			if stomMultiColor("手机号OK",{
					{   52,  359, 0x000000},
					{   79,  585, 0xffd1a2},
					{  525,  651, 0xffc2a2},
					{  295,  645, 0xffcaa2},
				}) then
				stomMultiColorTap("获取验证码",{
					{  500,  479, 0xf4f4f4},
					{   99,  573, 0xffd4a8},
					{  571,  643, 0xffc1a2},
					{  319,  641, 0xffcaa2},
				})
				clicksend = clicksend+1
			end
			if stomMultiColor("手机注册2",{
				{   73,  573, 0xffd2a3},
				{  299,  631, 0xffcaa2},
				{  583,  585, 0xffc1a2},
				{  259,  235, 0x000000},
			}) then
				freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
				return 1
			end
			if clicksend > 0 then
				loop = 3
			end
		elseif loop == 3 then
			if stomMultiColor("安全",{
					{   49,   71, 0x333333},
					{  259,   81, 0x000000},
					{  381,   97, 0x000000},
					{  328,   80, 0x000000},
				}) then
				mSleep(5000)
				--苹果
				local x1,y1 = findMultiColorInRegionFuzzy( 0xc91711, "-28|-26|0xfe8b81,-6|24|0xe32b21,20|-28|0xd96c67", 90, 3, 361, 633, 1109)
				stomLog(x1.."--x1--"..y1)
				--篮子
				local x2,y2 = findMultiColorInRegionFuzzy( 0xff9801, "-1|-34|0xff6207,-8|-12|0xff8902,8|-13|0xff8602", 90, 3, 361, 633, 1109)
				stomLog(x2.."--x2--"..y2)
				swip(x1,y1,x2,y2+50)
				mSleep(5000)
			end
			if stomMultiColor("已发送",{
				{   54,  555, 0x7ed321},
				{   91,  625, 0xffd3a5},
				{  567,  697, 0xffc1a2},
			}) then
				loop = 4
			end
		elseif loop == 4 then
			messg = GetSMS_60ma(UserID,UserKey,docks,phonenumber)
			if messg then
				t1 = os.time()
				--stomLog(messg)
				messg = string.gsub(messg,os.date("%Y-%m-%d",os.time()),"")
				messg = string.gsub(messg,"30分","")
				messg = string.sub(messg,33)
				--stomLog(messg)
				yanzhenma = string.match(messg,"%d+")
				stomLog("yanzhenmaOK="..yanzhenma)
				stomInpuTextTap(50,  476, yanzhenma,2);mSleep(1000)
				issms = 1
				addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
				freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
				loop = 5
			else
				stomLog("get sms")
				fa = fa +1
				stomtoast(fa..error_60ma)
				mSleep(5000)
			end	
			if fa > 25 then
				addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
				freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
				if issms == 0 then
					stomLog("获取短信失败")
					upContentData(conmenttype,phonenumber,ksuid,field2,field3,"nosms")
					return 1
				else
					upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"neterror")
					return 1
				end
			end
		elseif loop == 5 then
			if stomMultiColorTap("同意并注册",{
					{   77,  661, 0xff8b00},
					{  305,  639, 0xff7100},
					{  555,  633, 0xff5500},
				}) or 
				stomMultiColorTap("同意并注册2",{
					{  107,  603, 0xff8800},
					{  311,  585, 0xff7100},
					{  539,  623, 0xff5800},
				}) then
				mSleep(2000)
			end
			if stomMultiColor("直接登录",{
				{   25,  613, 0xff4400},
				{  611,  697, 0xff4400},
				{  289,  607, 0xff4400},
				{  301,  697, 0xff4400},
			}) then
				upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"nonew")
				return 1
			end
			if stomMultiColor("立即抢",{
					{  257,  869, 0xfedc25},
					{  387,  863, 0xffde2a},
					{  323,  853, 0xffdb1c},
				}) or 
				stomMultiColor("开",{
					{  325,  733, 0x95570b},
					{  281,  735, 0xffe49d},
					{  361,  721, 0xffe59f},
				}) or
				stomMultiColor("聚划算",{
					{  161,  149, 0xff8601},
					{  491,  145, 0xff5500},
					{  419,  201, 0xff6200},
				}) or
				stomMultiColor("商品分类",{
					{   97,  163, 0xff8c32},
					{  439,  157, 0xff6411},
					{  359,  151, 0xff6f1a},
				}) or
				stomMultiColor("tao",{
					{   65, 1059, 0xff26ab},
					{   57, 1113, 0xff5f7f},
					{   29, 1093, 0xff215b},
				})or 
				stomMultiColor("登录",{
					{  107,  633, 0xffd0a2},
					{  257,  659, 0xffcba2},
					{  499,  647, 0xffc3a2},
					{  555,  455, 0xf4f4f4},
				})or 
				stomMultiColorTap("我的",{
					{  577, 1103, 0xf7f6f7},
					{   29, 1087, 0xff8a00},
					{   55, 1127, 0xff7400},
					{  103, 1111, 0xf8f7f7},
				}) then
				loop = 6
			end
		elseif loop == 6 then
			upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"1")
			stommSleep(5000)
			return 0 
		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 300 then
			stomLog("超时300")
			return 1
		end
	
	end

end
function create_1164831301()	--二三里
	apple_appid = "1164831301"
	local loop = 0
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	local issms = 0
	local clicksend = 0
	createpasswd = myRand(4,10,1)
	conmenttype = "ersanli"
	while (true) do
		stomLog("ersanli--"..loop)
		stommSleep(500);
		if loop == 0 then
			stomMultiColorTap("关闭",{
				{  618,   33, 0xff5b29},
				{  589,    9, 0xff5b29},
				{  625,    7, 0xff5b29},
			})
			stomMultiColorTap("我的白",{
				{  575, 1085, 0xf9f9f9},
				{  337, 1073, 0x01a7e8},
				{   69, 1075, 0x10acf0},
			})
			stomMultiColorTap("点击登录", {
				{  149,  153, 0x737373},
				{  337, 1073, 0x01a7e8},
				{  581, 1063, 0x10acf0},
				{  109,  191, 0x7f7f7f},
				{  529,  151, 0x185172},
			})
			stomMultiColorTap("点击登录白",{
				{  115,  143, 0xffffff},
				{  149,  147, 0xe6e6e6},
				{  313, 1057, 0x01a7e8},
				{  579, 1069, 0x10acf0},
				{  527,  147, 0x31a2e4},
			})
			stomMultiColorTap("我有邀请码",{
				{  298,  791, 0xffffff},
				{   89,  550, 0x10acf0},
				{  543,  646, 0x10acf0},
				{  233,  204, 0x212121},
			})
			if stomMultiColorTap("手机号", {
				{  319,  747, 0x10acf0},
				{  101,  673, 0x10acf0},
				{  547,  763, 0x10acf0},
				{   90,  406, 0xffffff},
				{  227,  203, 0x212121},
			}) then
				loop = 1
			end
		elseif loop == 1 then
			stomLog("获取号码。。。")
			check_Rules = 1
			Telnum, ksuid = getTelnum_60ma_st(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
			if Telnum then
				phonenumber = Telnum
				loop = 2
				t1 = os.time()
			else
				num = num + 1
				mSleep(5000)
			end
			if num > 20 then
				stomLog("获取号码失败")
				return 1
			end
		elseif loop == 2 then
			if stomMultiColor("no号码",{
					{   89,  413, 0xffffff},
					{  103,  669, 0x10acf0},
					{  563,  762, 0x10acf0},
				})then
				stommSleep(500) 
				stomInpuTextTap(90,  407, phonenumber, 3)
			end
			if stomColorInReg("you号码",0x000000, 90, 181, 385, 277, 429)then
				stomInpuTextTap(90,  527, "30144760", 3)
				clicksend = clicksend+1
			end
			if clicksend > 0 then
				loop = 3
			end
		elseif loop == 3 then
			stomMultiColorTap("去键盘",{
				{  232,  204, 0x212121},
				{  413,  236, 0x212121},
				{  582,  408, 0xcccccc},
				{  569,  509, 0xffffff},
			})
			stomMultiColorTap("一键登录",{
				{  309,  755, 0x10acf0},
				{   95,  673, 0x10acf0},
				{  533,  765, 0x10acf0},
				{   89,  399, 0x000000},
			})
			if stomMultiColor("请输入验证码",{
				{  121,  245, 0x212121},
				{  505,  272, 0x212121},
				{  559,  535, 0xf5f5f5},
				{  561,  451, 0xffffff},
			}) then
				loop = 4
				t1 = os.time()
			end
		elseif loop == 4 then
			messg = GetSMS_60ma(UserID,UserKey,docks,phonenumber)
			if messg then
				--stomLog(messg)
				messg = string.gsub(messg,os.date("%Y-%m-%d",os.time()),"")
				messg = string.gsub(messg,"10分","")
				messg = string.sub(messg,33)
				--stomLog(messg)
				yanzhenma = string.match(messg,"%d+")
				stomLog("yanzhenmaOK="..yanzhenma)
				stomInpuTextTap(71,  537, yanzhenma,2);mSleep(1000)
				issms = 1
				addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
				freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
				loop = 5
			else
				stomLog("get sms")
				fa = fa +1
				mSleep(5000)
			end	
			if fa > 15 then
				addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
				freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
				if issms == 0 then
					stomLog("获取短信失败")
					upContentData(conmenttype,phonenumber,ksuid,field2,field3,"nosms")
					return 1
				else
					upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"neterror")
					return 1
				end
			end
		elseif loop == 5 then
			if stomMultiColorTap("同意并注册",{
					{   77,  661, 0xff8b00},
					{  305,  639, 0xff7100},
					{  555,  633, 0xff5500},
				}) or 
				stomMultiColorTap("同意并注册2",{
					{  107,  603, 0xff8800},
					{  311,  585, 0xff7100},
					{  539,  623, 0xff5800},
				}) then
				mSleep(2000)
			end
			if stomMultiColor("直接登录",{
				{   25,  613, 0xff4400},
				{  611,  697, 0xff4400},
				{  289,  607, 0xff4400},
				{  301,  697, 0xff4400},
			}) then
				upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"nonew")
				return 1
			end
			if stomMultiColor("LV1",{
					{  257,  177, 0xffd80c},
					{  335, 1067, 0x01a7e8},
					{  571, 1071, 0x10acf0},
					{  527,  157, 0x31a2e4},
				}) or 
				stomMultiColorTap("确定",{
					{  308,  635, 0x007aff},
					{  339, 1061, 0x00648b},
					{  571, 1063, 0x096790},
					{  148,  525, 0x000000},
					{  240,  174, 0x999225},
				})or 
				stomMultiColorTap("lv11",{
					{  269,  176, 0x99870c},
					{  333, 1067, 0x00648b},
					{  573, 1069, 0x096790},
					{  557,  193, 0x266d97},
				})then
				loop = 6
			end
		elseif loop == 6 then
			upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"1")
			return 0 
		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 220 then
			return 1
		end
	
	end

end
function create_1288910541()					--掌门
	apple_appid = "1288910541"
	local loop = 0
	local t1 = os.time()
	local getloop = 0
	local xiago = 0
	local num = 0
	local fa = 0
	local conmenttype = "ZhangMen"
	local qicheBug = 0
	local nichengBug = 0
	local nicheng = myRand(3,5,1)
	getPhoneType = "dm"
	docks = "18774"
	while (true) do
		stomLog("--com.zmlearn.ZMParent--"..loop)
		stommSleep(500);
		if loop == 0 then
			stomMultiColorTap("跳过11", {
				{  573,   52, 0x666666},
				{  543,   56, 0xacacac},
				{  287, 1015, 0xef4c4f},
				{  428,  802, 0x333333},
				{  212,  836, 0x333333},
			})
			if stomMultiColor("号码框11",{
				{  128,  484, 0xffffff},
				{   63,  662, 0xffabaa},
				{  574,  662, 0xffabaa},
				{   81,  268, 0xef4c4f},
				{  516,  263, 0x333333},
				{  506,  257, 0x5e5e5e},
			}) then
				loop = 1
			end
		elseif loop == 1 then
			stomLog("获取号码。。。"..getloop)
			if getloop == 0 then
				check_Rules = 1
				Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
				if Telnum then
					stomLog(Telnum)
					getloop = 1
					num = 0
				else
					stomLog("重新获取号码中")
					stommSleep(2000)
					num = num + 1
				end
				if num > 20 then
					stomLog("获取号码失败")
					return 1
				end
			elseif getloop == 1 then
				phonenumber = Telnum
				stomMultiColorTap("号码框11",{
					{  128,  484, 0xffffff},
					{   63,  662, 0xffabaa},
					{  574,  662, 0xffabaa},
					{   81,  268, 0xef4c4f},
					{  516,  263, 0x333333},
					{  506,  257, 0x5e5e5e},
				})
				stomMultiColorTap("无键获取验证码",{
					{  314,  687, 0xff5655},
					{   80,  263, 0xef4c4f},
					{  104,  258, 0xf89ea0},
					{  348,  279, 0x333333},
					{  337,  280, 0x5a5a5a},
				})
			
				if stomMultiColorTap("获取验证码11",{
					{  326,  326, 0xff5655},
					{  541,  174, 0xcccccc},
					{   45,   90, 0x999999},
					{   63,  348, 0xff5655},
					{  576,  348, 0xff5655},
				}) then
					xiago = xiago + 1
					stommSleep(1000)
				else
					if stomMultiColor("键号码框11",{
						{  128,  169, 0xffffff},
						{  277,  172, 0x999999},
						{   45,   90, 0x999999},
						{   63,  348, 0xffabaa},
						{  576,  348, 0xffabaa},
					}) then
						stomLog("输入号码"..phonenumber)
						stommSleep(500) 
						stomInpuTextTap(128,  169, phonenumber, 3)
						stommSleep(500)
					end
				end	
				
				if stomMultiColor("拖动滑块验证",{
					{  106,  786, 0x7e7e7e},
					{  147,  792, 0x7e7e7e},
					{  117,  677, 0x66d200},
					{   68,  816, 0xffffff},
					{  557,  678, 0xdaddde},
				}) then
					stomLog("需要验证，重新开始")
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					return 1
				end
				if stomMultiColor("骑车中",{
					{  288,  621, 0xc6c6c6},
					{  283,  570, 0x72caff},
					{  315,  574, 0x485983},
					{  318,  539, 0xec5b35},
					{  312,  521, 0xffe0cd},
				}) then
					stomLog("骑车中。。。")
					stommSleep(5000)
					qicheBug = qicheBug + 1
				end
				if qicheBug > 7 then
					stomLog("骑车卡点。。。")
					return 1
				end
				if stomMultiColor("验证码框",{
					{   98,  491, 0xffffff},
					{   85,  543, 0x333333},
					{  190,  543, 0xe6e6e6},
					{  126,  279, 0x333333},
					{  351,  289, 0x6d6d6d},
					{  350,  298, 0xc4c4c4},
				}) then
					getloop = 2
				end
				
			elseif getloop == 2 then
				stomLog("获取短信...")
				messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
				if messg then
					yanzhenma = string.match(messg,"%d+")
					stomLog("yanzhenmaOK-"..yanzhenma)
					stomInpuTextTap(90,  494, yanzhenma,3);mSleep(3000)
				else
					stomLog("get sms")
					fa = fa +1
				end	
				if fa > 30 then
					stomLog("获取短信失败")
					stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					return 1
				end
				if stomMultiColor("姓名框", {
					{  199,  354, 0xffffff},
					{  318,  358, 0xc7c7cd},
					{  144,  358, 0xc7c7cd},
					{  231,  170, 0x333333},
					{  229,  181, 0x6f6f6f},
					{  576,  882, 0xef4c4f},
				}) then
					loop = 2
				end
				if stomMultiColor("Hello", {
				{   37,  119, 0x373f53},
				{   49,  122, 0x8d919d},
				{  271,  120, 0x757b88},
				{  573,  124, 0xff6810},
				{   70, 1078, 0xef4c4f},
				}) then
					stomLog("号码重复。。。")
					upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"nonew")
					return 1
				end
				
				if stomMultiColor("Hello1",{
				{  580,  123, 0xff6511},
				{   80, 1063, 0xef4c4f},
				{  126, 1087, 0xffffff},
			})then
					stomLog("号码重复。。。")
					upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"nonew")
					mSleep(5000)
					return 1
				end
				stommSleep(500)
			end
		elseif loop == 2 then
			stomMultiColorTap("姓名框", {
				{  199,  354, 0xffffff},
				{  318,  358, 0xc7c7cd},
				{  144,  358, 0xc7c7cd},
				{  231,  170, 0x333333},
				{  229,  181, 0x6f6f6f},
				{  576,  882, 0xef4c4f},
			})
			if stomMultiColor("键姓名框", {
				{  198,  353, 0xffffff},
				{  231,  170, 0x333333},
				{  229,  179, 0x6f6f6f},
				{  317,  359, 0xc7c7cd},
			}) then
				stomLog("aaa")
				stommSleep(1000)
				m = math.random(4,6) 
				myRand(3,m,2)
				ningcheng = myRand(3,m,2)
				stomInpuTextTap( 252,  355, ningcheng,5)
				stomLog("bbb")
					
			end
			
			stomMultiColorTap("还原昵称",{
				{  527,  179, 0xffffff},
				{  521,  359, 0xcccccc},
				{  393,  163, 0x333333},
				{  365,  169, 0x7f7f7f},
				{  354,  158, 0x505050},
			})
			if stomMultiColorTap("一键预约",{
				{  331,  856, 0xef4c4f},
				{  576,  882, 0xef4c4f},
				{  318,  358, 0xffffff},
				{  364,  179, 0x333333},
				{  362,  170, 0x7f7f7f},
			})then
				nichengBug = nichengBug + 1
				stommSleep(1000)
			end
			if nichengBug > 1 then
				loop = 3
			end
			if stomMultiColor("Hello", {
				{   37,  119, 0x373f53},
				{   49,  122, 0x8d919d},
				{  271,  120, 0x757b88},
				{  573,  124, 0xff6810},
				{   70, 1078, 0xef4c4f},
			}) then
				provinceOK = province
				ksuidOK = ksuid
				upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"1")
				mSleep(5000)
				return 0
			end
			if stomMultiColor("Hello1",{
				{  580,  123, 0xff6511},
				{   80, 1063, 0xef4c4f},
				{  126, 1087, 0xffffff},
			})then
				provinceOK = province
				ksuidOK = ksuid
				upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"1")
				mSleep(5000)
				return 0
			end
		elseif loop == 3 then
			
			stomMultiColorTap("二次昵称框",{
				{  279,  357, 0xffffff},
				{  231,  170, 0x333333},
				{  229,  179, 0x6f6f6f},
				{   65,  880, 0xef4c4f},
				{  572,  883, 0xef4c4f},
			})
			if stomMultiColor("二次键昵称框",{
				{  257,  362, 0xffffff},
				{  522,  359, 0xcccccc},
				{  364,  159, 0x333333},
				{  370,  181, 0xb2b2b2},
				{  395,  169, 0x474747},
			})then
				aa = Rnd_Word(zf["名字"],2,2)
				stomInpuTextTap( 252,  355, aa,2)
				nichengBug = 0
				loop = 2
			end
			
		
		
--			stomMultiColorTap("一键预约",{
--				{  331,  856, 0xef4c4f},
--				{  576,  882, 0xef4c4f},
--				{  318,  358, 0xffffff},
--				{  364,  179, 0x333333},
--				{  362,  170, 0x7f7f7f},
--			})
--			if stomMultiColor("Hello", {
--				{   37,  119, 0x373f53},
--				{   49,  122, 0x8d919d},
--				{  271,  120, 0x757b88},
--				{  573,  124, 0xff6810},
--				{   70, 1078, 0xef4c4f},
--			}) then
--				provinceOK = province
--				ksuidOK = ksuid
--				upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"1")
--				mSleep(5000)
--				return 0
--			end
			
		
		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 300 then
			return 1
		end
	end

end
function create_1064779641()		--大象保险
	apple_appid = "1064779641"
	local loop = 100
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	local issms = 0
	local mima1 = 0
	local mima2 = 0
	createpasswd = myRand(4,10,1)
	conmenttype = "DaXiangBaoXian"
	
	getPhoneType = "dm"
	docks = "18634"
	needcheck = 0
	
	while (true) do
		stomLog("DaXiangBaoXian--"..loop)
		stommSleep(500);
		if loop == 100 then
			for i =1 , 4 do
				stommoveTo(467, 803, 240, 803)
				stommSleep(300)
			end
			if stomMultiColorTap("立即开启", {
				{  267,  933, 0xffffff},
				{  235,  603, 0xf66340},
				{  421,  453, 0xf64e27},
				{  515,  643, 0xf44117},
			}) then
				loop = 0
			end
		elseif loop == 0 then
			
			stomMultiColorTap("立即开启", {
				{  267,  933, 0xffffff},
				{  235,  603, 0xf66340},
				{  421,  453, 0xf64e27},
				{  515,  643, 0xf44117},
			})
			stomMultiColorTap("注册", {
				{  584,  601, 0xffffff},
				{   49,  689, 0xffa380},
				{  583,  741, 0xff977c},
				{  343,  165, 0xe52e1c},
				{  313,  183, 0xffffff},
			})
			if stomMultiColor("准备输入号码",{
				{   61,  399, 0xffa380},
				{  587,  457, 0xff977c},
				{  485,  329, 0xcccccc},
				{  599,  303, 0xcccccc},
			}) then
				loop = 1
			end
		elseif loop == 1 then
			stomLog("获取号码。。。"..getloop)
			if getloop == 0 then
				check_Rules = 1
				Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
				phonenumber = Telnum
				if Telnum then
					stomLog(Telnum)
					getloop = 1
					num = 0
				else
					stomLog("重新获取号码中")
					stommSleep(5000)
					num = num + 1
				end
				if num > 30 then
					stomLog("获取号码失败")
					return 1
				end
			elseif getloop == 1 then
				phonenumber = Telnum
				if stomMultiColorTap("获取短信",{
					{  505,  291, 0x222222},
					{   53,  393, 0xffa380},
					{  579,  458, 0xff977c},
				}) then
					yanzm = yanzm + 1
					stommSleep(2000) 
				else
					if stomMultiColor("注册灰",{
						{   51,  214, 0xffffff},
						{  580,  200, 0xffffff},
						{  495,  297, 0xcccccc},
						{   99,  425, 0xffa380},
					}) then
						stomLog("输入号码"..phonenumber)
						stommSleep(500) 
						stomInpuTextTap(51,  221, phonenumber, 3)
						stommSleep(500)
					end
				end
				if stomMultiColorTap("获取短信",{
						{  491,  295, 0x222222},
						{  595,  335, 0x222222},
						{  580,  200, 0xffffff},
						{   55,  425, 0xffa380},
						{  581,  489, 0xff977c},
					}) then
					getloop = 2
				end
				if yanzm > 2 then
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					upContentData(conmenttype,phonenumber,ksuid,field2,field3,"yanzm10")
					return 10
				end
				if stomMultiColor("输入验证码",{
						{   62,   28, 0x757575},
						{  315,  216, 0x2c2b02},
						{   61,  216, 0x2c2b02},
						{  307,  655, 0xffffff},
					}) then
				end

			elseif getloop == 2 then
				stomLog("获取短信...")
--				stomMultiColorTap("获取按钮OK",{
--						{  253,  473, 0x4fcb19},
--						{  362,  460, 0x4fcb19},
--						{  177,  336, 0x212121},
--						{  171,  361, 0xffffff},
--					})
--				stomMultiColorTap("获取按钮OK2",{
--					{  253,  473, 0x4fcb19},
--					{  362,  460, 0x4fcb19},
--					{  240,  341, 0x212121},
--					{  235,  361, 0xffffff},
--				})
				if issms == 0 then
					messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
				end
				if messg then
					yanzhenma = string.match(messg,"%d+")
					stomLog("yanzhenmaOK="..yanzhenma)
					issms = 1
					stomInpuTextTap(55,  315, yanzhenma,2)
					upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"1")
					getloop = 200
				else
					stomLog("get sms")
					fa = fa +1
					stommSleep(5000)
				end	
				if fa > 15 then
					stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					if issms == 0 then
						stomLog("获取短信失败")
						upContentData(conmenttype,phonenumber,ksuid,field2,field3,"getsms60")
						return 1
					else
						upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"neterror")
						return 1
					end
				end
			elseif getloop == 200 then	
				
				if stomMultiColorTap("注册",{
					{  255,  461, 0xff622a},
					{   59,  423, 0xff622a},
					{  577,  488, 0xff5224},
				}) then
					
				end
				
				if stomMultiColor("密码1",{
					{   53,  499, 0xffa380},
					{   55,  212, 0xffffff},
					{  575,  555, 0xff977c},
				}) then
					getloop = 3
				end

			elseif getloop == 3 then
				if mima1 == 1 and mima2 == 1 then
					getloop = 4
				end
				if mima1==0 and stomMultiColor("密码1",{
					{   53,  499, 0xffa380},
					{   55,  212, 0xffffff},
					{  575,  555, 0xff977c},
				}) then
					stomInpuTextTap(55,  212, createpasswd, 2)
					stommSleep(1000)
				end
				if stomMultiColor("密码1OK",{
					{   55,  212, 0x3d3d3d},
					{   57,  501, 0xffa380},
					{  587,  558, 0xff977c},
				}) then
					mima1 = 1
				end
				if mima2==0 and stomMultiColor("密码2",{
					{   55,  312, 0xffffff},
					{   83,  503, 0xffa380},
					{  577,  553, 0xff977c},
				}) then
					stomInpuTextTap(55,  312, createpasswd, 2)
				end
				if stomMultiColor("密码2OK",{
					{   55,  313, 0x3d3d3d},
					{   55,  495, 0xff622a},
					{  587,  559, 0xff5224},
				}) then
					mima2 = 1
				end
			elseif getloop == 4 then	
				stomMultiColorTap("确定",{
					{  273,  527, 0xff5e29},
					{   51,  494, 0xff622a},
					{  593,  559, 0xff5224},
					{   55,  313, 0x3d3d3d},
					{   54,  211, 0x3d3d3d},
				})
				
				if stomMultiColor("首页灰",{
					{   79, 1077, 0x80230d},
					{  400, 1076, 0x0e0e0e},
					{   83,   83, 0x111111},
					{  159,   67, 0x808080},
				}) or 
				stomMultiColor("首页",{
					{   47,   84, 0x222222},
					{   79, 1079, 0xff471a},
					{  400, 1076, 0x1d1d1d},
					{  499, 1099, 0xffffff},
				}) or 
				stomMultiColor("首页灰白",{
					{   79, 1078, 0xff471a},
					{  400, 1076, 0x1d1d1d},
					{   47,   90, 0x060606},
					{  215,   65, 0x333333},
				})then
					stommSleep(2000)
					return 0
				end
				
			
			
			
			
			end
			
			
		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 300 then
			return 1
		end
	end

end


function create_1329890841()					---  知识圈
	apple_appid = "1329890841"
	local loop = 0
	local t1 = os.time()
	local getloop = 0
	local xiago = 0
	local num = 0
	local fa = 0
	local conmenttype = "ZhiShiQuan"
	local qicheBug = 0
	local nichengBug = 0
	local nicheng = myRand(3,5,1)
	while (true) do
		stomLog("--com.xiaoyatech-project-V1.manager-mingbai--"..loop)
		stommSleep(500);
		if loop == 0 then
			stomMultiColorTap("隐私授权z", {
				{  469,  873, 0xe05864},
				{  424,  871, 0xffffff},
				{  413,  869, 0xf1b3b8},
				{  211,  849, 0xbcbcbc},
				{  319,  867, 0xffffff},
			})
			stomMultiColorTap("点击登录", {
				{  323,   86, 0xffffff},
				{  359,   97, 0xe5e5e5},
				{  575, 1094, 0xe05864},
				{   61,  426, 0xffb877},
			})
			stomMultiColorTap("我的z", {
				{  574, 1072, 0xffffff},
				{  318, 1101, 0xe05864},
				{  317, 1052, 0xf5c7cb},
				{  302,   96, 0x000000},
			})
		
			stomMultiColorTap("号码框", {
				{  194,  435, 0xffffff},
				{  317,  441, 0xccccd2},
				{  511,  577, 0xe05864},
				{  379,  201, 0x000000},
				{  183,  972, 0x68c66d},
				{   67,  679, 0xcccccc},
			})
			if stomMultiColor("键号码框",{
				{  193,  310, 0xffffff},
				{  309,  313, 0xccccd2},
				{  379,   73, 0x000000},
				{  572,  622, 0xcccccc},
				{   68,  549, 0xcccccc},
			}) then
				loop = 1
			end
		elseif loop == 1 then
			stomLog("获取号码。。。"..getloop)
			if getloop == 0 then
				check_Rules = 1
				Telnum, ksuid = getTelnum_60ma_st(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
				if Telnum then
					stomLog(Telnum)
					getloop = 1
					num = 0
				else
					stomLog("重新获取号码中")
					stommSleep(2000)
					num = num + 1
				end
				if num > 20 then
					stomLog("获取号码失败")
					return 1
				end
			elseif getloop == 1 then
				phonenumber = Telnum

				if stomMultiColorTap("获取验证码z",{
					{  511,  437, 0xe05864},
					{  542,  317, 0xcccccc},
					{  377,   72, 0x000000},
					{   69,  550, 0xcccccc},
					{  569,  621, 0xcccccc},
				}) then
					xiago = xiago + 1
					stommSleep(1000)
				else
					if stomMultiColor("键号码框z",{
						{  193,  310, 0xffffff},
						{  309,  313, 0xccccd2},
						{  379,   73, 0x000000},
						{  572,  622, 0xcccccc},
						{   68,  549, 0xcccccc},
					}) then
						stomLog("输入号码"..phonenumber)
						stommSleep(500) 
						stomInpuTextTap(176,  312, phonenumber, 3)
						stommSleep(500)
					end
				end	
				
--				if stomMultiColor("拖动滑块验证",{
--					{  106,  786, 0x7e7e7e},
--					{  147,  792, 0x7e7e7e},
--					{  117,  677, 0x66d200},
--					{   68,  816, 0xffffff},
--					{  557,  678, 0xdaddde},
--				}) then
--					stomLog("需要验证，重新开始")
--					stommSleep(500)
--					return 1
--				end
--				if stomMultiColor("骑车中",{
--					{  288,  621, 0xc6c6c6},
--					{  283,  570, 0x72caff},
--					{  315,  574, 0x485983},
--					{  318,  539, 0xec5b35},
--					{  312,  521, 0xffe0cd},
--				}) then
--					stomLog("骑车中。。。")
--					stommSleep(5000)
--					qicheBug = qicheBug + 1
--				end
--				if qicheBug > 7 then
--					stomLog("骑车卡点。。。")
--					return 1
--				end
				if stomMultiColorTap("验证码框z",{
					{  192,  436, 0xffffff},
					{  542,  316, 0xcccccc},
					{  508,  438, 0xaaaaaa},
					{  570,  551, 0xcccccc},
					{  377,   73, 0x000000},
				}) then
					getloop = 2
				end
				
			elseif getloop == 2 then
				stomLog("获取短信...")
				messg = GetSMS_60ma(UserID,UserKey,docks,phonenumber)
				if messg then
					messg = string.gsub(messg,"30分","")
					messg = string.sub(messg,9)
					yanzhenma = string.match(messg,"%d+")
					stomLog("yanzhenmaOK-"..yanzhenma)
					stomInpuTextTap(163,  440, yanzhenma,3);mSleep(3000)
					addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
					freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
					--[[
					yanzhenmalist = stringToList(yanzhenma)
					isnext = 0
					for i =1, 4 do
						if i == 4 then
							isnext = 1
						end
						stomInpuTextTap(86+(150*(i-1)),  419, yanzhenmalist[i], isnext);mSleep(1000)
					end
					]]
				else
					stomLog("get sms")
					fa = fa +1
				end	
				if fa > 30 then
					stomLog("获取短信失败")
					addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
					freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
					return 1
				end
				stomMultiColorTap("红登录z",{
					{  315,  565, 0xe05864},
					{  296,  443, 0xcccccc},
					{  328,  584, 0xf2b5ba},
					{  379,   73, 0x000000},
				})
				if stomMultiColor("姓名框z", {
					{  111,  504, 0xffffff},
					{  187,  509, 0xceced4},
					{  323,  289, 0xc6c6c6},
					{   52,  615, 0xe97077},
					{  599,  690, 0xe97077},
				}) then
					loop = 2
				end
--				if stomMultiColor("Hello", {		
--				{   37,  119, 0x373f53},
--				{   49,  122, 0x8d919d},
--				{  271,  120, 0x757b88},
--				{  573,  124, 0xff6810},
--				{   70, 1078, 0xef4c4f},
--			}) then
--				stomLog("号码重复。。。")
--				upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"nonew")
--				return 1
--			end
				stommSleep(500)
			end
		elseif loop == 2 then
			if stomMultiColor("姓名框z", {
				{  111,  504, 0xffffff},
				{  187,  509, 0xceced4},
				{  323,  289, 0xc6c6c6},
				{   52,  615, 0xe97077},
				{  599,  690, 0xe97077},
			}) then
				stomLog("aaa")
				stommSleep(1000)
				m = math.random(4,8) 
				myRand(3,m,2)
				ningcheng = myRand(3,m,2)
				stomInpuTextTap( 111,  504, ningcheng,3)
				stomLog("bbb")
					
			end
			
			stomMultiColorTap("进入知鸦",{
				{  317,  649, 0xe97077},
				{  359,  654, 0xf2a9ae},
				{  349,  647, 0xffffff},
				{  322,  288, 0xc6c6c6},
				{  273,  647, 0xf5bbbe},
			})
			
			if stomMultiColor("我的注册成功", {
				{  319,  118, 0xe5e5e5},
				{  318, 1099, 0xe05864},
				{  320, 1052, 0xf5c7cb},
				{  599, 1056, 0xcb7637},
				{   60,  425, 0xffb877},
			}) then
				provinceOK = province
				ksuidOK = ksuid
				upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"1")
				mSleep(5000)
				return 0
			end
		
--			stomMultiColorTap("一键预约",{
--				{  331,  856, 0xef4c4f},
--				{  576,  882, 0xef4c4f},
--				{  318,  358, 0xffffff},
--				{  364,  179, 0x333333},
--				{  362,  170, 0x7f7f7f},
--			})
--			if stomMultiColor("Hello", {
--				{   37,  119, 0x373f53},
--				{   49,  122, 0x8d919d},
--				{  271,  120, 0x757b88},
--				{  573,  124, 0xff6810},
--				{   70, 1078, 0xef4c4f},
--			}) then
--				provinceOK = province
--				ksuidOK = ksuid
--				upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"1")
--				mSleep(5000)
--				return 0
--			end
			
		
		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 300 then
			return 1
		end
	end

end
function create_563091001_60ma()					---  打卡助手
	apple_appid = "563091001"
	local conmenttype = "DaKaZhuShou"
	local loop = 0
	local t1 = os.time()
	local getloop = 0
	local xiago = 0
	local num = 0
	local fa = 0
	while (true) do
		stomLog("--com.amgtec.DaKa--"..loop)
		stommSleep(500);
		if stomMultiColorTap("取消加入",{
				{  207,  705, 0xffffff},
				{  320,  504, 0x586bfc},
				{  320,  452, 0x586bfc},
				{  343,  517, 0x586bfc},
			}) then
			stommSleep(1000)
		end
		if stomMultiColorTap("取消加入1",{
				{  207,  635, 0xffffff},
				{  320,  437, 0x586bfc},
				{  305,  450, 0x586bfc},
				{  330,  399, 0x586bfc},
			}) then
			stommSleep(1000)
		end
		
		if loop == 0 then
			stomMultiColorTap("下一步d",{
				{  314, 1058, 0xafb8fd},
				{  325, 1060, 0xbdc4fe},
				{  345, 1057, 0x586bfb},
				{  357,  968, 0xcccccc},
				{  291, 1050, 0x586bfb},
			})
			stomMultiColorTap("立即体验d",{
				{  334, 1065, 0x586bfb},
				{  339, 1052, 0x7a89fc},
				{  309, 1059, 0x7f8dfb},
				{  296, 1064, 0x697afc},
				{  357,  968, 0x586bfc},
			})
			stomMultiColorTap("立即注册d",{
				{  581,   81, 0x333333},
				{  584,   78, 0x6a6a6a},
				{  599,   87, 0x333333},
				{  531,   78, 0x949494},
				{  190,  271, 0x1b99fe},
				{  428,  644, 0x9ba6fd},
			})
		
			if stomMultiColor("键号码框d",{
				{   87,  433, 0x9ba6fe},
				{  551,  477, 0x9ba6fe},
				{  459,  299, 0xf2faff},
				{   92,  180, 0x000000},
			}) then
				loop = 1
			end
		elseif loop == 1 then
			stomLog("获取号码。。。"..getloop)
			if getloop == 0 then
				check_Rules = 1
				Telnum, ksuid = getTelnum_60ma_st(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
				if Telnum then
					stomLog(Telnum)
					getloop = 1
					num = 0
				else
					stomLog("重新获取号码中")
					stommSleep(2000)
					num = num + 1
				end
				if num > 20 then
					stomLog("获取号码失败")
					return 1
				end
			elseif getloop == 1 then
				phonenumber = Telnum

				if stomMultiColorTap("获取验证码z",{
					{  512,  327, 0xffffff},
					{  533,  320, 0x333333},
					{  540,  257, 0xcccccc},
					{  528,  313, 0x9f9f9f},
					{  576,  456, 0x9ba6fe},
				}) then
					xiago = xiago + 1
					stommSleep(1000)
				else
					if stomMultiColor("键号码框d",{
						{  113,  254, 0xffffff},
						{  244,  257, 0xd1d1d6},
						{  451,  299, 0xf2faff},
						{   64,  454, 0x9ba6fe},
						{   93,  181, 0x000000},
						{   90,  174, 0x767676},
					}) then
						stomLog("输入号码"..phonenumber)
						stommSleep(500) 
						stomInpuTextTap( 90,  256, phonenumber,5)
						stommSleep(500)
					end
				end	
				if xiago > 2 then
					stomLog("获取验证码失败")
					return 1
				end
				if stomMultiColor("验证码框d",{
					{  114,  330, 0xffffff},
					{  404,  334, 0xffffff},
					{   67,  455, 0x9ba6fe},
					{   93,  180, 0x000000},
					{   90,  175, 0x767676},
					{  469,  326, 0xcccccc},
				}) then
					getloop = 2
				end
				
			elseif getloop == 2 then
				stomLog("获取短信...")
				messg = GetSMS_60ma(UserID,UserKey,docks,phonenumber)
				if messg then
					yanzhenma = string.match(messg,"%d+")
					stomLog("yanzhenmaOK-"..yanzhenma)
					stomInpuTextTap(132,  333, yanzhenma,5);mSleep(3000)
					addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
					freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
					
					main1path="Documents/"..idfa.."-1.PNG"
					stomsnapshotfull(main1path)
				else
					stomLog("get sms")
					fa = fa +1
				end	
				if fa > 30 then
					stomLog("获取短信失败")
					addBlackTelnum_60ma(UserID,UserKey,docks,phonenumber)
					freeTelnum_60ma(UserID,UserKey,docks,phonenumber)
					return 1
				end
				stomMultiColorTap("注册d",{
					{  324,  439, 0x586bfc},
					{  403,  333, 0xcccccc},
					{  130,  177, 0x000000},
					{  117,  167, 0x707070},
				})
				
				if stomMultiColor("姓名框d",{
					{  147,  254, 0xc7c7cd},
					{  329,  198, 0x000000},
					{  318,  191, 0x333333},
					{   65,  483, 0x9ba6fe},
					{  540,  257, 0xffffff},
				}) then
					loop = 2
				end
--				if stomMultiColor("Hello", {		
--				{   37,  119, 0x373f53},
--				{   49,  122, 0x8d919d},
--				{  271,  120, 0x757b88},
--				{  573,  124, 0xff6810},
--				{   70, 1078, 0xef4c4f},
--			}) then
--				stomLog("号码重复。。。")
--				upContentData(conmenttype,phonenumber,ksuid,idfa,field3,"nonew")
--				return 1
--			end
				stommSleep(500)
			end
		elseif loop == 2 then
			
			if stomMultiColorTap("密码框d",{
				{  105,  335, 0xd1d1d6},
				{  540,  256, 0xcccccc},
				{   65,  481, 0x9ba6fe},
				{  329,  198, 0x000000},
				{  344,  170, 0x727272},
			})then
				stommSleep(1000)
				m = math.random(6,12) 
				myRand(3,m,2)
				mima = myRand(3,m,2)
				stomInpuTextTap( 105,  335, mima,5)
			else
				if stomMultiColor("姓名框d",{
					{  147,  254, 0xc7c7cd},
					{  329,  198, 0x000000},
					{  318,  191, 0x333333},
					{   65,  483, 0x9ba6fe},
					{  540,  257, 0xffffff},
				}) then
					stomLog("aaa")
					stommSleep(1000)
					m = math.random(5,9) 
					myRand(3,m,2)
					ningcheng = myRand(3,m,2)
					stomInpuTextTap( 147,  254, ningcheng,5)
					stomLog("bbb")
						
				end
			end
			
				stomMultiColorTap("完成登录信息",{
					{  314,  463, 0x586bfc},
					{  541,  333, 0xcccccc},
					{   70,  334, 0x333333},
					{  328,  197, 0x000000},
				})
			if stomMultiColor("我的注册成功",{
				{  310, 1043, 0x20a1fe},
				{  572, 1078, 0x999999},
				{  320, 1095, 0x016aff},
				{  319, 1020, 0x29b1fe},
				{  319, 1084, 0xffffff},
			}) then
				provinceOK = province
				ksuidOK = ksuid
				upContentData(conmenttype,phonenumber,ksuid,idfa,mima,"1")
				loop = 3
			end
		elseif loop == 3 then
			stomMultiColorTap("我的",{
				{  585, 1093, 0xffffff},
				{  311, 1057, 0x1995fe},
				{  329, 1047, 0x1e9efe},
				{  329, 1047, 0x1e9efe},
			})
			if stomMultiColorTap("取消加入",{
				{  207,  705, 0xffffff},
				{  320,  504, 0x586bfc},
				{  320,  452, 0x586bfc},
				{  343,  517, 0x586bfc},
				}) then
				stommSleep(1000)
			end
			if stomMultiColor("我的灰",{
				{  311, 1061, 0x062b4b},
				{  581, 1091, 0x4c4c4c},
				{   95, 1071, 0x4c4c4c},
				{   91,  655, 0x492222},
			}) then
				stomtap(525,  239);
			end
			if stomMultiColor("我的2",{
				{   91,  619, 0xf77373},
				{  103,  653, 0xf77373},
				{   83,  959, 0xf77373},
				{  435,  213, 0x6f94fc},
			}) then
				stommSleep(3000)
				if stomMultiColorTap("取消加入",{
					{  207,  705, 0xffffff},
					{  320,  504, 0x586bfc},
					{  320,  452, 0x586bfc},
					{  343,  517, 0x586bfc},
					}) then
					stommSleep(3000)
				end
				stomtap(525,  239);
				stommSleep(1000)
			end
			if stomMultiColor("我的3",{
				{  193,  105, 0x586bfb},
				{  191,  155, 0xffffff},
				{  317, 1065, 0xf6f6f6},
				{  562,  491, 0x999999},
			}) then
				if stomMultiColorTap("取消加入",{
				{  207,  705, 0xffffff},
				{  320,  504, 0x586bfc},
				{  320,  452, 0x586bfc},
				{  343,  517, 0x586bfc},
					}) then
					stommSleep(1000)
				end
				stommSleep(5000)
				main2path="Documents/"..idfa.."-2.PNG"
				stomsnapshotfull(main2path)
				loop = 4
			end
		elseif loop == 4 then
			url = "https://api.ojbknet.com/api/postfile.php?appid="..apple_appid..os.date("%Y%m%d",os.time())
			stomLog(postImage(url,main1path))
			stommSleep(500)
			stomLog(postImage(url,main2path))
			return 0
		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 300 then
			return 1
		end
	end

end
function create_563091001()					---  打卡助手
	apple_appid = "563091001"
	local conmenttype = "DaKaZhuShou"
	local loop = 0
	local t1 = os.time()
	local getloop = 0
	local xiago = 0
	local num = 0
	local fa = 0
	getPhoneType = "dm"
	docks = "18693"

	while (true) do
		stomLog("--com.amgtec.DaKa--"..loop)
		stommSleep(500);
		if stomMultiColorTap("取消加入",{
				{  207,  705, 0xffffff},
				{  320,  504, 0x586bfc},
				{  320,  452, 0x586bfc},
				{  343,  517, 0x586bfc},
			}) then
			stommSleep(1000)
		end
		if stomMultiColorTap("取消加入1",{
				{  207,  635, 0xffffff},
				{  320,  437, 0x586bfc},
				{  305,  450, 0x586bfc},
				{  330,  399, 0x586bfc},
			}) then
			stommSleep(1000)
		end
		
		if loop == 0 then
			stomMultiColorTap("下一步d",{
				{  314, 1058, 0xafb8fd},
				{  325, 1060, 0xbdc4fe},
				{  345, 1057, 0x586bfb},
				{  357,  968, 0xcccccc},
				{  291, 1050, 0x586bfb},
			})
			stomMultiColorTap("立即体验d",{
				{  334, 1065, 0x586bfb},
				{  339, 1052, 0x7a89fc},
				{  309, 1059, 0x7f8dfb},
				{  296, 1064, 0x697afc},
				{  357,  968, 0x586bfc},
			})
			stomMultiColorTap("立即注册d",{
				{  581,   81, 0x333333},
				{  584,   78, 0x6a6a6a},
				{  599,   87, 0x333333},
				{  531,   78, 0x949494},
				{  190,  271, 0x1b99fe},
				{  428,  644, 0x9ba6fd},
			})
		
			if stomMultiColor("键号码框d",{
				{   87,  433, 0x9ba6fe},
				{  551,  477, 0x9ba6fe},
				{  459,  299, 0xf2faff},
				{   92,  180, 0x000000},
			}) then
				loop = 1
			end
		elseif loop == 1 then
			stomLog("获取号码。。。"..getloop)
			if getloop == 0 then
				check_Rules = 1
				Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
				if Telnum then
					stomLog(Telnum)
					getloop = 1
					num = 0
				else
					stomLog("重新获取号码中")
					stommSleep(2000)
					num = num + 1
				end
				if num > 20 then
					stomLog("获取号码失败")
					return 1
				end
			elseif getloop == 1 then
				phonenumber = Telnum

				if stomMultiColorTap("获取验证码z",{
					{  512,  327, 0xffffff},
					{  533,  320, 0x333333},
					{  540,  257, 0xcccccc},
					{  528,  313, 0x9f9f9f},
					{  576,  456, 0x9ba6fe},
				}) then
					xiago = xiago + 1
					stommSleep(1000)
				else
					if stomMultiColor("键号码框d",{
						{  113,  254, 0xffffff},
						{  244,  257, 0xd1d1d6},
						{  451,  299, 0xf2faff},
						{   64,  454, 0x9ba6fe},
						{   93,  181, 0x000000},
						{   90,  174, 0x767676},
					}) then
						stomLog("输入号码"..phonenumber)
						stommSleep(500) 
						stomInpuTextTap( 90,  256, phonenumber,5)
						stommSleep(500)
					end
				end	
				if xiago > 2 then
					stomLog("获取验证码失败")
					stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					return 1
				end
				if stomMultiColor("验证码框d",{
					{  114,  330, 0xffffff},
					{  404,  334, 0xffffff},
					{   67,  455, 0x9ba6fe},
					{   93,  180, 0x000000},
					{   90,  175, 0x767676},
					{  469,  326, 0xcccccc},
				}) then
					getloop = 2
				end
				
			elseif getloop == 2 then
				stomLog("获取短信...")
				messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
				if messg then
					yanzhenma = string.match(messg,"%d+")
					stomLog("yanzhenmaOK-"..yanzhenma)
					stomInpuTextTap(132,  333, yanzhenma,5);mSleep(3000)
					main1path="Documents/"..idfa.."-1.PNG"
					stomsnapshotfull(main1path)
				else
					stomLog("get sms")
					fa = fa +1
				end	
				if fa > 30 then
					stomLog("获取短信失败")
					stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					return 1
				end
				stomMultiColorTap("注册d",{
					{  324,  439, 0x586bfc},
					{  403,  333, 0xcccccc},
					{  130,  177, 0x000000},
					{  117,  167, 0x707070},
				})
				
				if stomMultiColor("姓名框d",{
					{  147,  254, 0xc7c7cd},
					{  329,  198, 0x000000},
					{  318,  191, 0x333333},
					{   65,  483, 0x9ba6fe},
					{  540,  257, 0xffffff},
				}) then
					loop = 2
				end

				stommSleep(500)
			end
		elseif loop == 2 then
			
			if stomMultiColorTap("密码框d",{
				{  105,  335, 0xd1d1d6},
				{  540,  256, 0xcccccc},
				{   65,  481, 0x9ba6fe},
				{  329,  198, 0x000000},
				{  344,  170, 0x727272},
			})then
				stommSleep(1000)
				m = math.random(6,12) 
				myRand(3,m,2)
				mima = myRand(3,m,2)
				stomInpuTextTap( 105,  335, mima,5)
			else
				if stomMultiColor("姓名框d",{
					{  147,  254, 0xc7c7cd},
					{  329,  198, 0x000000},
					{  318,  191, 0x333333},
					{   65,  483, 0x9ba6fe},
					{  540,  257, 0xffffff},
				}) then
					stomLog("aaa")
					stommSleep(1000)
					m = math.random(5,9) 
					myRand(3,m,2)
					ningcheng = myRand(3,m,2)
					stomInpuTextTap( 147,  254, ningcheng,5)
					stomLog("bbb")
						
				end
			end
			
			stomMultiColorTap("完成登录信息",{
				{  314,  463, 0x586bfc},
				{  541,  333, 0xcccccc},
				{   70,  334, 0x333333},
				{  328,  197, 0x000000},
			})
			if stomMultiColor("我的注册成功",{
				{  310, 1043, 0x20a1fe},
				{  572, 1078, 0x999999},
				{  320, 1095, 0x016aff},
				{  319, 1020, 0x29b1fe},
				{  319, 1084, 0xffffff},
			}) then
				provinceOK = province
				ksuidOK = ksuid
				upContentData(conmenttype,phonenumber,ksuid,idfa,mima,"1")
				loop = 3
			end
		elseif loop == 3 then
			stomMultiColorTap("我的",{
				{  585, 1093, 0xffffff},
				{  311, 1057, 0x1995fe},
				{  329, 1047, 0x1e9efe},
				{  329, 1047, 0x1e9efe},
			})
			if stomMultiColorTap("取消加入",{
				{  207,  705, 0xffffff},
				{  320,  504, 0x586bfc},
				{  320,  452, 0x586bfc},
				{  343,  517, 0x586bfc},
				}) then
				stommSleep(1000)
			end
			if stomMultiColor("我的灰",{
				{  311, 1061, 0x062b4b},
				{  581, 1091, 0x4c4c4c},
				{   95, 1071, 0x4c4c4c},
				{   91,  655, 0x492222},
			}) then
				stomtap(525,  239);
			end
			if stomMultiColor("我的2",{
				{   91,  619, 0xf77373},
				{  103,  653, 0xf77373},
				{   83,  959, 0xf77373},
				{  435,  213, 0x6f94fc},
			}) then
				stommSleep(3000)
				if stomMultiColorTap("取消加入",{
					{  207,  705, 0xffffff},
					{  320,  504, 0x586bfc},
					{  320,  452, 0x586bfc},
					{  343,  517, 0x586bfc},
					}) then
					stommSleep(3000)
				end
				stomtap(525,  239);
				stommSleep(1000)
			end
			if stomMultiColor("我的3",{
				{  193,  105, 0x586bfb},
				{  191,  155, 0xffffff},
				{  317, 1065, 0xf6f6f6},
				{  562,  491, 0x999999},
			}) then
				if stomMultiColorTap("取消加入",{
				{  207,  705, 0xffffff},
				{  320,  504, 0x586bfc},
				{  320,  452, 0x586bfc},
				{  343,  517, 0x586bfc},
					}) then
					stommSleep(1000)
				end
				stommSleep(5000)
				main2path="Documents/"..idfa.."-2.PNG"
				stomsnapshotfull(main2path)
				loop = 4
			end
		elseif loop == 4 then
			url = "https://api.ojbknet.com/api/postfile.php?appid="..apple_appid..os.date("%Y%m%d",os.time())
			stomLog(postImage(url,main1path))
			stommSleep(500)
			stomLog(postImage(url,main2path))
			return 0
		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 300 then
			return 1
		end
	end

end


function create_919043762()					---  星城
	apple_appid = "919043762"
	local time_cha =  math.random(10,15)*60
	local loop = 0
	local t1 = os.time()
	local getloop = 0
	local xiago = 0
	local num = 0
	local fa = 0
	local Return = 0
	local conmenttype = "XingCheng"
	while (true) do

		if stomMultiColor("加载中",{
			{  164,  765, 0x7d2530},
			{  156,  775, 0xec4b66},
			{  176,  565, 0xdd4f6d},
			{  477,   85, 0xff38ff},
			{  493,  276, 0xffe8ff},
		}) then
			stommSleep(5000)
		end
		
		stomMultiColorTap("星城任意点击",{
			{  321,  567, 0x760017},
			{  401,  573, 0xc80016},
			{  430,  571, 0xf8ca31},
			{  426,  567, 0x040405},
			{  472,  605, 0xf7b00b},
			{  464,  605, 0x0278ee},
		})
		
		stomMultiColorTap("立即玩",{
			{  437,  571, 0xffffff},
			{  438,  582, 0xf4dae3},
			{  451,  596, 0xdb2e74},
			{  332,  613, 0x013ee9},
			{  332,  531, 0x64c4f4},
		})
		stomMultiColorTap("略过",{
			{  225,  937, 0x4c0d77},
			{  217,  935, 0xffff66},
			{  375,  936, 0xd48900},
			{  364,  829, 0x0c0c2f},
			{  364,  803, 0x030303},
		})

		if stomMultiColorTap("无法联系主机",{
			{  187,  603, 0x792cc2},
			{  139,  573, 0x665740},
			{  465,  577, 0xbca3d0},
			{  452,  584, 0xfbf8fc},
			{  485,  574, 0x4e1a7d},
			{  486,  586, 0x9d7873},
		}) then
			loop = 1 
		end
		if loop == 1 then
			local Return = 0
			if stomMultiColor("创建角色框11",{
				{  103,  567, 0xeaaa00},
				{  142,  574, 0xedcc99},
				{  482,  945, 0x323232},
				{  418,  195, 0x0089f8},
				{  416,  285, 0xf23598},
			}) then
				stommSleep(1000)
				Return = Return + 1
				m = math.random(2,3)
				a = myRand(4,m,2)
				name = Rnd_Word(zf["名字"],m,3)
				stomInpuTextTap( 474,  763, name..a,3)
				stommSleep(2000)
				stomLog(Return.."不管用啊")
			end
			if Return > 0 then
				stomLog(Return.."不点啊")
				stomMultiColorTap("键盘返回",{
					{  572, 1045, 0xfc4bf4},
					{  571,  951, 0xd4a315},
					{  562,  940, 0xa36baa},
					{  536,  589, 0xffffff},
					{  546,  584, 0x996ba8},
				})
				Return = 0
				loop = 0
			end
		end
	
			stomMultiColorTap("无法与主机连接",{
			{  570,  472, 0x9c4ee2},
			{  500,  442, 0xa37bd3},
			{  578,  174, 0xbca3d0},
			{  562,  205, 0xd8a7d3},
			{  594,  206, 0x265f7f},
		})

		if stomMultiColor("创建角色框",{
			{  141,  566, 0xedcc99},
			{   93,  566, 0xf8dd00},
			{  482,  945, 0xffffff},
			{  397,  201, 0x004a8c},
			{  372,  200, 0xfbd59b},
		}) then
			stommSleep(1000)
			Return = Return + 1
			m = math.random(2,3)
			a = myRand(4,m,2)
			name = Rnd_Word(zf["名字"],m,3)
			stomInpuTextTap( 474,  763, name..a,3)
			stommSleep(2000)
			stomLog(Return.."不管用啊")
		end
		if Return > 0 then
			stomLog(Return.."不点啊")
			stomMultiColorTap("键盘返回",{
				{  572, 1045, 0xfc4bf4},
				{  571,  951, 0xd4a315},
				{  562,  940, 0xa36baa},
				{  536,  589, 0xffffff},
				{  546,  584, 0x996ba8},
			})
			Return = 0
		end
		
		if stomMultiColorTap("确定创建角色",{
			{  103,  567, 0xeaaa00},
			{  142,  574, 0xedcc99},
			{  482,  945, 0x323232},
			{  418,  195, 0x0089f8},
			{  416,  285, 0xf23598},
		}) then
			stommSleep(3000)
		end
		
		stomMultiColorTap("向右机器",{
			{  281,  191, 0xf5f5f5},
			{  354,  195, 0x273653},
			{  356,  129, 0xfcacc2},
			{  224,   74, 0x2297b4},
		})
		
		stomMultiColorTap("向左机器",{
			{  275,  963, 0xf3f3f3},
			{  359,  997, 0x273653},
			{  224, 1081, 0x2297b4},
			{  198,  967, 0xefb691},
		})
		
		stomMultiColorTap("向左机器1",{
			{  271,  866, 0xf1f1f1},
			{  357,  862, 0x273653},
			{  122,  852, 0xff253c},
			{  221,  985, 0x2297b4},
		})
	
		stomMultiColorTap("游戏说明",{
			{  514,  968, 0xd9b283},
			{  318, 1001, 0xfccc1a},
			{  590, 1008, 0x7e5e00},
			{  569,  560, 0x7c765a},
		})
		
		stomMultiColorTap("得分记录",{
			{  525,  978, 0xe4cc79},
			{  324,  873, 0x793c06},
			{  279,  125, 0xb87f2a},
			{  455,  394, 0x8a590a},
		})
	
		stomMultiColorTap("新手星",{
			{  535, 1001, 0xb20063},
			{  458,  847, 0xfcd31a},
			{  496,  750, 0x04e6ff},
			{  158,  654, 0x48d000},
		})
		
		stomMultiColorTap("金猪送福",{
			{  549, 1001, 0x5b2f19},
			{  552,  640, 0xf00602},
			{  505,  632, 0xfff027},
			{  497,  575, 0xb2210d},
			{   75,  450, 0xccc6be},
		})
		
		stomMultiColorTap("白手指1",{
			{  470,  174, 0xedab28},
			{  473,  169, 0x532202},
			{  236,  881, 0xf5f5f5},
			{  312,  890, 0x273653},
			{  179, 1010, 0x2297b4},
		})
		
		stomMultiColorTap("白手指2",{
			{  163,  760, 0xb8d5f4},
			{  140,  785, 0x2a4e77},
			{  293,  189, 0xfbfbfb},
			{  356,  197, 0x273653},
			{  221,   75, 0x2297b4},
		})
		
		stomMultiColorTap("白手指3",{
			{   27,  945, 0x1e2232},
			{   54,  847, 0xe5e7ef},
			{  223,   74, 0x2297b4},
			{  361,  163, 0x273653},
			{  352,  130, 0xfcacc2},
		})
	
		stomMultiColorTap("白手指4",{
			{  249,  911, 0x474f74},
			{  228,  932, 0x222637},
			{  340,  254, 0xfaaac0},
			{  353,  199, 0x273653},
			{  224,   73, 0x2297b4},
		})
	
		stomMultiColorTap("白手指5",{
			{   26,  942, 0x1d202f},
			{   55,  847, 0xe7e9f0},
			{  347,  250, 0xfaa7be},
			{  361,  166, 0x273653},
			{  221,   74, 0x2297b4},
		})
	
		stomMultiColorTap("白手指6",{
			{  606,  489, 0xb5d273},
			{  347,  253, 0xfaa7be},
			{  354,  192, 0x273653},
			{  223,   77, 0x2297b4},
		})

		stomMultiColorTap("白手指7",{
			{  429,  194, 0xf0fdfe},
			{  353,  959, 0x273653},
			{  352, 1025, 0xfcacc2},
			{  223, 1081, 0x2297b4},
			{  519,  163, 0x573800},
		})
	
		stomMultiColorTap("白手指8",{
			{  136,  461, 0xae78f7},
			{  118,  506, 0x5b00be},
			{  229, 1081, 0x2297b4},
			{  354, 1027, 0xfcacc2},
			{  359,  993, 0x273653},
		})

		stomMultiColorTap("白手指9",{
			{  533, 1002, 0xffffff},
			{  465,  932, 0x050109},
			{  355,  198, 0x273653},
			{  226,   75, 0x2297b4},
			{  359,  128, 0xfcacc2},
		})
		stomMultiColorTap("白手指10",{
			{   43, 1096, 0xca3535},
			{   23,  995, 0x451212},
			{  225,   75, 0x2297b4},
			{  361,  162, 0x273653},
			{  343,  131, 0xfba2b8},
		})
	
		stomMultiColorTap("白手指11",{
			{  605, 1011, 0x410000},
			{  337,  252, 0xf9aabe},
			{  354,  198, 0x273653},
			{  222,   75, 0x2297b4},
		})
		stomMultiColorTap("白手指12",{
			{   30,  174, 0x24283c},
			{   54,  215, 0xe5e7ef},
			{  359,  994, 0x273653},
			{  353, 1026, 0xfcacc2},
			{  221, 1084, 0x2297b4},
		})
		stomMultiColorTap("白手指13",{
			{   28,  300, 0x202435},
			{   54,  346, 0xe5e7ef},
			{   12,  253, 0x41486b},
			{  359,  993, 0x273653},
			{  353, 1026, 0xfcacc2},
			{  223, 1080, 0x2297b4},
		})
		stomMultiColorTap("白手指14",{
			{  164,  578, 0x174400},
			{  223,  119, 0x2297b4},
			{  356,  237, 0x273653},
			{  345,  298, 0xfaa9bf},
			{  416,  720, 0x33021c},
		})
		stommSleep(1000)

		t2 = os.time()
		if os.difftime(t2,t1) > time_cha then
			
			return 0
		end
	end
	
end
function creat_976048109()
	apple_appid = "976048109"
	local conmenttype = "miaojie"
	local loop = 0
	local t1 = os.time()
	local getloop = 0
	local xiago = 0
	local num = 0
	local fa = 0
	while (true) do
		stomtoast("loop="..loop,1)
		if loop == 0 then
			if stomMultiColor("同意注册",{
				{   64,  400, 0xff0000},
				{  266,  456, 0xff0000},
				{  526,  404, 0xff0000},
				{   50,  182, 0x000000},
			}) or stomMultiColorReg("同意注册2",0xff0000, "464|-4|0xff0000,254|36|0xff0000", 90, 11, 143, 623, 663) then
				stommSleep(10*1000)
				return 10
			end
--			if stomMultiColor("hongLOGO",{
--				{  283,  265, 0xfe3c3b},
--				{  327,  247, 0xfc3b3b},
--				{  311,  298, 0xfd3b3e},
--			}) then
--				stomMultiColorTap("免费注册",{
--					{  337,  995, 0x333333},
--					{  169,  877, 0x333333},
--					{  345,  973, 0xffffff},
--					{  428,  891, 0x333333},
--				})
--			end
			
			if stomMultiColor("提交成功",{
				{  313,  239, 0x21d480},
				{  287,  297, 0x21d480},
				{  347,  291, 0x21d480},
				{  375,  319, 0xffffff},
			}) then
				stommSleep(10*1000)
				main1path="Documents/"..idfa.."-1.PNG"
				stomsnapshotfull(main1path)
				t1 = os.time()
				loop = 1
			end

		elseif loop == 1 then
			local url = "https://api.ojbknet.com/api/postfile.php?appid="..apple_appid..os.date("%Y%m%d",os.time())
			stomLog(postImage(url,main1path))
			stommSleep(1000)
			return 0
		end
		stommSleep(1500)
		t2 = os.time()
		if os.difftime(t2,t1) > 600 then
			return 1
		end
		
	end
end
function sendStartbuks(body_send,url)
	stomLog(url)
	requestHeaders ={}
	requestHeaders["Content-Type"] = 'application/json'
	requestHeaders["User-Agent"] = sbkUA
	requestHeaders["Accept-Language"] = 'zh-cn'
	requestHeaders["Accept-Encoding"] = 'br, gzip, deflate'
	requestHeaders["Connection"] = 'keep-alive'
	requestHeaders["x-phone-type"]= 'iOS'
	requestHeaders["x-bs-device-id"] = device_external_code
	
	body_send_js = json.encode(body_send)
	errorxbk = ""
	for i =1 , 3 do
		local code , resHeaders, response = stomhttpsPost(url, 10, requestHeaders, body_send_js)
		stomLog(response)
		errorxbk = urlEncode(response)
		stomLog(code)
		if code == 200 then
			return 0
		end
		stommSleep(2000)
	end
	return 2
end
function sendStartbuksLogin(body_send,url)
	stomLog(url)
	requestHeaders ={}
	requestHeaders["Content-Type"] = 'application/json'
	requestHeaders["User-Agent"] = sbkUA
	requestHeaders["Accept-Language"] = 'zh-cn'
	requestHeaders["Accept-Encoding"] = 'br, gzip, deflate'
	requestHeaders["Connection"] = 'keep-alive'
	requestHeaders["x-phone-type"]= 'iOS'
	requestHeaders["x-bs-device-id"] = device_external_code
	
	body_send_js = json.encode(body_send)
	errorxbk = ""
	for i =1 , 3 do
		local code , resHeaders, response = stomhttpsPost(url, 10, requestHeaders, body_send_js)
		stomLog(response)
		errorxbk = urlEncode(response)
		stomLog(code)
		if code == 400 then
			return 0
		elseif code == 200 then
			return 1
		end
		stommSleep(2000)
	end
	return 2
end
function getStartbuks(url)
	stomLog(url)
	requestHeaders ={}
	requestHeaders["Content-Type"] = 'application/json'
	requestHeaders["User-Agent"] = sbkUA
	requestHeaders["Accept-Language"] = 'zh-cn'
	requestHeaders["Accept-Encoding"] = 'br, gzip, deflate'
	requestHeaders["Connection"] = 'keep-alive'
	requestHeaders["x-phone-type"]= 'iOS'
	requestHeaders["x-bs-device-id"] = device_external_code
	for i =1 , 3 do
		local code , resHeaders, response = stomhttpGet(url, 10, requestHeaders)
		stomLog(response)
		stomLog(code)
		if code == 200 then
			local data = json.decode(response)
			stuserName = data.userName
			stuserNameToken = data.userNameToken
			return 0
		end
		stommSleep(2000)
	end
	return 2
end
function putStartbuks(body_send,url)
	stomLog(url)
	requestHeaders ={}
	requestHeaders["Content-Type"] = 'application/json'
	requestHeaders["User-Agent"] = sbkUA
	requestHeaders["Accept-Language"] = 'zh-cn'
	requestHeaders["Accept-Encoding"] = 'br, gzip, deflate'
	requestHeaders["Connection"] = 'keep-alive'
	requestHeaders["x-phone-type"]= 'iOS'
	requestHeaders["x-bs-device-id"] = device_external_code
	
	body_send_js = json.encode(body_send)
	errorxbk = ""
	for i =1 , 3 do
		local code , resHeaders, response = stomhttpsPut(url, 10, requestHeaders, body_send_js)
		stomLog(response)
		errorxbk = urlEncode(response)
		stomLog(code)
		if code == 200 then
			--local data = json.decode(response)
			return 0
		elseif code == 400 then
			--local data = json.decode(response)
			--errorxbk = data['error']['message']
			return 1
		end
		stommSleep(2000)
	end
	return 2
end

function create_499819758()		--星巴克
	stomLog("create_499819758")
	local loop = 0
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	createpasswd = myRand(4,10,1)
	damauser,damapasswd = "zk1013","ekcom8888"
	docks1 = "14BAB4CC3190D6B"
	conmenttype = "startbuks"
	apple_appid = "499819758"
	
	getPhoneType = "dm"
	docks = "12315"
	
	local getpcon = 10
	local num = 0
	stommSleep(2000)
	while (true) do	
		stomLog("获取号码。。。"..getpcon)
	
		if getpcon == 10 then
			fdpjson = System.getFakefdp()
			stomLog(fdpjson)
			if fdpjson=="{}" then
				stommSleep(2000)
			else
				getpcon = 11
			end
		elseif getpcon == 11 then	
			fdptbale = json.decode(fdpjson)
			device_external_code = fdptbale['dfp']
			os_version = fdptbale['version']
			model = fdptbale['model']
			app_version = "7.2.1"
			sbkUA = 'Starbucks/483 CFNetwork/978.0.7 Darwin/18.5.0'
			
			devicexbk = {}
			devicexbk["os_version"]=os_version
			devicexbk["os_name"]="iOS"
			devicexbk["user_agent"]="iOS com.starbuckschina.mystarbucksmoments/"..app_version.." ("..model.."; iOS "..os_version..")"
			devicexbk["manufacturer"]="Apple"
			devicexbk["model"]=model
			devicexbk["timezone"]="Asia/Shanghai"
			devicexbk["device_external_code"]=device_external_code
			devicexbk["app_version"]=app_version
			devicexbk["id"]=idfa
			devicexbk["language"]="zh"
			getpcon = 0
--		elseif getpcon == 999 then
--			stomLog("generate")
--			url = "https://profile.starbucks.com.cn/api/account/username/generate"
--			if getStartbuks(url) == 0 then
--				getpcon = 0
--			else
--				stommSleep(5000)
--			end
		elseif getpcon == 0 then
			check_Rules = 1
			Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
			if Telnum then
				checkcode = 0
				if checkcode == 0 then
					phonenumber = Telnum
					stomLog(Telnum)
					body_send = {}
					body_send["template"]="create-cn"
					body_send["phoneNumber"]=Telnum
					surl = "https://profile.starbucks.com.cn/api/sms/send"
					if sendStartbuks(body_send,surl) == 0 then
						getpcon = 1
						t1 = os.time()
					else
						upContentData(conmenttype,Telnum,ksuid,errorxbk,field3,"needcheck")
						stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
						stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
						return 1
					end
				end
			else
				stomLog("重新获取号码中")
				ksuidOK = "000"
				stommSleep(3000)
			end
			num = num + 1
			if num > 100 then
				--stomtoast("获取号码失败", 5)
				stomLog("获取号码失败")
				return 1
			end
		elseif getpcon == 1 then
			stomLog("获取短信。。。")
			phonenumber = Telnum
			messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
			if messg then
				stomLog(messg)
				yanzhenma = string.match(messg,"%d+")
				stomLog(yanzhenma)
				getpcon = 2
				t1 = os.time()
				fa = 0
			else
				stomLog("重新获取短信中"..Telnum)
			end
			fa = fa +1
			if fa > 15 then
				stomLog("获取短信失败")
				stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
				stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
				upContentData(conmenttype,Telnum,ksuid,field2,field3,"nosms")
				return 1
			end
			stommSleep(5000)
		elseif getpcon == 2 then	
			body_send ={}
			body_send['device']= devicexbk
			body_send['cellPhone']= phonenumber
			body_send['pin']= yanzhenma
			url = "https://profile.starbucks.com.cn/api/account/login"
			if sendStartbuksLogin(body_send,url) == 0 then
				stomLog("generate")
				url = "https://profile.starbucks.com.cn/api/account/username/generate"
				if getStartbuks(url) == 0 then
					getpcon = 3
					t1 = os.time()
				else
					stommSleep(2000)
				end
			else
				upContentData(conmenttype,Telnum,ksuid,errorxbk,field3,"notnew")
				stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
				stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
				return 1
			end
		elseif getpcon == 3 then	
			body_send={}
			body_send["gender"]="Male"
			body_send["birthday"]="0"..math.random(1,9).."/"..math.random(10,28).."/19"..math.random(80,99)
			body_send["optOut"]=1
			body_send["cellPhone"]= phonenumber
			body_send["firstName"]= createpasswd
			body_send["userName"]= stuserName
			body_send["lastName"]=""
			body_send["password"]="Aa123456"
			body_send["sourceCode"]="APP"
			body_send["device"]= devicexbk
			body_send["avatar"]="avatar_20180810_3uu8vt.png"
			body_send["token"]= stuserNameToken
			
			url = "https://profile.starbucks.com.cn/api/account/register"
			if putStartbuks(body_send,url) == 0 then
				getpcon = 4
				--setvpn("discon")
			else
				return 1
			end
		elseif getpcon == 4 then
			upContentData(conmenttype,phonenumber,ksuid,idfa,stuserName.."----Aa123456","1")
			return 0
		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 120 then
			return 1
		end
	end
end
function singeWYX(str)
	--str="country_code=86&imgCodeToken=a706-b0d0af7cd287&mobile=15676019881&sign_key=wuyouxing&key&&timeStamp=1568803169962&type=0"
	local str=string.gsub(str,"=","")
	local tb = strSplit(str,"&")
	table.sort(tb)
	str = table.concat(tb,"")
	singestr = "sfj8ehg84772g78gq7vw82g738firs"..str.."sfj8ehg84772g78gq7vw82g738firs"
	stomLog(singestr)
	--stomtoast(singestr:md5(), 10)
	local s = string.upper(singestr:md5())
	--stomtoast(singestr,10)
	return s
end
function resetWYX()
	getpcon = 100
	fa = 0
	t1 = os.time()
end
function create_1037589370()--无忧行
	stomLog("create_1037589370")
	local loop = 0
	t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	createpasswd = myRand(4,10,1)
	damauser,damapasswd = "zk1013","ekcom8888"
	docks1 = "14BAB4CC3190D6B"
	conmenttype = "wuYouXing"
	apple_appid = "1037589370"
	
	getPhoneType = "ym"
	docks = "9845"
	
	wyxUserAgent = 'Roam/'..appVersion..' (iPhone; iOS '..fakeos..'; Scale/3.00)'
	
	requestHeaders ={}
	requestHeaders["Content-Type"] = 'application/json'
	requestHeaders["Connection"] = 'keep-alive'
	requestHeaders["Accept"] = '*/*'
	requestHeaders["User-Agent"] = wyxUserAgent
	requestHeaders["Accept-Language"] = 'zh-Hans;q=1, en;q=0.9'
	requestHeaders["Accept-Encoding"] = 'br, gzip, deflate'
	getpcon = 0
	local num = 0
	n_token = nil
	while (true) do
		math.randomseed(tonumber(tostring(os.time()):reverse():sub(1,6)))
		local p_time = tostring(os.time()+28800)..tostring(math.random(100,999))
		local p_sign = System.getFakeJegoTripSign(p_time)
		stomLog(p_time.."获取号码。。。"..getpcon)
		-- stomLog("p_sign="..p_sign)
		if stomMultiColor("跳过",{
			{  271, 1099, 0xff6316},
			{  302, 1100, 0xcccccc},
			{  368, 1099, 0xcccccc},
			{  335, 1099, 0xcccccc},
		}) then
			stomtap(558,   80)
			stommSleep(2000)
		end
		n_token = System.getFakeJegoNToken()
		if n_token ~= nil and getpcon == 0 then
			getpcon = 100
		end
		if getpcon == 100 then
			check_Rules = 1
			Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
			if Telnum then
				checkcode = 0
				if checkcode == 0 then
					phonenumber = Telnum
					stomLog(Telnum)
					body_send = {}
					local url ='https://app1.jegotrip.com.cn/api/user/v1/phoneUserLogin?n_token='..n_token..'&lang=zh_cn&timestamp='..p_time..'&sign='..p_sign
					body_send = {}
					body_send["password"]= "73cd66b8fe36d4ae7909d69063461a87"
					body_send["mobile"]= Telnum
					body_send["logintype"]="2"
					body_send["countryCode"]="86"
					body_send_js = json.encode(body_send)
					stomLog(body_send_js)
					local code , resHeaders, response = stomhttpsPost(url, 10, requestHeaders, body_send_js)
					stomLog(response)
					if code == 200 then
						restable = json.decode(response)
						if restable.code == "415" then
							getpcon = 101
						else
							stomLog(url)
							stomtoast(response,2)
							stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
							stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
							stommSleep(1*2000)
							num = num + 20
						end
					else
						stomLog(url)
						stomtoast(response,2)
						stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
						stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
						stommSleep(1*2000)
						num = num + 20
					end
				end
			else
				stomLog("重新获取号码中")
				ksuidOK = "000"
				stommSleep(3000)
			end
			num = num + 1
			if num > 100 then
				--stomtoast("获取号码失败", 5)
				stomLog("获取号码失败")
				return 1
			end
		elseif getpcon == 101 then
			local url = 'https://app1.jegotrip.com.cn/api/activity/v1/channelRedeemCode?lang=zh_cn&n_token='
			..n_token..'&timestamp='..p_time..'&sign='..p_sign
			body_send = {}
			body_send["channelCode"]= ""
			body_send["mobile"]= Telnum
			body_send_js = json.encode(body_send)
			local code , resHeaders, response = stomhttpsPost(url, 10, requestHeaders, body_send_js)
			stomLog(response)
			
			local url = 'https://app1.jegotrip.com.cn/api/user/v1/getCodeNumber?lang=zh_cn&n_token='
			..n_token..'&timestamp='..p_time..'&sign='..p_sign
			body_send = {}
			body_send["country_code"]= "86"
			body_send["mobile"]= Telnum
			body_send_js = json.encode(body_send)
			local code , resHeaders, response = stomhttpsPost(url, 10, requestHeaders, body_send_js)
			stomLog(response)
			getpcon = 102
			
		elseif getpcon == 102 then
			local url = 'https://app1.jegotrip.com.cn/api/user/v1/getImgCode?lang=zh_cn&n_token='
			..n_token..'&timestamp='..p_time..'&sign='..p_sign
			body_send = {}
			body_send["country_code"]= "86"
			body_send["mobile"]= Telnum
			body_send_js = json.encode(body_send)
			local code , resHeaders, response = stomhttpsPost(url, 10, requestHeaders, body_send_js)
			if code == 200 then
				restable = json.decode(response)
				if restable.code == "0" then
					wyximgdata = restable.body.imgBase64
					-- stomLog(wyximgdata)
					tb = strSplit(wyximgdata,",")
					wyximgdata = tb[2]
					getpcon = 103
				end
			end
		elseif getpcon == 103 then
			passwd,gameid = "zk1013|1007DD0FCBD01319","7001"
			imgcode = Haoi_create(passwd,gameid,wyximgdata,1)
			stomLog(imgcode)
			if imgcode then
				getpcon = 104
			else
				resetWYX()
			end
		elseif getpcon == 104 then	
			local url = 'https://app1.jegotrip.com.cn/api/user/v1/verifyImgCode?lang=zh_cn&n_token='
			..n_token..'&timestamp='..p_time..'&sign='..p_sign
			body_send = {}
			body_send["country_code"]= "86"
			body_send["mobile"]= Telnum
			body_send["imgCode"] = imgcode
			body_send_js = json.encode(body_send)
			local code , resHeaders, response = stomhttpsPost(url, 10, requestHeaders, body_send_js)
			stomLog(response)
			if code == 200 then
				restable = json.decode(response)
				if restable.code == "0" then
					imgCodeToken = restable.body.imgCodeToken
					getpcon = 105
				else
					resetWYX()
				end
			end
		elseif getpcon == 105 then	
			local url = 'https://app1.jegotrip.com.cn/api/user/v1/getCodeByImgCode?lang=zh_cn&n_token='
			..n_token..'&timestamp='..p_time..'&sign='..p_sign
			body_send = {}
			body_send["country_code"]= "86"
			body_send["mobile"]= Telnum
			body_send["imgCodeToken"] = imgCodeToken
			body_send["device_id"]= ""
			body_send["third_type"]= ""
			timeStamp = tostring(os.time()+28800)..tostring(math.random(100,999))
			body_send["timeStamp"]= timeStamp
			body_send["type"]= "0"
			signstr = "country_code=86&imgCodeToken="..imgCodeToken.."&mobile="..Telnum.."&sign_key=wuyouxing&key&&timeStamp="..timeStamp.."&type=0"
			body_send["sign"]= string.upper(stomsha1(signstr))
			body_send_js = json.encode(body_send)
			local code , resHeaders, response = stomhttpsPost(url, 10, requestHeaders, body_send_js)
			if code == 200 then
				restable = json.decode(response)
				if restable.code == "0" then
					getpcon = 106
				else
					resetWYX()
				end
			end
		elseif getpcon == 106 then
			stomLog("获取短信。。。")
			phonenumber = Telnum
			messg = stomSMS_GetSMS(UserID,UserKey,docks,phonenumber)
			if messg then
				stomLog(messg)
				yanzhenma = string.match(messg,"%d+")
				stomLog(yanzhenma)
				getpcon = 107
				t1 = os.time()
				fa = 0
			else
				stomLog("重新获取短信中"..Telnum)
			end
			fa = fa +1
			if fa == 3 then
				stomLog("获取短信失败6")
				getpcon = 101
				--stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
				--stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
				--upContentData(conmenttype,Telnum,ksuid,field2,field3,"nosms")
				--return 1
			end
			if fa > 16 then
				stomLog("获取短信失败")
				stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
				stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
				--upContentData(conmenttype,Telnum,ksuid,field2,field3,"nosms")
				return 1
			end
			stommSleep(5000)
		elseif getpcon == 107 then	
			local url = 'https://app1.jegotrip.com.cn/api/user/v1/verifyCodeByPhone?lang=zh_cn&n_token='
			..n_token..'&timestamp='..p_time..'&sign='..p_sign
			body_send = {}
			body_send["country_code"]= "86"
			body_send["mobile"]= Telnum
			body_send["verify_code"]= yanzhenma
			body_send["type"]= "2"
			body_send_js = json.encode(body_send)
			local code , resHeaders, response = stomhttpsPost(url, 10, requestHeaders, body_send_js)
			stomLog(response)
			if code == 200 then
				restable = json.decode(response)
				if restable.code == "0" then
					getpcon = 108
				-- else
				-- 	resetWYX()
				end
			end
		elseif getpcon == 108 then	
			local url = 'https://app1.jegotrip.com.cn/api/user/v1/phoneRegist?lang=zh_cn&n_token='
			..n_token..'&timestamp='..p_time..'&sign='..p_sign
			body_send = {}
			body_send["country_code"]= "86"
			body_send["mobile"]= Telnum
			body_send["password"]= "73cd66b8fe36d4ae7909d69063461a87"
			body_send["country_name"]= "中国"
			body_send_js = json.encode(body_send)
			local code , resHeaders, response = stomhttpsPost(url, 10, requestHeaders, body_send_js)
			if code == 200 then
				restable = json.decode(response)
				if restable.code == "0" then
					getpcon = 109
				else
					resetWYX()
				end
			end
		elseif getpcon == 109 then	
			local url = 'https://app1.jegotrip.com.cn/api/user/v1/phoneUserLogin?lang=zh_cn&n_token='
			..n_token..'&timestamp='..p_time..'&sign='..p_sign
			body_send = {}
			body_send["country_code"]= "86"
			body_send["mobile"]= Telnum
			body_send["password"]= "73cd66b8fe36d4ae7909d69063461a87"
			body_send["logintype"]= "1"
			body_send_js = json.encode(body_send)
			local code , resHeaders, response = stomhttpsPost(url, 10, requestHeaders, body_send_js)
			if code == 200 then
				stomLog(response)
				restable = json.decode(response)
				if restable.code == "0" then
					loginToken = restable.body.token
					getpcon = 110
				else
					resetWYX()
				end
			end
		elseif getpcon == 110 then	
			local url = 'https://app1.jegotrip.com.cn/api/user/v1/getUser?lang=zh_cn&n_token='
			..loginToken..'&timestamp='..p_time..'&sign='..p_sign
			body_send = {}
			body_send_js = json.encode(body_send)
			local code , resHeaders, response = stomhttpsPost(url, 10, requestHeaders, "{}")
			if code == 200 then
				stomLog(url)
				stomLog(response)
				-- restable = json.decode(response)
				-- if restable.code == "0" then
				-- 	loginToken = restable.body.token
				-- 	getpcon = 111
				-- else
				-- 	resetWYX()
				-- end
				getpcon = 4
			end


		elseif getpcon == 4 then
			upContentData(conmenttype,phonenumber,ksuid,idfa,nil,"1")
			return 0
		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 120 then
			return 1
		end
	end
end

function create_499819758_longtu()
	stomLog("create_499819758")
	local loop = 0
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	createpasswd = myRand(4,10,1)
	damauser,damapasswd = "zk1013","ekcom8888"
	docks1 = "14BAB4CC3190D6B"
	conmenttype = "startbuks"
	apple_appid = "499819758"
	
	getPhoneType = "ym"
	docks = "3394"
	
	local getpcon = 0
	local num = 0

	while (true) do	
		stomLog("获取号码。。。"..getpcon)
		if getpcon == 0 then
			check_Rules = 1
			Telnum, ksuid = stomSMS_GetPhone(UserID,UserKey,docks,province,city,operator,telnumsection,telback,gettype,check_Rules,checkPhonenum)
			if Telnum then
				checkcode = 1
				if checkcode == 0 then
					phonenumber = Telnum
					stomLog(Telnum)
					body_send = {}
					body_send["template"]="create-cn"
					body_send["phoneNumber"]=Telnum
					surl = "https://profile.starbucks.com.cn/api/sms/send"
					if sendStartbuks(body_send,surl) == 0 then
						getpcon = 1
						t1 = os.time()
					else
						--upContentData(conmenttype,Telnum,ksuid,errorxbk,field3,"needcheck")
						stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
						stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
						return 1
					end
				else
					stomSMS_FreePhone(UserID,UserKey,docks,phonenumber)
					stomSMS_AddBlackPhone(UserID,UserKey,docks,phonenumber)
					getpcon = 1
				end
			else
				stomLog("重新获取号码中")
				ksuidOK = "000"
				stommSleep(3000)
			end
			num = num + 1
			if num > 100 then
				--stomtoast("获取号码失败", 5)
				stomLog("获取号码失败")
				return 1
			end
		elseif getpcon == 1 then
			local url = "http://www.longtugame.com/active/ajax"
			body_send = {}
			body_send["email"]= lt_email
			body_send["phone"]= Telnum
			body_send["system"]="ios"--android
			body_send["parmtype"]="addyyinfo"
			body_send["activeid"]= "41"
			body_send["channel"]="jwhd"
			body_send["prize"]="m"
			body_send_js = json.encode(body_send)
			stomLog(body_send_js)

			requestHeaders={}
			requestHeaders["Accept"] = 'application/json, text/javascript, */*; q=0.01,*/*'
			requestHeaders["Content-Type"] = 'application/x-www-form-urlencoded; charset=UTF-8'
			requestHeaders["Origin"] = 'http://hero.longtugame.com'
			requestHeaders["Referer"] = 'http://hero.longtugame.com/t2/247/4899.html?channel=jwhd'
			requestHeaders["User-Agent"] = UA
			requestHeaders["Host"] = 'www.longtugame.com'
			requestHeaders["Accept-Encoding"] = 'gzip, deflate'
			local code , resHeaders, response = stomhttpsPost(url, 10, requestHeaders, body_send_js)
			stomLog(response)
			stomLog(code)


			return 0
		end



	end
end
function creat_1356464028()
	apple_appid = "1356464028"
	local conmenttype = "youka"
	local loop = 0
	local t1 = os.time()
	local getloop = 0
	local xiago = 0
	local num = 0
	local fa = 0
	local namecount = 0
	local pwcount = 0
	local creatcount = 0
	createpasswd = myRand(4,math.random(8,12),1)
	createnickname = myRand(4,math.random(8,12),1)
	while (true) do
		stomtoast("loop="..loop,1)
		if loop == 0 then
			stomMultiColorTap("知道了",{
					{  111,  501, 0xffe780},
					{  111,  637, 0xffe780},
					{  499, 1039, 0xfffaa2},
					{  517, 1037, 0xf9902d},
				})
			stomMultiColorTap("游卡",{
					{  196,  717, 0xfdf8f8},
					{  192,  700, 0xca5155},
					{  293,  379, 0xce2230},
					{  325,  761, 0xce2230},
					{  202,  583, 0xca5155},
				})
			stomMultiColorTap("立即注册",{
					{  174,  754, 0xcf2432},
					{  221,  375, 0xce2230},
					{  261,  761, 0xce2230},
					{  472,  509, 0x060606},
				})

			if stomMultiColor("注册登录",{
					{  233,  621, 0xffffff},
					{  219,  377, 0xce2230},
					{  261,  759, 0xce2230},
					{  472,  509, 0x060606},
					}) then
				loop = 1
			end
		elseif loop == 1 then
			if stomMultiColor("注册登录",{
					{  233,  621, 0xffffff},
					{  219,  377, 0xce2230},
					{  261,  759, 0xce2230},
					{  472,  509, 0x060606},
					}) then
				if stomColorInReg("name ok",0x060606, 90, 367, 423, 415, 473) then 
					namecount = 1
				end
				if stomColorInReg("pw ok",0x000000, 90, 307, 419, 329, 471) then 
					pwcount = 1
				end
				if namecount == 1 and pwcount == 1 then
					loop = 2
					t1 = os.time()
				end
				if namecount == 0 then
					stomInpuTextTap(createnickname, 391,  432, 3)
					stommSleep(500)
					stomMultiColorTap("画面",{
							{  545,  235, 0xf74a4e},
						})
				end
				if pwcount == 0 then
					stomInpuTextTap(createpasswd, 319,  434, 3)
					stommSleep(500)
					stomMultiColorTap("画面",{
							{  545,  235, 0xf74a4e},
						})
				end
			else
				stomMultiColorTap("画面",{
						{  545,  235, 0xf74a4e},
					})
			end
		elseif loop == 2 then
			if stomMultiColorTap("注册登录",{
					{  233,  621, 0xffffff},
					{  219,  377, 0xce2230},
					{  261,  759, 0xce2230},
					{  472,  509, 0x060606},
					}) then
				creatcount = creatcount + 1
				stommSleep(5000)
			end
			if creatcount > 5 then
				return 1
			end
			stomMultiColorTap("进入游戏",{
					{  113,  469, 0xf8be32},
					{  121,  565, 0xfed43f},
					{   79,  673, 0xe58217},
				})
		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > 600 then
			return 0
		end

	end
end

function creat_benpao()
	randname = ZKQ_Word(zhangkq["姓氏"],1,1)..ZKQ_Word(zhangkq["名字"],math.random(2,4),math.random(2,4))
	local t1 = os.time()
	local loop = 0
	while (true) do
		--stomLog("loop="..loop)
		stomMultiColorTap("我的奖品",{
			{  303,  973, 0xffffff},
			{  249,  855, 0xfcb233},
			{  459,  209, 0xffc841},
			{  477,  893, 0x3d86b3},
		})
		if loop == 0 then
			stomMultiColorTap("开始游戏",{
				{  213, 1009, 0xfeb437},
				{  277, 1023, 0xffb83d},
				{  199, 1037, 0xffb83d},
			})
			stomMultiColorTap("跳过",{
				{  571,  215, 0x99c2d5},
				{  553,  179, 0x368ab7},
				{  491,  229, 0x55a5c7},
				{  605,  215, 0x398cb5},
			})
			stomMultiColorTap("愿意",{
				{  309,  995, 0xffb83d},
				{  213,  983, 0xfcb132},
				{  409, 1007, 0xfdb437},
			})
			if stomMultiColorTap("不虚跑你输入",{
				{  279,  781, 0xffffff},
				{  239, 1013, 0x5dcfff},
				{  181,  781, 0xffc642},
				{  407, 1027, 0x5dcfff},
			}) then
				stommSleep(500)
			end
			stomMultiColorTap("未输入确认",{
				{  369,  781, 0xffb83c},
				{  267,  785, 0xffb83c},
				{  233,  637, 0xffffff},
				{  121,  655, 0xfac42a},
			})
			if stomMultiColor("输入框有键盘",{
				{  181,  173, 0xffc642},
				{  453,  189, 0xffc642},
				{  233,  435, 0x5dcfff},
				{  405,  433, 0x5dcfff},
			}) then
				stommSleep(500)
				if stomColorInReg("已输入", 0x000000, 90, 255, 167, 375, 199) then
					stomLog("已输入")
					stomMultiColorTap("不虚跑你",{
						{  315,  423, 0x5dcfff},
						{  235,  437, 0x5dcfff},
						{  403,  437, 0x5dcfff},
					})
					loop = 1
					t1 = os.time()
				else
					if stomMultiColorTap("准备输入",{
						{  309,  187, 0xffffff},
						{  235,  429, 0x5dcfff},
						{  401,  433, 0x5dcfff},
						{  449,  173, 0xffc642},
					}) then
						stommSleep(1000)
						stomInpuText(randname)
					end
				end
			end	
		elseif loop == 1 then
			local randcount = math.random(0,1)
			
			stomMultiColorTap("不虚跑你",{
				{  180+randcount*290, 1013, 0xffffff},
				{  215, 1015, 0xffb83d},
				{  433, 1013, 0x5dcfff},
			})
			if stomMultiColorTap("盒子",{
				{  215,  249, 0xfac42a},
				{  177,  305, 0xff3c30},
				{  585,  247, 0x2877a2},
				{  229,  411, 0xff3c30},
			}) then
				stomtap(321, 1033)
				loop = 2
				t1 = os.time()
			end
			stommSleep(math.random(1000,3000))
		elseif loop == 2 then
			if stomMultiColorTap("盒子",{
				{  215,  249, 0xfac42a},
				{  177,  305, 0xff3c30},
				{  585,  247, 0x2877a2},
				{  229,  411, 0xff3c30},
			}) then
				stomtap(321, 1033)
			end
			if stomMultiColorTap("go",{
				{  313,  593, 0xf4341a},
				{  121,  961, 0xff553b},
				{  455,  953, 0xfeb638},
			}) then
				stommSleep(3000)
			end
			if stomMultiColor("保存秀一波",{
				{  185,  823, 0x2dbbfa},
				{  455,  799, 0xffb83a},
				{  475,  325, 0xffc841},
				{  443,  377, 0x3d86b3},
			}) then
				return 0
			end
		end
		stommSleep(100)
		t2 = os.time()
		if os.difftime(t2,t1) > 120 then
			return 0
		end
	end
end
function tap_1420407553()   ----------白菜二手车
	local t1 = os.time()
	for var= 1, 4 do
		if stomMultiColorTap("下一步",{
				{  321,  975, 0xfebe09},
				{  156,  823, 0x0354ed},
				{  300,  776, 0xfffdf6},
				{  311,  964, 0xfffdf6},
				{  448,  745, 0x2b8ede},
				}) then
			stommSleep(500)
		else 
			for var= 1, 4 do
				stommoveTo(441,  928, 188,  920)
				stommSleep(300)
			end
		end
		stommSleep(3000)
		t2 = os.time()
		if os.difftime(t2,t1) > 60 then
			return 0
		end
	end
end
function tap_424598114()   --苏宁易购
	local t1 = os.time()
	for var= 1, 4 do
		if stomMultiColorTap("同意",    {{  501, 1079, 0xff5800},
			{  383, 1079, 0xff7800},
			{  267, 1071, 0xf2f2f2},
			{  115, 1069, 0xf2f2f2},
			{  575, 1071, 0xff4100},}) then
			stommSleep(500)
		else 
			for var= 1, 4 do
				stommoveTo(441,  928, 188,  920)
				stommSleep(300)
			end
		end
	end
end
function tap_559977766()   --懒人听书
	local t1 = os.time()
	for var= 1, 4 do
		if stomMultiColorTap("同意",    {{  501, 1079, 0xff5800},
			{  383, 1079, 0xff7800},
			{  267, 1071, 0xf2f2f2},
			{  115, 1069, 0xf2f2f2},
			{  575, 1071, 0xff4100},}) then
			stommSleep(500)
		else 
			for var= 1, 4 do
				stommoveTo(441,  928, 188,  920)
				stommSleep(300)
			end
		end
	end
end
function tap_436957087()   --搜狐新闻
	local t1 = os.time()
	local loop = 1
	local outtime = math.random(400,600)
	while (true) do
		stomLog("loop="..loop)
		if loop == 1 then
			if stomMultiColorTap("同意",{
				{  457,  961, 0xee2f10},
				{  435,  965, 0xffffff},
				{  501,  973, 0xffffff},
				{  591,  144, 0xfd472c},
				{  603,  135, 0x4a1a01},
			}) then
				loop = 2
			end
		elseif loop == 2 then
			if stomMultiColorTap("新闻红",{
				{  103, 1073, 0xfe5e2d},
				{  115, 1089, 0xf23e1e},
			}) or stomMultiColorTap("新闻红2",{
				{   97, 1061, 0xfb5a2b},
				{  117, 1079, 0xf34421},
				{   87, 1077, 0xf44721},
			}) then
				stommSleep(5000)
				stomColorInRegTap("字", 0x000000, 90, 295, 667, 467, 907)
				stommSleep(2000)
			end
--			if stomColorInReg("字", 0x000000, 90, 155, 347, 507, 973) then
				if stomMultiColor("返回",{
					{   37, 1081, 0x4e4e4e},
					{   37, 1102, 0x4e4e4e},
					{   45, 1095, 0xffffff},
				}) or stomMultiColor("返回2",{
					{   44, 1083, 0x454545},
					{   45, 1103, 0x454545},
					{   49, 1095, 0xffffff},
				}) or stomColorInReg("返回3", 0x4e4e4e, 90, 9, 1037, 91, 1135) then
					loop = 3
				end
--			else
--				stommSleep(2000)
--			end
		elseif loop == 3 then
			local num = math.random(3,10)
			for i=1,num do
				stommSleep(math.random(1,10)*1000)
				stommoveTo(277, 859, 277, 779)
				stommSleep(math.random(1,10)*1000)
			end
			loop = 4
		elseif loop == 4 then
			stomMultiColorTap("返回",{
				{   37, 1081, 0x4e4e4e},
				{   37, 1102, 0x4e4e4e},
				{   45, 1095, 0xffffff},
			})
			stomMultiColorTap("返回2",{
				{   44, 1083, 0x454545},
				{   45, 1103, 0x454545},
				{   49, 1095, 0xffffff},
			})
			stomColorInRegTap("返回3", 0x4e4e4e, 90, 9, 1037, 91, 1135)
			if stomMultiColorTap("新闻红",{
				{  103, 1073, 0xfe5e2d},
				{  115, 1089, 0xf23e1e},
			}) or stomMultiColorTap("新闻红2",{
				{   97, 1061, 0xfb5a2b},
				{  117, 1079, 0xf34421},
				{   87, 1077, 0xf44721},
			})then
				loop = 2
			end
		end
		
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > outtime then
			return 0
		end
	end
end

function tap_1466585545()		--精灵盛典
	stomLog("randcreate="..randcreate)
	apple_appid = "1466585545"
	local loop = 100
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	local issms = 0
	local mima1 = 0
	local mima2 = 0
	local timeout = 60
	createpasswd = myRand(4,10,1)
	conmenttype = "JingLingShengDian"
	
	getPhoneType = "dm"
	docks = "18634"
	needcheck = 0
	
	while (true) do
		if randcreate > 4 then
			return
		end
		stomMultiColorTap("游客登录",{
			{  145,  772, 0xffffff},
			{  213,  417, 0x71c7f2},
			{  201,  725, 0x70c4f2},
			{  305,  341, 0x353535},
			{  397,  345, 0x353535},
		})
		stomMultiColorTap("确认",{
			{  105,  489, 0xbf9a61},
			{  115,  663, 0xc7a268},
			{  577,  831, 0x5b2423},
			{  565,  519, 0x422d2a},
		})
		stomMultiColorTap("登录",{
			{  169,  516, 0xeee5b8},
			{  157,  547, 0xaf8e62},
			{  520, 1072, 0xedd88f},
			{  595, 1077, 0xead98d},
		})
		if stomMultiColorTap("创建",{
			{   73,  955, 0xe5cf93},
			{   69, 1038, 0xb39262},
			{  149, 1085, 0xd3b78a},
		}) then
			stommSleep(10*1000)
			return
		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > timeout then
			return 1
		end
	end
end
function tap_1436135312()   ----------一刀传世
	local t1 = os.time()
	local timeout = 60
	stomLog("randcreate="..randcreate)
	while (true) do
		if randcreate > 4 then
			return
		end
		stomMultiColorTap("账号注册",{
			{  516,  795, 0x555555},
			{  537,  800, 0x8e8e8e},
			{  594,  755, 0xf27241},
			{  342,  420, 0xf16144},
			{  155,  339, 0x0099ff},
		})
	
		stomMultiColorTap("立即注册",{
			{  384,  731, 0xf27241},
			{  278,  724, 0xfbcebd},
			{  579,  497, 0xffffff},
			{  256,  409, 0xf86049},
		})
		stomMultiColorTap("注册成功",{
			{  274,  788, 0x408ed6},
			{  257,  791, 0x99c3ea},
			{  575,  579, 0xff672c},
			{   74,  448, 0xff672c},
			{  197,  490, 0xffffff},
		})
	
		stomMultiColorTap("取消Game",{
			{   46,   38, 0x5856d6},
			{   41,   29, 0xacaae4},
			{   80,   44, 0x5856d6},
			{   88,   32, 0x7a77dc},
			{  294,   49, 0x000000},
			{  302,   58, 0x676463},
		})
		if stomMultiColorTap("选服进入游戏",{
			{  323,  899, 0xb3962d},
			{  287,  941, 0x6d4818},
			{  413,  911, 0x7f6222},
		}) then
			stommSleep(3000)
			--stomsnapshotfull("Documents/main.png")  	
			return
		end
		stommSleep(1000)
		t2 = os.time()
		if os.difftime(t2,t1) > timeout then
			return 
		end
	end
end
function tap_1322451426()		--鬼语迷城
	stomLog("randcreate="..randcreate)
	apple_appid = "1322451426"
	local loop = 100
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	local issms = 0
	local mima1 = 0
	local mima2 = 0
	local timeout = 60
	createpasswd = myRand(4,10,1)
	conmenttype = "JingLingShengDian"
	
	getPhoneType = "dm"
	docks = "18634"
	needcheck = 0
	
	while (true) do
		if randcreate > 4 then
			return
		end
		
		stomMultiColorTap("职业",{
			{   61,  385, 0x857e75},
			{   70,  501, 0x948e86},
			{   77,  744, 0xa7a39c},
		})
		if stomMultiColorTap("游客登录",{
			{  105,  809, 0xffffff},
			{  229,  287, 0xf9633d},
			{  165,  850, 0xff9a32},
			{  411,  815, 0x515151},
		}) then
			stommSleep(10000)
			return
		end
		stommSleep(500)
		t2 = os.time()
		if os.difftime(t2,t1) > timeout then
			return 
		end
	end
end
function tap_1452958918()		--biubiu加速器
	stomLog("randcreate="..randcreate)
	apple_appid = "1452958918"
	local loop = 100
	local t1 = os.time()
	local creatcon = 0
	local getloop = 0
	local yanzm = 0
	local num = 0
	local fa = 0
	local issms = 0
	local mima1 = 0
	local mima2 = 0
	local timeout = 30
	createpasswd = myRand(4,10,1)
	
	getPhoneType = "dm"
	docks = "18634"
	needcheck = 0
	
	while (true) do
		
		stomColorInRegTap("tyi", 0x545fff, 90, 271, 835, 367, 893)
		if stomMultiColorTap("游客登录",{
			{  103, 1065, 0x5470ff},
			{   99, 1087, 0x546dff},
			{  393,  593, 0x4c74ff},
		}) then
			return
		end
		stommSleep(1000)
		t2 = os.time()
		if os.difftime(t2,t1) > timeout then
			return 
		end
	end
end
function SW1282917929_fn_update()
	SW1282917929_fn_tankuang()
end

function downAndTarResFile(nowresver,tarPath,tarfiles)
	if updateRes_ver == nowresver then
		stomLog(nowresver);
		stomLog("eventlog ok")
		stomcloseApp(apple_bid)
		stommSleep(2000)
		--local cmd = "cd "..stomgetSandboxPath(apple_bid).."/Documents/;tar -cf "..ShenwuRespath.." Resources ini/config.ini Data/data.fls;"
		local cmd = "cd "..stomgetSandboxPath(apple_bid).."/Documents/;tar -cf "..tarPath.." "..tarfiles
		stomLog(cmd)
		System.execute(cmd)
		stomLogPUT("下载更新完成",0)
		os.exit()
	end
	stomLog("nowresver="..nowresver)
end

function download_updateRes()
	stomLog("download_updateRes...")
	ShenwuRespath = updateRespath
	sandPath = stomgetSandboxPath(apple_bid) 
	stomdelFile(sandPath.."/Documents/ini")
	setvpn("discon")
	local t1 = os.time()
	while (true) do
		stomtoast("正在下载更新",2)
		OpenApp(apple_bid)
		if apple_bid == "com.duoyi.shenwu3" then
			SW1282917929_fn_update()
			if stomisFileExist(sandPath.."/Documents/ini/config.ini") then
				local t = stomreadFileToTbale(sandPath.."/Documents/ini/config.ini")
				for i =1,#t do
					local nows = stomsplit(t[i],"=")
					if nows[1] == "Version" then
						nowver = string.match(nows[2],"%d+.%d+.%d+")
					end
				end
				local nowresver = nowver
				local tarfiles = "Resources ini/config.ini Data/data.fls;"
				downAndTarResFile(nowresver,updateRespath,tarfiles)
			end
		
		
		
		
		end
		stommSleep(5000)
		local t2 = os.time()
		if os.difftime(t2,t1) > 20*60 then
			stomLog("eventlog 15分钟")
			os.exit()
		end
	end
end

function tar_updateRes()
	stomLog("tar_updateRes..."..updateRes_ver)
	if updateRes_ver ~= "1" then
		local ShenwuRespath = updateRespath
		local sandPath = stomgetSandboxPath(apple_bid) 
		local t1 =os.time()
		stomcloseApp(apple_bid)
		local cmd = "tar -xf "..ShenwuRespath.. " -C "..sandPath.."/Documents"
		System.execute(cmd)
		stommSleep(2000)
		local t = stomreadFileToTbale(sandPath.."/Documents/ini/config.ini")
		for i =1,#t do
			local nows = stomsplit(t[i],"=")
			if nows[1] == "Version" then
				nowver = string.match(nows[2],"%d+.%d+.%d+")
			end
		end
		if updateRes_ver== nowver then
			stomLog(nowver);
			return 0
		else
			stomLogPUT("升级包不匹配",1)
			stomLog("升级包不匹配")
			stomdelFile(ShenwuRespath)
			os.exit()
		end
--		while (true) do
--			if stomisFileExist(ShenwuRespath) then
--				stomcloseApp(apple_bid)
--				local cmd = "tar -xf "..ShenwuRespath.. " -C "..sandPath.."/Documents"
--				System.execute(cmd)
--				stommSleep(2000)
--				local t = stomreadFileToTbale(sandPath.."/Documents/ini/config.ini")
--				local nows = t[2]
--				if nows then
--					nowver = string.match(nows,"%d+.%d+.%d+")
--				end
--				if newver== nowver then
--					stomLog(nowver);
--					return 0
--				end
--			end
--			stommSleep(5000)
--			local t2 = os.time()
--			if os.difftime(t2,t1) > 10*60 then
--				stomLog("unzip超过5分钟")
--				os.exit()
--			end
--		end
	end
end

function check_updateRes()
	updateRes_ver = taskConfigTable["ipaVer"]
	local logfile = stomgetList("/private/var/mobile/Media/Slion")
	if #logfile > 5 then
		for i,v in ipairs(logfile) do
			if v ~= apple_appid.."_"..updateRes_ver.."_res.tar" then
				local path = "/private/var/mobile/Media/Slion/"..v
				stomdelFile(path)
			end
		end
	end
	
	if updateRes_ver == "1" then
		return true
	else
		updateRespath = "/User/Media/Slion/"..apple_appid.."_"..updateRes_ver.."_res.tar"
		sandPath = stomgetSandboxPath(apple_bid) 
		if stomisFileExist(updateRespath) then
			stomLog("checkupdateRes...OK")
			return true
		else
			if download_updateRes() then
				return true
			end
		end
	end
	return false
end

function delAppResourcesFile()
	stomLog("delAppFile")
	stomLogPUT("delAppFile",0)
	local sandPath = stomgetSandboxPath(apple_bid)
	if apple_appid == "1282917929" then
		System.execute2("/bin/rm -rf "..sandPath.."/Documents/Resources")
		System.execute2("/bin/rm -rf "..sandPath.."/Documents/Data")
	end
end
function touchAPP()
	stomLog("touchAPP...");
	if appbid == "com.ci123.yunqiphone" then	--妈妈社区
		for i = 1 , 3 do
			stommoveTo(393,  639, 203,  627, 10)
			stommSleep(500)
			stomtap(435,  843)
			stommSleep(500)
		end
	end
	--if appbid == "com.baidu.BaiduMobile" then	--baidu
	stomMultiColorTap("温馨提示",{
	{  433,  861, 0x3c76f1},
	{  219,  858, 0xffffff},
	{  242,  926, 0x595959},
	{  197, 1031, 0x4f0200},
	})
	stomMultiColorTap("昵称功能闪亮登场",{
		{  320,  891, 0x595959},
		{  328,  786, 0xffffff},
		{  318,  737, 0x5681ff},
		{  185, 1074, 0x383838},
	})
	stomMultiColorTap("广告弹窗",{
		{  320,  954, 0x808080},
		{  188, 1074, 0x515151},
		{   80, 1079, 0x191919},
		{  321,  193, 0x141970},
		{  395,  191, 0x700301},
	})
	stomMultiColorTap("同意",{
		{  355,  827, 0x3c76f1},
		{  517,  845, 0x3c76f1},
		{  251,  839, 0xffffff},
	})
	--end
	
	
	
	if appbid == "com.58.pricecar" then	--白菜二手车
		tap_1420407553()
	elseif appbid == "SuningEMall" then	--苏宁易购
		tap_424598114()
	elseif appbid == "com.yytingting.iting" then
		tap_559977766()		--懒人听书
	elseif appbid == "com.sohu.newspaper" then
		tap_436957087()		--搜狐新闻
	elseif appbid == "com.sy.jlsd.sy" then
		tap_1466585545()	--精灵盛典
	elseif appbid == "com.jgcp.ydcs" then
		tap_1436135312()   	--一刀传世
	elseif appbid == "com.sgt.gymc" then	
		tap_1322451426()		--鬼语迷城
	elseif appbid == "com.njh.biubiu.cn" then
		tap_1452958918()		--biubiu加速器
	end
	
	if appbid == "com.tuniu.app" then	--途牛旅游
		stomColorInRegTap("同意",0x32c45d, 90, 429, 955, 641, 1139)
		if stomColorInReg("同意2",0x32c45d, 90, 335, 721, 397, 757) then
			stomtap(800,  1650)
		end
	end
	
end



function creatTaskSlion()
	stomLog(appbid);
	stomLog("creatTaskSlion...");
	--[[
	if appbid == "SuningEMall" then
		status = create_424598114()
	elseif appbid == "com.liulishuo.engzo2" then
		needcheck = 1
		--status = create_597364850_60ma()
		if isdau == 1 then
			status = create_597364850_60ma()
		else
			status = create_597364850()	
		end
	elseif appbid == "com.alibaba.wireless" then
		status = create_507097717()
	elseif appbid == "com.liulishuo.Telis" then
		status = create_1153192044()
	elseif appbid == "com.nhnent.SKQUEST" then
		status = create_901858272()
	elseif appbid == "com.openet.gtgj" then
		status = create_515199321()
	elseif appbid == "com.yuzhou.knowyou" then
		status = create_1329364068()
	elseif appbid == "com.soyoung.qingyang.medical" then
		status = create_1322331084()
	elseif appbid == "com.taobao.taobao4iphone" then		--淘宝-注册
		status = create_387682726()
	elseif appbid == "com.HSW.AkilometerNews" then		--二三里-注册
		status = create_1164831301()
	elseif appbid == "com.starbuckschina.mystarbucksmoments.cpa" then		--星巴克中国-注册
		status = create_499819758_longtu()
	elseif appbid == "com.zmlearn.ZMParent" then--掌门家长-注册
		status = create_1288910541()
	elseif appbid == "com.bz365.iOS" then--大象保险
		status = create_1064779641()
		status = 0
	elseif appbid == "com.xiaoyatech-project-V1.manager-mingbai" then--知识圈-注册
		status = create_1329890841()
	elseif appbid == "com.amgtec.DaKa" then--打卡助手	
		status = create_563091001()					
	elseif appbid == "game.xin.hd.free" then--星城	
		status = create_919043762()	
	elseif appbid == "com.yuntao.miaojie" then	--喵街注册
		status = creat_976048109()
	elseif appbid == "com.cmi.jegotrip" then--无忧行
		status = create_1037589370()
	elseif appbid == "com.sanguosha.mjz" then--三国杀名将传
		status = creat_1356464028()
	else]]
	if appbid == "com.duoyi.shenwu3" then--神武3-注册
		status = create_1282917929_main()
		--status = 0

	end
	
	return status
end
--[[
function luaStart()
	status = 1
	xtbcon = 1
	Telnum = "0"
	createpasswd = "0"
	UserID, UserKey, docks= "45701","1DE9040BA593C651A470","F7E2BEBD74DFCC4"
	provinceOK = "000"
	ksuidOK = "000"
	t1 = os.time()
	appbid = stomgetBid()
	TaskInfo = stomgetTaskInfo()
	taskname = TaskInfo["taskname"]
	fakeos = TaskInfo["OS"]
	idfa = TaskInfo["idfa"]
	tasktype = TaskInfo["tasktype"]
	isdau = TaskInfo["isdau"]
	appVersion = TaskInfo["appVersion"]
	devmodel = TaskInfo["model"]
	stomLog(json.encode(TaskInfo))
	apple_bid = appbid
	math.randomseed(tonumber(tostring(os.time()):reverse():sub(1,6))) 
	randcreate = math.random(1,10)
	math.randomseed(tonumber(tostring(os.time()):reverse():sub(1,6))) 
	if tasktype == 0 then
		opentime = TaskInfo["loopnum"]+10
	else
		opentime = math.random(30,60)
	end
	
	status = create_1037589370()

	if string.find(taskname,"-注册") and tasktype == 0 then
		status = creatTaskSlion()
		status = creatTask()
	else
		status = 0
	end
	if status == 0 then
		while (true) do
			stomLog("wati...")
			t2 = os.time()
			touchAPP()
			if os.difftime(t2,t1) >= opentime then
				return 0
			end
			stommSleep(2*1000)
		end
	end
end

function main()
	-- stommSleep(5*1000);
	-- stommSleep(10*1000)
	-- stomsnapshotfull("Documents/main.png")
	luaStart()
	stomLog("####################==========>SLion LUA END <==========###################")
	Telnum2 = Telnum or "0"
	createpasswd2 = createpasswd or "0"
	status2 = status or "0"
	if status2 ~= 0 then
		Telnum2 = 0
		createpasswd2 = 0
	end
	okmsg = status2.."@"..Telnum2.."@"..createpasswd2
	stomLog(okmsg)
	stomLuDone(okmsg)
end]]

function nnnnnn()
end


