bb = require("badboy")
json = bb.getJSON()
strutils = bb.getStrUtils()
bb.loadluasocket()
http = bb.http
ltn12 = bb.ltn12
function getDeviceID()
	local t = stomgetDeviceInfo()
	return t['UDID']
end
function stomsha1(str)
	return str:sha1(str)
end

function strtomd5(str)
	return str:md5(str) 
end

function mSleep(time)
	return Thread.sleep(time)
end

function touchDown(id,tx,ty);
	return Touch.down(id,tx,ty);
end

function touchUp(id,tx,ty);
	return Touch.up(id,tx,ty);
end

function touchMove(id,tx,ty)
	return Touch.move(id,tx,ty);
end
function toast(text,time)
	local str = text or ""
	local t = time or 2
	local msg = str.."@"..t
	return System.toast(text,time);
end
function findMultiColorInRegionFuzzy(color1, colors, p, x0, y0, x1, y1)
	return Screen.findMultiColorInRegionFuzzy(color1, colors, p, x0, y0, x1, y1);
end
function findColorInRegionFuzzy(color, p, x0, y0, x1, y1)
	return Screen.findColorInRegionFuzzy(color, p, x0, y0, x1, y1);
end
function keepScreen()
	return 0
end

function nLog(msg)
	--msg = msg or "msg nil"
	--System.log(msg);
	return 0
end
function lua_restart()
	return 0
end
function strSplit(str, reps)
	local resultStrList = {}
    string.gsub(str,'[^'..reps..']+',function ( w )
        table.insert(resultStrList,w)
    end)
    return resultStrList
end
function stringToList(str)
	k = string.len(str)
	list1={}
	for i=1,k do
		list1[i]=string.sub(str,i,i)
	end
	return list1
end
function stomgetDeviceInfo()
	local s = System.getDeviceInfo()
	return json.decode(s)
end
function stomplistRead(path)
	local s = System.plistRead(path)
	return json.decode(s)
end
function stomplistWrite(str,path)
	return System.plistWrite(path,str)
end
function stomuploadZip(url,appid,path)
	return System.uploadZip(url,appid,path)
end
function stomdownloadZip(url,appid,path)
	return System.downloadZip(url,appid,path)
end
function stomdownloadFile(url,path)
	--code=STask.afDownloadFile
	return STask.afDownloadFile(url,path)
end
function stomduploadFile(url,path)
	--code = STask.afDownloadFile
	return STask.afUploadFile(url,path)
end
function stominstallDeb(path)
	local cmd = "/usr/bin/dpkg -i "..path
	System.execute2(cmd)
end
function stomopenURL(url)
	return System.openURL(url)
end
function stomcleanSafariCaches()
	System.execute("/usr/bin/STask -cleanSafariCaches");
end
function stomgetappBundlePath(bid)		--获取 app 应用路径
	return System.appBundlePath(bid)
end
function stomgetSandboxPath(bid)
	return System.appDataPath(bid)		--获取沙盒路径
end
function stomgetBid()
	return System.getBid()
end
function stomrunApp(bid)
	return System.runApp(bid)
end
function stomcloseApp(bid)
	return System.closeApp(bid)
end
function stomisFrontApp(bid)
	return System.isFrontApp(bid)
end

function stomcheckAppisInstall(bid)
	return System.checkAppisInstall(bid)
end

function stomcheckAPPisInstalled(bid)
    return System.checkAPPisInstalled(bid)
end

function stomgetTaskInfo()
	local str = System.getTaskInfo();	--获取任务信息字符串，用@ 分割
	--stomLog(str)
	return json.decode(str)
end

--点击
function stomtap(x,y)
	tx,ty = x+math.random(-2,2), y+math.random(-2,2)
	mSleep(math.random(10,50))
	touchDown(1,tx,ty);
	mSleep(math.random(10,50));
	touchUp(1,tx,ty);
end
function tap(x,y)
	tx,ty = x+math.random(-2,2), y+math.random(-2,2)
	mSleep(math.random(10,50))
	touchDown(1,tx,ty);
	mSleep(math.random(10,50));
	touchUp(1,tx,ty);
end
function randrd(a1,a2)
	rns=rns or 0  --用于精确随机种子
	rns=rns+1
	math.randomseed(tostring(os.time()):reverse():sub(1, 6))
	local rd = math.random(a1,a2)
	return rd
end

function stomtrim(s) 
  return (string.gsub(s, "^%s*(.-)%s*$", "%1")) 
end
function stomdelFile(path) 
  return System.execute2("/bin/rm -rf "..path)
end
function stomsplit(str, delimiter)
	local result = {}
	if str==nil or str=='' or delimiter==nil then
	    return result
	end
	for match in (str..delimiter):gmatch("(.-)"..delimiter) do
	    table.insert(result, match)
	end
	return result
end

function stommoveTo(x1,y1,x2,y2)
--	touchDown(1, x1, y1+  randrd(5, 10));
--	mSleep(math.random(50, 200));
--	local i = x1
--	while (true) do
--		local s = randrd(5, 10)
--		xi1 = i +  randrd(20, 30)
--		yi1 = y1 + randrd(-5,5)
--		xi2 = i +  randrd(20, 30)
--		yi2 = y1 + randrd(-5,5)
--		i = xi1
--		y1 = yi1
--		if i >= x2 then
--			break
--		end
--		mSleep(math.random(10, 20));
--		touchMove(1, xi1,yi1); 
--	end
--	touchUp(1, xi1,yi1);
	touchDown(1, x1, y1);
	mSleep(20);
	touchMove(1, x2,y2); 
	mSleep(20);
	touchUp(1, x2,y2);
	mSleep(20);
end
function swip(x1,y1,x2,y2)
	local step, x, y, index = 20, x1 , y1, math.random(1,5)
	touchDown(index, x, y)
	local function move(from, to) 
		if from > to then
			return -1 * step 
		else 
			return step 
		end 
	end
	while (math.abs(x-x2) >= step) or (math.abs(y-y2) >= step) do
		if math.abs(x-x2) >= step then x = x + move(x1,x2) end
		if math.abs(y-y2) >= step then y = y + move(y1,y2) end
		touchMove(index, x, y)
		mSleep(20)
	end
	touchMove(index, x2, y2)
	mSleep(30)
	touchUp(index, x2, y2)
end
function moveToMulti222(x1,y1,x2,y2)
	touchDown(1, x1, y1+  randrd(0, 5));
	--touchDown(2, x1+  randrd(5, 10), y1+  randrd(5, 10));
	mSleep(math.random(50, 200));
	local i = x1
	while (true) do
		local s = randrd(5, 10)
		xi1 = i +  randrd(5, 10)
		yi1 = y1 + randrd(-5,5)
		xi2 = i +  randrd(5, 10)
		yi2 = y1 + randrd(-5,5)
		i = xi1
		y1 = yi1
		
		xok = math.abs(i-x2)
		yok = math.abs(i-x2)
		if i >= x2 then
			break
		end
		mSleep(math.random(20, 50));
		touchMove(1, xi1,yi1); 
		--touchMove(2, xi2,yi2); 
	end
	mSleep(math.random(500, 1000));
	touchUp(1, xi1,yi1);
	--touchUp(2, xi2,yi2); 
end
--延时
function stommSleep(time)
	return mSleep(time)
end

function stomwriteFile(fileName,content,mode)
	local mode = mode or "w"	--默认是清空写入模式 "w",追加写入模式 "a"
    local f = assert(io.open(fileName,mode))
    f:write(content)
    f:close()
end

function stomisFileExist(file_name)--指定文件是否存在
	stommSleep(1000)
	local f = io.open(file_name, "r")
	if f ~= nil then
		f:close()
		return true
	else
		stomLog("no file:" ..file_name)
		return false
	end
end

--将指定文件中的内容按行读取
function stomreadFileToTbale(path)
    local file = io.open(path,"r");
    if file then
        local _list = {};
        for l in file:lines() do
            table.insert(_list,l)
        end
        file:close();
        return _list
    end
end
--list = readFile(userPath().."/lua/main.lua");
function stomgetSystem(cmd)
	local currentVersion  = io.popen(cmd)
	local cv = currentVersion:read("*a")
	currentVersion:close()
	return cv
end
--遍历文件
function stomgetList(path)
    local a = io.popen("ls "..path);
	local f = {};
	if a then
		for l in a:lines() do
			table.insert(f,l)
		end
	end
	return f
end
--日志
function stomLogPUT(msg,t)
	local msg = msg or "msg nil"
	msgs = tostring(msg)
	local msgtype = t or 0	--0是绿色，1是红色
	if t == 3 then
		msgs = msgs
		t = 1
	else	
		msgs = os.date("%m-%d %H:%M:%S ",os.time())..msgs
	end
	System.putLog(msgs,msgtype)
end
function stominitLog(logName)
	stomwriteFile(logName,msg.."\n", "a")
end

function stomLog(msg)
	msg = msg or "msg nil"
	msg = tostring(msg)
	if kaifa == "1" then
		--nLog(msg)
		stomwriteFile(logName,os.date("%Y-%m-%d %H:%M:%S ",os.time())..msg.."\n", "a")
	end
end
function converRGB2Hex(rc,gc,bc)
	local color={r=rc,g=gc,b=bc}
	local str = ""
	if string.len(string.sub(string.format("%#x",color.r),3)) == 1 then
		rstr = str.."0"..string.sub(string.format("%#x",color.r),3)
	elseif string.len(string.sub(string.format("%#x",color.r),3)) == 0 then
		rstr = "00"
	else
		rstr = str..string.sub(string.format("%#x",color.r),3)
	end
	if string.len(string.sub(string.format("%#x",color.g),3)) == 1 then
		gstr = str.."0"..string.sub(string.format("%#x",color.g),3)
	elseif string.len(string.sub(string.format("%#x",color.g),3)) == 0 then
		gstr = "00"
	else
		gstr = str..string.sub(string.format("%#x",color.g),3)
	end
	if string.len(string.sub(string.format("%#x",color.b),3)) <= 1 then
		bstr = str.."0"..string.sub(string.format("%#x",color.b),3)
	elseif string.len(string.sub(string.format("%#x",color.b),3)) == 0 then
		bstr = "00"
	else
		bstr = str..string.sub(string.format("%#x",color.b),3)
	end
	return	tostring("0x"..rstr..gstr..bstr)
end
function getColorRGB(x, y)
	local r,g,b = Screen.getColorRGB(x, y)
	if r and g and b then
		return r,g,b
	else
		stomLog("getColorRGB nil")
		return -1, -1, -1
	end
end
function getColor(x,y)
	local r,g,b = Screen.getColorRGB(x, y)
	return converRGB2Hex(r,g,b)
end
-- 函数:多点比色点击
function stomMultiColorTap(msg1,array1,px,py,tm)
	if type(array1) == 'table' then
		array = array1
		msg = msg1
	else
		array = msg1
		msg = array1
	end
	local s=85
	local tm = tm or 50
	local px = px or 0
	local py = py or 0
	s = math.floor(0xff*(100-s)*0.01)
	keepScreen(true)
	for var = 1, #array do
		local lr,lg,lb = getColorRGB(array[var][1],array[var][2])
		local r = math.floor(array[var][3]/0x10000)
		local g = math.floor(array[var][3]%0x10000/0x100)
		local b = math.floor(array[var][3]%0x100)
		if math.abs(lr-r) > s or math.abs(lg-g) > s or math.abs(lb-b) > s then
			keepScreen(false)
			return false
		end
	end
	keepScreen(false)
	stomLog("Tap"..msg)
	stomtap(array[1][1]+px, array[1][2]+py)
	stommSleep(tm)
	return true
end


-- 函数:多点比色
function stomMultiColor(msg1,array1,tm)
	if type(array1) == 'table' then
		array = array1
		msg = msg1
	else
		array = msg1
		msg = array1
	end
	local s=85
	local tm = tm or 50
	s = math.floor(0xff*(100-s)*0.01)
	keepScreen(true)
	for var = 1, #array do
		local lr,lg,lb = getColorRGB(array[var][1],array[var][2])
		local r = math.floor(array[var][3]/0x10000)
		local g = math.floor(array[var][3]%0x10000/0x100)
		local b = math.floor(array[var][3]%0x100)
		if math.abs(lr-r) > s or math.abs(lg-g) > s or math.abs(lb-b) > s then
			keepScreen(false)
			return false
		end
	end
	keepScreen(false)
	stomLog(msg)
	return true
end
-- 函数:区域多点比色点击
function stomMultiColorRegTap(msg,c1,c2,s,x1,y1,x2,y2,px,py,tm)
	keepScreen(true)
	local px = px or 0
	local py = py or 0
	local tm = tm or 50
	local x,y = findMultiColorInRegionFuzzy(c1,c2,s,x1,y1,x2,y2)
	if x > 0 then
		stommSleep(50)
		stomtap(x + px ,y + py)
		stommSleep(tm)
		stomLog(x..";"..y..";Tap"..msg)
		keepScreen(false)
		return true,x,y
	else
		keepScreen(false)
		return false
	end
end

-- 函数:区域多点比色
function stomMultiColorReg(msg,c1,c2,s,x1,y1,x2,y2)
	keepScreen(true)
	local x,y = findMultiColorInRegionFuzzy(c1,c2,s,x1,y1,x2,y2)
	if x > 0 then
		stomLog(x..";"..y..";"..msg)
		keepScreen(false)
		return true,x,y
	else
		keepScreen(false)
		return false
	end
end

-- 函数:区域单点比色点击
function stomColorInRegTap(msg,c,p,x0,y0,x1,y1,tm)
	mSleep(100)
	keepScreen(true)
	local tm = tm or 50
	local x,y = findColorInRegionFuzzy(c,p,x0,y0,x1,y1);
	if x > 0 then
		stommSleep(50)
		stomtap(x,y)
		stommSleep(tm)
		--stomLog(x..";"..y..";Tap"..msg)
		keepScreen(false)
		return true,x,y
	else
		keepScreen(false)
		return false
	end
end

-- 函数:区域单点比色
function stomColorInReg(msg,c,p,x0,y0,x1,y1)
	mSleep(100)
	keepScreen(true)
	local x,y = findColorInRegionFuzzy(c,p,x0,y0,x1,y1);
	if x > 0 then
		--stomLog(x..";"..y..";"..msg)
		keepScreen(false)
		return true,x,y
	else
		keepScreen(false)
		return false
	end
end

function stomInpuTextTap(x,y,string,isnext)
	return System.inputText(x,y,string,isnext)
end

function stomInpuText(string)
	return System.inputText(string)
end

function stomsnapshotfull(pic_name)
	--System.snapShot("Documents/main.png")
	return System.snapShot(pic_name)
end
function stomsnapshot(picname, x1, y1, x2, y2, quality)
	return System.regionSnapShot(picname, x1, y1, x2, y2, quality);
end

function stomtoast(text,time)
	local str = text or ""
	local t = time or 2
	local msg = str.."@"..t
	return System.toast(text,time);
end
function stomLuDone(str)
	System.luadone(str)
end
function stomgetSlionVersion()
	--return System.execute("STask -version")
	local p = "/private/var/mobile/Library/Preferences/SLionVersion"
	if stomisFileExist(p) then
		s = stomreadFileToTbale(p)
		local ver = string.match(s[1],"%d+.%d+")
		return ver
	end
	return 1
end
function trim(s) 
  return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end
zf={
	["姓氏"]="周李王彭吕张闫岳杜戴赵马郝姚文江胡刘陈邓江毛习曹司钟任徐",
	["名字"]="香莹旭敏疏影歌涛章杰伦恩来泽东进平思丝丽颖美艳学友宝川马"..
	"照师欣新乔恩启紫修小琴青庆晴清倾箐沁进金锦华琪鱼花布珠露"..
	"明光千永兆环丰良祺珍曲书沛琪仙之竹向识益女北未自作宜冰伦"..
	"封风峰冯丰锋烽嘉游有佑悠幽攸莲涟爱琴勤钦建剑壮锦尽劲津巾"..
	"瑾矜静华桦符福赋刚余鱼于雨玉宇语羽欲预俞域御育郁渝裕於峪"
}
--stomLog(Rnd_Word(zf["姓氏"],3,3)..Rnd_Word(zf["名字"],3,3))
function GetDeviceSeed()	--根据设备ID 产生不同的值
	mSleep(100)
	local SJ = 0; for l=1,string.len(math.random(0,9)) do SJ=string.byte(math.random(0,9):sub(l,l))+SJ end
	return SJ
end
function Rnd_Word(strs,i,Szzd)
	local RetStr,Length,Seed="",1,0
	if string.byte(strs:sub(1,1))>=0x80 then
		Length = 3
	end
	--math.randomseed(tostring(os.time()):reverse():sub(1, 6) + GetDeviceSeed() + (Seed or 0))	--叠加时间参数确保任何数值不同
	math.randomseed(tonumber(tostring(os.time()):reverse():sub(1,6))) 
	math.random(string.len(strs)/Length)
	for i=1, i do
		Seed=math.random(string.len(strs)/Length)
		RetStr = RetStr..string.sub(strs,(Seed*Length)-(Length-1),(Seed*Length))
	end
	return(RetStr)
end
function Randtelnumsection2(phtype)
	rns=rns or 0  --用于精确随机种子
	rns=rns+1
	math.randomseed(tonumber(tostring(os.time()):reverse():sub(1,6)))
	mSleep(100)
	local p1 = {"13","15","18","17"}
	local p2 = {"13","15","18"}
	if phtype == 1 then
		return p2[math.random(1,#p2)]
	else
		return p1[math.random(1,#p1)]
	end
end
function myRand(rnType,rnLen,rnUL)
	--local zmRan,HexRan,myrandS,rns
	local RetStr,Length,Seed="",1,0
	rnUL=rnUL or 9
	rns = rns or 1  --用于精确随机种子
	zmRan={"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"}
	HexRan={"0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f","A","B","C","D","E","F"}
	myrandS=""
	trand = socket.gettime()*1000
	--trand = os.time()*rns
	--stomLog(trand)
	math.randomseed(tonumber(tostring((trand)*1):reverse():sub(1,6)))
	--math.randomseed(tonumber(tostring(socket.gettime()*1000):reverse():sub(1,6)))
	--math.randomseed(tostring(os.time()):reverse():sub(1, 6) + GetDeviceSeed() + (Seed or 0))
	stommSleep(100)
	rns = math.random(1,8)
	if rnType==1 then --生成数字
		myrandS=math.random(9)
		for r1=1,rnLen-1 do
			myrandS=myrandS..math.random(0,9)
		end
	elseif rnType==2 then --生成手机号,rnLen,rn11无需设置
		local mheader={"13","15"}
		myrandS=mheader[math.random(#mheader)]
		for r1=1,9 do
			myrandS=myrandS..math.random(0,9)
		end
	elseif rnType==3 then --生成字母
		for r1=1,rnLen do
			myrandS=myrandS..zmRan[math.random(52)]
		end
	elseif rnType==4 or rnType==5 then --生成数字/字母组合或邮箱
		local rn3=math.random(2,5)
		for r1=1,rn3 do
			myrandS=myrandS..zmRan[math.random(52)]
		end
		for r1=1,rnLen-rn3 do
			myrandS=myrandS..math.random(0,9)
		end
		if rnType==5 then
			local mailheader={"@qq.com","@hotmail.com","@sohu.com"} --自行增减
			myrandS=myrandS..mailheader[math.random(#mailheader)]
		end
	elseif rnType==6 then --生成16进制
		myrandS=HexRan[math.random(2,22)]
		for r1=1,rnLen-1 do
			myrandS=myrandS..HexRan[math.random(22)]
		end
	elseif rnType==7 then --生成中文
		if ZW_txt==nil then
			file_zw=io.open("/User/Media/TouchSprite/plugin/中文字库.txt","r")
			ZW_txt=file_zw:read("*all")
		end
		ZW_txt=ZW_txt or ""
		if ZW_txt=="" then return "无字库" end
		for r1=1,rnLen do
			local aaa=math.random(1,#ZW_txt/3)
			myrandS=myrandS..string.sub(ZW_txt,aaa*3+1,aaa*3+3)
		end
		return myrandS
	elseif rnType==8 then --生成16进制数字
		myrandS=HexRan[math.random(2,9)]
		for r1=1,rnLen-1 do
			myrandS=myrandS..HexRan[math.random(2,9)]
		end
	elseif rnType==9 then --生成IDFA
		local sid = stomsha1(tostring(os.time()+os.clock()))
		myrandS = string.format('%s-%s-4%s-%s-%s',
			string.sub(sid,1,8),
			string.sub(sid,9,12),
			string.sub(sid,14,16),
			string.sub(sid,17,20),
			string.sub(sid,21,32)
		)
	end

	if rnUL==1 then
		return string.upper(myrandS) --返回大写
	elseif rnUL==2 then
		return string.lower(myrandS) --返回小写
	else
		return myrandS
	end
end
function urlEncode(s)
	if s then
		s = string.gsub(s, "([^%w%.%- ])", function(c) return string.format("%%%02X", string.byte(c)) end)
		return string.gsub(s, " ", "+")
	end
	return "nil"
end

function urlDecode(s)
	s = string.gsub(s, '%%(%x%x)', function(h) return string.char(tonumber(h, 16)) end)
	return s
end

function encodeQuery(query)
	local res = ""
	for k, v in pairs(query) do
		if type(v) == "table" then
			v = json.encode(v)
		end
		res = res .. k .. "=" .. urlEncode(v) .. "&"
	end
	if res:sub(-1) == "&" then
		res = res:sub(1, -2)
	end
	return res
end

function encodeQueryUnencode(query)
	local res = ""
	for k, v in pairs(query) do
		res = res .. k .. "=" .. v .. "&"
	end
	if res:sub(-1) == "&" then
		res = res:sub(1, -2)
	end
	return res
end

function stomhttpGet(url,header_send, body_send)
	return Http.get(url,10,"")
end
function stomhttpsGet(url,timeout,header_send_table)
	return Https.get(url,timeout,header_send_table)
end
function stomhttpsPost(url,timeout,header_send_table, body_send_json)
	return Https.post(url,timeout,header_send_table, body_send_json)
end
function stomhttpsPut(url,timeout,header_send_table, body_send_json)
	return Https.put(url,timeout,header_send_table, body_send_json)
end
function postImage(url,path)
	return System.uploadImage(url,path)
end

--haoai
function myhttp(url,method,headers,post_data)
	stomLog("myhttp...")
--	headers = {
--			["Cache-Control"] = "no-cache";
--			["Content-Type"] = "application/json";
--			["Content-Length"] = #post_data;
--			["User-Agent"] = "Mozilla/5.0";
--		}
	local response = {}
	local res, code, response_headers = http.request{
		url = url,  
		method = method,  
		headers = headers,
		source = ltn12.source.string(post_data),  
		sink = ltn12.sink.table(response)  
	}
	if type(response) == "table" then
		resbody = table.concat(response)
	else
		resbody = nil
	end
	return tonumber(code), response_headers, resbody
end

