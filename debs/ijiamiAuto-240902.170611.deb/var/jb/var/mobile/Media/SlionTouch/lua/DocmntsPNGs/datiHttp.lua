
function getAnswer_HaoAi()
	local math_random = math.random
	local function get_ran_key()
		math.randomseed(os.time())
		return math.random(0,9)..math.random(0,9)..math.random(0,9)..math.random(0,9)..math.random(0,9)..math.random(0,9)..math.random(0,9)..math.random(0,9)..math.random(0,9)..math.random(0,9)
	end
	local url = ""
	function SendFile(GameID, FilePath, TimeOut)
		local MyUserStr = "zk1013|1007DD0FCBD01319|t:30"
		GameID = GameID or 5001
		TimeOut = TimeOut or 30
		http.TIMEOUT = timeout
		local files
		local file = io.open(FilePath,"rb")
		if file then
			files = file:read("*a")
			file:close()
		end
		local response_body = {}
		local get_ran_key2=get_ran_key()
		local boundary = "---------------------------7de3a916a0ab0"
		
		local datatable = {
			"--"..boundary.."\n",
			'Content-Disposition: form-data; name="userStr"\n\n',
			MyUserStr,
			"\n--"..boundary.."\n",
			'Content-Disposition: form-data; name="gameid"\n\n',
			GameID,
			"\n--"..boundary.."\n",
			'Content-Disposition: form-data; name="timeout"\n\n',
			TimeOut,
			"\n--"..boundary.."\n",
			'Content-Disposition: form-data; name="rebate"\n\n',
			"3238|737F8BC68791CEB1",
			"\n--"..boundary.."\n",
			'Content-Disposition: form-data; name="daili"\n\n',
			"Haoi",
			"\n--"..boundary.."\n",
			'Content-Disposition: form-data; name="kou"\n\n',
			"\n--"..boundary.."\n",
			'Content-Disposition: form-data; name="beizhu"\n\n',
			"\n--"..boundary.."\n",
			'Content-Disposition: form-data; name="ver"\n\n',
			"Web2",
			"\n--"..boundary.."\n",
			'Content-Disposition: form-data; name="key"\n\n',
			get_ran_key2,
			"\n--"..boundary.."\n",
			'Content-Disposition: form-data; name="img"; filename="post.png"\n',
			'Content-Type: image/png\n\n',
			files,
			"\n--"..boundary.."--"
		}
		local data = table.concat(datatable)
		url,post_ = getHaoiHost()
		local headers = {
			["Accept"]= "*/*",
			["Accept-Language"] = "zh-cn",
			["Content-Type"] = "multipart/form-data; boundary=---------------------------7de3a916a0ab0",
			["Host"] = post_ ,
			["Content-Length"] = #data,
			["Accept-Encoding"] = "gzip, deflate",
			["User-Agent"] = "ben",
			["Connection"] = "Keep-Alive",
			["Expect"] = "100-continue"
		}
		
		local rep , code = http.request{
			url = "http://"..url.."/UploadAPI.aspx",
			method = "POST",
			headers = headers  ,
			source = ltn12.source.string(data),
			sink = ltn12.sink.table(response_body),
		}
		if type(response_body) == "table" then
			res = table.concat(response_body)
			stomLog(res)
			return res
		else
			stomLog("sendfile nil")
			return nil
		end
		
	end
	
	function GetAnswer (TID)
		local str = TID
		local str_ = "id="..str.."&r="..get_ran_key()
		local response_body = {}
		local headers = {
			["Accept"]= "*/*",
			["Accept-Language"] = "zh-cn",
			["Content-Type"] = "application/x-www-form-urlencoded",
			["Host"] = post_ ,
			["Content-Length"] = #str_,
			["Accept-Encoding"] = "gzip, deflate",
			["User-Agent"] = "ben",
			["Connection"] = "Keep-Alive",
		}
		
		local rep , code = http.request{
			url = "http://"..url.."/getanswer.aspx",
			method = "POST",
			headers = headers  ,
			source = ltn12.source.string(str_),
			
			sink = ltn12.sink.table(response_body),
		}
		if type(response_body) == "table" then
			res = table.concat(response_body)
			return res
		else
			stomLog("getans nil")
			return nil
		end
	end
	
	function getHaoiHost()
		-- 获取好爱Host
		local useUrl
		fwqurl = {
			'http://1.haoi23.net/svlist.html',
			'http://2.haoi23.net/svlist.html',
			'http://3.haoi23.net/svlist.html',
			'http://4.haoi23.net/svlist.html',
			'http://0.haoi23.net/svlist.html'
		}
		local s=math.random(1,2)
		for i=1,5 do
			local res, code = http.request(fwqurl[s])
			stomLog(""..code)
			if code == 200 then
				s=s+1
				local b = string.find(res,":")
				url = string.sub(res,4,b+4)
				post_ =  string.sub(res,4,b-1)
				h="haoi23"
				j=url,post_;
				stomLog("服务器"..j)
				if string.find(j,h) ~= 0 then   --获取成功
					stomLog("获取到服务器地址")
					break
				else
					url = 'sv13.haoi23.net:8009'
					post_ = 'sv13.haoi23.net'
				end
			end
		end
		if code ~= 200 then   --获取失败
			url = 'sv13.haoi23.net:8009'
			post_ = 'sv13.haoi23.net'
		end
		return url,post_;
	end
end

function sendPIC_HaoAi(picPath,tmtype,tmtimeout)
	local aa = math.random(1,18409)
	getAnswer_HaoAi()
	TID = 1
	local sctp=1
	local answer = {}
	while true do
		TID = SendFile(tmtype, picPath, tmtimeout)
		if type(TID) == "string" then
			sctp = 0
			break
		else
			stommSleep(500)
			sctp=sctp+1
			stomLog("继续上传图片")
		end
		if sctp > 5 then
			return answer
		end
	end
	while true do
		local res = GetAnswer(TID)--这个变量就是答案
		if res then
			stomLog('结果是:')
			stomLog(res)
			local reslen = string.len(res)
			if reslen > 0 then
				if string.find(res,"#") then
				else
					answer = stomsplit(res,",")
					return answer
				end
			else
				stommSleep(2000)
			end
		end
		stomLog('结果nil:')
		sctp=sctp+1
		if sctp > 5 then
			return answer
		end
		stommSleep(2000)
	end
end
